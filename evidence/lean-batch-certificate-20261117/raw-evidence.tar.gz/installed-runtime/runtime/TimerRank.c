// Lean compiler output
// Module: TimerRank
// Imports: public import Init public meta import Init public import TypedMachine
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_int_dec_le(lean_object*, lean_object*);
uint8_t l_List_all___redArg(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* l_Int_toNat(lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TimerRank_instDecidableWellTimed___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_instDecidableWellTimed___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TimerRank_instDecidableWellTimed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_instDecidableWellTimed___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_dueCount(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TimerRank_instDecidableWellTimed___lam__0(lean_object* v_now_1_, lean_object* v_entry_2_){
_start:
{
lean_object* v_due_3_; uint8_t v___x_4_; 
v_due_3_ = lean_ctor_get(v_entry_2_, 1);
v___x_4_ = lean_int_dec_le(v_now_1_, v_due_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_instDecidableWellTimed___lam__0___boxed(lean_object* v_now_5_, lean_object* v_entry_6_){
_start:
{
uint8_t v_res_7_; lean_object* v_r_8_; 
v_res_7_ = l_FormalSpecAgent_TimerRank_instDecidableWellTimed___lam__0(v_now_5_, v_entry_6_);
lean_dec_ref(v_entry_6_);
lean_dec(v_now_5_);
v_r_8_ = lean_box(v_res_7_);
return v_r_8_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TimerRank_instDecidableWellTimed(lean_object* v_s_9_){
_start:
{
lean_object* v_now_10_; lean_object* v_timers_11_; lean_object* v___f_12_; uint8_t v___x_13_; 
v_now_10_ = lean_ctor_get(v_s_9_, 2);
lean_inc(v_now_10_);
v_timers_11_ = lean_ctor_get(v_s_9_, 3);
lean_inc(v_timers_11_);
lean_dec_ref(v_s_9_);
v___f_12_ = lean_alloc_closure((void*)(l_FormalSpecAgent_TimerRank_instDecidableWellTimed___lam__0___boxed), 2, 1);
lean_closure_set(v___f_12_, 0, v_now_10_);
v___x_13_ = l_List_all___redArg(v_timers_11_, v___f_12_);
return v___x_13_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_instDecidableWellTimed___boxed(lean_object* v_s_14_){
_start:
{
uint8_t v_res_15_; lean_object* v_r_16_; 
v_res_15_ = l_FormalSpecAgent_TimerRank_instDecidableWellTimed(v_s_14_);
v_r_16_ = lean_box(v_res_15_);
return v_r_16_;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(lean_object* v_s_17_, lean_object* v_a_18_, lean_object* v_a_19_){
_start:
{
if (lean_obj_tag(v_a_18_) == 0)
{
lean_object* v___x_20_; 
v___x_20_ = l_List_reverse___redArg(v_a_19_);
return v___x_20_;
}
else
{
lean_object* v_head_21_; lean_object* v_tail_22_; lean_object* v___x_24_; uint8_t v_isShared_25_; uint8_t v_isSharedCheck_34_; 
v_head_21_ = lean_ctor_get(v_a_18_, 0);
v_tail_22_ = lean_ctor_get(v_a_18_, 1);
v_isSharedCheck_34_ = !lean_is_exclusive(v_a_18_);
if (v_isSharedCheck_34_ == 0)
{
v___x_24_ = v_a_18_;
v_isShared_25_ = v_isSharedCheck_34_;
goto v_resetjp_23_;
}
else
{
lean_inc(v_tail_22_);
lean_inc(v_head_21_);
lean_dec(v_a_18_);
v___x_24_ = lean_box(0);
v_isShared_25_ = v_isSharedCheck_34_;
goto v_resetjp_23_;
}
v_resetjp_23_:
{
lean_object* v_due_26_; lean_object* v_now_27_; uint8_t v___x_28_; 
v_due_26_ = lean_ctor_get(v_head_21_, 1);
v_now_27_ = lean_ctor_get(v_s_17_, 2);
v___x_28_ = lean_int_dec_le(v_due_26_, v_now_27_);
if (v___x_28_ == 0)
{
lean_del_object(v___x_24_);
lean_dec(v_head_21_);
v_a_18_ = v_tail_22_;
goto _start;
}
else
{
lean_object* v___x_31_; 
if (v_isShared_25_ == 0)
{
lean_ctor_set(v___x_24_, 1, v_a_19_);
v___x_31_ = v___x_24_;
goto v_reusejp_30_;
}
else
{
lean_object* v_reuseFailAlloc_33_; 
v_reuseFailAlloc_33_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_33_, 0, v_head_21_);
lean_ctor_set(v_reuseFailAlloc_33_, 1, v_a_19_);
v___x_31_ = v_reuseFailAlloc_33_;
goto v_reusejp_30_;
}
v_reusejp_30_:
{
v_a_18_ = v_tail_22_;
v_a_19_ = v___x_31_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0___boxed(lean_object* v_s_35_, lean_object* v_a_36_, lean_object* v_a_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(v_s_35_, v_a_36_, v_a_37_);
lean_dec_ref(v_s_35_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_dueCount(lean_object* v_s_39_){
_start:
{
lean_object* v_timers_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; 
v_timers_40_ = lean_ctor_get(v_s_39_, 3);
lean_inc(v_timers_40_);
v___x_41_ = lean_box(0);
v___x_42_ = l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(v_s_39_, v_timers_40_, v___x_41_);
lean_dec_ref(v_s_39_);
v___x_43_ = l_List_lengthTR___redArg(v___x_42_);
lean_dec(v___x_42_);
return v___x_43_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank(lean_object* v_limit_44_, lean_object* v_s_45_){
_start:
{
lean_object* v_now_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; 
v_now_46_ = lean_ctor_get(v_s_45_, 2);
v___x_47_ = lean_int_sub(v_limit_44_, v_now_46_);
v___x_48_ = l_Int_toNat(v___x_47_);
lean_dec(v___x_47_);
v___x_49_ = l_FormalSpecAgent_TimerRank_dueCount(v_s_45_);
v___x_50_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_50_, 0, v___x_48_);
lean_ctor_set(v___x_50_, 1, v___x_49_);
return v___x_50_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank___boxed(lean_object* v_limit_51_, lean_object* v_s_52_){
_start:
{
lean_object* v_res_53_; 
v_res_53_ = l_FormalSpecAgent_TimerRank_rank(v_limit_51_, v_s_52_);
lean_dec(v_limit_51_);
return v_res_53_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TypedMachine(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_TimerRank(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TypedMachine(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
