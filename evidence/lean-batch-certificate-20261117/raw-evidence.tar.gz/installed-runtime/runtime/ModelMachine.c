// Lean compiler output
// Module: ModelMachine
// Imports: public import Init public meta import Init public import BatchObserve
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_string_mk(lean_object*);
lean_object* lean_int_neg(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
static lean_once_cell_t l_MachineRuntime_e0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e0___closed__0;
static lean_once_cell_t l_MachineRuntime_e0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e0___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e0;
static const lean_ctor_object l_MachineRuntime_e1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e1___closed__0 = (const lean_object*)&l_MachineRuntime_e1___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e1 = (const lean_object*)&l_MachineRuntime_e1___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e2___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e2;
static const lean_ctor_object l_MachineRuntime_e3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e3___closed__0 = (const lean_object*)&l_MachineRuntime_e3___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e3 = (const lean_object*)&l_MachineRuntime_e3___closed__0_value;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__0___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__1___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__2___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__2;
static lean_once_cell_t l_MachineRuntime_e4___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__3;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__4___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__4;
static lean_once_cell_t l_MachineRuntime_e4___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__5;
static lean_once_cell_t l_MachineRuntime_e4___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__6;
LEAN_EXPORT lean_object* l_MachineRuntime_e4;
static const lean_ctor_object l_MachineRuntime_e5___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e5___closed__0 = (const lean_object*)&l_MachineRuntime_e5___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e5 = (const lean_object*)&l_MachineRuntime_e5___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e6___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e6___closed__0 = (const lean_object*)&l_MachineRuntime_e6___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e6 = (const lean_object*)&l_MachineRuntime_e6___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e7___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e7___closed__0;
static lean_once_cell_t l_MachineRuntime_e7___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e7___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e7;
static const lean_ctor_object l_MachineRuntime_e8___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e8___closed__0 = (const lean_object*)&l_MachineRuntime_e8___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e8 = (const lean_object*)&l_MachineRuntime_e8___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e9___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e9___closed__0;
static lean_once_cell_t l_MachineRuntime_e9___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e9___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e9;
static lean_once_cell_t l_MachineRuntime_e10___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e10___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e10;
static const lean_ctor_object l_MachineRuntime_e11___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e11___closed__0 = (const lean_object*)&l_MachineRuntime_e11___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e11 = (const lean_object*)&l_MachineRuntime_e11___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e12___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e12___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e12;
LEAN_EXPORT lean_object* l_MachineRuntime_e13___closed__0___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e13___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e13___closed__1___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e13___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e13___closed__2___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e13___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__2;
static lean_once_cell_t l_MachineRuntime_e13___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__3;
static lean_once_cell_t l_MachineRuntime_e13___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__4;
LEAN_EXPORT lean_object* l_MachineRuntime_e13;
static const lean_ctor_object l_MachineRuntime_e14___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e14___closed__0 = (const lean_object*)&l_MachineRuntime_e14___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e14 = (const lean_object*)&l_MachineRuntime_e14___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e15___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e15___closed__0 = (const lean_object*)&l_MachineRuntime_e15___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e15 = (const lean_object*)&l_MachineRuntime_e15___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e16___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e16___closed__0 = (const lean_object*)&l_MachineRuntime_e16___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e16 = (const lean_object*)&l_MachineRuntime_e16___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e17___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_e17___closed__0 = (const lean_object*)&l_MachineRuntime_e17___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e17 = (const lean_object*)&l_MachineRuntime_e17___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e18___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 4}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_e18___closed__0 = (const lean_object*)&l_MachineRuntime_e18___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e18 = (const lean_object*)&l_MachineRuntime_e18___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e19___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 4}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_MachineRuntime_e19___closed__0 = (const lean_object*)&l_MachineRuntime_e19___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e19 = (const lean_object*)&l_MachineRuntime_e19___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e20___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e20___closed__0;
static lean_once_cell_t l_MachineRuntime_e20___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e20___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e20;
static lean_once_cell_t l_MachineRuntime_e21___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e21___closed__0;
static lean_once_cell_t l_MachineRuntime_e21___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e21___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e21;
static const lean_ctor_object l_MachineRuntime_e22___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e22___closed__0 = (const lean_object*)&l_MachineRuntime_e22___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e22 = (const lean_object*)&l_MachineRuntime_e22___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e23___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e23___closed__0;
static lean_once_cell_t l_MachineRuntime_e23___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e23___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e23;
static const lean_ctor_object l_MachineRuntime_e24___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e24___closed__0 = (const lean_object*)&l_MachineRuntime_e24___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e24 = (const lean_object*)&l_MachineRuntime_e24___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e25___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 10}, .m_objs = {((lean_object*)&l_MachineRuntime_e24___closed__0_value)}};
static const lean_object* l_MachineRuntime_e25___closed__0 = (const lean_object*)&l_MachineRuntime_e25___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e25 = (const lean_object*)&l_MachineRuntime_e25___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e26___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 8}, .m_objs = {((lean_object*)&l_MachineRuntime_e19___closed__0_value),((lean_object*)&l_MachineRuntime_e25___closed__0_value)}};
static const lean_object* l_MachineRuntime_e26___closed__0 = (const lean_object*)&l_MachineRuntime_e26___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e26 = (const lean_object*)&l_MachineRuntime_e26___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e27___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e27___closed__0;
static lean_once_cell_t l_MachineRuntime_e27___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e27___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e27;
static lean_once_cell_t l_MachineRuntime_e28___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e28___closed__0;
static lean_once_cell_t l_MachineRuntime_e28___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e28___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e28;
static const lean_ctor_object l_MachineRuntime_e29___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 8}, .m_objs = {((lean_object*)&l_MachineRuntime_e19___closed__0_value),((lean_object*)&l_MachineRuntime_e24___closed__0_value)}};
static const lean_object* l_MachineRuntime_e29___closed__0 = (const lean_object*)&l_MachineRuntime_e29___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e29 = (const lean_object*)&l_MachineRuntime_e29___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e30___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e30___closed__0;
static lean_once_cell_t l_MachineRuntime_e30___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e30___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e30;
static const lean_ctor_object l_MachineRuntime_e31___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e31___closed__0 = (const lean_object*)&l_MachineRuntime_e31___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e31 = (const lean_object*)&l_MachineRuntime_e31___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e32___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_e32___closed__0 = (const lean_object*)&l_MachineRuntime_e32___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e32___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(255) << 1) | 1)),((lean_object*)&l_MachineRuntime_e32___closed__0_value)}};
static const lean_object* l_MachineRuntime_e32___closed__1 = (const lean_object*)&l_MachineRuntime_e32___closed__1_value;
static const lean_ctor_object l_MachineRuntime_e32___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(128) << 1) | 1)),((lean_object*)&l_MachineRuntime_e32___closed__1_value)}};
static const lean_object* l_MachineRuntime_e32___closed__2 = (const lean_object*)&l_MachineRuntime_e32___closed__2_value;
static const lean_ctor_object l_MachineRuntime_e32___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_e32___closed__2_value)}};
static const lean_object* l_MachineRuntime_e32___closed__3 = (const lean_object*)&l_MachineRuntime_e32___closed__3_value;
static const lean_ctor_object l_MachineRuntime_e32___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&l_MachineRuntime_e32___closed__3_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e32___closed__4 = (const lean_object*)&l_MachineRuntime_e32___closed__4_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e32 = (const lean_object*)&l_MachineRuntime_e32___closed__4_value;
static lean_once_cell_t l_MachineRuntime_e33___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e33___closed__0;
static lean_once_cell_t l_MachineRuntime_e33___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e33___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e33;
static lean_once_cell_t l_MachineRuntime_e34___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e34___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e34;
static lean_once_cell_t l_MachineRuntime_e35___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e35___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e35;
static lean_once_cell_t l_MachineRuntime_e36___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e36___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e36;
static const lean_ctor_object l_MachineRuntime_e37___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 23}, .m_objs = {((lean_object*)&l_MachineRuntime_e15___closed__0_value)}};
static const lean_object* l_MachineRuntime_e37___closed__0 = (const lean_object*)&l_MachineRuntime_e37___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e37 = (const lean_object*)&l_MachineRuntime_e37___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e38___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e38___closed__0;
static lean_once_cell_t l_MachineRuntime_e38___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e38___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e38;
static lean_once_cell_t l_MachineRuntime_e39___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e39___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e39;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_e6___closed__0_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__0 = (const lean_object*)&l_MachineRuntime_rule__0___closed__0_value;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__1;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__2;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__3 = (const lean_object*)&l_MachineRuntime_rule__0___closed__3_value;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__5;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_e8___closed__0_value),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__6 = (const lean_object*)&l_MachineRuntime_rule__0___closed__6_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_e14___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__7 = (const lean_object*)&l_MachineRuntime_rule__0___closed__7_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_MachineRuntime_e11___closed__0_value),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__8 = (const lean_object*)&l_MachineRuntime_rule__0___closed__8_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_e15___closed__0_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__9 = (const lean_object*)&l_MachineRuntime_rule__0___closed__9_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e16___closed__0_value),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__10 = (const lean_object*)&l_MachineRuntime_rule__0___closed__10_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)&l_MachineRuntime_e17___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__11 = (const lean_object*)&l_MachineRuntime_rule__0___closed__11_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(6) << 1) | 1)),((lean_object*)&l_MachineRuntime_e18___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__12 = (const lean_object*)&l_MachineRuntime_rule__0___closed__12_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)&l_MachineRuntime_e19___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__13 = (const lean_object*)&l_MachineRuntime_rule__0___closed__13_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__13_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__0___closed__14 = (const lean_object*)&l_MachineRuntime_rule__0___closed__14_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__12_value),((lean_object*)&l_MachineRuntime_rule__0___closed__14_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__15 = (const lean_object*)&l_MachineRuntime_rule__0___closed__15_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__11_value),((lean_object*)&l_MachineRuntime_rule__0___closed__15_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__16 = (const lean_object*)&l_MachineRuntime_rule__0___closed__16_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__10_value),((lean_object*)&l_MachineRuntime_rule__0___closed__16_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__17 = (const lean_object*)&l_MachineRuntime_rule__0___closed__17_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__9_value),((lean_object*)&l_MachineRuntime_rule__0___closed__17_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__18 = (const lean_object*)&l_MachineRuntime_rule__0___closed__18_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__8_value),((lean_object*)&l_MachineRuntime_rule__0___closed__18_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__19 = (const lean_object*)&l_MachineRuntime_rule__0___closed__19_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__7_value),((lean_object*)&l_MachineRuntime_rule__0___closed__19_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__20 = (const lean_object*)&l_MachineRuntime_rule__0___closed__20_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__6_value),((lean_object*)&l_MachineRuntime_rule__0___closed__20_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__21 = (const lean_object*)&l_MachineRuntime_rule__0___closed__21_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_rule__0___closed__21_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__22 = (const lean_object*)&l_MachineRuntime_rule__0___closed__22_value;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__23_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__23;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__24_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__24;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__25;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__26;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__27_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__27;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__28;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__29;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__30;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__31;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__32_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__32;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__33_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__33;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__34_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__34;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__0;
static lean_once_cell_t l_MachineRuntime_rule__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__1___closed__0;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_e22___closed__0_value)}};
static const lean_object* l_MachineRuntime_rule__1___closed__1 = (const lean_object*)&l_MachineRuntime_rule__1___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__1___closed__1_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__1___closed__2 = (const lean_object*)&l_MachineRuntime_rule__1___closed__2_value;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__22_value),((lean_object*)&l_MachineRuntime_rule__1___closed__2_value)}};
static const lean_object* l_MachineRuntime_rule__1___closed__3 = (const lean_object*)&l_MachineRuntime_rule__1___closed__3_value;
static lean_once_cell_t l_MachineRuntime_rule__1___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__1___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__1___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__1___closed__5;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__1;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__0;
static const lean_ctor_object l_MachineRuntime_rule__2___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__22_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__2___closed__1 = (const lean_object*)&l_MachineRuntime_rule__2___closed__1_value;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__2;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__3;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__4;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__2;
static lean_once_cell_t l_MachineRuntime_rule__3___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__3___closed__0;
static lean_once_cell_t l_MachineRuntime_rule__3___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__3___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__3;
static const lean_ctor_object l_MachineRuntime_rule__4___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__4___closed__0 = (const lean_object*)&l_MachineRuntime_rule__4___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__4___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__4___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__4___closed__1 = (const lean_object*)&l_MachineRuntime_rule__4___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__4___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__22_value),((lean_object*)&l_MachineRuntime_rule__4___closed__1_value)}};
static const lean_object* l_MachineRuntime_rule__4___closed__2 = (const lean_object*)&l_MachineRuntime_rule__4___closed__2_value;
static lean_once_cell_t l_MachineRuntime_rule__4___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__4___closed__3;
static lean_once_cell_t l_MachineRuntime_rule__4___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__4___closed__4;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__4;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__0;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__1;
static const lean_ctor_object l_MachineRuntime_rule__5___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__5___closed__2 = (const lean_object*)&l_MachineRuntime_rule__5___closed__2_value;
static const lean_ctor_object l_MachineRuntime_rule__5___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__5___closed__2_value),((lean_object*)&l_MachineRuntime_rule__2___closed__1_value)}};
static const lean_object* l_MachineRuntime_rule__5___closed__3 = (const lean_object*)&l_MachineRuntime_rule__5___closed__3_value;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__5;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__6;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__5;
static const lean_ctor_object l_MachineRuntime_rule__6___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*6 + 0, .m_other = 6, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(6) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__6___closed__0 = (const lean_object*)&l_MachineRuntime_rule__6___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_rule__6 = (const lean_object*)&l_MachineRuntime_rule__6___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__7___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*6 + 0, .m_other = 6, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__7___closed__0 = (const lean_object*)&l_MachineRuntime_rule__7___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_rule__7 = (const lean_object*)&l_MachineRuntime_rule__7___closed__0_value;
static lean_once_cell_t l_MachineRuntime_rule__8___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__8___closed__0;
static lean_once_cell_t l_MachineRuntime_rule__8___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__8___closed__1;
static lean_once_cell_t l_MachineRuntime_rule__8___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__8___closed__2;
static lean_once_cell_t l_MachineRuntime_rule__8___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__8___closed__3;
static lean_once_cell_t l_MachineRuntime_rule__8___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__8___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__8___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__8___closed__5;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__8;
static const lean_ctor_object l_MachineRuntime_rule__9___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__9___closed__0 = (const lean_object*)&l_MachineRuntime_rule__9___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__9___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__9___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__9___closed__1 = (const lean_object*)&l_MachineRuntime_rule__9___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__9___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*6 + 0, .m_other = 6, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(9) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(9) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),((lean_object*)&l_MachineRuntime_rule__9___closed__1_value)}};
static const lean_object* l_MachineRuntime_rule__9___closed__2 = (const lean_object*)&l_MachineRuntime_rule__9___closed__2_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_rule__9 = (const lean_object*)&l_MachineRuntime_rule__9___closed__2_value;
static const lean_ctor_object l_MachineRuntime_rule__10___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)&l_MachineRuntime_e1___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__10___closed__0 = (const lean_object*)&l_MachineRuntime_rule__10___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__10___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__10___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__10___closed__1 = (const lean_object*)&l_MachineRuntime_rule__10___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__10___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*6 + 0, .m_other = 6, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(10) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(10) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),((lean_object*)&l_MachineRuntime_rule__10___closed__1_value)}};
static const lean_object* l_MachineRuntime_rule__10___closed__2 = (const lean_object*)&l_MachineRuntime_rule__10___closed__2_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_rule__10 = (const lean_object*)&l_MachineRuntime_rule__10___closed__2_value;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__0;
static const lean_ctor_object l_MachineRuntime_rule__11___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_MachineRuntime_e31___closed__0_value),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__11___closed__1 = (const lean_object*)&l_MachineRuntime_rule__11___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__11___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_e32___closed__4_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__11___closed__2 = (const lean_object*)&l_MachineRuntime_rule__11___closed__2_value;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__3;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__5;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__6;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__7;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__8;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__9;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__10;
static lean_once_cell_t l_MachineRuntime_rule__11___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__11___closed__11;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__11;
static lean_once_cell_t l_MachineRuntime_rule__12___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__12___closed__0;
static lean_once_cell_t l_MachineRuntime_rule__12___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__12___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__12;
static lean_once_cell_t l_MachineRuntime_rule__13___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__13___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__13;
static const lean_ctor_object l_MachineRuntime_schema___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__0 = (const lean_object*)&l_MachineRuntime_schema___closed__0_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__1 = (const lean_object*)&l_MachineRuntime_schema___closed__1_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__2 = (const lean_object*)&l_MachineRuntime_schema___closed__2_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(3) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__3 = (const lean_object*)&l_MachineRuntime_schema___closed__3_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__4 = (const lean_object*)&l_MachineRuntime_schema___closed__4_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(5) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__5 = (const lean_object*)&l_MachineRuntime_schema___closed__5_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__5_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__6 = (const lean_object*)&l_MachineRuntime_schema___closed__6_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__4_value),((lean_object*)&l_MachineRuntime_schema___closed__6_value)}};
static const lean_object* l_MachineRuntime_schema___closed__7 = (const lean_object*)&l_MachineRuntime_schema___closed__7_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__3_value),((lean_object*)&l_MachineRuntime_schema___closed__7_value)}};
static const lean_object* l_MachineRuntime_schema___closed__8 = (const lean_object*)&l_MachineRuntime_schema___closed__8_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__2_value),((lean_object*)&l_MachineRuntime_schema___closed__8_value)}};
static const lean_object* l_MachineRuntime_schema___closed__9 = (const lean_object*)&l_MachineRuntime_schema___closed__9_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__1_value),((lean_object*)&l_MachineRuntime_schema___closed__9_value)}};
static const lean_object* l_MachineRuntime_schema___closed__10 = (const lean_object*)&l_MachineRuntime_schema___closed__10_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__0_value),((lean_object*)&l_MachineRuntime_schema___closed__10_value)}};
static const lean_object* l_MachineRuntime_schema___closed__11 = (const lean_object*)&l_MachineRuntime_schema___closed__11_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_schema = (const lean_object*)&l_MachineRuntime_schema___closed__11_value;
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0___boxed(lean_object*);
static const lean_closure_object l_MachineRuntime_model___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_MachineRuntime_model___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_MachineRuntime_model___closed__0 = (const lean_object*)&l_MachineRuntime_model___closed__0_value;
static lean_once_cell_t l_MachineRuntime_model___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__1;
static lean_once_cell_t l_MachineRuntime_model___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__2;
static lean_once_cell_t l_MachineRuntime_model___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__3;
static lean_once_cell_t l_MachineRuntime_model___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__4;
static lean_once_cell_t l_MachineRuntime_model___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__5;
static lean_once_cell_t l_MachineRuntime_model___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__6;
static lean_once_cell_t l_MachineRuntime_model___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__7;
static lean_once_cell_t l_MachineRuntime_model___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__8;
static lean_once_cell_t l_MachineRuntime_model___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__9;
static lean_once_cell_t l_MachineRuntime_model___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__10;
static lean_once_cell_t l_MachineRuntime_model___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__11;
static lean_once_cell_t l_MachineRuntime_model___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__12;
static lean_once_cell_t l_MachineRuntime_model___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__13;
static lean_once_cell_t l_MachineRuntime_model___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__14;
static lean_once_cell_t l_MachineRuntime_model___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__15;
static lean_once_cell_t l_MachineRuntime_model___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__16;
static const lean_ctor_object l_MachineRuntime_model___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(10) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_model___closed__17 = (const lean_object*)&l_MachineRuntime_model___closed__17_value;
static const lean_ctor_object l_MachineRuntime_model___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(9) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__17_value)}};
static const lean_object* l_MachineRuntime_model___closed__18 = (const lean_object*)&l_MachineRuntime_model___closed__18_value;
static const lean_ctor_object l_MachineRuntime_model___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(8) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__18_value)}};
static const lean_object* l_MachineRuntime_model___closed__19 = (const lean_object*)&l_MachineRuntime_model___closed__19_value;
static const lean_ctor_object l_MachineRuntime_model___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__19_value)}};
static const lean_object* l_MachineRuntime_model___closed__20 = (const lean_object*)&l_MachineRuntime_model___closed__20_value;
static const lean_ctor_object l_MachineRuntime_model___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__20_value)}};
static const lean_object* l_MachineRuntime_model___closed__21 = (const lean_object*)&l_MachineRuntime_model___closed__21_value;
static const lean_ctor_object l_MachineRuntime_model___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__21_value)}};
static const lean_object* l_MachineRuntime_model___closed__22 = (const lean_object*)&l_MachineRuntime_model___closed__22_value;
static const lean_ctor_object l_MachineRuntime_model___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__22_value)}};
static const lean_object* l_MachineRuntime_model___closed__23 = (const lean_object*)&l_MachineRuntime_model___closed__23_value;
static const lean_ctor_object l_MachineRuntime_model___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__23_value)}};
static const lean_object* l_MachineRuntime_model___closed__24 = (const lean_object*)&l_MachineRuntime_model___closed__24_value;
static const lean_ctor_object l_MachineRuntime_model___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__24_value)}};
static const lean_object* l_MachineRuntime_model___closed__25 = (const lean_object*)&l_MachineRuntime_model___closed__25_value;
static lean_once_cell_t l_MachineRuntime_model___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__26;
LEAN_EXPORT lean_object* l_MachineRuntime_model;
static const lean_ctor_object l_MachineRuntime_eventSchemas___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_eventSchemas___closed__0 = (const lean_object*)&l_MachineRuntime_eventSchemas___closed__0_value;
static const lean_ctor_object l_MachineRuntime_eventSchemas___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_eventSchemas___closed__1 = (const lean_object*)&l_MachineRuntime_eventSchemas___closed__1_value;
static const lean_ctor_object l_MachineRuntime_eventSchemas___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_eventSchemas___closed__1_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_eventSchemas___closed__2 = (const lean_object*)&l_MachineRuntime_eventSchemas___closed__2_value;
LEAN_EXPORT lean_object* l_MachineRuntime_eventSchemas(lean_object*);
LEAN_EXPORT lean_object* l_MachineRuntime_eventSchemas___boxed(lean_object*);
static lean_object* _init_l_MachineRuntime_e0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_l_MachineRuntime_e0___closed__1(void){
_start:
{
lean_object* v___x_3_; uint8_t v___x_4_; lean_object* v___x_5_; 
v___x_3_ = lean_obj_once(&l_MachineRuntime_e0___closed__0, &l_MachineRuntime_e0___closed__0_once, _init_l_MachineRuntime_e0___closed__0);
v___x_4_ = 0;
v___x_5_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5_, 0, v___x_3_);
lean_ctor_set_uint8(v___x_5_, sizeof(void*)*1, v___x_4_);
return v___x_5_;
}
}
static lean_object* _init_l_MachineRuntime_e0(void){
_start:
{
lean_object* v___x_6_; 
v___x_6_ = lean_obj_once(&l_MachineRuntime_e0___closed__1, &l_MachineRuntime_e0___closed__1_once, _init_l_MachineRuntime_e0___closed__1);
return v___x_6_;
}
}
static lean_object* _init_l_MachineRuntime_e2___closed__0(void){
_start:
{
lean_object* v___x_12_; uint8_t v___x_13_; lean_object* v___x_14_; 
v___x_12_ = lean_unsigned_to_nat(4294967295u);
v___x_13_ = 4;
v___x_14_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_14_, 0, v___x_12_);
lean_ctor_set_uint8(v___x_14_, sizeof(void*)*1, v___x_13_);
return v___x_14_;
}
}
static lean_object* _init_l_MachineRuntime_e2(void){
_start:
{
lean_object* v___x_15_; 
v___x_15_ = lean_obj_once(&l_MachineRuntime_e2___closed__0, &l_MachineRuntime_e2___closed__0_once, _init_l_MachineRuntime_e2___closed__0);
return v___x_15_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_20_; lean_object* v___x_21_; 
v___x_20_ = 116;
v___x_21_ = lean_box_uint32(v___x_20_);
return v___x_21_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__0(void){
_start:
{
lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; 
v___x_22_ = lean_box(0);
v___x_23_ = l_MachineRuntime_e4___closed__0___boxed__const__1;
v___x_24_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_24_, 0, v___x_23_);
lean_ctor_set(v___x_24_, 1, v___x_22_);
return v___x_24_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_25_; lean_object* v___x_26_; 
v___x_25_ = 114;
v___x_26_ = lean_box_uint32(v___x_25_);
return v___x_26_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__1(void){
_start:
{
lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; 
v___x_27_ = lean_obj_once(&l_MachineRuntime_e4___closed__0, &l_MachineRuntime_e4___closed__0_once, _init_l_MachineRuntime_e4___closed__0);
v___x_28_ = l_MachineRuntime_e4___closed__1___boxed__const__1;
v___x_29_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_29_, 0, v___x_28_);
lean_ctor_set(v___x_29_, 1, v___x_27_);
return v___x_29_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_30_; lean_object* v___x_31_; 
v___x_30_ = 97;
v___x_31_ = lean_box_uint32(v___x_30_);
return v___x_31_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__2(void){
_start:
{
lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; 
v___x_32_ = lean_obj_once(&l_MachineRuntime_e4___closed__1, &l_MachineRuntime_e4___closed__1_once, _init_l_MachineRuntime_e4___closed__1);
v___x_33_ = l_MachineRuntime_e4___closed__2___boxed__const__1;
v___x_34_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_34_, 0, v___x_33_);
lean_ctor_set(v___x_34_, 1, v___x_32_);
return v___x_34_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__3(void){
_start:
{
lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; 
v___x_35_ = lean_obj_once(&l_MachineRuntime_e4___closed__2, &l_MachineRuntime_e4___closed__2_once, _init_l_MachineRuntime_e4___closed__2);
v___x_36_ = l_MachineRuntime_e4___closed__0___boxed__const__1;
v___x_37_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_37_, 0, v___x_36_);
lean_ctor_set(v___x_37_, 1, v___x_35_);
return v___x_37_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__4___boxed__const__1(void){
_start:
{
uint32_t v___x_38_; lean_object* v___x_39_; 
v___x_38_ = 115;
v___x_39_ = lean_box_uint32(v___x_38_);
return v___x_39_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__4(void){
_start:
{
lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_40_ = lean_obj_once(&l_MachineRuntime_e4___closed__3, &l_MachineRuntime_e4___closed__3_once, _init_l_MachineRuntime_e4___closed__3);
v___x_41_ = l_MachineRuntime_e4___closed__4___boxed__const__1;
v___x_42_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_42_, 0, v___x_41_);
lean_ctor_set(v___x_42_, 1, v___x_40_);
return v___x_42_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__5(void){
_start:
{
lean_object* v___x_43_; lean_object* v___x_44_; 
v___x_43_ = lean_obj_once(&l_MachineRuntime_e4___closed__4, &l_MachineRuntime_e4___closed__4_once, _init_l_MachineRuntime_e4___closed__4);
v___x_44_ = lean_string_mk(v___x_43_);
return v___x_44_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__6(void){
_start:
{
lean_object* v___x_45_; uint8_t v___x_46_; lean_object* v___x_47_; 
v___x_45_ = lean_obj_once(&l_MachineRuntime_e4___closed__5, &l_MachineRuntime_e4___closed__5_once, _init_l_MachineRuntime_e4___closed__5);
v___x_46_ = 2;
v___x_47_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_47_, 0, v___x_45_);
lean_ctor_set_uint8(v___x_47_, sizeof(void*)*1, v___x_46_);
return v___x_47_;
}
}
static lean_object* _init_l_MachineRuntime_e4(void){
_start:
{
lean_object* v___x_48_; 
v___x_48_ = lean_obj_once(&l_MachineRuntime_e4___closed__6, &l_MachineRuntime_e4___closed__6_once, _init_l_MachineRuntime_e4___closed__6);
return v___x_48_;
}
}
static lean_object* _init_l_MachineRuntime_e7___closed__0(void){
_start:
{
lean_object* v___x_58_; lean_object* v___x_59_; 
v___x_58_ = lean_unsigned_to_nat(4u);
v___x_59_ = lean_nat_to_int(v___x_58_);
return v___x_59_;
}
}
static lean_object* _init_l_MachineRuntime_e7___closed__1(void){
_start:
{
lean_object* v___x_60_; uint8_t v___x_61_; lean_object* v___x_62_; 
v___x_60_ = lean_obj_once(&l_MachineRuntime_e7___closed__0, &l_MachineRuntime_e7___closed__0_once, _init_l_MachineRuntime_e7___closed__0);
v___x_61_ = 0;
v___x_62_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_62_, 0, v___x_60_);
lean_ctor_set_uint8(v___x_62_, sizeof(void*)*1, v___x_61_);
return v___x_62_;
}
}
static lean_object* _init_l_MachineRuntime_e7(void){
_start:
{
lean_object* v___x_63_; 
v___x_63_ = lean_obj_once(&l_MachineRuntime_e7___closed__1, &l_MachineRuntime_e7___closed__1_once, _init_l_MachineRuntime_e7___closed__1);
return v___x_63_;
}
}
static lean_object* _init_l_MachineRuntime_e9___closed__0(void){
_start:
{
lean_object* v___x_68_; lean_object* v___x_69_; 
v___x_68_ = lean_unsigned_to_nat(1u);
v___x_69_ = lean_nat_to_int(v___x_68_);
return v___x_69_;
}
}
static lean_object* _init_l_MachineRuntime_e9___closed__1(void){
_start:
{
lean_object* v___x_70_; uint8_t v___x_71_; lean_object* v___x_72_; 
v___x_70_ = lean_obj_once(&l_MachineRuntime_e9___closed__0, &l_MachineRuntime_e9___closed__0_once, _init_l_MachineRuntime_e9___closed__0);
v___x_71_ = 0;
v___x_72_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_72_, 0, v___x_70_);
lean_ctor_set_uint8(v___x_72_, sizeof(void*)*1, v___x_71_);
return v___x_72_;
}
}
static lean_object* _init_l_MachineRuntime_e9(void){
_start:
{
lean_object* v___x_73_; 
v___x_73_ = lean_obj_once(&l_MachineRuntime_e9___closed__1, &l_MachineRuntime_e9___closed__1_once, _init_l_MachineRuntime_e9___closed__1);
return v___x_73_;
}
}
static lean_object* _init_l_MachineRuntime_e10___closed__0(void){
_start:
{
lean_object* v___x_74_; lean_object* v___x_75_; lean_object* v___x_76_; 
v___x_74_ = l_MachineRuntime_e9;
v___x_75_ = ((lean_object*)(l_MachineRuntime_e8));
v___x_76_ = lean_alloc_ctor(12, 2, 0);
lean_ctor_set(v___x_76_, 0, v___x_75_);
lean_ctor_set(v___x_76_, 1, v___x_74_);
return v___x_76_;
}
}
static lean_object* _init_l_MachineRuntime_e10(void){
_start:
{
lean_object* v___x_77_; 
v___x_77_ = lean_obj_once(&l_MachineRuntime_e10___closed__0, &l_MachineRuntime_e10___closed__0_once, _init_l_MachineRuntime_e10___closed__0);
return v___x_77_;
}
}
static lean_object* _init_l_MachineRuntime_e12___closed__0(void){
_start:
{
lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; 
v___x_82_ = l_MachineRuntime_e9;
v___x_83_ = ((lean_object*)(l_MachineRuntime_e11));
v___x_84_ = lean_alloc_ctor(18, 2, 0);
lean_ctor_set(v___x_84_, 0, v___x_83_);
lean_ctor_set(v___x_84_, 1, v___x_82_);
return v___x_84_;
}
}
static lean_object* _init_l_MachineRuntime_e12(void){
_start:
{
lean_object* v___x_85_; 
v___x_85_ = lean_obj_once(&l_MachineRuntime_e12___closed__0, &l_MachineRuntime_e12___closed__0_once, _init_l_MachineRuntime_e12___closed__0);
return v___x_85_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_86_; lean_object* v___x_87_; 
v___x_86_ = 0;
v___x_87_ = lean_box_uint32(v___x_86_);
return v___x_87_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__0(void){
_start:
{
lean_object* v___x_88_; lean_object* v___x_89_; lean_object* v___x_90_; 
v___x_88_ = lean_box(0);
v___x_89_ = l_MachineRuntime_e13___closed__0___boxed__const__1;
v___x_90_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_90_, 0, v___x_89_);
lean_ctor_set(v___x_90_, 1, v___x_88_);
return v___x_90_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_91_; lean_object* v___x_92_; 
v___x_91_ = 10;
v___x_92_ = lean_box_uint32(v___x_91_);
return v___x_92_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__1(void){
_start:
{
lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; 
v___x_93_ = lean_obj_once(&l_MachineRuntime_e13___closed__0, &l_MachineRuntime_e13___closed__0_once, _init_l_MachineRuntime_e13___closed__0);
v___x_94_ = l_MachineRuntime_e13___closed__1___boxed__const__1;
v___x_95_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_95_, 0, v___x_94_);
lean_ctor_set(v___x_95_, 1, v___x_93_);
return v___x_95_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_96_; lean_object* v___x_97_; 
v___x_96_ = 24320;
v___x_97_ = lean_box_uint32(v___x_96_);
return v___x_97_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__2(void){
_start:
{
lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; 
v___x_98_ = lean_obj_once(&l_MachineRuntime_e13___closed__1, &l_MachineRuntime_e13___closed__1_once, _init_l_MachineRuntime_e13___closed__1);
v___x_99_ = l_MachineRuntime_e13___closed__2___boxed__const__1;
v___x_100_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_100_, 0, v___x_99_);
lean_ctor_set(v___x_100_, 1, v___x_98_);
return v___x_100_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__3(void){
_start:
{
lean_object* v___x_101_; lean_object* v___x_102_; 
v___x_101_ = lean_obj_once(&l_MachineRuntime_e13___closed__2, &l_MachineRuntime_e13___closed__2_once, _init_l_MachineRuntime_e13___closed__2);
v___x_102_ = lean_string_mk(v___x_101_);
return v___x_102_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__4(void){
_start:
{
lean_object* v___x_103_; uint8_t v___x_104_; lean_object* v___x_105_; 
v___x_103_ = lean_obj_once(&l_MachineRuntime_e13___closed__3, &l_MachineRuntime_e13___closed__3_once, _init_l_MachineRuntime_e13___closed__3);
v___x_104_ = 2;
v___x_105_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_105_, 0, v___x_103_);
lean_ctor_set_uint8(v___x_105_, sizeof(void*)*1, v___x_104_);
return v___x_105_;
}
}
static lean_object* _init_l_MachineRuntime_e13(void){
_start:
{
lean_object* v___x_106_; 
v___x_106_ = lean_obj_once(&l_MachineRuntime_e13___closed__4, &l_MachineRuntime_e13___closed__4_once, _init_l_MachineRuntime_e13___closed__4);
return v___x_106_;
}
}
static lean_object* _init_l_MachineRuntime_e20___closed__0(void){
_start:
{
lean_object* v___x_128_; lean_object* v___x_129_; 
v___x_128_ = lean_unsigned_to_nat(5u);
v___x_129_ = lean_nat_to_int(v___x_128_);
return v___x_129_;
}
}
static lean_object* _init_l_MachineRuntime_e20___closed__1(void){
_start:
{
lean_object* v___x_130_; uint8_t v___x_131_; lean_object* v___x_132_; 
v___x_130_ = lean_obj_once(&l_MachineRuntime_e20___closed__0, &l_MachineRuntime_e20___closed__0_once, _init_l_MachineRuntime_e20___closed__0);
v___x_131_ = 0;
v___x_132_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_132_, 0, v___x_130_);
lean_ctor_set_uint8(v___x_132_, sizeof(void*)*1, v___x_131_);
return v___x_132_;
}
}
static lean_object* _init_l_MachineRuntime_e20(void){
_start:
{
lean_object* v___x_133_; 
v___x_133_ = lean_obj_once(&l_MachineRuntime_e20___closed__1, &l_MachineRuntime_e20___closed__1_once, _init_l_MachineRuntime_e20___closed__1);
return v___x_133_;
}
}
static lean_object* _init_l_MachineRuntime_e21___closed__0(void){
_start:
{
lean_object* v___x_134_; lean_object* v___x_135_; 
v___x_134_ = lean_unsigned_to_nat(10u);
v___x_135_ = lean_nat_to_int(v___x_134_);
return v___x_135_;
}
}
static lean_object* _init_l_MachineRuntime_e21___closed__1(void){
_start:
{
lean_object* v___x_136_; uint8_t v___x_137_; lean_object* v___x_138_; 
v___x_136_ = lean_obj_once(&l_MachineRuntime_e21___closed__0, &l_MachineRuntime_e21___closed__0_once, _init_l_MachineRuntime_e21___closed__0);
v___x_137_ = 0;
v___x_138_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_138_, 0, v___x_136_);
lean_ctor_set_uint8(v___x_138_, sizeof(void*)*1, v___x_137_);
return v___x_138_;
}
}
static lean_object* _init_l_MachineRuntime_e21(void){
_start:
{
lean_object* v___x_139_; 
v___x_139_ = lean_obj_once(&l_MachineRuntime_e21___closed__1, &l_MachineRuntime_e21___closed__1_once, _init_l_MachineRuntime_e21___closed__1);
return v___x_139_;
}
}
static lean_object* _init_l_MachineRuntime_e23___closed__0(void){
_start:
{
lean_object* v___x_144_; lean_object* v___x_145_; 
v___x_144_ = lean_obj_once(&l_MachineRuntime_e9___closed__0, &l_MachineRuntime_e9___closed__0_once, _init_l_MachineRuntime_e9___closed__0);
v___x_145_ = lean_int_neg(v___x_144_);
return v___x_145_;
}
}
static lean_object* _init_l_MachineRuntime_e23___closed__1(void){
_start:
{
lean_object* v___x_146_; uint8_t v___x_147_; lean_object* v___x_148_; 
v___x_146_ = lean_obj_once(&l_MachineRuntime_e23___closed__0, &l_MachineRuntime_e23___closed__0_once, _init_l_MachineRuntime_e23___closed__0);
v___x_147_ = 0;
v___x_148_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_148_, 0, v___x_146_);
lean_ctor_set_uint8(v___x_148_, sizeof(void*)*1, v___x_147_);
return v___x_148_;
}
}
static lean_object* _init_l_MachineRuntime_e23(void){
_start:
{
lean_object* v___x_149_; 
v___x_149_ = lean_obj_once(&l_MachineRuntime_e23___closed__1, &l_MachineRuntime_e23___closed__1_once, _init_l_MachineRuntime_e23___closed__1);
return v___x_149_;
}
}
static lean_object* _init_l_MachineRuntime_e27___closed__0(void){
_start:
{
lean_object* v___x_161_; lean_object* v___x_162_; 
v___x_161_ = lean_unsigned_to_nat(3u);
v___x_162_ = lean_nat_to_int(v___x_161_);
return v___x_162_;
}
}
static lean_object* _init_l_MachineRuntime_e27___closed__1(void){
_start:
{
lean_object* v___x_163_; uint8_t v___x_164_; lean_object* v___x_165_; 
v___x_163_ = lean_obj_once(&l_MachineRuntime_e27___closed__0, &l_MachineRuntime_e27___closed__0_once, _init_l_MachineRuntime_e27___closed__0);
v___x_164_ = 0;
v___x_165_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_165_, 0, v___x_163_);
lean_ctor_set_uint8(v___x_165_, sizeof(void*)*1, v___x_164_);
return v___x_165_;
}
}
static lean_object* _init_l_MachineRuntime_e27(void){
_start:
{
lean_object* v___x_166_; 
v___x_166_ = lean_obj_once(&l_MachineRuntime_e27___closed__1, &l_MachineRuntime_e27___closed__1_once, _init_l_MachineRuntime_e27___closed__1);
return v___x_166_;
}
}
static lean_object* _init_l_MachineRuntime_e28___closed__0(void){
_start:
{
lean_object* v___x_167_; lean_object* v___x_168_; 
v___x_167_ = lean_unsigned_to_nat(7u);
v___x_168_ = lean_nat_to_int(v___x_167_);
return v___x_168_;
}
}
static lean_object* _init_l_MachineRuntime_e28___closed__1(void){
_start:
{
lean_object* v___x_169_; uint8_t v___x_170_; lean_object* v___x_171_; 
v___x_169_ = lean_obj_once(&l_MachineRuntime_e28___closed__0, &l_MachineRuntime_e28___closed__0_once, _init_l_MachineRuntime_e28___closed__0);
v___x_170_ = 0;
v___x_171_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_171_, 0, v___x_169_);
lean_ctor_set_uint8(v___x_171_, sizeof(void*)*1, v___x_170_);
return v___x_171_;
}
}
static lean_object* _init_l_MachineRuntime_e28(void){
_start:
{
lean_object* v___x_172_; 
v___x_172_ = lean_obj_once(&l_MachineRuntime_e28___closed__1, &l_MachineRuntime_e28___closed__1_once, _init_l_MachineRuntime_e28___closed__1);
return v___x_172_;
}
}
static lean_object* _init_l_MachineRuntime_e30___closed__0(void){
_start:
{
lean_object* v___x_177_; lean_object* v___x_178_; 
v___x_177_ = lean_unsigned_to_nat(99u);
v___x_178_ = lean_nat_to_int(v___x_177_);
return v___x_178_;
}
}
static lean_object* _init_l_MachineRuntime_e30___closed__1(void){
_start:
{
lean_object* v___x_179_; uint8_t v___x_180_; lean_object* v___x_181_; 
v___x_179_ = lean_obj_once(&l_MachineRuntime_e30___closed__0, &l_MachineRuntime_e30___closed__0_once, _init_l_MachineRuntime_e30___closed__0);
v___x_180_ = 0;
v___x_181_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_181_, 0, v___x_179_);
lean_ctor_set_uint8(v___x_181_, sizeof(void*)*1, v___x_180_);
return v___x_181_;
}
}
static lean_object* _init_l_MachineRuntime_e30(void){
_start:
{
lean_object* v___x_182_; 
v___x_182_ = lean_obj_once(&l_MachineRuntime_e30___closed__1, &l_MachineRuntime_e30___closed__1_once, _init_l_MachineRuntime_e30___closed__1);
return v___x_182_;
}
}
static lean_object* _init_l_MachineRuntime_e33___closed__0(void){
_start:
{
lean_object* v___x_203_; lean_object* v___x_204_; 
v___x_203_ = lean_unsigned_to_nat(2u);
v___x_204_ = lean_nat_to_int(v___x_203_);
return v___x_204_;
}
}
static lean_object* _init_l_MachineRuntime_e33___closed__1(void){
_start:
{
lean_object* v___x_205_; uint8_t v___x_206_; lean_object* v___x_207_; 
v___x_205_ = lean_obj_once(&l_MachineRuntime_e33___closed__0, &l_MachineRuntime_e33___closed__0_once, _init_l_MachineRuntime_e33___closed__0);
v___x_206_ = 0;
v___x_207_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_207_, 0, v___x_205_);
lean_ctor_set_uint8(v___x_207_, sizeof(void*)*1, v___x_206_);
return v___x_207_;
}
}
static lean_object* _init_l_MachineRuntime_e33(void){
_start:
{
lean_object* v___x_208_; 
v___x_208_ = lean_obj_once(&l_MachineRuntime_e33___closed__1, &l_MachineRuntime_e33___closed__1_once, _init_l_MachineRuntime_e33___closed__1);
return v___x_208_;
}
}
static lean_object* _init_l_MachineRuntime_e34___closed__0(void){
_start:
{
lean_object* v___x_209_; lean_object* v___x_210_; lean_object* v___x_211_; 
v___x_209_ = l_MachineRuntime_e9;
v___x_210_ = ((lean_object*)(l_MachineRuntime_e8));
v___x_211_ = lean_alloc_ctor(16, 2, 0);
lean_ctor_set(v___x_211_, 0, v___x_210_);
lean_ctor_set(v___x_211_, 1, v___x_209_);
return v___x_211_;
}
}
static lean_object* _init_l_MachineRuntime_e34(void){
_start:
{
lean_object* v___x_212_; 
v___x_212_ = lean_obj_once(&l_MachineRuntime_e34___closed__0, &l_MachineRuntime_e34___closed__0_once, _init_l_MachineRuntime_e34___closed__0);
return v___x_212_;
}
}
static lean_object* _init_l_MachineRuntime_e35___closed__0(void){
_start:
{
lean_object* v___x_213_; lean_object* v___x_214_; lean_object* v___x_215_; 
v___x_213_ = l_MachineRuntime_e33;
v___x_214_ = ((lean_object*)(l_MachineRuntime_e8));
v___x_215_ = lean_alloc_ctor(17, 2, 0);
lean_ctor_set(v___x_215_, 0, v___x_214_);
lean_ctor_set(v___x_215_, 1, v___x_213_);
return v___x_215_;
}
}
static lean_object* _init_l_MachineRuntime_e35(void){
_start:
{
lean_object* v___x_216_; 
v___x_216_ = lean_obj_once(&l_MachineRuntime_e35___closed__0, &l_MachineRuntime_e35___closed__0_once, _init_l_MachineRuntime_e35___closed__0);
return v___x_216_;
}
}
static lean_object* _init_l_MachineRuntime_e36___closed__0(void){
_start:
{
lean_object* v___x_217_; lean_object* v___x_218_; lean_object* v___x_219_; 
v___x_217_ = l_MachineRuntime_e0;
v___x_218_ = ((lean_object*)(l_MachineRuntime_e8));
v___x_219_ = lean_alloc_ctor(17, 2, 0);
lean_ctor_set(v___x_219_, 0, v___x_218_);
lean_ctor_set(v___x_219_, 1, v___x_217_);
return v___x_219_;
}
}
static lean_object* _init_l_MachineRuntime_e36(void){
_start:
{
lean_object* v___x_220_; 
v___x_220_ = lean_obj_once(&l_MachineRuntime_e36___closed__0, &l_MachineRuntime_e36___closed__0_once, _init_l_MachineRuntime_e36___closed__0);
return v___x_220_;
}
}
static lean_object* _init_l_MachineRuntime_e38___closed__0(void){
_start:
{
lean_object* v___x_224_; lean_object* v___x_225_; 
v___x_224_ = lean_unsigned_to_nat(4096u);
v___x_225_ = lean_nat_to_int(v___x_224_);
return v___x_225_;
}
}
static lean_object* _init_l_MachineRuntime_e38___closed__1(void){
_start:
{
lean_object* v___x_226_; uint8_t v___x_227_; lean_object* v___x_228_; 
v___x_226_ = lean_obj_once(&l_MachineRuntime_e38___closed__0, &l_MachineRuntime_e38___closed__0_once, _init_l_MachineRuntime_e38___closed__0);
v___x_227_ = 0;
v___x_228_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_228_, 0, v___x_226_);
lean_ctor_set_uint8(v___x_228_, sizeof(void*)*1, v___x_227_);
return v___x_228_;
}
}
static lean_object* _init_l_MachineRuntime_e38(void){
_start:
{
lean_object* v___x_229_; 
v___x_229_ = lean_obj_once(&l_MachineRuntime_e38___closed__1, &l_MachineRuntime_e38___closed__1_once, _init_l_MachineRuntime_e38___closed__1);
return v___x_229_;
}
}
static lean_object* _init_l_MachineRuntime_e39___closed__0(void){
_start:
{
lean_object* v___x_230_; lean_object* v___x_231_; lean_object* v___x_232_; 
v___x_230_ = l_MachineRuntime_e38;
v___x_231_ = ((lean_object*)(l_MachineRuntime_e37));
v___x_232_ = lean_alloc_ctor(16, 2, 0);
lean_ctor_set(v___x_232_, 0, v___x_231_);
lean_ctor_set(v___x_232_, 1, v___x_230_);
return v___x_232_;
}
}
static lean_object* _init_l_MachineRuntime_e39(void){
_start:
{
lean_object* v___x_233_; 
v___x_233_ = lean_obj_once(&l_MachineRuntime_e39___closed__0, &l_MachineRuntime_e39___closed__0_once, _init_l_MachineRuntime_e39___closed__0);
return v___x_233_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__1(void){
_start:
{
lean_object* v___x_238_; lean_object* v___x_239_; uint8_t v___x_240_; lean_object* v___x_241_; 
v___x_238_ = l_MachineRuntime_e7;
v___x_239_ = lean_unsigned_to_nat(0u);
v___x_240_ = 0;
v___x_241_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_241_, 0, v___x_239_);
lean_ctor_set(v___x_241_, 1, v___x_238_);
lean_ctor_set_uint8(v___x_241_, sizeof(void*)*2, v___x_240_);
return v___x_241_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__2(void){
_start:
{
lean_object* v___x_242_; lean_object* v___x_243_; uint8_t v___x_244_; lean_object* v___x_245_; 
v___x_242_ = l_MachineRuntime_e10;
v___x_243_ = lean_unsigned_to_nat(0u);
v___x_244_ = 0;
v___x_245_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_245_, 0, v___x_243_);
lean_ctor_set(v___x_245_, 1, v___x_242_);
lean_ctor_set_uint8(v___x_245_, sizeof(void*)*2, v___x_244_);
return v___x_245_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__4(void){
_start:
{
lean_object* v___x_250_; lean_object* v___x_251_; uint8_t v___x_252_; lean_object* v___x_253_; 
v___x_250_ = l_MachineRuntime_e12;
v___x_251_ = lean_unsigned_to_nat(2u);
v___x_252_ = 4;
v___x_253_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_253_, 0, v___x_251_);
lean_ctor_set(v___x_253_, 1, v___x_250_);
lean_ctor_set_uint8(v___x_253_, sizeof(void*)*2, v___x_252_);
return v___x_253_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__5(void){
_start:
{
lean_object* v___x_254_; lean_object* v___x_255_; uint8_t v___x_256_; lean_object* v___x_257_; 
v___x_254_ = l_MachineRuntime_e13;
v___x_255_ = lean_unsigned_to_nat(4u);
v___x_256_ = 2;
v___x_257_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_257_, 0, v___x_255_);
lean_ctor_set(v___x_257_, 1, v___x_254_);
lean_ctor_set_uint8(v___x_257_, sizeof(void*)*2, v___x_256_);
return v___x_257_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__23(void){
_start:
{
lean_object* v___x_317_; lean_object* v___x_318_; lean_object* v___x_319_; 
v___x_317_ = l_MachineRuntime_e20;
v___x_318_ = lean_unsigned_to_nat(2u);
v___x_319_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_319_, 0, v___x_318_);
lean_ctor_set(v___x_319_, 1, v___x_317_);
return v___x_319_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__24(void){
_start:
{
lean_object* v___x_320_; lean_object* v___x_321_; lean_object* v___x_322_; 
v___x_320_ = l_MachineRuntime_e20;
v___x_321_ = lean_unsigned_to_nat(0u);
v___x_322_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_322_, 0, v___x_321_);
lean_ctor_set(v___x_322_, 1, v___x_320_);
return v___x_322_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__25(void){
_start:
{
lean_object* v___x_323_; lean_object* v___x_324_; lean_object* v___x_325_; 
v___x_323_ = lean_box(0);
v___x_324_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__24, &l_MachineRuntime_rule__0___closed__24_once, _init_l_MachineRuntime_rule__0___closed__24);
v___x_325_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_325_, 0, v___x_324_);
lean_ctor_set(v___x_325_, 1, v___x_323_);
return v___x_325_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__26(void){
_start:
{
lean_object* v___x_326_; lean_object* v___x_327_; lean_object* v___x_328_; 
v___x_326_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__25, &l_MachineRuntime_rule__0___closed__25_once, _init_l_MachineRuntime_rule__0___closed__25);
v___x_327_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__23, &l_MachineRuntime_rule__0___closed__23_once, _init_l_MachineRuntime_rule__0___closed__23);
v___x_328_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_328_, 0, v___x_327_);
lean_ctor_set(v___x_328_, 1, v___x_326_);
return v___x_328_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__27(void){
_start:
{
lean_object* v___x_329_; lean_object* v___x_330_; lean_object* v___x_331_; 
v___x_329_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__26, &l_MachineRuntime_rule__0___closed__26_once, _init_l_MachineRuntime_rule__0___closed__26);
v___x_330_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__22));
v___x_331_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_331_, 0, v___x_330_);
lean_ctor_set(v___x_331_, 1, v___x_329_);
return v___x_331_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__28(void){
_start:
{
lean_object* v___x_332_; lean_object* v___x_333_; lean_object* v___x_334_; 
v___x_332_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__27, &l_MachineRuntime_rule__0___closed__27_once, _init_l_MachineRuntime_rule__0___closed__27);
v___x_333_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__5, &l_MachineRuntime_rule__0___closed__5_once, _init_l_MachineRuntime_rule__0___closed__5);
v___x_334_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_334_, 0, v___x_333_);
lean_ctor_set(v___x_334_, 1, v___x_332_);
return v___x_334_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__29(void){
_start:
{
lean_object* v___x_335_; lean_object* v___x_336_; lean_object* v___x_337_; 
v___x_335_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__28, &l_MachineRuntime_rule__0___closed__28_once, _init_l_MachineRuntime_rule__0___closed__28);
v___x_336_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__4, &l_MachineRuntime_rule__0___closed__4_once, _init_l_MachineRuntime_rule__0___closed__4);
v___x_337_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_337_, 0, v___x_336_);
lean_ctor_set(v___x_337_, 1, v___x_335_);
return v___x_337_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__30(void){
_start:
{
lean_object* v___x_338_; lean_object* v___x_339_; lean_object* v___x_340_; 
v___x_338_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__29, &l_MachineRuntime_rule__0___closed__29_once, _init_l_MachineRuntime_rule__0___closed__29);
v___x_339_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__3));
v___x_340_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_340_, 0, v___x_339_);
lean_ctor_set(v___x_340_, 1, v___x_338_);
return v___x_340_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__31(void){
_start:
{
lean_object* v___x_341_; lean_object* v___x_342_; lean_object* v___x_343_; 
v___x_341_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__30, &l_MachineRuntime_rule__0___closed__30_once, _init_l_MachineRuntime_rule__0___closed__30);
v___x_342_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__2, &l_MachineRuntime_rule__0___closed__2_once, _init_l_MachineRuntime_rule__0___closed__2);
v___x_343_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_343_, 0, v___x_342_);
lean_ctor_set(v___x_343_, 1, v___x_341_);
return v___x_343_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__32(void){
_start:
{
lean_object* v___x_344_; lean_object* v___x_345_; lean_object* v___x_346_; 
v___x_344_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__31, &l_MachineRuntime_rule__0___closed__31_once, _init_l_MachineRuntime_rule__0___closed__31);
v___x_345_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__1, &l_MachineRuntime_rule__0___closed__1_once, _init_l_MachineRuntime_rule__0___closed__1);
v___x_346_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_346_, 0, v___x_345_);
lean_ctor_set(v___x_346_, 1, v___x_344_);
return v___x_346_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__33(void){
_start:
{
lean_object* v___x_347_; lean_object* v___x_348_; lean_object* v___x_349_; 
v___x_347_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__32, &l_MachineRuntime_rule__0___closed__32_once, _init_l_MachineRuntime_rule__0___closed__32);
v___x_348_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__0));
v___x_349_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_349_, 0, v___x_348_);
lean_ctor_set(v___x_349_, 1, v___x_347_);
return v___x_349_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__34(void){
_start:
{
lean_object* v___x_350_; lean_object* v___x_351_; lean_object* v___x_352_; lean_object* v___x_353_; lean_object* v___x_354_; 
v___x_350_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__33, &l_MachineRuntime_rule__0___closed__33_once, _init_l_MachineRuntime_rule__0___closed__33);
v___x_351_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_352_ = lean_unsigned_to_nat(1u);
v___x_353_ = lean_unsigned_to_nat(0u);
v___x_354_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_354_, 0, v___x_353_);
lean_ctor_set(v___x_354_, 1, v___x_353_);
lean_ctor_set(v___x_354_, 2, v___x_352_);
lean_ctor_set(v___x_354_, 3, v___x_353_);
lean_ctor_set(v___x_354_, 4, v___x_351_);
lean_ctor_set(v___x_354_, 5, v___x_350_);
return v___x_354_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0(void){
_start:
{
lean_object* v___x_355_; 
v___x_355_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__34, &l_MachineRuntime_rule__0___closed__34_once, _init_l_MachineRuntime_rule__0___closed__34);
return v___x_355_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1___closed__0(void){
_start:
{
lean_object* v___x_356_; lean_object* v___x_357_; uint8_t v___x_358_; lean_object* v___x_359_; 
v___x_356_ = l_MachineRuntime_e21;
v___x_357_ = lean_unsigned_to_nat(0u);
v___x_358_ = 0;
v___x_359_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_359_, 0, v___x_357_);
lean_ctor_set(v___x_359_, 1, v___x_356_);
lean_ctor_set_uint8(v___x_359_, sizeof(void*)*2, v___x_358_);
return v___x_359_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1___closed__4(void){
_start:
{
lean_object* v___x_369_; lean_object* v___x_370_; lean_object* v___x_371_; 
v___x_369_ = ((lean_object*)(l_MachineRuntime_rule__1___closed__3));
v___x_370_ = lean_obj_once(&l_MachineRuntime_rule__1___closed__0, &l_MachineRuntime_rule__1___closed__0_once, _init_l_MachineRuntime_rule__1___closed__0);
v___x_371_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_371_, 0, v___x_370_);
lean_ctor_set(v___x_371_, 1, v___x_369_);
return v___x_371_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1___closed__5(void){
_start:
{
lean_object* v___x_372_; lean_object* v___x_373_; lean_object* v___x_374_; lean_object* v___x_375_; lean_object* v___x_376_; 
v___x_372_ = lean_obj_once(&l_MachineRuntime_rule__1___closed__4, &l_MachineRuntime_rule__1___closed__4_once, _init_l_MachineRuntime_rule__1___closed__4);
v___x_373_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_374_ = lean_unsigned_to_nat(0u);
v___x_375_ = lean_unsigned_to_nat(1u);
v___x_376_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_376_, 0, v___x_375_);
lean_ctor_set(v___x_376_, 1, v___x_374_);
lean_ctor_set(v___x_376_, 2, v___x_375_);
lean_ctor_set(v___x_376_, 3, v___x_375_);
lean_ctor_set(v___x_376_, 4, v___x_373_);
lean_ctor_set(v___x_376_, 5, v___x_372_);
return v___x_376_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1(void){
_start:
{
lean_object* v___x_377_; 
v___x_377_ = lean_obj_once(&l_MachineRuntime_rule__1___closed__5, &l_MachineRuntime_rule__1___closed__5_once, _init_l_MachineRuntime_rule__1___closed__5);
return v___x_377_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__0(void){
_start:
{
lean_object* v___x_378_; lean_object* v___x_379_; uint8_t v___x_380_; lean_object* v___x_381_; 
v___x_378_ = l_MachineRuntime_e23;
v___x_379_ = lean_unsigned_to_nat(0u);
v___x_380_ = 0;
v___x_381_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_381_, 0, v___x_379_);
lean_ctor_set(v___x_381_, 1, v___x_378_);
lean_ctor_set_uint8(v___x_381_, sizeof(void*)*2, v___x_380_);
return v___x_381_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__2(void){
_start:
{
lean_object* v___x_385_; lean_object* v___x_386_; lean_object* v___x_387_; 
v___x_385_ = ((lean_object*)(l_MachineRuntime_rule__2___closed__1));
v___x_386_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__24, &l_MachineRuntime_rule__0___closed__24_once, _init_l_MachineRuntime_rule__0___closed__24);
v___x_387_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_387_, 0, v___x_386_);
lean_ctor_set(v___x_387_, 1, v___x_385_);
return v___x_387_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__3(void){
_start:
{
lean_object* v___x_388_; lean_object* v___x_389_; lean_object* v___x_390_; 
v___x_388_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__2, &l_MachineRuntime_rule__2___closed__2_once, _init_l_MachineRuntime_rule__2___closed__2);
v___x_389_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__0, &l_MachineRuntime_rule__2___closed__0_once, _init_l_MachineRuntime_rule__2___closed__0);
v___x_390_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_390_, 0, v___x_389_);
lean_ctor_set(v___x_390_, 1, v___x_388_);
return v___x_390_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__4(void){
_start:
{
lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_393_; lean_object* v___x_394_; lean_object* v___x_395_; 
v___x_391_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__3, &l_MachineRuntime_rule__2___closed__3_once, _init_l_MachineRuntime_rule__2___closed__3);
v___x_392_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_393_ = lean_unsigned_to_nat(0u);
v___x_394_ = lean_unsigned_to_nat(2u);
v___x_395_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_395_, 0, v___x_394_);
lean_ctor_set(v___x_395_, 1, v___x_393_);
lean_ctor_set(v___x_395_, 2, v___x_394_);
lean_ctor_set(v___x_395_, 3, v___x_394_);
lean_ctor_set(v___x_395_, 4, v___x_392_);
lean_ctor_set(v___x_395_, 5, v___x_391_);
return v___x_395_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2(void){
_start:
{
lean_object* v___x_396_; 
v___x_396_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__4, &l_MachineRuntime_rule__2___closed__4_once, _init_l_MachineRuntime_rule__2___closed__4);
return v___x_396_;
}
}
static lean_object* _init_l_MachineRuntime_rule__3___closed__0(void){
_start:
{
lean_object* v___x_397_; lean_object* v___x_398_; lean_object* v___x_399_; 
v___x_397_ = ((lean_object*)(l_MachineRuntime_rule__2___closed__1));
v___x_398_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__2, &l_MachineRuntime_rule__0___closed__2_once, _init_l_MachineRuntime_rule__0___closed__2);
v___x_399_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_399_, 0, v___x_398_);
lean_ctor_set(v___x_399_, 1, v___x_397_);
return v___x_399_;
}
}
static lean_object* _init_l_MachineRuntime_rule__3___closed__1(void){
_start:
{
lean_object* v___x_400_; lean_object* v___x_401_; lean_object* v___x_402_; lean_object* v___x_403_; lean_object* v___x_404_; lean_object* v___x_405_; 
v___x_400_ = lean_obj_once(&l_MachineRuntime_rule__3___closed__0, &l_MachineRuntime_rule__3___closed__0_once, _init_l_MachineRuntime_rule__3___closed__0);
v___x_401_ = ((lean_object*)(l_MachineRuntime_e18));
v___x_402_ = lean_unsigned_to_nat(6u);
v___x_403_ = lean_unsigned_to_nat(1u);
v___x_404_ = lean_unsigned_to_nat(3u);
v___x_405_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_405_, 0, v___x_404_);
lean_ctor_set(v___x_405_, 1, v___x_403_);
lean_ctor_set(v___x_405_, 2, v___x_403_);
lean_ctor_set(v___x_405_, 3, v___x_402_);
lean_ctor_set(v___x_405_, 4, v___x_401_);
lean_ctor_set(v___x_405_, 5, v___x_400_);
return v___x_405_;
}
}
static lean_object* _init_l_MachineRuntime_rule__3(void){
_start:
{
lean_object* v___x_406_; 
v___x_406_ = lean_obj_once(&l_MachineRuntime_rule__3___closed__1, &l_MachineRuntime_rule__3___closed__1_once, _init_l_MachineRuntime_rule__3___closed__1);
return v___x_406_;
}
}
static lean_object* _init_l_MachineRuntime_rule__4___closed__3(void){
_start:
{
lean_object* v___x_415_; lean_object* v___x_416_; lean_object* v___x_417_; 
v___x_415_ = ((lean_object*)(l_MachineRuntime_rule__4___closed__2));
v___x_416_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__2, &l_MachineRuntime_rule__0___closed__2_once, _init_l_MachineRuntime_rule__0___closed__2);
v___x_417_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_417_, 0, v___x_416_);
lean_ctor_set(v___x_417_, 1, v___x_415_);
return v___x_417_;
}
}
static lean_object* _init_l_MachineRuntime_rule__4___closed__4(void){
_start:
{
lean_object* v___x_418_; lean_object* v___x_419_; lean_object* v___x_420_; lean_object* v___x_421_; lean_object* v___x_422_; lean_object* v___x_423_; lean_object* v___x_424_; 
v___x_418_ = lean_obj_once(&l_MachineRuntime_rule__4___closed__3, &l_MachineRuntime_rule__4___closed__3_once, _init_l_MachineRuntime_rule__4___closed__3);
v___x_419_ = ((lean_object*)(l_MachineRuntime_e26));
v___x_420_ = lean_unsigned_to_nat(7u);
v___x_421_ = lean_unsigned_to_nat(2u);
v___x_422_ = lean_unsigned_to_nat(1u);
v___x_423_ = lean_unsigned_to_nat(4u);
v___x_424_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_424_, 0, v___x_423_);
lean_ctor_set(v___x_424_, 1, v___x_422_);
lean_ctor_set(v___x_424_, 2, v___x_421_);
lean_ctor_set(v___x_424_, 3, v___x_420_);
lean_ctor_set(v___x_424_, 4, v___x_419_);
lean_ctor_set(v___x_424_, 5, v___x_418_);
return v___x_424_;
}
}
static lean_object* _init_l_MachineRuntime_rule__4(void){
_start:
{
lean_object* v___x_425_; 
v___x_425_ = lean_obj_once(&l_MachineRuntime_rule__4___closed__4, &l_MachineRuntime_rule__4___closed__4_once, _init_l_MachineRuntime_rule__4___closed__4);
return v___x_425_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__0(void){
_start:
{
lean_object* v___x_426_; lean_object* v___x_427_; lean_object* v___x_428_; 
v___x_426_ = l_MachineRuntime_e27;
v___x_427_ = lean_unsigned_to_nat(0u);
v___x_428_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_428_, 0, v___x_427_);
lean_ctor_set(v___x_428_, 1, v___x_426_);
return v___x_428_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__1(void){
_start:
{
lean_object* v___x_429_; lean_object* v___x_430_; lean_object* v___x_431_; 
v___x_429_ = l_MachineRuntime_e28;
v___x_430_ = lean_unsigned_to_nat(0u);
v___x_431_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_431_, 0, v___x_430_);
lean_ctor_set(v___x_431_, 1, v___x_429_);
return v___x_431_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__4(void){
_start:
{
lean_object* v___x_437_; lean_object* v___x_438_; lean_object* v___x_439_; 
v___x_437_ = ((lean_object*)(l_MachineRuntime_rule__5___closed__3));
v___x_438_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__1, &l_MachineRuntime_rule__5___closed__1_once, _init_l_MachineRuntime_rule__5___closed__1);
v___x_439_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_439_, 0, v___x_438_);
lean_ctor_set(v___x_439_, 1, v___x_437_);
return v___x_439_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__5(void){
_start:
{
lean_object* v___x_440_; lean_object* v___x_441_; lean_object* v___x_442_; 
v___x_440_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__4, &l_MachineRuntime_rule__5___closed__4_once, _init_l_MachineRuntime_rule__5___closed__4);
v___x_441_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__0, &l_MachineRuntime_rule__5___closed__0_once, _init_l_MachineRuntime_rule__5___closed__0);
v___x_442_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_442_, 0, v___x_441_);
lean_ctor_set(v___x_442_, 1, v___x_440_);
return v___x_442_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__6(void){
_start:
{
lean_object* v___x_443_; lean_object* v___x_444_; lean_object* v___x_445_; lean_object* v___x_446_; lean_object* v___x_447_; lean_object* v___x_448_; 
v___x_443_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__5, &l_MachineRuntime_rule__5___closed__5_once, _init_l_MachineRuntime_rule__5___closed__5);
v___x_444_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_445_ = lean_unsigned_to_nat(3u);
v___x_446_ = lean_unsigned_to_nat(1u);
v___x_447_ = lean_unsigned_to_nat(5u);
v___x_448_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_448_, 0, v___x_447_);
lean_ctor_set(v___x_448_, 1, v___x_446_);
lean_ctor_set(v___x_448_, 2, v___x_446_);
lean_ctor_set(v___x_448_, 3, v___x_445_);
lean_ctor_set(v___x_448_, 4, v___x_444_);
lean_ctor_set(v___x_448_, 5, v___x_443_);
return v___x_448_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5(void){
_start:
{
lean_object* v___x_449_; 
v___x_449_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__6, &l_MachineRuntime_rule__5___closed__6_once, _init_l_MachineRuntime_rule__5___closed__6);
return v___x_449_;
}
}
static lean_object* _init_l_MachineRuntime_rule__8___closed__0(void){
_start:
{
lean_object* v___x_465_; lean_object* v___x_466_; uint8_t v___x_467_; lean_object* v___x_468_; 
v___x_465_ = l_MachineRuntime_e30;
v___x_466_ = lean_unsigned_to_nat(0u);
v___x_467_ = 0;
v___x_468_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_468_, 0, v___x_466_);
lean_ctor_set(v___x_468_, 1, v___x_465_);
lean_ctor_set_uint8(v___x_468_, sizeof(void*)*2, v___x_467_);
return v___x_468_;
}
}
static lean_object* _init_l_MachineRuntime_rule__8___closed__1(void){
_start:
{
lean_object* v___x_469_; lean_object* v___x_470_; lean_object* v___x_471_; 
v___x_469_ = l_MachineRuntime_e0;
v___x_470_ = lean_unsigned_to_nat(0u);
v___x_471_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_471_, 0, v___x_470_);
lean_ctor_set(v___x_471_, 1, v___x_469_);
return v___x_471_;
}
}
static lean_object* _init_l_MachineRuntime_rule__8___closed__2(void){
_start:
{
lean_object* v___x_472_; lean_object* v___x_473_; lean_object* v___x_474_; 
v___x_472_ = lean_box(0);
v___x_473_ = lean_obj_once(&l_MachineRuntime_rule__8___closed__1, &l_MachineRuntime_rule__8___closed__1_once, _init_l_MachineRuntime_rule__8___closed__1);
v___x_474_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_474_, 0, v___x_473_);
lean_ctor_set(v___x_474_, 1, v___x_472_);
return v___x_474_;
}
}
static lean_object* _init_l_MachineRuntime_rule__8___closed__3(void){
_start:
{
lean_object* v___x_475_; lean_object* v___x_476_; lean_object* v___x_477_; 
v___x_475_ = lean_obj_once(&l_MachineRuntime_rule__8___closed__2, &l_MachineRuntime_rule__8___closed__2_once, _init_l_MachineRuntime_rule__8___closed__2);
v___x_476_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__22));
v___x_477_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_477_, 0, v___x_476_);
lean_ctor_set(v___x_477_, 1, v___x_475_);
return v___x_477_;
}
}
static lean_object* _init_l_MachineRuntime_rule__8___closed__4(void){
_start:
{
lean_object* v___x_478_; lean_object* v___x_479_; lean_object* v___x_480_; 
v___x_478_ = lean_obj_once(&l_MachineRuntime_rule__8___closed__3, &l_MachineRuntime_rule__8___closed__3_once, _init_l_MachineRuntime_rule__8___closed__3);
v___x_479_ = lean_obj_once(&l_MachineRuntime_rule__8___closed__0, &l_MachineRuntime_rule__8___closed__0_once, _init_l_MachineRuntime_rule__8___closed__0);
v___x_480_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_480_, 0, v___x_479_);
lean_ctor_set(v___x_480_, 1, v___x_478_);
return v___x_480_;
}
}
static lean_object* _init_l_MachineRuntime_rule__8___closed__5(void){
_start:
{
lean_object* v___x_481_; lean_object* v___x_482_; lean_object* v___x_483_; lean_object* v___x_484_; lean_object* v___x_485_; lean_object* v___x_486_; lean_object* v___x_487_; 
v___x_481_ = lean_obj_once(&l_MachineRuntime_rule__8___closed__4, &l_MachineRuntime_rule__8___closed__4_once, _init_l_MachineRuntime_rule__8___closed__4);
v___x_482_ = ((lean_object*)(l_MachineRuntime_e29));
v___x_483_ = lean_unsigned_to_nat(7u);
v___x_484_ = lean_unsigned_to_nat(2u);
v___x_485_ = lean_unsigned_to_nat(1u);
v___x_486_ = lean_unsigned_to_nat(8u);
v___x_487_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_487_, 0, v___x_486_);
lean_ctor_set(v___x_487_, 1, v___x_485_);
lean_ctor_set(v___x_487_, 2, v___x_484_);
lean_ctor_set(v___x_487_, 3, v___x_483_);
lean_ctor_set(v___x_487_, 4, v___x_482_);
lean_ctor_set(v___x_487_, 5, v___x_481_);
return v___x_487_;
}
}
static lean_object* _init_l_MachineRuntime_rule__8(void){
_start:
{
lean_object* v___x_488_; 
v___x_488_ = lean_obj_once(&l_MachineRuntime_rule__8___closed__5, &l_MachineRuntime_rule__8___closed__5_once, _init_l_MachineRuntime_rule__8___closed__5);
return v___x_488_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__0(void){
_start:
{
lean_object* v___x_515_; lean_object* v___x_516_; uint8_t v___x_517_; lean_object* v___x_518_; 
v___x_515_ = l_MachineRuntime_e0;
v___x_516_ = lean_unsigned_to_nat(0u);
v___x_517_ = 0;
v___x_518_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_518_, 0, v___x_516_);
lean_ctor_set(v___x_518_, 1, v___x_515_);
lean_ctor_set_uint8(v___x_518_, sizeof(void*)*2, v___x_517_);
return v___x_518_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__3(void){
_start:
{
lean_object* v___x_527_; lean_object* v___x_528_; lean_object* v___x_529_; 
v___x_527_ = l_MachineRuntime_e33;
v___x_528_ = lean_unsigned_to_nat(1u);
v___x_529_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_529_, 0, v___x_528_);
lean_ctor_set(v___x_529_, 1, v___x_527_);
return v___x_529_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__4(void){
_start:
{
lean_object* v___x_530_; lean_object* v___x_531_; lean_object* v___x_532_; 
v___x_530_ = lean_box(0);
v___x_531_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__3, &l_MachineRuntime_rule__11___closed__3_once, _init_l_MachineRuntime_rule__11___closed__3);
v___x_532_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_532_, 0, v___x_531_);
lean_ctor_set(v___x_532_, 1, v___x_530_);
return v___x_532_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__5(void){
_start:
{
lean_object* v___x_533_; lean_object* v___x_534_; lean_object* v___x_535_; 
v___x_533_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__4, &l_MachineRuntime_rule__11___closed__4_once, _init_l_MachineRuntime_rule__11___closed__4);
v___x_534_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__22));
v___x_535_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_535_, 0, v___x_534_);
lean_ctor_set(v___x_535_, 1, v___x_533_);
return v___x_535_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__6(void){
_start:
{
lean_object* v___x_536_; lean_object* v___x_537_; lean_object* v___x_538_; 
v___x_536_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__5, &l_MachineRuntime_rule__11___closed__5_once, _init_l_MachineRuntime_rule__11___closed__5);
v___x_537_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__5, &l_MachineRuntime_rule__0___closed__5_once, _init_l_MachineRuntime_rule__0___closed__5);
v___x_538_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_538_, 0, v___x_537_);
lean_ctor_set(v___x_538_, 1, v___x_536_);
return v___x_538_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__7(void){
_start:
{
lean_object* v___x_539_; lean_object* v___x_540_; lean_object* v___x_541_; 
v___x_539_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__6, &l_MachineRuntime_rule__11___closed__6_once, _init_l_MachineRuntime_rule__11___closed__6);
v___x_540_ = ((lean_object*)(l_MachineRuntime_rule__11___closed__2));
v___x_541_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_541_, 0, v___x_540_);
lean_ctor_set(v___x_541_, 1, v___x_539_);
return v___x_541_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__8(void){
_start:
{
lean_object* v___x_542_; lean_object* v___x_543_; lean_object* v___x_544_; 
v___x_542_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__7, &l_MachineRuntime_rule__11___closed__7_once, _init_l_MachineRuntime_rule__11___closed__7);
v___x_543_ = ((lean_object*)(l_MachineRuntime_rule__11___closed__1));
v___x_544_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_544_, 0, v___x_543_);
lean_ctor_set(v___x_544_, 1, v___x_542_);
return v___x_544_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__9(void){
_start:
{
lean_object* v___x_545_; lean_object* v___x_546_; lean_object* v___x_547_; 
v___x_545_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__8, &l_MachineRuntime_rule__11___closed__8_once, _init_l_MachineRuntime_rule__11___closed__8);
v___x_546_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__3));
v___x_547_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_547_, 0, v___x_546_);
lean_ctor_set(v___x_547_, 1, v___x_545_);
return v___x_547_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__10(void){
_start:
{
lean_object* v___x_548_; lean_object* v___x_549_; lean_object* v___x_550_; 
v___x_548_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__9, &l_MachineRuntime_rule__11___closed__9_once, _init_l_MachineRuntime_rule__11___closed__9);
v___x_549_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__0, &l_MachineRuntime_rule__11___closed__0_once, _init_l_MachineRuntime_rule__11___closed__0);
v___x_550_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_550_, 0, v___x_549_);
lean_ctor_set(v___x_550_, 1, v___x_548_);
return v___x_550_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11___closed__11(void){
_start:
{
lean_object* v___x_551_; lean_object* v___x_552_; lean_object* v___x_553_; lean_object* v___x_554_; lean_object* v___x_555_; lean_object* v___x_556_; lean_object* v___x_557_; 
v___x_551_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__10, &l_MachineRuntime_rule__11___closed__10_once, _init_l_MachineRuntime_rule__11___closed__10);
v___x_552_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_553_ = lean_unsigned_to_nat(8u);
v___x_554_ = lean_unsigned_to_nat(1u);
v___x_555_ = lean_unsigned_to_nat(0u);
v___x_556_ = lean_unsigned_to_nat(11u);
v___x_557_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_557_, 0, v___x_556_);
lean_ctor_set(v___x_557_, 1, v___x_555_);
lean_ctor_set(v___x_557_, 2, v___x_554_);
lean_ctor_set(v___x_557_, 3, v___x_553_);
lean_ctor_set(v___x_557_, 4, v___x_552_);
lean_ctor_set(v___x_557_, 5, v___x_551_);
return v___x_557_;
}
}
static lean_object* _init_l_MachineRuntime_rule__11(void){
_start:
{
lean_object* v___x_558_; 
v___x_558_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__11, &l_MachineRuntime_rule__11___closed__11_once, _init_l_MachineRuntime_rule__11___closed__11);
return v___x_558_;
}
}
static lean_object* _init_l_MachineRuntime_rule__12___closed__0(void){
_start:
{
lean_object* v___x_559_; lean_object* v___x_560_; lean_object* v___x_561_; 
v___x_559_ = lean_obj_once(&l_MachineRuntime_rule__11___closed__5, &l_MachineRuntime_rule__11___closed__5_once, _init_l_MachineRuntime_rule__11___closed__5);
v___x_560_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__2, &l_MachineRuntime_rule__0___closed__2_once, _init_l_MachineRuntime_rule__0___closed__2);
v___x_561_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_561_, 0, v___x_560_);
lean_ctor_set(v___x_561_, 1, v___x_559_);
return v___x_561_;
}
}
static lean_object* _init_l_MachineRuntime_rule__12___closed__1(void){
_start:
{
lean_object* v___x_562_; lean_object* v___x_563_; lean_object* v___x_564_; lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_567_; 
v___x_562_ = lean_obj_once(&l_MachineRuntime_rule__12___closed__0, &l_MachineRuntime_rule__12___closed__0_once, _init_l_MachineRuntime_rule__12___closed__0);
v___x_563_ = l_MachineRuntime_e34;
v___x_564_ = lean_unsigned_to_nat(11u);
v___x_565_ = lean_unsigned_to_nat(1u);
v___x_566_ = lean_unsigned_to_nat(12u);
v___x_567_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_567_, 0, v___x_566_);
lean_ctor_set(v___x_567_, 1, v___x_565_);
lean_ctor_set(v___x_567_, 2, v___x_565_);
lean_ctor_set(v___x_567_, 3, v___x_564_);
lean_ctor_set(v___x_567_, 4, v___x_563_);
lean_ctor_set(v___x_567_, 5, v___x_562_);
return v___x_567_;
}
}
static lean_object* _init_l_MachineRuntime_rule__12(void){
_start:
{
lean_object* v___x_568_; 
v___x_568_ = lean_obj_once(&l_MachineRuntime_rule__12___closed__1, &l_MachineRuntime_rule__12___closed__1_once, _init_l_MachineRuntime_rule__12___closed__1);
return v___x_568_;
}
}
static lean_object* _init_l_MachineRuntime_rule__13___closed__0(void){
_start:
{
lean_object* v___x_569_; lean_object* v___x_570_; lean_object* v___x_571_; lean_object* v___x_572_; lean_object* v___x_573_; lean_object* v___x_574_; lean_object* v___x_575_; 
v___x_569_ = lean_obj_once(&l_MachineRuntime_rule__3___closed__0, &l_MachineRuntime_rule__3___closed__0_once, _init_l_MachineRuntime_rule__3___closed__0);
v___x_570_ = l_MachineRuntime_e35;
v___x_571_ = lean_unsigned_to_nat(11u);
v___x_572_ = lean_unsigned_to_nat(2u);
v___x_573_ = lean_unsigned_to_nat(1u);
v___x_574_ = lean_unsigned_to_nat(13u);
v___x_575_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_575_, 0, v___x_574_);
lean_ctor_set(v___x_575_, 1, v___x_573_);
lean_ctor_set(v___x_575_, 2, v___x_572_);
lean_ctor_set(v___x_575_, 3, v___x_571_);
lean_ctor_set(v___x_575_, 4, v___x_570_);
lean_ctor_set(v___x_575_, 5, v___x_569_);
return v___x_575_;
}
}
static lean_object* _init_l_MachineRuntime_rule__13(void){
_start:
{
lean_object* v___x_576_; 
v___x_576_ = lean_obj_once(&l_MachineRuntime_rule__13___closed__0, &l_MachineRuntime_rule__13___closed__0_once, _init_l_MachineRuntime_rule__13___closed__0);
return v___x_576_;
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0(lean_object* v_n_620_){
_start:
{
lean_object* v___x_621_; uint8_t v___x_622_; 
v___x_621_ = lean_unsigned_to_nat(0u);
v___x_622_ = lean_nat_dec_eq(v_n_620_, v___x_621_);
if (v___x_622_ == 0)
{
lean_object* v___x_623_; uint8_t v___x_624_; 
v___x_623_ = lean_unsigned_to_nat(1u);
v___x_624_ = lean_nat_dec_eq(v_n_620_, v___x_623_);
if (v___x_624_ == 0)
{
lean_object* v___x_625_; uint8_t v___x_626_; 
v___x_625_ = lean_unsigned_to_nat(2u);
v___x_626_ = lean_nat_dec_eq(v_n_620_, v___x_625_);
if (v___x_626_ == 0)
{
return v___x_621_;
}
else
{
lean_object* v___x_627_; 
v___x_627_ = lean_unsigned_to_nat(7u);
return v___x_627_;
}
}
else
{
lean_object* v___x_628_; 
v___x_628_ = lean_unsigned_to_nat(11u);
return v___x_628_;
}
}
else
{
lean_object* v___x_629_; 
v___x_629_ = lean_unsigned_to_nat(6u);
return v___x_629_;
}
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0___boxed(lean_object* v_n_630_){
_start:
{
lean_object* v_res_631_; 
v_res_631_ = l_MachineRuntime_model___lam__0(v_n_630_);
lean_dec(v_n_630_);
return v_res_631_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__1(void){
_start:
{
lean_object* v___x_633_; lean_object* v___x_634_; lean_object* v___x_635_; 
v___x_633_ = lean_box(0);
v___x_634_ = l_MachineRuntime_rule__13;
v___x_635_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_635_, 0, v___x_634_);
lean_ctor_set(v___x_635_, 1, v___x_633_);
return v___x_635_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__2(void){
_start:
{
lean_object* v___x_636_; lean_object* v___x_637_; lean_object* v___x_638_; 
v___x_636_ = lean_obj_once(&l_MachineRuntime_model___closed__1, &l_MachineRuntime_model___closed__1_once, _init_l_MachineRuntime_model___closed__1);
v___x_637_ = l_MachineRuntime_rule__12;
v___x_638_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_638_, 0, v___x_637_);
lean_ctor_set(v___x_638_, 1, v___x_636_);
return v___x_638_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__3(void){
_start:
{
lean_object* v___x_639_; lean_object* v___x_640_; lean_object* v___x_641_; 
v___x_639_ = lean_obj_once(&l_MachineRuntime_model___closed__2, &l_MachineRuntime_model___closed__2_once, _init_l_MachineRuntime_model___closed__2);
v___x_640_ = l_MachineRuntime_rule__11;
v___x_641_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_641_, 0, v___x_640_);
lean_ctor_set(v___x_641_, 1, v___x_639_);
return v___x_641_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__4(void){
_start:
{
lean_object* v___x_642_; lean_object* v___x_643_; lean_object* v___x_644_; 
v___x_642_ = lean_obj_once(&l_MachineRuntime_model___closed__3, &l_MachineRuntime_model___closed__3_once, _init_l_MachineRuntime_model___closed__3);
v___x_643_ = ((lean_object*)(l_MachineRuntime_rule__10));
v___x_644_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_644_, 0, v___x_643_);
lean_ctor_set(v___x_644_, 1, v___x_642_);
return v___x_644_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__5(void){
_start:
{
lean_object* v___x_645_; lean_object* v___x_646_; lean_object* v___x_647_; 
v___x_645_ = lean_obj_once(&l_MachineRuntime_model___closed__4, &l_MachineRuntime_model___closed__4_once, _init_l_MachineRuntime_model___closed__4);
v___x_646_ = ((lean_object*)(l_MachineRuntime_rule__9));
v___x_647_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_647_, 0, v___x_646_);
lean_ctor_set(v___x_647_, 1, v___x_645_);
return v___x_647_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__6(void){
_start:
{
lean_object* v___x_648_; lean_object* v___x_649_; lean_object* v___x_650_; 
v___x_648_ = lean_obj_once(&l_MachineRuntime_model___closed__5, &l_MachineRuntime_model___closed__5_once, _init_l_MachineRuntime_model___closed__5);
v___x_649_ = l_MachineRuntime_rule__8;
v___x_650_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_650_, 0, v___x_649_);
lean_ctor_set(v___x_650_, 1, v___x_648_);
return v___x_650_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__7(void){
_start:
{
lean_object* v___x_651_; lean_object* v___x_652_; lean_object* v___x_653_; 
v___x_651_ = lean_obj_once(&l_MachineRuntime_model___closed__6, &l_MachineRuntime_model___closed__6_once, _init_l_MachineRuntime_model___closed__6);
v___x_652_ = ((lean_object*)(l_MachineRuntime_rule__7));
v___x_653_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_653_, 0, v___x_652_);
lean_ctor_set(v___x_653_, 1, v___x_651_);
return v___x_653_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__8(void){
_start:
{
lean_object* v___x_654_; lean_object* v___x_655_; lean_object* v___x_656_; 
v___x_654_ = lean_obj_once(&l_MachineRuntime_model___closed__7, &l_MachineRuntime_model___closed__7_once, _init_l_MachineRuntime_model___closed__7);
v___x_655_ = ((lean_object*)(l_MachineRuntime_rule__6));
v___x_656_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_656_, 0, v___x_655_);
lean_ctor_set(v___x_656_, 1, v___x_654_);
return v___x_656_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__9(void){
_start:
{
lean_object* v___x_657_; lean_object* v___x_658_; lean_object* v___x_659_; 
v___x_657_ = lean_obj_once(&l_MachineRuntime_model___closed__8, &l_MachineRuntime_model___closed__8_once, _init_l_MachineRuntime_model___closed__8);
v___x_658_ = l_MachineRuntime_rule__5;
v___x_659_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_659_, 0, v___x_658_);
lean_ctor_set(v___x_659_, 1, v___x_657_);
return v___x_659_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__10(void){
_start:
{
lean_object* v___x_660_; lean_object* v___x_661_; lean_object* v___x_662_; 
v___x_660_ = lean_obj_once(&l_MachineRuntime_model___closed__9, &l_MachineRuntime_model___closed__9_once, _init_l_MachineRuntime_model___closed__9);
v___x_661_ = l_MachineRuntime_rule__4;
v___x_662_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_662_, 0, v___x_661_);
lean_ctor_set(v___x_662_, 1, v___x_660_);
return v___x_662_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__11(void){
_start:
{
lean_object* v___x_663_; lean_object* v___x_664_; lean_object* v___x_665_; 
v___x_663_ = lean_obj_once(&l_MachineRuntime_model___closed__10, &l_MachineRuntime_model___closed__10_once, _init_l_MachineRuntime_model___closed__10);
v___x_664_ = l_MachineRuntime_rule__3;
v___x_665_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_665_, 0, v___x_664_);
lean_ctor_set(v___x_665_, 1, v___x_663_);
return v___x_665_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__12(void){
_start:
{
lean_object* v___x_666_; lean_object* v___x_667_; lean_object* v___x_668_; 
v___x_666_ = lean_obj_once(&l_MachineRuntime_model___closed__11, &l_MachineRuntime_model___closed__11_once, _init_l_MachineRuntime_model___closed__11);
v___x_667_ = l_MachineRuntime_rule__2;
v___x_668_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_668_, 0, v___x_667_);
lean_ctor_set(v___x_668_, 1, v___x_666_);
return v___x_668_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__13(void){
_start:
{
lean_object* v___x_669_; lean_object* v___x_670_; lean_object* v___x_671_; 
v___x_669_ = lean_obj_once(&l_MachineRuntime_model___closed__12, &l_MachineRuntime_model___closed__12_once, _init_l_MachineRuntime_model___closed__12);
v___x_670_ = l_MachineRuntime_rule__1;
v___x_671_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_671_, 0, v___x_670_);
lean_ctor_set(v___x_671_, 1, v___x_669_);
return v___x_671_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__14(void){
_start:
{
lean_object* v___x_672_; lean_object* v___x_673_; lean_object* v___x_674_; 
v___x_672_ = lean_obj_once(&l_MachineRuntime_model___closed__13, &l_MachineRuntime_model___closed__13_once, _init_l_MachineRuntime_model___closed__13);
v___x_673_ = l_MachineRuntime_rule__0;
v___x_674_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_674_, 0, v___x_673_);
lean_ctor_set(v___x_674_, 1, v___x_672_);
return v___x_674_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__15(void){
_start:
{
lean_object* v___x_675_; lean_object* v___x_676_; lean_object* v___x_677_; 
v___x_675_ = lean_box(0);
v___x_676_ = l_MachineRuntime_e39;
v___x_677_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_677_, 0, v___x_676_);
lean_ctor_set(v___x_677_, 1, v___x_675_);
return v___x_677_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__16(void){
_start:
{
lean_object* v___x_678_; lean_object* v___x_679_; lean_object* v___x_680_; 
v___x_678_ = lean_obj_once(&l_MachineRuntime_model___closed__15, &l_MachineRuntime_model___closed__15_once, _init_l_MachineRuntime_model___closed__15);
v___x_679_ = l_MachineRuntime_e36;
v___x_680_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_680_, 0, v___x_679_);
lean_ctor_set(v___x_680_, 1, v___x_678_);
return v___x_680_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__26(void){
_start:
{
lean_object* v___x_708_; lean_object* v___f_709_; lean_object* v___x_710_; lean_object* v___x_711_; lean_object* v___x_712_; 
v___x_708_ = ((lean_object*)(l_MachineRuntime_model___closed__25));
v___f_709_ = ((lean_object*)(l_MachineRuntime_model___closed__0));
v___x_710_ = lean_obj_once(&l_MachineRuntime_model___closed__16, &l_MachineRuntime_model___closed__16_once, _init_l_MachineRuntime_model___closed__16);
v___x_711_ = lean_obj_once(&l_MachineRuntime_model___closed__14, &l_MachineRuntime_model___closed__14_once, _init_l_MachineRuntime_model___closed__14);
v___x_712_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_712_, 0, v___x_711_);
lean_ctor_set(v___x_712_, 1, v___x_710_);
lean_ctor_set(v___x_712_, 2, v___f_709_);
lean_ctor_set(v___x_712_, 3, v___x_708_);
return v___x_712_;
}
}
static lean_object* _init_l_MachineRuntime_model(void){
_start:
{
lean_object* v___x_713_; 
v___x_713_ = lean_obj_once(&l_MachineRuntime_model___closed__26, &l_MachineRuntime_model___closed__26_once, _init_l_MachineRuntime_model___closed__26);
return v___x_713_;
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_eventSchemas(lean_object* v_n_724_){
_start:
{
lean_object* v___x_725_; uint8_t v___x_726_; 
v___x_725_ = lean_unsigned_to_nat(0u);
v___x_726_ = lean_nat_dec_eq(v_n_724_, v___x_725_);
if (v___x_726_ == 0)
{
lean_object* v___x_727_; uint8_t v___x_728_; 
v___x_727_ = lean_unsigned_to_nat(1u);
v___x_728_ = lean_nat_dec_eq(v_n_724_, v___x_727_);
if (v___x_728_ == 0)
{
lean_object* v___x_729_; 
v___x_729_ = lean_box(0);
return v___x_729_;
}
else
{
lean_object* v___x_730_; 
v___x_730_ = ((lean_object*)(l_MachineRuntime_eventSchemas___closed__0));
return v___x_730_;
}
}
else
{
lean_object* v___x_731_; 
v___x_731_ = ((lean_object*)(l_MachineRuntime_eventSchemas___closed__2));
return v___x_731_;
}
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_eventSchemas___boxed(lean_object* v_n_732_){
_start:
{
lean_object* v_res_733_; 
v_res_733_ = l_MachineRuntime_eventSchemas(v_n_732_);
lean_dec(v_n_732_);
return v_res_733_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_BatchObserve(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ModelMachine(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_BatchObserve(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_MachineRuntime_e0 = _init_l_MachineRuntime_e0();
lean_mark_persistent(l_MachineRuntime_e0);
l_MachineRuntime_e2 = _init_l_MachineRuntime_e2();
lean_mark_persistent(l_MachineRuntime_e2);
l_MachineRuntime_e4___closed__0___boxed__const__1 = _init_l_MachineRuntime_e4___closed__0___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__0___boxed__const__1);
l_MachineRuntime_e4___closed__1___boxed__const__1 = _init_l_MachineRuntime_e4___closed__1___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__1___boxed__const__1);
l_MachineRuntime_e4___closed__2___boxed__const__1 = _init_l_MachineRuntime_e4___closed__2___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__2___boxed__const__1);
l_MachineRuntime_e4___closed__4___boxed__const__1 = _init_l_MachineRuntime_e4___closed__4___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__4___boxed__const__1);
l_MachineRuntime_e4 = _init_l_MachineRuntime_e4();
lean_mark_persistent(l_MachineRuntime_e4);
l_MachineRuntime_e7 = _init_l_MachineRuntime_e7();
lean_mark_persistent(l_MachineRuntime_e7);
l_MachineRuntime_e9 = _init_l_MachineRuntime_e9();
lean_mark_persistent(l_MachineRuntime_e9);
l_MachineRuntime_e10 = _init_l_MachineRuntime_e10();
lean_mark_persistent(l_MachineRuntime_e10);
l_MachineRuntime_e12 = _init_l_MachineRuntime_e12();
lean_mark_persistent(l_MachineRuntime_e12);
l_MachineRuntime_e13___closed__0___boxed__const__1 = _init_l_MachineRuntime_e13___closed__0___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e13___closed__0___boxed__const__1);
l_MachineRuntime_e13___closed__1___boxed__const__1 = _init_l_MachineRuntime_e13___closed__1___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e13___closed__1___boxed__const__1);
l_MachineRuntime_e13___closed__2___boxed__const__1 = _init_l_MachineRuntime_e13___closed__2___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e13___closed__2___boxed__const__1);
l_MachineRuntime_e13 = _init_l_MachineRuntime_e13();
lean_mark_persistent(l_MachineRuntime_e13);
l_MachineRuntime_e20 = _init_l_MachineRuntime_e20();
lean_mark_persistent(l_MachineRuntime_e20);
l_MachineRuntime_e21 = _init_l_MachineRuntime_e21();
lean_mark_persistent(l_MachineRuntime_e21);
l_MachineRuntime_e23 = _init_l_MachineRuntime_e23();
lean_mark_persistent(l_MachineRuntime_e23);
l_MachineRuntime_e27 = _init_l_MachineRuntime_e27();
lean_mark_persistent(l_MachineRuntime_e27);
l_MachineRuntime_e28 = _init_l_MachineRuntime_e28();
lean_mark_persistent(l_MachineRuntime_e28);
l_MachineRuntime_e30 = _init_l_MachineRuntime_e30();
lean_mark_persistent(l_MachineRuntime_e30);
l_MachineRuntime_e33 = _init_l_MachineRuntime_e33();
lean_mark_persistent(l_MachineRuntime_e33);
l_MachineRuntime_e34 = _init_l_MachineRuntime_e34();
lean_mark_persistent(l_MachineRuntime_e34);
l_MachineRuntime_e35 = _init_l_MachineRuntime_e35();
lean_mark_persistent(l_MachineRuntime_e35);
l_MachineRuntime_e36 = _init_l_MachineRuntime_e36();
lean_mark_persistent(l_MachineRuntime_e36);
l_MachineRuntime_e38 = _init_l_MachineRuntime_e38();
lean_mark_persistent(l_MachineRuntime_e38);
l_MachineRuntime_e39 = _init_l_MachineRuntime_e39();
lean_mark_persistent(l_MachineRuntime_e39);
l_MachineRuntime_rule__0 = _init_l_MachineRuntime_rule__0();
lean_mark_persistent(l_MachineRuntime_rule__0);
l_MachineRuntime_rule__1 = _init_l_MachineRuntime_rule__1();
lean_mark_persistent(l_MachineRuntime_rule__1);
l_MachineRuntime_rule__2 = _init_l_MachineRuntime_rule__2();
lean_mark_persistent(l_MachineRuntime_rule__2);
l_MachineRuntime_rule__3 = _init_l_MachineRuntime_rule__3();
lean_mark_persistent(l_MachineRuntime_rule__3);
l_MachineRuntime_rule__4 = _init_l_MachineRuntime_rule__4();
lean_mark_persistent(l_MachineRuntime_rule__4);
l_MachineRuntime_rule__5 = _init_l_MachineRuntime_rule__5();
lean_mark_persistent(l_MachineRuntime_rule__5);
l_MachineRuntime_rule__8 = _init_l_MachineRuntime_rule__8();
lean_mark_persistent(l_MachineRuntime_rule__8);
l_MachineRuntime_rule__11 = _init_l_MachineRuntime_rule__11();
lean_mark_persistent(l_MachineRuntime_rule__11);
l_MachineRuntime_rule__12 = _init_l_MachineRuntime_rule__12();
lean_mark_persistent(l_MachineRuntime_rule__12);
l_MachineRuntime_rule__13 = _init_l_MachineRuntime_rule__13();
lean_mark_persistent(l_MachineRuntime_rule__13);
l_MachineRuntime_model = _init_l_MachineRuntime_model();
lean_mark_persistent(l_MachineRuntime_model);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
