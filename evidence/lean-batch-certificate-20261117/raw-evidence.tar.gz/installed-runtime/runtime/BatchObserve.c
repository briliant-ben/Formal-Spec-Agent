// Lean compiler output
// Module: BatchObserve
// Imports: public import Init public meta import Init public import BatchReplay public import MachineObserve public import StoreFacts
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_FormalSpecAgent_TypedIR_getValue(uint8_t, lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_MachineObserve_packed(uint8_t, lean_object*);
lean_object* l_FormalSpecAgent_MachineObserve_snapshot(lean_object*, lean_object*);
lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_outcome_spec__0(lean_object*, lean_object*);
uint8_t l_instDecidableEqProd___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqPacked___boxed(lean_object*, lean_object*);
uint8_t l_instDecidableEqList___redArg(lean_object*, lean_object*, lean_object*);
uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(lean_object*, lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(uint8_t);
lean_object* l_FormalSpecAgent_BatchMachine_rollback(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__2___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___closed__0;
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_BatchObserve_transition_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_transition(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_success_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_success_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_error_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_error_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_BatchObserve_outcome_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_outcome(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_outcome___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__0(lean_object* v___x_1_, lean_object* v___x_2_, lean_object* v_a_3_, lean_object* v_b_4_){
_start:
{
uint8_t v___x_5_; 
v___x_5_ = l_instDecidableEqProd___redArg(v___x_1_, v___x_2_, v_a_3_, v_b_4_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__0___boxed(lean_object* v___x_6_, lean_object* v___x_7_, lean_object* v_a_8_, lean_object* v_b_9_){
_start:
{
uint8_t v_res_10_; lean_object* v_r_11_; 
v_res_10_ = l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__0(v___x_6_, v___x_7_, v_a_8_, v_b_9_);
v_r_11_ = lean_box(v_res_10_);
return v_r_11_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__1(lean_object* v___f_12_, lean_object* v_a_13_, lean_object* v_b_14_){
_start:
{
uint8_t v___x_15_; 
v___x_15_ = l_instDecidableEqList___redArg(v___f_12_, v_a_13_, v_b_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__1___boxed(lean_object* v___f_16_, lean_object* v_a_17_, lean_object* v_b_18_){
_start:
{
uint8_t v_res_19_; lean_object* v_r_20_; 
v_res_19_ = l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__1(v___f_16_, v_a_17_, v_b_18_);
v_r_20_ = lean_box(v_res_19_);
return v_r_20_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__2(lean_object* v___x_21_, lean_object* v_a_22_, lean_object* v_b_23_){
_start:
{
lean_object* v___x_24_; lean_object* v___f_25_; lean_object* v___f_26_; uint8_t v___x_27_; 
v___x_24_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
lean_inc_ref(v___x_24_);
v___f_25_ = lean_alloc_closure((void*)(l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__0___boxed), 4, 2);
lean_closure_set(v___f_25_, 0, v___x_24_);
lean_closure_set(v___f_25_, 1, v___x_21_);
v___f_26_ = lean_alloc_closure((void*)(l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__1___boxed), 3, 1);
lean_closure_set(v___f_26_, 0, v___f_25_);
v___x_27_ = l_instDecidableEqProd___redArg(v___x_24_, v___f_26_, v_a_22_, v_b_23_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__2___boxed(lean_object* v___x_28_, lean_object* v_a_29_, lean_object* v_b_30_){
_start:
{
uint8_t v_res_31_; lean_object* v_r_32_; 
v_res_31_ = l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__2(v___x_28_, v_a_29_, v_b_30_);
v_r_32_ = lean_box(v_res_31_);
return v_r_32_;
}
}
static lean_object* _init_l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___closed__0(void){
_start:
{
lean_object* v___x_33_; lean_object* v___f_34_; 
v___x_33_ = lean_alloc_closure((void*)(l_FormalSpecAgent_MachineObserve_instDecidableEqPacked___boxed), 2, 0);
v___f_34_ = lean_alloc_closure((void*)(l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___lam__2___boxed), 3, 1);
lean_closure_set(v___f_34_, 0, v___x_33_);
return v___f_34_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq(lean_object* v_x_35_, lean_object* v_x_36_){
_start:
{
lean_object* v_rule_37_; lean_object* v_event_38_; lean_object* v_fields_39_; lean_object* v_after_40_; lean_object* v_emitted_41_; lean_object* v_rule_42_; lean_object* v_event_43_; lean_object* v_fields_44_; lean_object* v_after_45_; lean_object* v_emitted_46_; uint8_t v___x_47_; 
v_rule_37_ = lean_ctor_get(v_x_35_, 0);
lean_inc(v_rule_37_);
v_event_38_ = lean_ctor_get(v_x_35_, 1);
lean_inc(v_event_38_);
v_fields_39_ = lean_ctor_get(v_x_35_, 2);
lean_inc(v_fields_39_);
v_after_40_ = lean_ctor_get(v_x_35_, 3);
lean_inc_ref(v_after_40_);
v_emitted_41_ = lean_ctor_get(v_x_35_, 4);
lean_inc(v_emitted_41_);
lean_dec_ref(v_x_35_);
v_rule_42_ = lean_ctor_get(v_x_36_, 0);
lean_inc(v_rule_42_);
v_event_43_ = lean_ctor_get(v_x_36_, 1);
lean_inc(v_event_43_);
v_fields_44_ = lean_ctor_get(v_x_36_, 2);
lean_inc(v_fields_44_);
v_after_45_ = lean_ctor_get(v_x_36_, 3);
lean_inc_ref(v_after_45_);
v_emitted_46_ = lean_ctor_get(v_x_36_, 4);
lean_inc(v_emitted_46_);
lean_dec_ref(v_x_36_);
v___x_47_ = lean_nat_dec_eq(v_rule_37_, v_rule_42_);
lean_dec(v_rule_42_);
lean_dec(v_rule_37_);
if (v___x_47_ == 0)
{
lean_dec(v_emitted_46_);
lean_dec_ref(v_after_45_);
lean_dec(v_fields_44_);
lean_dec(v_event_43_);
lean_dec(v_emitted_41_);
lean_dec_ref(v_after_40_);
lean_dec(v_fields_39_);
lean_dec(v_event_38_);
return v___x_47_;
}
else
{
uint8_t v___x_48_; 
v___x_48_ = lean_nat_dec_eq(v_event_38_, v_event_43_);
lean_dec(v_event_43_);
lean_dec(v_event_38_);
if (v___x_48_ == 0)
{
lean_dec(v_emitted_46_);
lean_dec_ref(v_after_45_);
lean_dec(v_fields_44_);
lean_dec(v_emitted_41_);
lean_dec_ref(v_after_40_);
lean_dec(v_fields_39_);
return v___x_48_;
}
else
{
lean_object* v___x_49_; uint8_t v___x_50_; 
v___x_49_ = lean_alloc_closure((void*)(l_FormalSpecAgent_MachineObserve_instDecidableEqPacked___boxed), 2, 0);
v___x_50_ = l_instDecidableEqList___redArg(v___x_49_, v_fields_39_, v_fields_44_);
if (v___x_50_ == 0)
{
lean_dec(v_emitted_46_);
lean_dec_ref(v_after_45_);
lean_dec(v_emitted_41_);
lean_dec_ref(v_after_40_);
return v___x_50_;
}
else
{
uint8_t v___x_51_; 
v___x_51_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(v_after_40_, v_after_45_);
if (v___x_51_ == 0)
{
lean_dec(v_emitted_46_);
lean_dec(v_emitted_41_);
return v___x_51_;
}
else
{
lean_object* v___f_52_; uint8_t v___x_53_; 
v___f_52_ = lean_obj_once(&l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___closed__0, &l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___closed__0_once, _init_l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___closed__0);
v___x_53_ = l_instDecidableEqList___redArg(v___f_52_, v_emitted_41_, v_emitted_46_);
return v___x_53_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq___boxed(lean_object* v_x_54_, lean_object* v_x_55_){
_start:
{
uint8_t v_res_56_; lean_object* v_r_57_; 
v_res_56_ = l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq(v_x_54_, v_x_55_);
v_r_57_ = lean_box(v_res_56_);
return v_r_57_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition(lean_object* v_x_58_, lean_object* v_x_59_){
_start:
{
uint8_t v___x_60_; 
v___x_60_ = l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition_decEq(v_x_58_, v_x_59_);
return v___x_60_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition___boxed(lean_object* v_x_61_, lean_object* v_x_62_){
_start:
{
uint8_t v_res_63_; lean_object* v_r_64_; 
v_res_63_ = l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition(v_x_61_, v_x_62_);
v_r_64_ = lean_box(v_res_63_);
return v_r_64_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_BatchObserve_transition_spec__0(lean_object* v_t_65_, lean_object* v_a_66_, lean_object* v_a_67_){
_start:
{
if (lean_obj_tag(v_a_66_) == 0)
{
lean_object* v___x_68_; 
lean_dec_ref(v_t_65_);
v___x_68_ = l_List_reverse___redArg(v_a_67_);
return v___x_68_;
}
else
{
lean_object* v_head_69_; lean_object* v_tail_70_; lean_object* v___x_72_; uint8_t v_isShared_73_; uint8_t v_isSharedCheck_85_; 
v_head_69_ = lean_ctor_get(v_a_66_, 0);
v_tail_70_ = lean_ctor_get(v_a_66_, 1);
v_isSharedCheck_85_ = !lean_is_exclusive(v_a_66_);
if (v_isSharedCheck_85_ == 0)
{
v___x_72_ = v_a_66_;
v_isShared_73_ = v_isSharedCheck_85_;
goto v_resetjp_71_;
}
else
{
lean_inc(v_tail_70_);
lean_inc(v_head_69_);
lean_dec(v_a_66_);
v___x_72_ = lean_box(0);
v_isShared_73_ = v_isSharedCheck_85_;
goto v_resetjp_71_;
}
v_resetjp_71_:
{
lean_object* v_fst_74_; lean_object* v_snd_75_; lean_object* v_fields_76_; uint8_t v___x_77_; lean_object* v___x_78_; uint8_t v___x_79_; lean_object* v___x_80_; lean_object* v___x_82_; 
v_fst_74_ = lean_ctor_get(v_head_69_, 0);
lean_inc(v_fst_74_);
v_snd_75_ = lean_ctor_get(v_head_69_, 1);
lean_inc(v_snd_75_);
lean_dec(v_head_69_);
v_fields_76_ = lean_ctor_get(v_t_65_, 3);
v___x_77_ = lean_unbox(v_fst_74_);
lean_inc_ref(v_fields_76_);
v___x_78_ = l_FormalSpecAgent_TypedIR_getValue(v___x_77_, v_fields_76_, v_snd_75_);
v___x_79_ = lean_unbox(v_fst_74_);
lean_dec(v_fst_74_);
v___x_80_ = l_FormalSpecAgent_MachineObserve_packed(v___x_79_, v___x_78_);
if (v_isShared_73_ == 0)
{
lean_ctor_set(v___x_72_, 1, v_a_67_);
lean_ctor_set(v___x_72_, 0, v___x_80_);
v___x_82_ = v___x_72_;
goto v_reusejp_81_;
}
else
{
lean_object* v_reuseFailAlloc_84_; 
v_reuseFailAlloc_84_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_84_, 0, v___x_80_);
lean_ctor_set(v_reuseFailAlloc_84_, 1, v_a_67_);
v___x_82_ = v_reuseFailAlloc_84_;
goto v_reusejp_81_;
}
v_reusejp_81_:
{
v_a_66_ = v_tail_70_;
v_a_67_ = v___x_82_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_transition(lean_object* v_schema_86_, lean_object* v_eventSchemas_87_, lean_object* v_t_88_){
_start:
{
lean_object* v_after_89_; lean_object* v_rule_90_; lean_object* v_event_91_; lean_object* v_emitted_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; 
v_after_89_ = lean_ctor_get(v_t_88_, 0);
lean_inc_ref(v_after_89_);
v_rule_90_ = lean_ctor_get(v_t_88_, 1);
lean_inc(v_rule_90_);
v_event_91_ = lean_ctor_get(v_t_88_, 2);
lean_inc_n(v_event_91_, 2);
v_emitted_92_ = lean_ctor_get(v_t_88_, 4);
lean_inc(v_emitted_92_);
v___x_93_ = lean_apply_1(v_eventSchemas_87_, v_event_91_);
v___x_94_ = lean_box(0);
v___x_95_ = l_List_mapTR_loop___at___00FormalSpecAgent_BatchObserve_transition_spec__0(v_t_88_, v___x_93_, v___x_94_);
v___x_96_ = l_FormalSpecAgent_MachineObserve_snapshot(v_schema_86_, v_after_89_);
v___x_97_ = l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_outcome_spec__0(v_emitted_92_, v___x_94_);
v___x_98_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_98_, 0, v_rule_90_);
lean_ctor_set(v___x_98_, 1, v_event_91_);
lean_ctor_set(v___x_98_, 2, v___x_95_);
lean_ctor_set(v___x_98_, 3, v___x_96_);
lean_ctor_set(v___x_98_, 4, v___x_97_);
return v___x_98_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorIdx(lean_object* v_x_99_){
_start:
{
if (lean_obj_tag(v_x_99_) == 0)
{
lean_object* v___x_100_; 
v___x_100_ = lean_unsigned_to_nat(0u);
return v___x_100_;
}
else
{
lean_object* v___x_101_; 
v___x_101_ = lean_unsigned_to_nat(1u);
return v___x_101_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorIdx___boxed(lean_object* v_x_102_){
_start:
{
lean_object* v_res_103_; 
v_res_103_ = l_FormalSpecAgent_BatchObserve_Outcome_ctorIdx(v_x_102_);
lean_dec_ref(v_x_102_);
return v_res_103_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___redArg(lean_object* v_t_104_, lean_object* v_k_105_){
_start:
{
if (lean_obj_tag(v_t_104_) == 0)
{
lean_object* v_a_106_; lean_object* v_a_107_; lean_object* v___x_108_; 
v_a_106_ = lean_ctor_get(v_t_104_, 0);
lean_inc_ref(v_a_106_);
v_a_107_ = lean_ctor_get(v_t_104_, 1);
lean_inc(v_a_107_);
lean_dec_ref_known(v_t_104_, 2);
v___x_108_ = lean_apply_2(v_k_105_, v_a_106_, v_a_107_);
return v___x_108_;
}
else
{
uint8_t v_a_109_; lean_object* v_a_110_; lean_object* v___x_111_; lean_object* v___x_112_; 
v_a_109_ = lean_ctor_get_uint8(v_t_104_, sizeof(void*)*1);
v_a_110_ = lean_ctor_get(v_t_104_, 0);
lean_inc_ref(v_a_110_);
lean_dec_ref_known(v_t_104_, 1);
v___x_111_ = lean_box(v_a_109_);
v___x_112_ = lean_apply_2(v_k_105_, v___x_111_, v_a_110_);
return v___x_112_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorElim(lean_object* v_motive_113_, lean_object* v_ctorIdx_114_, lean_object* v_t_115_, lean_object* v_h_116_, lean_object* v_k_117_){
_start:
{
lean_object* v___x_118_; 
v___x_118_ = l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___redArg(v_t_115_, v_k_117_);
return v___x_118_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___boxed(lean_object* v_motive_119_, lean_object* v_ctorIdx_120_, lean_object* v_t_121_, lean_object* v_h_122_, lean_object* v_k_123_){
_start:
{
lean_object* v_res_124_; 
v_res_124_ = l_FormalSpecAgent_BatchObserve_Outcome_ctorElim(v_motive_119_, v_ctorIdx_120_, v_t_121_, v_h_122_, v_k_123_);
lean_dec(v_ctorIdx_120_);
return v_res_124_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_success_elim___redArg(lean_object* v_t_125_, lean_object* v_success_126_){
_start:
{
lean_object* v___x_127_; 
v___x_127_ = l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___redArg(v_t_125_, v_success_126_);
return v___x_127_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_success_elim(lean_object* v_motive_128_, lean_object* v_t_129_, lean_object* v_h_130_, lean_object* v_success_131_){
_start:
{
lean_object* v___x_132_; 
v___x_132_ = l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___redArg(v_t_129_, v_success_131_);
return v___x_132_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_error_elim___redArg(lean_object* v_t_133_, lean_object* v_error_134_){
_start:
{
lean_object* v___x_135_; 
v___x_135_ = l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___redArg(v_t_133_, v_error_134_);
return v___x_135_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_Outcome_error_elim(lean_object* v_motive_136_, lean_object* v_t_137_, lean_object* v_h_138_, lean_object* v_error_139_){
_start:
{
lean_object* v___x_140_; 
v___x_140_ = l_FormalSpecAgent_BatchObserve_Outcome_ctorElim___redArg(v_t_137_, v_error_139_);
return v___x_140_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome_decEq(lean_object* v_x_141_, lean_object* v_x_142_){
_start:
{
if (lean_obj_tag(v_x_141_) == 0)
{
if (lean_obj_tag(v_x_142_) == 0)
{
lean_object* v_a_143_; lean_object* v_a_144_; lean_object* v_a_145_; lean_object* v_a_146_; uint8_t v___x_147_; 
v_a_143_ = lean_ctor_get(v_x_141_, 0);
lean_inc_ref(v_a_143_);
v_a_144_ = lean_ctor_get(v_x_141_, 1);
lean_inc(v_a_144_);
lean_dec_ref_known(v_x_141_, 2);
v_a_145_ = lean_ctor_get(v_x_142_, 0);
lean_inc_ref(v_a_145_);
v_a_146_ = lean_ctor_get(v_x_142_, 1);
lean_inc(v_a_146_);
lean_dec_ref_known(v_x_142_, 2);
v___x_147_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(v_a_143_, v_a_145_);
if (v___x_147_ == 0)
{
lean_dec(v_a_146_);
lean_dec(v_a_144_);
return v___x_147_;
}
else
{
lean_object* v___x_148_; uint8_t v___x_149_; 
v___x_148_ = lean_alloc_closure((void*)(l_FormalSpecAgent_BatchObserve_instDecidableEqSeenTransition___boxed), 2, 0);
v___x_149_ = l_instDecidableEqList___redArg(v___x_148_, v_a_144_, v_a_146_);
return v___x_149_;
}
}
else
{
uint8_t v___x_150_; 
lean_dec_ref_known(v_x_142_, 1);
lean_dec_ref_known(v_x_141_, 2);
v___x_150_ = 0;
return v___x_150_;
}
}
else
{
if (lean_obj_tag(v_x_142_) == 0)
{
uint8_t v___x_151_; 
lean_dec_ref_known(v_x_142_, 2);
lean_dec_ref_known(v_x_141_, 1);
v___x_151_ = 0;
return v___x_151_;
}
else
{
uint8_t v_a_152_; lean_object* v_a_153_; uint8_t v_a_154_; lean_object* v_a_155_; lean_object* v___x_156_; lean_object* v___x_157_; uint8_t v___x_158_; 
v_a_152_ = lean_ctor_get_uint8(v_x_141_, sizeof(void*)*1);
v_a_153_ = lean_ctor_get(v_x_141_, 0);
lean_inc_ref(v_a_153_);
lean_dec_ref_known(v_x_141_, 1);
v_a_154_ = lean_ctor_get_uint8(v_x_142_, sizeof(void*)*1);
v_a_155_ = lean_ctor_get(v_x_142_, 0);
lean_inc_ref(v_a_155_);
lean_dec_ref_known(v_x_142_, 1);
v___x_156_ = l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(v_a_152_);
v___x_157_ = l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(v_a_154_);
v___x_158_ = lean_nat_dec_eq(v___x_156_, v___x_157_);
lean_dec(v___x_157_);
lean_dec(v___x_156_);
if (v___x_158_ == 0)
{
lean_dec_ref(v_a_155_);
lean_dec_ref(v_a_153_);
return v___x_158_;
}
else
{
uint8_t v___x_159_; 
v___x_159_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(v_a_153_, v_a_155_);
return v___x_159_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome_decEq___boxed(lean_object* v_x_160_, lean_object* v_x_161_){
_start:
{
uint8_t v_res_162_; lean_object* v_r_163_; 
v_res_162_ = l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome_decEq(v_x_160_, v_x_161_);
v_r_163_ = lean_box(v_res_162_);
return v_r_163_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome(lean_object* v_x_164_, lean_object* v_x_165_){
_start:
{
uint8_t v___x_166_; 
v___x_166_ = l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome_decEq(v_x_164_, v_x_165_);
return v___x_166_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome___boxed(lean_object* v_x_167_, lean_object* v_x_168_){
_start:
{
uint8_t v_res_169_; lean_object* v_r_170_; 
v_res_169_ = l_FormalSpecAgent_BatchObserve_instDecidableEqOutcome(v_x_167_, v_x_168_);
v_r_170_ = lean_box(v_res_169_);
return v_r_170_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_BatchObserve_outcome_spec__0(lean_object* v_schema_171_, lean_object* v_eventSchemas_172_, lean_object* v_a_173_, lean_object* v_a_174_){
_start:
{
if (lean_obj_tag(v_a_173_) == 0)
{
lean_object* v___x_175_; 
lean_dec_ref(v_eventSchemas_172_);
lean_dec(v_schema_171_);
v___x_175_ = l_List_reverse___redArg(v_a_174_);
return v___x_175_;
}
else
{
lean_object* v_head_176_; lean_object* v_tail_177_; lean_object* v___x_179_; uint8_t v_isShared_180_; uint8_t v_isSharedCheck_186_; 
v_head_176_ = lean_ctor_get(v_a_173_, 0);
v_tail_177_ = lean_ctor_get(v_a_173_, 1);
v_isSharedCheck_186_ = !lean_is_exclusive(v_a_173_);
if (v_isSharedCheck_186_ == 0)
{
v___x_179_ = v_a_173_;
v_isShared_180_ = v_isSharedCheck_186_;
goto v_resetjp_178_;
}
else
{
lean_inc(v_tail_177_);
lean_inc(v_head_176_);
lean_dec(v_a_173_);
v___x_179_ = lean_box(0);
v_isShared_180_ = v_isSharedCheck_186_;
goto v_resetjp_178_;
}
v_resetjp_178_:
{
lean_object* v___x_181_; lean_object* v___x_183_; 
lean_inc_ref(v_eventSchemas_172_);
lean_inc(v_schema_171_);
v___x_181_ = l_FormalSpecAgent_BatchObserve_transition(v_schema_171_, v_eventSchemas_172_, v_head_176_);
if (v_isShared_180_ == 0)
{
lean_ctor_set(v___x_179_, 1, v_a_174_);
lean_ctor_set(v___x_179_, 0, v___x_181_);
v___x_183_ = v___x_179_;
goto v_reusejp_182_;
}
else
{
lean_object* v_reuseFailAlloc_185_; 
v_reuseFailAlloc_185_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_185_, 0, v___x_181_);
lean_ctor_set(v_reuseFailAlloc_185_, 1, v_a_174_);
v___x_183_ = v_reuseFailAlloc_185_;
goto v_reusejp_182_;
}
v_reusejp_182_:
{
v_a_173_ = v_tail_177_;
v_a_174_ = v___x_183_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_outcome(lean_object* v_schema_187_, lean_object* v_eventSchemas_188_, lean_object* v_initial_189_, lean_object* v_result_190_){
_start:
{
if (lean_obj_tag(v_result_190_) == 0)
{
lean_object* v_a_191_; lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; uint8_t v___x_195_; 
lean_dec_ref(v_eventSchemas_188_);
v_a_191_ = lean_ctor_get(v_result_190_, 0);
lean_inc(v_a_191_);
v___x_192_ = l_FormalSpecAgent_BatchMachine_rollback(v_initial_189_, v_result_190_);
lean_dec_ref_known(v_result_190_, 1);
v___x_193_ = l_FormalSpecAgent_MachineObserve_snapshot(v_schema_187_, v___x_192_);
v___x_194_ = lean_alloc_ctor(1, 1, 1);
lean_ctor_set(v___x_194_, 0, v___x_193_);
v___x_195_ = lean_unbox(v_a_191_);
lean_dec(v_a_191_);
lean_ctor_set_uint8(v___x_194_, sizeof(void*)*1, v___x_195_);
return v___x_194_;
}
else
{
lean_object* v_a_196_; lean_object* v_after_197_; lean_object* v_trace_198_; lean_object* v___x_200_; uint8_t v_isShared_201_; uint8_t v_isSharedCheck_208_; 
v_a_196_ = lean_ctor_get(v_result_190_, 0);
lean_inc(v_a_196_);
lean_dec_ref_known(v_result_190_, 1);
v_after_197_ = lean_ctor_get(v_a_196_, 0);
v_trace_198_ = lean_ctor_get(v_a_196_, 1);
v_isSharedCheck_208_ = !lean_is_exclusive(v_a_196_);
if (v_isSharedCheck_208_ == 0)
{
v___x_200_ = v_a_196_;
v_isShared_201_ = v_isSharedCheck_208_;
goto v_resetjp_199_;
}
else
{
lean_inc(v_trace_198_);
lean_inc(v_after_197_);
lean_dec(v_a_196_);
v___x_200_ = lean_box(0);
v_isShared_201_ = v_isSharedCheck_208_;
goto v_resetjp_199_;
}
v_resetjp_199_:
{
lean_object* v___x_202_; lean_object* v___x_203_; lean_object* v___x_204_; lean_object* v___x_206_; 
lean_inc(v_schema_187_);
v___x_202_ = l_FormalSpecAgent_MachineObserve_snapshot(v_schema_187_, v_after_197_);
v___x_203_ = lean_box(0);
v___x_204_ = l_List_mapTR_loop___at___00FormalSpecAgent_BatchObserve_outcome_spec__0(v_schema_187_, v_eventSchemas_188_, v_trace_198_, v___x_203_);
if (v_isShared_201_ == 0)
{
lean_ctor_set(v___x_200_, 1, v___x_204_);
lean_ctor_set(v___x_200_, 0, v___x_202_);
v___x_206_ = v___x_200_;
goto v_reusejp_205_;
}
else
{
lean_object* v_reuseFailAlloc_207_; 
v_reuseFailAlloc_207_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_207_, 0, v___x_202_);
lean_ctor_set(v_reuseFailAlloc_207_, 1, v___x_204_);
v___x_206_ = v_reuseFailAlloc_207_;
goto v_reusejp_205_;
}
v_reusejp_205_:
{
return v___x_206_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchObserve_outcome___boxed(lean_object* v_schema_209_, lean_object* v_eventSchemas_210_, lean_object* v_initial_211_, lean_object* v_result_212_){
_start:
{
lean_object* v_res_213_; 
v_res_213_ = l_FormalSpecAgent_BatchObserve_outcome(v_schema_209_, v_eventSchemas_210_, v_initial_211_, v_result_212_);
lean_dec_ref(v_initial_211_);
return v_res_213_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_BatchReplay(uint8_t builtin);
lean_object* initialize_MachineObserve(uint8_t builtin);
lean_object* initialize_StoreFacts(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_BatchObserve(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_BatchReplay(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_MachineObserve(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_StoreFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
