// Lean compiler output
// Module: BatchMachine
// Imports: public import Init public meta import Init public import TimerProgress
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_int_dec_le(lean_object*, lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_nextTimer(lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_stepTimer(lean_object*, lean_object*, lean_object*);
uint8_t l_FormalSpecAgent_TypedMachine_invariantsHold(lean_object*, lean_object*);
uint8_t l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_external(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00FormalSpecAgent_BatchMachine_advance_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00FormalSpecAgent_BatchMachine_advance_spec__0___boxed(lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_BatchMachine_advance___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_BatchMachine_advance___closed__0 = (const lean_object*)&l_FormalSpecAgent_BatchMachine_advance___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advance(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_BatchMachine_tick___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_BatchMachine_tick___closed__0 = (const lean_object*)&l_FormalSpecAgent_BatchMachine_tick___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_tick(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_BatchMachine_dispatch___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_BatchMachine_dispatch___closed__0 = (const lean_object*)&l_FormalSpecAgent_BatchMachine_dispatch___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_dispatch(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux___redArg(lean_object* v_model_1_, lean_object* v_snapshot_2_, lean_object* v_limit_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = l_FormalSpecAgent_TypedMachine_nextTimer(v_snapshot_2_);
if (lean_obj_tag(v___x_4_) == 0)
{
lean_object* v_values_5_; lean_object* v_state_6_; lean_object* v_timers_7_; lean_object* v___x_9_; uint8_t v_isShared_10_; uint8_t v_isSharedCheck_17_; 
lean_dec_ref(v_model_1_);
v_values_5_ = lean_ctor_get(v_snapshot_2_, 0);
v_state_6_ = lean_ctor_get(v_snapshot_2_, 1);
v_timers_7_ = lean_ctor_get(v_snapshot_2_, 3);
v_isSharedCheck_17_ = !lean_is_exclusive(v_snapshot_2_);
if (v_isSharedCheck_17_ == 0)
{
lean_object* v_unused_18_; 
v_unused_18_ = lean_ctor_get(v_snapshot_2_, 2);
lean_dec(v_unused_18_);
v___x_9_ = v_snapshot_2_;
v_isShared_10_ = v_isSharedCheck_17_;
goto v_resetjp_8_;
}
else
{
lean_inc(v_timers_7_);
lean_inc(v_state_6_);
lean_inc(v_values_5_);
lean_dec(v_snapshot_2_);
v___x_9_ = lean_box(0);
v_isShared_10_ = v_isSharedCheck_17_;
goto v_resetjp_8_;
}
v_resetjp_8_:
{
lean_object* v___x_12_; 
if (v_isShared_10_ == 0)
{
lean_ctor_set(v___x_9_, 2, v_limit_3_);
v___x_12_ = v___x_9_;
goto v_reusejp_11_;
}
else
{
lean_object* v_reuseFailAlloc_16_; 
v_reuseFailAlloc_16_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_16_, 0, v_values_5_);
lean_ctor_set(v_reuseFailAlloc_16_, 1, v_state_6_);
lean_ctor_set(v_reuseFailAlloc_16_, 2, v_limit_3_);
lean_ctor_set(v_reuseFailAlloc_16_, 3, v_timers_7_);
v___x_12_ = v_reuseFailAlloc_16_;
goto v_reusejp_11_;
}
v_reusejp_11_:
{
lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v___x_15_; 
v___x_13_ = lean_box(0);
v___x_14_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_14_, 0, v___x_12_);
lean_ctor_set(v___x_14_, 1, v___x_13_);
v___x_15_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_15_, 0, v___x_14_);
return v___x_15_;
}
}
}
else
{
lean_object* v_val_19_; lean_object* v___x_21_; uint8_t v_isShared_22_; uint8_t v_isSharedCheck_80_; 
v_val_19_ = lean_ctor_get(v___x_4_, 0);
v_isSharedCheck_80_ = !lean_is_exclusive(v___x_4_);
if (v_isSharedCheck_80_ == 0)
{
v___x_21_ = v___x_4_;
v_isShared_22_ = v_isSharedCheck_80_;
goto v_resetjp_20_;
}
else
{
lean_inc(v_val_19_);
lean_dec(v___x_4_);
v___x_21_ = lean_box(0);
v_isShared_22_ = v_isSharedCheck_80_;
goto v_resetjp_20_;
}
v_resetjp_20_:
{
lean_object* v_due_23_; lean_object* v___x_25_; uint8_t v_isShared_26_; uint8_t v_isSharedCheck_78_; 
v_due_23_ = lean_ctor_get(v_val_19_, 1);
v_isSharedCheck_78_ = !lean_is_exclusive(v_val_19_);
if (v_isSharedCheck_78_ == 0)
{
lean_object* v_unused_79_; 
v_unused_79_ = lean_ctor_get(v_val_19_, 0);
lean_dec(v_unused_79_);
v___x_25_ = v_val_19_;
v_isShared_26_ = v_isSharedCheck_78_;
goto v_resetjp_24_;
}
else
{
lean_inc(v_due_23_);
lean_dec(v_val_19_);
v___x_25_ = lean_box(0);
v_isShared_26_ = v_isSharedCheck_78_;
goto v_resetjp_24_;
}
v_resetjp_24_:
{
uint8_t v___x_27_; 
v___x_27_ = lean_int_dec_le(v_due_23_, v_limit_3_);
if (v___x_27_ == 0)
{
lean_object* v_values_28_; lean_object* v_state_29_; lean_object* v_timers_30_; lean_object* v___x_32_; uint8_t v_isShared_33_; uint8_t v_isSharedCheck_44_; 
lean_dec(v_due_23_);
lean_dec_ref(v_model_1_);
v_values_28_ = lean_ctor_get(v_snapshot_2_, 0);
v_state_29_ = lean_ctor_get(v_snapshot_2_, 1);
v_timers_30_ = lean_ctor_get(v_snapshot_2_, 3);
v_isSharedCheck_44_ = !lean_is_exclusive(v_snapshot_2_);
if (v_isSharedCheck_44_ == 0)
{
lean_object* v_unused_45_; 
v_unused_45_ = lean_ctor_get(v_snapshot_2_, 2);
lean_dec(v_unused_45_);
v___x_32_ = v_snapshot_2_;
v_isShared_33_ = v_isSharedCheck_44_;
goto v_resetjp_31_;
}
else
{
lean_inc(v_timers_30_);
lean_inc(v_state_29_);
lean_inc(v_values_28_);
lean_dec(v_snapshot_2_);
v___x_32_ = lean_box(0);
v_isShared_33_ = v_isSharedCheck_44_;
goto v_resetjp_31_;
}
v_resetjp_31_:
{
lean_object* v___x_35_; 
if (v_isShared_33_ == 0)
{
lean_ctor_set(v___x_32_, 2, v_limit_3_);
v___x_35_ = v___x_32_;
goto v_reusejp_34_;
}
else
{
lean_object* v_reuseFailAlloc_43_; 
v_reuseFailAlloc_43_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_43_, 0, v_values_28_);
lean_ctor_set(v_reuseFailAlloc_43_, 1, v_state_29_);
lean_ctor_set(v_reuseFailAlloc_43_, 2, v_limit_3_);
lean_ctor_set(v_reuseFailAlloc_43_, 3, v_timers_30_);
v___x_35_ = v_reuseFailAlloc_43_;
goto v_reusejp_34_;
}
v_reusejp_34_:
{
lean_object* v___x_36_; lean_object* v___x_38_; 
v___x_36_ = lean_box(0);
if (v_isShared_26_ == 0)
{
lean_ctor_set(v___x_25_, 1, v___x_36_);
lean_ctor_set(v___x_25_, 0, v___x_35_);
v___x_38_ = v___x_25_;
goto v_reusejp_37_;
}
else
{
lean_object* v_reuseFailAlloc_42_; 
v_reuseFailAlloc_42_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_42_, 0, v___x_35_);
lean_ctor_set(v_reuseFailAlloc_42_, 1, v___x_36_);
v___x_38_ = v_reuseFailAlloc_42_;
goto v_reusejp_37_;
}
v_reusejp_37_:
{
lean_object* v___x_40_; 
if (v_isShared_22_ == 0)
{
lean_ctor_set(v___x_21_, 0, v___x_38_);
v___x_40_ = v___x_21_;
goto v_reusejp_39_;
}
else
{
lean_object* v_reuseFailAlloc_41_; 
v_reuseFailAlloc_41_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_41_, 0, v___x_38_);
v___x_40_ = v_reuseFailAlloc_41_;
goto v_reusejp_39_;
}
v_reusejp_39_:
{
return v___x_40_;
}
}
}
}
}
else
{
lean_object* v___x_46_; 
lean_del_object(v___x_21_);
lean_inc_ref(v_model_1_);
v___x_46_ = l_FormalSpecAgent_TypedMachine_stepTimer(v_model_1_, v_snapshot_2_, v_due_23_);
if (lean_obj_tag(v___x_46_) == 0)
{
lean_object* v_a_47_; lean_object* v___x_49_; uint8_t v_isShared_50_; uint8_t v_isSharedCheck_54_; 
lean_del_object(v___x_25_);
lean_dec(v_limit_3_);
lean_dec_ref(v_model_1_);
v_a_47_ = lean_ctor_get(v___x_46_, 0);
v_isSharedCheck_54_ = !lean_is_exclusive(v___x_46_);
if (v_isSharedCheck_54_ == 0)
{
v___x_49_ = v___x_46_;
v_isShared_50_ = v_isSharedCheck_54_;
goto v_resetjp_48_;
}
else
{
lean_inc(v_a_47_);
lean_dec(v___x_46_);
v___x_49_ = lean_box(0);
v_isShared_50_ = v_isSharedCheck_54_;
goto v_resetjp_48_;
}
v_resetjp_48_:
{
lean_object* v___x_52_; 
if (v_isShared_50_ == 0)
{
v___x_52_ = v___x_49_;
goto v_reusejp_51_;
}
else
{
lean_object* v_reuseFailAlloc_53_; 
v_reuseFailAlloc_53_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_53_, 0, v_a_47_);
v___x_52_ = v_reuseFailAlloc_53_;
goto v_reusejp_51_;
}
v_reusejp_51_:
{
return v___x_52_;
}
}
}
else
{
lean_object* v_a_55_; lean_object* v_after_56_; lean_object* v___x_57_; 
v_a_55_ = lean_ctor_get(v___x_46_, 0);
lean_inc(v_a_55_);
lean_dec_ref_known(v___x_46_, 1);
v_after_56_ = lean_ctor_get(v_a_55_, 0);
lean_inc_ref(v_after_56_);
v___x_57_ = l_FormalSpecAgent_BatchMachine_advanceAux___redArg(v_model_1_, v_after_56_, v_limit_3_);
if (lean_obj_tag(v___x_57_) == 0)
{
lean_dec(v_a_55_);
lean_del_object(v___x_25_);
return v___x_57_;
}
else
{
lean_object* v_a_58_; lean_object* v___x_60_; uint8_t v_isShared_61_; uint8_t v_isSharedCheck_77_; 
v_a_58_ = lean_ctor_get(v___x_57_, 0);
v_isSharedCheck_77_ = !lean_is_exclusive(v___x_57_);
if (v_isSharedCheck_77_ == 0)
{
v___x_60_ = v___x_57_;
v_isShared_61_ = v_isSharedCheck_77_;
goto v_resetjp_59_;
}
else
{
lean_inc(v_a_58_);
lean_dec(v___x_57_);
v___x_60_ = lean_box(0);
v_isShared_61_ = v_isSharedCheck_77_;
goto v_resetjp_59_;
}
v_resetjp_59_:
{
lean_object* v_after_62_; lean_object* v_trace_63_; lean_object* v___x_65_; uint8_t v_isShared_66_; uint8_t v_isSharedCheck_76_; 
v_after_62_ = lean_ctor_get(v_a_58_, 0);
v_trace_63_ = lean_ctor_get(v_a_58_, 1);
v_isSharedCheck_76_ = !lean_is_exclusive(v_a_58_);
if (v_isSharedCheck_76_ == 0)
{
v___x_65_ = v_a_58_;
v_isShared_66_ = v_isSharedCheck_76_;
goto v_resetjp_64_;
}
else
{
lean_inc(v_trace_63_);
lean_inc(v_after_62_);
lean_dec(v_a_58_);
v___x_65_ = lean_box(0);
v_isShared_66_ = v_isSharedCheck_76_;
goto v_resetjp_64_;
}
v_resetjp_64_:
{
lean_object* v___x_68_; 
if (v_isShared_26_ == 0)
{
lean_ctor_set_tag(v___x_25_, 1);
lean_ctor_set(v___x_25_, 1, v_trace_63_);
lean_ctor_set(v___x_25_, 0, v_a_55_);
v___x_68_ = v___x_25_;
goto v_reusejp_67_;
}
else
{
lean_object* v_reuseFailAlloc_75_; 
v_reuseFailAlloc_75_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_75_, 0, v_a_55_);
lean_ctor_set(v_reuseFailAlloc_75_, 1, v_trace_63_);
v___x_68_ = v_reuseFailAlloc_75_;
goto v_reusejp_67_;
}
v_reusejp_67_:
{
lean_object* v___x_70_; 
if (v_isShared_66_ == 0)
{
lean_ctor_set(v___x_65_, 1, v___x_68_);
v___x_70_ = v___x_65_;
goto v_reusejp_69_;
}
else
{
lean_object* v_reuseFailAlloc_74_; 
v_reuseFailAlloc_74_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_74_, 0, v_after_62_);
lean_ctor_set(v_reuseFailAlloc_74_, 1, v___x_68_);
v___x_70_ = v_reuseFailAlloc_74_;
goto v_reusejp_69_;
}
v_reusejp_69_:
{
lean_object* v___x_72_; 
if (v_isShared_61_ == 0)
{
lean_ctor_set(v___x_60_, 0, v___x_70_);
v___x_72_ = v___x_60_;
goto v_reusejp_71_;
}
else
{
lean_object* v_reuseFailAlloc_73_; 
v_reuseFailAlloc_73_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_73_, 0, v___x_70_);
v___x_72_ = v_reuseFailAlloc_73_;
goto v_reusejp_71_;
}
v_reusejp_71_:
{
return v___x_72_;
}
}
}
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux(lean_object* v_model_81_, lean_object* v_snapshot_82_, lean_object* v_limit_83_, lean_object* v_hwell_84_, lean_object* v_hbound_85_){
_start:
{
lean_object* v___x_86_; 
v___x_86_ = l_FormalSpecAgent_BatchMachine_advanceAux___redArg(v_model_81_, v_snapshot_82_, v_limit_83_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter___redArg(lean_object* v_x_87_, lean_object* v_h__1_88_, lean_object* v_h__2_89_){
_start:
{
if (lean_obj_tag(v_x_87_) == 0)
{
lean_object* v___x_90_; 
lean_dec(v_h__2_89_);
v___x_90_ = lean_apply_1(v_h__1_88_, lean_box(0));
return v___x_90_;
}
else
{
lean_object* v_val_91_; lean_object* v___x_92_; 
lean_dec(v_h__1_88_);
v_val_91_ = lean_ctor_get(v_x_87_, 0);
lean_inc(v_val_91_);
lean_dec_ref_known(v_x_87_, 1);
v___x_92_ = lean_apply_2(v_h__2_89_, v_val_91_, lean_box(0));
return v___x_92_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter(lean_object* v_motive_93_, lean_object* v_x_94_, lean_object* v_h__1_95_, lean_object* v_h__2_96_){
_start:
{
if (lean_obj_tag(v_x_94_) == 0)
{
lean_object* v___x_97_; 
lean_dec(v_h__2_96_);
v___x_97_ = lean_apply_1(v_h__1_95_, lean_box(0));
return v___x_97_;
}
else
{
lean_object* v_val_98_; lean_object* v___x_99_; 
lean_dec(v_h__1_95_);
v_val_98_ = lean_ctor_get(v_x_94_, 0);
lean_inc(v_val_98_);
lean_dec_ref_known(v_x_94_, 1);
v___x_99_ = lean_apply_2(v_h__2_96_, v_val_98_, lean_box(0));
return v___x_99_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter___redArg(lean_object* v_x_100_, lean_object* v_h__1_101_, lean_object* v_h__2_102_){
_start:
{
if (lean_obj_tag(v_x_100_) == 0)
{
lean_object* v_a_103_; lean_object* v___x_104_; 
lean_dec(v_h__2_102_);
v_a_103_ = lean_ctor_get(v_x_100_, 0);
lean_inc(v_a_103_);
lean_dec_ref_known(v_x_100_, 1);
v___x_104_ = lean_apply_2(v_h__1_101_, v_a_103_, lean_box(0));
return v___x_104_;
}
else
{
lean_object* v_a_105_; lean_object* v___x_106_; 
lean_dec(v_h__1_101_);
v_a_105_ = lean_ctor_get(v_x_100_, 0);
lean_inc(v_a_105_);
lean_dec_ref_known(v_x_100_, 1);
v___x_106_ = lean_apply_2(v_h__2_102_, v_a_105_, lean_box(0));
return v___x_106_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter(lean_object* v_motive_107_, lean_object* v_x_108_, lean_object* v_h__1_109_, lean_object* v_h__2_110_){
_start:
{
if (lean_obj_tag(v_x_108_) == 0)
{
lean_object* v_a_111_; lean_object* v___x_112_; 
lean_dec(v_h__2_110_);
v_a_111_ = lean_ctor_get(v_x_108_, 0);
lean_inc(v_a_111_);
lean_dec_ref_known(v_x_108_, 1);
v___x_112_ = lean_apply_2(v_h__1_109_, v_a_111_, lean_box(0));
return v___x_112_;
}
else
{
lean_object* v_a_113_; lean_object* v___x_114_; 
lean_dec(v_h__1_109_);
v_a_113_ = lean_ctor_get(v_x_108_, 0);
lean_inc(v_a_113_);
lean_dec_ref_known(v_x_108_, 1);
v___x_114_ = lean_apply_2(v_h__2_110_, v_a_113_, lean_box(0));
return v___x_114_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter___redArg(lean_object* v_x_115_, lean_object* v_h__1_116_, lean_object* v_h__2_117_){
_start:
{
if (lean_obj_tag(v_x_115_) == 0)
{
lean_object* v_a_118_; lean_object* v___x_119_; 
lean_dec(v_h__2_117_);
v_a_118_ = lean_ctor_get(v_x_115_, 0);
lean_inc(v_a_118_);
lean_dec_ref_known(v_x_115_, 1);
v___x_119_ = lean_apply_1(v_h__1_116_, v_a_118_);
return v___x_119_;
}
else
{
lean_object* v_a_120_; lean_object* v___x_121_; 
lean_dec(v_h__1_116_);
v_a_120_ = lean_ctor_get(v_x_115_, 0);
lean_inc(v_a_120_);
lean_dec_ref_known(v_x_115_, 1);
v___x_121_ = lean_apply_1(v_h__2_117_, v_a_120_);
return v___x_121_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter(lean_object* v_motive_122_, lean_object* v_x_123_, lean_object* v_h__1_124_, lean_object* v_h__2_125_){
_start:
{
if (lean_obj_tag(v_x_123_) == 0)
{
lean_object* v_a_126_; lean_object* v___x_127_; 
lean_dec(v_h__2_125_);
v_a_126_ = lean_ctor_get(v_x_123_, 0);
lean_inc(v_a_126_);
lean_dec_ref_known(v_x_123_, 1);
v___x_127_ = lean_apply_1(v_h__1_124_, v_a_126_);
return v___x_127_;
}
else
{
lean_object* v_a_128_; lean_object* v___x_129_; 
lean_dec(v_h__1_124_);
v_a_128_ = lean_ctor_get(v_x_123_, 0);
lean_inc(v_a_128_);
lean_dec_ref_known(v_x_123_, 1);
v___x_129_ = lean_apply_1(v_h__2_125_, v_a_128_);
return v___x_129_;
}
}
}
LEAN_EXPORT uint8_t l_List_all___at___00FormalSpecAgent_BatchMachine_advance_spec__0(lean_object* v_snapshot_130_, lean_object* v_x_131_){
_start:
{
if (lean_obj_tag(v_x_131_) == 0)
{
uint8_t v___x_132_; 
v___x_132_ = 1;
return v___x_132_;
}
else
{
lean_object* v_head_133_; lean_object* v_tail_134_; lean_object* v_now_135_; lean_object* v_due_136_; uint8_t v___x_137_; 
v_head_133_ = lean_ctor_get(v_x_131_, 0);
v_tail_134_ = lean_ctor_get(v_x_131_, 1);
v_now_135_ = lean_ctor_get(v_snapshot_130_, 2);
v_due_136_ = lean_ctor_get(v_head_133_, 1);
v___x_137_ = lean_int_dec_le(v_now_135_, v_due_136_);
if (v___x_137_ == 0)
{
return v___x_137_;
}
else
{
v_x_131_ = v_tail_134_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00FormalSpecAgent_BatchMachine_advance_spec__0___boxed(lean_object* v_snapshot_139_, lean_object* v_x_140_){
_start:
{
uint8_t v_res_141_; lean_object* v_r_142_; 
v_res_141_ = l_List_all___at___00FormalSpecAgent_BatchMachine_advance_spec__0(v_snapshot_139_, v_x_140_);
lean_dec(v_x_140_);
lean_dec_ref(v_snapshot_139_);
v_r_142_ = lean_box(v_res_141_);
return v_r_142_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advance(lean_object* v_model_146_, lean_object* v_snapshot_147_, lean_object* v_limit_148_){
_start:
{
lean_object* v_now_149_; lean_object* v_timers_150_; uint8_t v___x_151_; 
v_now_149_ = lean_ctor_get(v_snapshot_147_, 2);
v_timers_150_ = lean_ctor_get(v_snapshot_147_, 3);
v___x_151_ = lean_int_dec_lt(v_limit_148_, v_now_149_);
if (v___x_151_ == 0)
{
uint8_t v___x_152_; 
v___x_152_ = l_List_all___at___00FormalSpecAgent_BatchMachine_advance_spec__0(v_snapshot_147_, v_timers_150_);
if (v___x_152_ == 0)
{
lean_object* v___x_153_; 
lean_dec(v_limit_148_);
lean_dec_ref(v_snapshot_147_);
lean_dec_ref(v_model_146_);
v___x_153_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_advance___closed__0));
return v___x_153_;
}
else
{
lean_object* v___x_154_; 
v___x_154_ = l_FormalSpecAgent_BatchMachine_advanceAux___redArg(v_model_146_, v_snapshot_147_, v_limit_148_);
return v___x_154_;
}
}
else
{
lean_object* v___x_155_; 
lean_dec(v_limit_148_);
lean_dec_ref(v_snapshot_147_);
lean_dec_ref(v_model_146_);
v___x_155_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_advance___closed__0));
return v___x_155_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_tick(lean_object* v_model_159_, lean_object* v_snapshot_160_, lean_object* v_limit_161_){
_start:
{
lean_object* v___x_162_; 
lean_inc_ref(v_model_159_);
v___x_162_ = l_FormalSpecAgent_BatchMachine_advance(v_model_159_, v_snapshot_160_, v_limit_161_);
if (lean_obj_tag(v___x_162_) == 0)
{
lean_dec_ref(v_model_159_);
return v___x_162_;
}
else
{
lean_object* v_a_163_; lean_object* v_after_164_; uint8_t v___x_165_; 
v_a_163_ = lean_ctor_get(v___x_162_, 0);
lean_inc(v_a_163_);
v_after_164_ = lean_ctor_get(v_a_163_, 0);
lean_inc_ref(v_after_164_);
lean_dec(v_a_163_);
v___x_165_ = l_FormalSpecAgent_TypedMachine_invariantsHold(v_model_159_, v_after_164_);
if (v___x_165_ == 0)
{
lean_object* v___x_166_; 
lean_dec_ref_known(v___x_162_, 1);
v___x_166_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_tick___closed__0));
return v___x_166_;
}
else
{
return v___x_162_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_dispatch(lean_object* v_model_170_, lean_object* v_snapshot_171_, lean_object* v_event_172_, lean_object* v_fields_173_, lean_object* v_limit_174_){
_start:
{
lean_object* v_externalEvents_175_; uint8_t v___x_176_; 
v_externalEvents_175_ = lean_ctor_get(v_model_170_, 3);
v___x_176_ = l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(v_event_172_, v_externalEvents_175_);
if (v___x_176_ == 0)
{
lean_object* v___x_177_; 
lean_dec(v_limit_174_);
lean_dec_ref(v_fields_173_);
lean_dec(v_event_172_);
lean_dec_ref(v_snapshot_171_);
lean_dec_ref(v_model_170_);
v___x_177_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_dispatch___closed__0));
return v___x_177_;
}
else
{
lean_object* v___x_178_; 
lean_inc_ref(v_model_170_);
v___x_178_ = l_FormalSpecAgent_BatchMachine_advance(v_model_170_, v_snapshot_171_, v_limit_174_);
if (lean_obj_tag(v___x_178_) == 0)
{
lean_dec_ref(v_fields_173_);
lean_dec(v_event_172_);
lean_dec_ref(v_model_170_);
return v___x_178_;
}
else
{
lean_object* v_a_179_; lean_object* v_after_180_; lean_object* v_trace_181_; lean_object* v___x_183_; uint8_t v_isShared_184_; uint8_t v_isSharedCheck_210_; 
v_a_179_ = lean_ctor_get(v___x_178_, 0);
lean_inc(v_a_179_);
lean_dec_ref_known(v___x_178_, 1);
v_after_180_ = lean_ctor_get(v_a_179_, 0);
v_trace_181_ = lean_ctor_get(v_a_179_, 1);
v_isSharedCheck_210_ = !lean_is_exclusive(v_a_179_);
if (v_isSharedCheck_210_ == 0)
{
v___x_183_ = v_a_179_;
v_isShared_184_ = v_isSharedCheck_210_;
goto v_resetjp_182_;
}
else
{
lean_inc(v_trace_181_);
lean_inc(v_after_180_);
lean_dec(v_a_179_);
v___x_183_ = lean_box(0);
v_isShared_184_ = v_isSharedCheck_210_;
goto v_resetjp_182_;
}
v_resetjp_182_:
{
lean_object* v_now_185_; lean_object* v___x_186_; 
v_now_185_ = lean_ctor_get(v_after_180_, 2);
lean_inc(v_now_185_);
v___x_186_ = l_FormalSpecAgent_TypedMachine_external(v_model_170_, v_after_180_, v_event_172_, v_fields_173_, v_now_185_);
lean_dec_ref(v_after_180_);
if (lean_obj_tag(v___x_186_) == 0)
{
lean_object* v_a_187_; lean_object* v___x_189_; uint8_t v_isShared_190_; uint8_t v_isSharedCheck_194_; 
lean_del_object(v___x_183_);
lean_dec(v_trace_181_);
v_a_187_ = lean_ctor_get(v___x_186_, 0);
v_isSharedCheck_194_ = !lean_is_exclusive(v___x_186_);
if (v_isSharedCheck_194_ == 0)
{
v___x_189_ = v___x_186_;
v_isShared_190_ = v_isSharedCheck_194_;
goto v_resetjp_188_;
}
else
{
lean_inc(v_a_187_);
lean_dec(v___x_186_);
v___x_189_ = lean_box(0);
v_isShared_190_ = v_isSharedCheck_194_;
goto v_resetjp_188_;
}
v_resetjp_188_:
{
lean_object* v___x_192_; 
if (v_isShared_190_ == 0)
{
v___x_192_ = v___x_189_;
goto v_reusejp_191_;
}
else
{
lean_object* v_reuseFailAlloc_193_; 
v_reuseFailAlloc_193_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_193_, 0, v_a_187_);
v___x_192_ = v_reuseFailAlloc_193_;
goto v_reusejp_191_;
}
v_reusejp_191_:
{
return v___x_192_;
}
}
}
else
{
lean_object* v_a_195_; lean_object* v___x_197_; uint8_t v_isShared_198_; uint8_t v_isSharedCheck_209_; 
v_a_195_ = lean_ctor_get(v___x_186_, 0);
v_isSharedCheck_209_ = !lean_is_exclusive(v___x_186_);
if (v_isSharedCheck_209_ == 0)
{
v___x_197_ = v___x_186_;
v_isShared_198_ = v_isSharedCheck_209_;
goto v_resetjp_196_;
}
else
{
lean_inc(v_a_195_);
lean_dec(v___x_186_);
v___x_197_ = lean_box(0);
v_isShared_198_ = v_isSharedCheck_209_;
goto v_resetjp_196_;
}
v_resetjp_196_:
{
lean_object* v_after_199_; lean_object* v___x_200_; lean_object* v___x_201_; lean_object* v___x_202_; lean_object* v___x_204_; 
v_after_199_ = lean_ctor_get(v_a_195_, 0);
lean_inc_ref(v_after_199_);
v___x_200_ = lean_box(0);
v___x_201_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_201_, 0, v_a_195_);
lean_ctor_set(v___x_201_, 1, v___x_200_);
v___x_202_ = l_List_appendTR___redArg(v_trace_181_, v___x_201_);
if (v_isShared_184_ == 0)
{
lean_ctor_set(v___x_183_, 1, v___x_202_);
lean_ctor_set(v___x_183_, 0, v_after_199_);
v___x_204_ = v___x_183_;
goto v_reusejp_203_;
}
else
{
lean_object* v_reuseFailAlloc_208_; 
v_reuseFailAlloc_208_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_208_, 0, v_after_199_);
lean_ctor_set(v_reuseFailAlloc_208_, 1, v___x_202_);
v___x_204_ = v_reuseFailAlloc_208_;
goto v_reusejp_203_;
}
v_reusejp_203_:
{
lean_object* v___x_206_; 
if (v_isShared_198_ == 0)
{
lean_ctor_set(v___x_197_, 0, v___x_204_);
v___x_206_ = v___x_197_;
goto v_reusejp_205_;
}
else
{
lean_object* v_reuseFailAlloc_207_; 
v_reuseFailAlloc_207_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_207_, 0, v___x_204_);
v___x_206_ = v_reuseFailAlloc_207_;
goto v_reusejp_205_;
}
v_reusejp_205_:
{
return v___x_206_;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback(lean_object* v_initial_211_, lean_object* v_result_212_){
_start:
{
if (lean_obj_tag(v_result_212_) == 0)
{
lean_inc_ref(v_initial_211_);
return v_initial_211_;
}
else
{
lean_object* v_a_213_; lean_object* v_after_214_; 
v_a_213_ = lean_ctor_get(v_result_212_, 0);
v_after_214_ = lean_ctor_get(v_a_213_, 0);
lean_inc_ref(v_after_214_);
return v_after_214_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback___boxed(lean_object* v_initial_215_, lean_object* v_result_216_){
_start:
{
lean_object* v_res_217_; 
v_res_217_ = l_FormalSpecAgent_BatchMachine_rollback(v_initial_215_, v_result_216_);
lean_dec_ref(v_result_216_);
lean_dec_ref(v_initial_215_);
return v_res_217_;
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter___redArg(lean_object* v_result_218_, lean_object* v_h__1_219_, lean_object* v_h__2_220_){
_start:
{
if (lean_obj_tag(v_result_218_) == 0)
{
lean_object* v_a_221_; lean_object* v___x_222_; 
lean_dec(v_h__1_219_);
v_a_221_ = lean_ctor_get(v_result_218_, 0);
lean_inc(v_a_221_);
lean_dec_ref_known(v_result_218_, 1);
v___x_222_ = lean_apply_1(v_h__2_220_, v_a_221_);
return v___x_222_;
}
else
{
lean_object* v_a_223_; lean_object* v___x_224_; 
lean_dec(v_h__2_220_);
v_a_223_ = lean_ctor_get(v_result_218_, 0);
lean_inc(v_a_223_);
lean_dec_ref_known(v_result_218_, 1);
v___x_224_ = lean_apply_1(v_h__1_219_, v_a_223_);
return v___x_224_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter(lean_object* v_motive_225_, lean_object* v_result_226_, lean_object* v_h__1_227_, lean_object* v_h__2_228_){
_start:
{
if (lean_obj_tag(v_result_226_) == 0)
{
lean_object* v_a_229_; lean_object* v___x_230_; 
lean_dec(v_h__1_227_);
v_a_229_ = lean_ctor_get(v_result_226_, 0);
lean_inc(v_a_229_);
lean_dec_ref_known(v_result_226_, 1);
v___x_230_ = lean_apply_1(v_h__2_228_, v_a_229_);
return v___x_230_;
}
else
{
lean_object* v_a_231_; lean_object* v___x_232_; 
lean_dec(v_h__2_228_);
v_a_231_ = lean_ctor_get(v_result_226_, 0);
lean_inc(v_a_231_);
lean_dec_ref_known(v_result_226_, 1);
v___x_232_ = lean_apply_1(v_h__1_227_, v_a_231_);
return v___x_232_;
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TimerProgress(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_BatchMachine(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TimerProgress(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
