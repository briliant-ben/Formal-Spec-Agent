// Lean compiler output
// Module: TimerProgress
// Imports: public import Init public meta import Init public import TimerMinimum public import TimerEffects
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter___redArg(lean_object* v_x_1_, lean_object* v_h__1_2_, lean_object* v_h__2_3_){
_start:
{
if (lean_obj_tag(v_x_1_) == 0)
{
lean_object* v_a_4_; lean_object* v___x_5_; 
lean_dec(v_h__2_3_);
v_a_4_ = lean_ctor_get(v_x_1_, 0);
lean_inc(v_a_4_);
lean_dec_ref_known(v_x_1_, 1);
v___x_5_ = lean_apply_1(v_h__1_2_, v_a_4_);
return v___x_5_;
}
else
{
lean_object* v_a_6_; lean_object* v_fst_7_; lean_object* v_snd_8_; lean_object* v___x_9_; 
lean_dec(v_h__1_2_);
v_a_6_ = lean_ctor_get(v_x_1_, 0);
lean_inc(v_a_6_);
lean_dec_ref_known(v_x_1_, 1);
v_fst_7_ = lean_ctor_get(v_a_6_, 0);
lean_inc(v_fst_7_);
v_snd_8_ = lean_ctor_get(v_a_6_, 1);
lean_inc(v_snd_8_);
lean_dec(v_a_6_);
v___x_9_ = lean_apply_2(v_h__2_3_, v_fst_7_, v_snd_8_);
return v___x_9_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter(lean_object* v_motive_10_, lean_object* v_x_11_, lean_object* v_h__1_12_, lean_object* v_h__2_13_){
_start:
{
if (lean_obj_tag(v_x_11_) == 0)
{
lean_object* v_a_14_; lean_object* v___x_15_; 
lean_dec(v_h__2_13_);
v_a_14_ = lean_ctor_get(v_x_11_, 0);
lean_inc(v_a_14_);
lean_dec_ref_known(v_x_11_, 1);
v___x_15_ = lean_apply_1(v_h__1_12_, v_a_14_);
return v___x_15_;
}
else
{
lean_object* v_a_16_; lean_object* v_fst_17_; lean_object* v_snd_18_; lean_object* v___x_19_; 
lean_dec(v_h__1_12_);
v_a_16_ = lean_ctor_get(v_x_11_, 0);
lean_inc(v_a_16_);
lean_dec_ref_known(v_x_11_, 1);
v_fst_17_ = lean_ctor_get(v_a_16_, 0);
lean_inc(v_fst_17_);
v_snd_18_ = lean_ctor_get(v_a_16_, 1);
lean_inc(v_snd_18_);
lean_dec(v_a_16_);
v___x_19_ = lean_apply_2(v_h__2_13_, v_fst_17_, v_snd_18_);
return v___x_19_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter___redArg(lean_object* v_x_20_, lean_object* v_h__1_21_, lean_object* v_h__2_22_, lean_object* v_h__3_23_){
_start:
{
if (lean_obj_tag(v_x_20_) == 0)
{
lean_object* v___x_24_; lean_object* v___x_25_; 
lean_dec(v_h__3_23_);
lean_dec(v_h__2_22_);
v___x_24_ = lean_box(0);
v___x_25_ = lean_apply_1(v_h__1_21_, v___x_24_);
return v___x_25_;
}
else
{
lean_object* v_tail_26_; 
lean_dec(v_h__1_21_);
v_tail_26_ = lean_ctor_get(v_x_20_, 1);
if (lean_obj_tag(v_tail_26_) == 0)
{
lean_object* v_head_27_; lean_object* v___x_28_; 
lean_dec(v_h__3_23_);
v_head_27_ = lean_ctor_get(v_x_20_, 0);
lean_inc(v_head_27_);
lean_dec_ref_known(v_x_20_, 2);
v___x_28_ = lean_apply_1(v_h__2_22_, v_head_27_);
return v___x_28_;
}
else
{
lean_object* v___x_29_; 
lean_dec(v_h__2_22_);
v___x_29_ = lean_apply_3(v_h__3_23_, v_x_20_, lean_box(0), lean_box(0));
return v___x_29_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TimerProgress_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter(lean_object* v_motive_30_, lean_object* v_x_31_, lean_object* v_h__1_32_, lean_object* v_h__2_33_, lean_object* v_h__3_34_){
_start:
{
if (lean_obj_tag(v_x_31_) == 0)
{
lean_object* v___x_35_; lean_object* v___x_36_; 
lean_dec(v_h__3_34_);
lean_dec(v_h__2_33_);
v___x_35_ = lean_box(0);
v___x_36_ = lean_apply_1(v_h__1_32_, v___x_35_);
return v___x_36_;
}
else
{
lean_object* v_tail_37_; 
lean_dec(v_h__1_32_);
v_tail_37_ = lean_ctor_get(v_x_31_, 1);
if (lean_obj_tag(v_tail_37_) == 0)
{
lean_object* v_head_38_; lean_object* v___x_39_; 
lean_dec(v_h__3_34_);
v_head_38_ = lean_ctor_get(v_x_31_, 0);
lean_inc(v_head_38_);
lean_dec_ref_known(v_x_31_, 2);
v___x_39_ = lean_apply_1(v_h__2_33_, v_head_38_);
return v___x_39_;
}
else
{
lean_object* v___x_40_; 
lean_dec(v_h__2_33_);
v___x_40_ = lean_apply_3(v_h__3_34_, v_x_31_, lean_box(0), lean_box(0));
return v___x_40_;
}
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TimerMinimum(uint8_t builtin);
lean_object* initialize_TimerEffects(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_TimerProgress(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TimerMinimum(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TimerEffects(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
