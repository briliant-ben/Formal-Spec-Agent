// Lean compiler output
// Module: TimerEffects
// Imports: public import Init public meta import Init public import TimerRank
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__5_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__5_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__3_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__3_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__5_splitter___redArg(lean_object* v_actions_1_, lean_object* v_h__1_2_, lean_object* v_h__2_3_){
_start:
{
if (lean_obj_tag(v_actions_1_) == 0)
{
lean_object* v___x_4_; lean_object* v___x_5_; 
lean_dec(v_h__2_3_);
v___x_4_ = lean_box(0);
v___x_5_ = lean_apply_1(v_h__1_2_, v___x_4_);
return v___x_5_;
}
else
{
lean_object* v_head_6_; lean_object* v_tail_7_; lean_object* v___x_8_; 
lean_dec(v_h__1_2_);
v_head_6_ = lean_ctor_get(v_actions_1_, 0);
lean_inc(v_head_6_);
v_tail_7_ = lean_ctor_get(v_actions_1_, 1);
lean_inc(v_tail_7_);
lean_dec_ref_known(v_actions_1_, 2);
v___x_8_ = lean_apply_2(v_h__2_3_, v_head_6_, v_tail_7_);
return v___x_8_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__5_splitter(lean_object* v_motive_9_, lean_object* v_actions_10_, lean_object* v_h__1_11_, lean_object* v_h__2_12_){
_start:
{
if (lean_obj_tag(v_actions_10_) == 0)
{
lean_object* v___x_13_; lean_object* v___x_14_; 
lean_dec(v_h__2_12_);
v___x_13_ = lean_box(0);
v___x_14_ = lean_apply_1(v_h__1_11_, v___x_13_);
return v___x_14_;
}
else
{
lean_object* v_head_15_; lean_object* v_tail_16_; lean_object* v___x_17_; 
lean_dec(v_h__1_11_);
v_head_15_ = lean_ctor_get(v_actions_10_, 0);
lean_inc(v_head_15_);
v_tail_16_ = lean_ctor_get(v_actions_10_, 1);
lean_inc(v_tail_16_);
lean_dec_ref_known(v_actions_10_, 2);
v___x_17_ = lean_apply_2(v_h__2_12_, v_head_15_, v_tail_16_);
return v___x_17_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__3_splitter___redArg(lean_object* v_a_18_, lean_object* v_h__1_19_, lean_object* v_h__2_20_, lean_object* v_h__3_21_, lean_object* v_h__4_22_){
_start:
{
switch(lean_obj_tag(v_a_18_))
{
case 0:
{
uint8_t v_kind_23_; lean_object* v_slot_24_; lean_object* v_expr_25_; lean_object* v___x_26_; lean_object* v___x_27_; 
lean_dec(v_h__4_22_);
lean_dec(v_h__3_21_);
lean_dec(v_h__2_20_);
v_kind_23_ = lean_ctor_get_uint8(v_a_18_, sizeof(void*)*2);
v_slot_24_ = lean_ctor_get(v_a_18_, 0);
lean_inc(v_slot_24_);
v_expr_25_ = lean_ctor_get(v_a_18_, 1);
lean_inc_ref(v_expr_25_);
lean_dec_ref_known(v_a_18_, 2);
v___x_26_ = lean_box(v_kind_23_);
v___x_27_ = lean_apply_3(v_h__1_19_, v___x_26_, v_slot_24_, v_expr_25_);
return v___x_27_;
}
case 1:
{
lean_object* v_message_28_; lean_object* v_fields_29_; lean_object* v___x_30_; 
lean_dec(v_h__4_22_);
lean_dec(v_h__3_21_);
lean_dec(v_h__1_19_);
v_message_28_ = lean_ctor_get(v_a_18_, 0);
lean_inc(v_message_28_);
v_fields_29_ = lean_ctor_get(v_a_18_, 1);
lean_inc(v_fields_29_);
lean_dec_ref_known(v_a_18_, 2);
v___x_30_ = lean_apply_2(v_h__2_20_, v_message_28_, v_fields_29_);
return v___x_30_;
}
case 2:
{
lean_object* v_timer_31_; lean_object* v_delay_32_; lean_object* v___x_33_; 
lean_dec(v_h__3_21_);
lean_dec(v_h__2_20_);
lean_dec(v_h__1_19_);
v_timer_31_ = lean_ctor_get(v_a_18_, 0);
lean_inc(v_timer_31_);
v_delay_32_ = lean_ctor_get(v_a_18_, 1);
lean_inc_ref(v_delay_32_);
lean_dec_ref_known(v_a_18_, 2);
v___x_33_ = lean_apply_2(v_h__4_22_, v_timer_31_, v_delay_32_);
return v___x_33_;
}
default: 
{
lean_object* v_timer_34_; lean_object* v___x_35_; 
lean_dec(v_h__4_22_);
lean_dec(v_h__2_20_);
lean_dec(v_h__1_19_);
v_timer_34_ = lean_ctor_get(v_a_18_, 0);
lean_inc(v_timer_34_);
lean_dec_ref_known(v_a_18_, 1);
v___x_35_ = lean_apply_1(v_h__3_21_, v_timer_34_);
return v___x_35_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__3_splitter(lean_object* v_motive_36_, lean_object* v_a_37_, lean_object* v_h__1_38_, lean_object* v_h__2_39_, lean_object* v_h__3_40_, lean_object* v_h__4_41_){
_start:
{
switch(lean_obj_tag(v_a_37_))
{
case 0:
{
uint8_t v_kind_42_; lean_object* v_slot_43_; lean_object* v_expr_44_; lean_object* v___x_45_; lean_object* v___x_46_; 
lean_dec(v_h__4_41_);
lean_dec(v_h__3_40_);
lean_dec(v_h__2_39_);
v_kind_42_ = lean_ctor_get_uint8(v_a_37_, sizeof(void*)*2);
v_slot_43_ = lean_ctor_get(v_a_37_, 0);
lean_inc(v_slot_43_);
v_expr_44_ = lean_ctor_get(v_a_37_, 1);
lean_inc_ref(v_expr_44_);
lean_dec_ref_known(v_a_37_, 2);
v___x_45_ = lean_box(v_kind_42_);
v___x_46_ = lean_apply_3(v_h__1_38_, v___x_45_, v_slot_43_, v_expr_44_);
return v___x_46_;
}
case 1:
{
lean_object* v_message_47_; lean_object* v_fields_48_; lean_object* v___x_49_; 
lean_dec(v_h__4_41_);
lean_dec(v_h__3_40_);
lean_dec(v_h__1_38_);
v_message_47_ = lean_ctor_get(v_a_37_, 0);
lean_inc(v_message_47_);
v_fields_48_ = lean_ctor_get(v_a_37_, 1);
lean_inc(v_fields_48_);
lean_dec_ref_known(v_a_37_, 2);
v___x_49_ = lean_apply_2(v_h__2_39_, v_message_47_, v_fields_48_);
return v___x_49_;
}
case 2:
{
lean_object* v_timer_50_; lean_object* v_delay_51_; lean_object* v___x_52_; 
lean_dec(v_h__3_40_);
lean_dec(v_h__2_39_);
lean_dec(v_h__1_38_);
v_timer_50_ = lean_ctor_get(v_a_37_, 0);
lean_inc(v_timer_50_);
v_delay_51_ = lean_ctor_get(v_a_37_, 1);
lean_inc_ref(v_delay_51_);
lean_dec_ref_known(v_a_37_, 2);
v___x_52_ = lean_apply_2(v_h__4_41_, v_timer_50_, v_delay_51_);
return v___x_52_;
}
default: 
{
lean_object* v_timer_53_; lean_object* v___x_54_; 
lean_dec(v_h__4_41_);
lean_dec(v_h__2_39_);
lean_dec(v_h__1_38_);
v_timer_53_ = lean_ctor_get(v_a_37_, 0);
lean_inc(v_timer_53_);
lean_dec_ref_known(v_a_37_, 1);
v___x_54_ = lean_apply_1(v_h__3_40_, v_timer_53_);
return v___x_54_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__1_splitter___redArg(lean_object* v_x_55_, lean_object* v_h__1_56_, lean_object* v_h__2_57_){
_start:
{
if (lean_obj_tag(v_x_55_) == 0)
{
lean_object* v_a_58_; lean_object* v___x_59_; 
lean_dec(v_h__1_56_);
v_a_58_ = lean_ctor_get(v_x_55_, 0);
lean_inc(v_a_58_);
lean_dec_ref_known(v_x_55_, 1);
v___x_59_ = lean_apply_1(v_h__2_57_, v_a_58_);
return v___x_59_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
lean_dec(v_h__2_57_);
v_a_60_ = lean_ctor_get(v_x_55_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v_x_55_, 1);
v___x_61_ = lean_apply_1(v_h__1_56_, v_a_60_);
return v___x_61_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerEffects_0__FormalSpecAgent_TypedMachine_work_match__1_splitter(lean_object* v_motive_62_, lean_object* v_x_63_, lean_object* v_h__1_64_, lean_object* v_h__2_65_){
_start:
{
if (lean_obj_tag(v_x_63_) == 0)
{
lean_object* v_a_66_; lean_object* v___x_67_; 
lean_dec(v_h__1_64_);
v_a_66_ = lean_ctor_get(v_x_63_, 0);
lean_inc(v_a_66_);
lean_dec_ref_known(v_x_63_, 1);
v___x_67_ = lean_apply_1(v_h__2_65_, v_a_66_);
return v___x_67_;
}
else
{
lean_object* v_a_68_; lean_object* v___x_69_; 
lean_dec(v_h__2_65_);
v_a_68_ = lean_ctor_get(v_x_63_, 0);
lean_inc(v_a_68_);
lean_dec_ref_known(v_x_63_, 1);
v___x_69_ = lean_apply_1(v_h__1_64_, v_a_68_);
return v___x_69_;
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TimerRank(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_TimerEffects(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TimerRank(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
