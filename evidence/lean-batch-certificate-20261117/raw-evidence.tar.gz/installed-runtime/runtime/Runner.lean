import ModelMachine
open FormalSpecAgent.MachineObserve

def array (xs : List String) : String := "[" ++ String.intercalate "," xs ++ "]"
def pvalue : Packed → String
  | .integer v => "{\"kind\":\"int\",\"value\":" ++ toString v ++ "}"
  | .boolean v => "{\"kind\":\"bool\",\"value\":" ++ toString v ++ "}"
  | .text v => "{\"kind\":\"string\",\"value\":" ++ array (v.toList.map fun c => toString c.toNat) ++ "}"
  | .octets v => "{\"kind\":\"bytes\",\"value\":" ++ array (v.map fun b => toString b.val) ++ "}"
  | .sequence v => "{\"kind\":\"seq32\",\"value\":" ++ toString v ++ "}"
def ss (s : SeenSnapshot) : String :=
  "{\"state\":" ++ toString s.state ++ ",\"now_ms\":" ++ toString s.now ++
  ",\"variables\":" ++ array (s.values.map pvalue) ++ ",\"timers\":" ++
  array (s.timers.map fun (n,t) => array [toString n,toString t]) ++ "}"
def msg (m : SeenMessage) : String :=
  "{\"message\":" ++ toString m.1 ++ ",\"fields\":" ++
  array (m.2.map fun (n,v) => array [toString n,pvalue v]) ++ "}"
def faultName : FormalSpecAgent.TypedMachine.Fault → String
  | .uncovered => "uncovered" | .conflict => "conflict" | .badDelay => "badDelay"
  | .invariant => "invariant" | .time => "time" | .timerInjection => "timerInjection"
  | .pendingTimer => "pendingTimer" | .noTimer => "noTimer"
def outcomeText : Outcome → String
  | .success r e s emitted => "{\"status\":\"ok\",\"rule\":" ++ toString r ++
      ",\"event\":" ++ toString e ++ ",\"after\":" ++ ss s ++
      ",\"emitted\":" ++ array (emitted.map msg) ++ "}"
  | .error f s => "{\"status\":\"error\",\"fault\":\"" ++ faultName f ++
      "\",\"after\":" ++ ss s ++ ",\"emitted\":[]}"

def transitionText (t : FormalSpecAgent.BatchObserve.SeenTransition) : String :=
  "{\"rule\":" ++ toString t.rule ++ ",\"event\":" ++ toString t.event ++
  ",\"fields\":" ++ array (t.fields.map pvalue) ++ ",\"after\":" ++ ss t.after ++
  ",\"emitted\":" ++ array (t.emitted.map msg) ++ "}"
def batchText : FormalSpecAgent.BatchObserve.Outcome → String
  | .success s trace => "{\"status\":\"ok\",\"after\":" ++ ss s ++
      ",\"trace\":" ++ array (trace.map transitionText) ++ "}"
  | .error f s => "{\"status\":\"error\",\"fault\":\"" ++ faultName f ++
      "\",\"after\":" ++ ss s ++ ",\"trace\":[]}"

def main : IO Unit := do
  let s_0_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_0_0 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_0_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_0_0 r_0_0))
  let s_0_1 := FormalSpecAgent.BatchMachine.rollback s_0_0 r_0_0
  let r_0_1 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_0_1 (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_0_1 r_0_1))
  let s_0_2 := FormalSpecAgent.BatchMachine.rollback s_0_1 r_0_1
  let r_0_2 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_0_2 (10)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_0_2 r_0_2))
  let s_0_3 := FormalSpecAgent.BatchMachine.rollback s_0_2 r_0_2
  let s_1_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_1_0 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_1_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_1_0 r_1_0))
  let s_1_1 := FormalSpecAgent.BatchMachine.rollback s_1_0 r_1_0
  let r_1_1 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_1_1 5 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_1_1 r_1_1))
  let s_1_2 := FormalSpecAgent.BatchMachine.rollback s_1_1 r_1_1
  let r_1_2 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_1_2 (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_1_2 r_1_2))
  let s_1_3 := FormalSpecAgent.BatchMachine.rollback s_1_2 r_1_2
  let s_2_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_2_0 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_2_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_2_0 r_2_0))
  let s_2_1 := FormalSpecAgent.BatchMachine.rollback s_2_0 r_2_0
  let r_2_1 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_2_1 9 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_2_1 r_2_1))
  let s_2_2 := FormalSpecAgent.BatchMachine.rollback s_2_1 r_2_1
  let r_2_2 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_2_2 (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_2_2 r_2_2))
  let s_2_3 := FormalSpecAgent.BatchMachine.rollback s_2_2 r_2_2
  let r_2_3 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_2_3 10 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_2_3 r_2_3))
  let s_2_4 := FormalSpecAgent.BatchMachine.rollback s_2_3 r_2_3
  let r_2_4 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_2_4 (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_2_4 r_2_4))
  let s_2_5 := FormalSpecAgent.BatchMachine.rollback s_2_4 r_2_4
  let s_3_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_3_0 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_3_0 8 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_3_0 r_3_0))
  let s_3_1 := FormalSpecAgent.BatchMachine.rollback s_3_0 r_3_0
  let r_3_1 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_3_1 (10)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_3_1 r_3_1))
  let s_3_2 := FormalSpecAgent.BatchMachine.rollback s_3_1 r_3_1
  let r_3_2 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_3_2 (12)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_3_2 r_3_2))
  let s_3_3 := FormalSpecAgent.BatchMachine.rollback s_3_2 r_3_2
  let s_4_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_4_0 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_4_0 4 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (10)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_4_0 r_4_0))
  let s_4_1 := FormalSpecAgent.BatchMachine.rollback s_4_0 r_4_0
  let r_4_1 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_4_1 2 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (10)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_4_1 r_4_1))
  let s_4_2 := FormalSpecAgent.BatchMachine.rollback s_4_1 r_4_1
  let r_4_2 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_4_2 1 ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (10)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_4_2 r_4_2))
  let s_4_3 := FormalSpecAgent.BatchMachine.rollback s_4_2 r_4_2
  let r_4_3 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_4_3 (-1)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_4_3 r_4_3))
  let s_4_4 := FormalSpecAgent.BatchMachine.rollback s_4_3 r_4_3
  let s_5_0 := ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_5_0 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_5_0 6 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_5_0 r_5_0))
  let s_5_1 := FormalSpecAgent.BatchMachine.rollback s_5_0 r_5_0
  let r_5_1 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_5_1 (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_5_1 r_5_1))
  let s_5_2 := FormalSpecAgent.BatchMachine.rollback s_5_1 r_5_1
  let s_6_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_6_0 := FormalSpecAgent.BatchMachine.dispatch MachineRuntime.model s_6_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_6_0 r_6_0))
  let s_6_1 := FormalSpecAgent.BatchMachine.rollback s_6_0 r_6_0
  let r_6_1 := FormalSpecAgent.BatchMachine.tick MachineRuntime.model s_6_1 (5)
  IO.println (batchText (FormalSpecAgent.BatchObserve.outcome MachineRuntime.schema MachineRuntime.eventSchemas s_6_1 r_6_1))
  let s_6_2 := FormalSpecAgent.BatchMachine.rollback s_6_1 r_6_1
