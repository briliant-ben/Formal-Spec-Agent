import BatchObserve

set_option maxRecDepth 16384

namespace MachineRuntime

def e0 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (0)

def e1 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean false

def e2 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e3 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([] : FormalSpecAgent.Bytes)

def e4 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116])

def e5 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean true

def e6 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.field .octets 0

def e7 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (4)

def e8 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 0

def e9 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (1)

def e10 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.add e8 e9

def e11 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.variable .sequence 2

def e12 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.seqAdd e11 e9

def e13 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])

def e14 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 1

def e15 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 3

def e16 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.variable .text 4

def e17 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.stateIs 0

def e18 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.timerActive 0

def e19 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.timerActive 2

def e20 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (5)

def e21 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (10)

def e22 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 0

def e23 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (-1)

def e24 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 5

def e25 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolNot e24

def e26 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolAnd e19 e25

def e27 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (3)

def e28 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (7)

def e29 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolAnd e19 e24

def e30 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (99)

def e31 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e32 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes)

def e33 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (2)

def e34 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e8 e9

def e35 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e8 e33

def e36 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e8 e0

def e37 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e15

def e38 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (4096)

def e39 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e37 e38

def rule_0 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 0, source := 0, target := 1, event := 0, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .octets 3 e6, FormalSpecAgent.TypedMachine.Action.assign .integer 0 e7, FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.assign .boolean 1 e5, FormalSpecAgent.TypedMachine.Action.assign .sequence 2 e12, FormalSpecAgent.TypedMachine.Action.assign .text 4 e13, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 2 e20, FormalSpecAgent.TypedMachine.Action.arm 0 e20] }

def rule_1 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 1, source := 0, target := 1, event := 1, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e21, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 0 e22] }

def rule_2 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 2, source := 0, target := 2, event := 2, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e23, FormalSpecAgent.TypedMachine.Action.arm 0 e20, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_3 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 3, source := 1, target := 1, event := 6, guard := e18, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_4 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 4, source := 1, target := 2, event := 7, guard := e26, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.cancel 0] }

def rule_5 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 5, source := 1, target := 1, event := 3, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.arm 0 e27, FormalSpecAgent.TypedMachine.Action.arm 0 e28, FormalSpecAgent.TypedMachine.Action.cancel 2, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_6 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 6, source := 0, target := 0, event := 4, guard := e5, actions := [] }

def rule_7 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 7, source := 0, target := 1, event := 4, guard := e5, actions := [] }

def rule_8 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 8, source := 1, target := 2, event := 7, guard := e29, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e30, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 0 e0] }

def rule_9 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 9, source := 1, target := 1, event := 9, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .boolean 5 e5] }

def rule_10 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 10, source := 1, target := 1, event := 10, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .boolean 5 e1] }

def rule_11 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 11, source := 0, target := 1, event := 8, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e0, FormalSpecAgent.TypedMachine.Action.assign .boolean 1 e5, FormalSpecAgent.TypedMachine.Action.assign .sequence 2 e31, FormalSpecAgent.TypedMachine.Action.assign .octets 3 e32, FormalSpecAgent.TypedMachine.Action.assign .text 4 e13, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 1 e33] }

def rule_12 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 12, source := 1, target := 1, event := 11, guard := e34, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 1 e33] }

def rule_13 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 13, source := 1, target := 2, event := 11, guard := e35, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def schema : List (FormalSpecAgent.TypedIR.Kind × Nat) := [(.integer, 0), (.boolean, 1), (.sequence, 2), (.octets, 3), (.text, 4), (.boolean, 5)]

def model : FormalSpecAgent.TypedMachine.Model :=
  { rules := [rule_0, rule_1, rule_2, rule_3, rule_4, rule_5, rule_6, rule_7, rule_8, rule_9, rule_10, rule_11, rule_12, rule_13], invariants := [e36, e39], timerEvents := fun n => if n = 0 then 6 else if n = 1 then 11 else if n = 2 then 7 else 0, externalEvents := [0, 1, 2, 3, 4, 5, 8, 9, 10] }

def eventSchemas (n : Nat) : List (FormalSpecAgent.TypedIR.Kind × Nat) := if n = 0 then [(.octets, 0)] else if n = 1 then [(.integer, 0)] else if n = 2 then [] else if n = 3 then [] else if n = 4 then [] else if n = 5 then [] else if n = 6 then [] else if n = 7 then [] else if n = 8 then [] else if n = 9 then [] else if n = 10 then [] else if n = 11 then [] else []

end MachineRuntime
