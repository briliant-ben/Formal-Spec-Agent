// Lean compiler output
// Module: TimerMinimum
// Imports: public import Init public meta import Init public import TimerRank
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_pick(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_pick___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_optionPick(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_optionPick_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_optionPick_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TypedMachine_nextTimer_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TypedMachine_nextTimer_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_pick(lean_object* v_best_1_, lean_object* v_entry_2_){
_start:
{
lean_object* v_timer_3_; lean_object* v_due_4_; lean_object* v_timer_5_; lean_object* v_due_6_; uint8_t v___x_7_; 
v_timer_3_ = lean_ctor_get(v_entry_2_, 0);
v_due_4_ = lean_ctor_get(v_entry_2_, 1);
v_timer_5_ = lean_ctor_get(v_best_1_, 0);
v_due_6_ = lean_ctor_get(v_best_1_, 1);
v___x_7_ = lean_int_dec_lt(v_due_4_, v_due_6_);
if (v___x_7_ == 0)
{
uint8_t v___x_8_; 
v___x_8_ = lean_int_dec_eq(v_due_4_, v_due_6_);
if (v___x_8_ == 0)
{
lean_inc_ref(v_best_1_);
return v_best_1_;
}
else
{
uint8_t v___x_9_; 
v___x_9_ = lean_nat_dec_lt(v_timer_3_, v_timer_5_);
if (v___x_9_ == 0)
{
lean_inc_ref(v_best_1_);
return v_best_1_;
}
else
{
lean_inc_ref(v_entry_2_);
return v_entry_2_;
}
}
}
else
{
lean_inc_ref(v_entry_2_);
return v_entry_2_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_pick___boxed(lean_object* v_best_10_, lean_object* v_entry_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_pick(v_best_10_, v_entry_11_);
lean_dec_ref(v_entry_11_);
lean_dec_ref(v_best_10_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan(lean_object* v_best_13_, lean_object* v_x_14_){
_start:
{
if (lean_obj_tag(v_x_14_) == 0)
{
return v_best_13_;
}
else
{
lean_object* v_head_15_; lean_object* v_tail_16_; lean_object* v___x_17_; 
v_head_15_ = lean_ctor_get(v_x_14_, 0);
v_tail_16_ = lean_ctor_get(v_x_14_, 1);
v___x_17_ = l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_pick(v_best_13_, v_head_15_);
lean_dec_ref(v_best_13_);
v_best_13_ = v___x_17_;
v_x_14_ = v_tail_16_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan___boxed(lean_object* v_best_19_, lean_object* v_x_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan(v_best_19_, v_x_20_);
lean_dec(v_x_20_);
return v_res_21_;
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan_match__1_splitter___redArg(lean_object* v_x_22_, lean_object* v_h__1_23_, lean_object* v_h__2_24_){
_start:
{
if (lean_obj_tag(v_x_22_) == 0)
{
lean_object* v___x_25_; lean_object* v___x_26_; 
lean_dec(v_h__2_24_);
v___x_25_ = lean_box(0);
v___x_26_ = lean_apply_1(v_h__1_23_, v___x_25_);
return v___x_26_;
}
else
{
lean_object* v_head_27_; lean_object* v_tail_28_; lean_object* v___x_29_; 
lean_dec(v_h__1_23_);
v_head_27_ = lean_ctor_get(v_x_22_, 0);
lean_inc(v_head_27_);
v_tail_28_ = lean_ctor_get(v_x_22_, 1);
lean_inc(v_tail_28_);
lean_dec_ref_known(v_x_22_, 2);
v___x_29_ = lean_apply_2(v_h__2_24_, v_head_27_, v_tail_28_);
return v___x_29_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_scan_match__1_splitter(lean_object* v_motive_30_, lean_object* v_x_31_, lean_object* v_h__1_32_, lean_object* v_h__2_33_){
_start:
{
if (lean_obj_tag(v_x_31_) == 0)
{
lean_object* v___x_34_; lean_object* v___x_35_; 
lean_dec(v_h__2_33_);
v___x_34_ = lean_box(0);
v___x_35_ = lean_apply_1(v_h__1_32_, v___x_34_);
return v___x_35_;
}
else
{
lean_object* v_head_36_; lean_object* v_tail_37_; lean_object* v___x_38_; 
lean_dec(v_h__1_32_);
v_head_36_ = lean_ctor_get(v_x_31_, 0);
lean_inc(v_head_36_);
v_tail_37_ = lean_ctor_get(v_x_31_, 1);
lean_inc(v_tail_37_);
lean_dec_ref_known(v_x_31_, 2);
v___x_38_ = lean_apply_2(v_h__2_33_, v_head_36_, v_tail_37_);
return v___x_38_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_optionPick(lean_object* v_best_39_, lean_object* v_entry_40_){
_start:
{
if (lean_obj_tag(v_best_39_) == 0)
{
lean_object* v___x_41_; 
v___x_41_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_41_, 0, v_entry_40_);
return v___x_41_;
}
else
{
lean_object* v_val_42_; lean_object* v_timer_43_; lean_object* v_due_44_; lean_object* v_timer_45_; lean_object* v_due_46_; uint8_t v___x_47_; 
v_val_42_ = lean_ctor_get(v_best_39_, 0);
v_timer_43_ = lean_ctor_get(v_entry_40_, 0);
v_due_44_ = lean_ctor_get(v_entry_40_, 1);
v_timer_45_ = lean_ctor_get(v_val_42_, 0);
v_due_46_ = lean_ctor_get(v_val_42_, 1);
v___x_47_ = lean_int_dec_lt(v_due_44_, v_due_46_);
if (v___x_47_ == 0)
{
uint8_t v___x_48_; 
v___x_48_ = lean_int_dec_eq(v_due_44_, v_due_46_);
if (v___x_48_ == 0)
{
lean_dec_ref(v_entry_40_);
return v_best_39_;
}
else
{
uint8_t v___x_49_; 
v___x_49_ = lean_nat_dec_lt(v_timer_43_, v_timer_45_);
if (v___x_49_ == 0)
{
lean_dec_ref(v_entry_40_);
return v_best_39_;
}
else
{
lean_object* v___x_51_; uint8_t v_isShared_52_; uint8_t v_isSharedCheck_56_; 
v_isSharedCheck_56_ = !lean_is_exclusive(v_best_39_);
if (v_isSharedCheck_56_ == 0)
{
lean_object* v_unused_57_; 
v_unused_57_ = lean_ctor_get(v_best_39_, 0);
lean_dec(v_unused_57_);
v___x_51_ = v_best_39_;
v_isShared_52_ = v_isSharedCheck_56_;
goto v_resetjp_50_;
}
else
{
lean_dec(v_best_39_);
v___x_51_ = lean_box(0);
v_isShared_52_ = v_isSharedCheck_56_;
goto v_resetjp_50_;
}
v_resetjp_50_:
{
lean_object* v___x_54_; 
if (v_isShared_52_ == 0)
{
lean_ctor_set(v___x_51_, 0, v_entry_40_);
v___x_54_ = v___x_51_;
goto v_reusejp_53_;
}
else
{
lean_object* v_reuseFailAlloc_55_; 
v_reuseFailAlloc_55_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_55_, 0, v_entry_40_);
v___x_54_ = v_reuseFailAlloc_55_;
goto v_reusejp_53_;
}
v_reusejp_53_:
{
return v___x_54_;
}
}
}
}
}
else
{
lean_object* v___x_59_; uint8_t v_isShared_60_; uint8_t v_isSharedCheck_64_; 
v_isSharedCheck_64_ = !lean_is_exclusive(v_best_39_);
if (v_isSharedCheck_64_ == 0)
{
lean_object* v_unused_65_; 
v_unused_65_ = lean_ctor_get(v_best_39_, 0);
lean_dec(v_unused_65_);
v___x_59_ = v_best_39_;
v_isShared_60_ = v_isSharedCheck_64_;
goto v_resetjp_58_;
}
else
{
lean_dec(v_best_39_);
v___x_59_ = lean_box(0);
v_isShared_60_ = v_isSharedCheck_64_;
goto v_resetjp_58_;
}
v_resetjp_58_:
{
lean_object* v___x_62_; 
if (v_isShared_60_ == 0)
{
lean_ctor_set(v___x_59_, 0, v_entry_40_);
v___x_62_ = v___x_59_;
goto v_reusejp_61_;
}
else
{
lean_object* v_reuseFailAlloc_63_; 
v_reuseFailAlloc_63_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_63_, 0, v_entry_40_);
v___x_62_ = v_reuseFailAlloc_63_;
goto v_reusejp_61_;
}
v_reusejp_61_:
{
return v___x_62_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_optionPick_match__1_splitter___redArg(lean_object* v_best_66_, lean_object* v_h__1_67_, lean_object* v_h__2_68_){
_start:
{
if (lean_obj_tag(v_best_66_) == 0)
{
lean_object* v___x_69_; lean_object* v___x_70_; 
lean_dec(v_h__2_68_);
v___x_69_ = lean_box(0);
v___x_70_ = lean_apply_1(v_h__1_67_, v___x_69_);
return v___x_70_;
}
else
{
lean_object* v_val_71_; lean_object* v___x_72_; 
lean_dec(v_h__1_67_);
v_val_71_ = lean_ctor_get(v_best_66_, 0);
lean_inc(v_val_71_);
lean_dec_ref_known(v_best_66_, 1);
v___x_72_ = lean_apply_1(v_h__2_68_, v_val_71_);
return v___x_72_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TimerMinimum_optionPick_match__1_splitter(lean_object* v_motive_73_, lean_object* v_best_74_, lean_object* v_h__1_75_, lean_object* v_h__2_76_){
_start:
{
if (lean_obj_tag(v_best_74_) == 0)
{
lean_object* v___x_77_; lean_object* v___x_78_; 
lean_dec(v_h__2_76_);
v___x_77_ = lean_box(0);
v___x_78_ = lean_apply_1(v_h__1_75_, v___x_77_);
return v___x_78_;
}
else
{
lean_object* v_val_79_; lean_object* v___x_80_; 
lean_dec(v_h__1_75_);
v_val_79_ = lean_ctor_get(v_best_74_, 0);
lean_inc(v_val_79_);
lean_dec_ref_known(v_best_74_, 1);
v___x_80_ = lean_apply_1(v_h__2_76_, v_val_79_);
return v___x_80_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TypedMachine_nextTimer_match__1_splitter___redArg(lean_object* v_best_81_, lean_object* v_h__1_82_, lean_object* v_h__2_83_){
_start:
{
if (lean_obj_tag(v_best_81_) == 0)
{
lean_object* v___x_84_; lean_object* v___x_85_; 
lean_dec(v_h__2_83_);
v___x_84_ = lean_box(0);
v___x_85_ = lean_apply_1(v_h__1_82_, v___x_84_);
return v___x_85_;
}
else
{
lean_object* v_val_86_; lean_object* v___x_87_; 
lean_dec(v_h__1_82_);
v_val_86_ = lean_ctor_get(v_best_81_, 0);
lean_inc(v_val_86_);
lean_dec_ref_known(v_best_81_, 1);
v___x_87_ = lean_apply_1(v_h__2_83_, v_val_86_);
return v___x_87_;
}
}
}
LEAN_EXPORT lean_object* l___private_TimerMinimum_0__FormalSpecAgent_TypedMachine_nextTimer_match__1_splitter(lean_object* v_motive_88_, lean_object* v_best_89_, lean_object* v_h__1_90_, lean_object* v_h__2_91_){
_start:
{
if (lean_obj_tag(v_best_89_) == 0)
{
lean_object* v___x_92_; lean_object* v___x_93_; 
lean_dec(v_h__2_91_);
v___x_92_ = lean_box(0);
v___x_93_ = lean_apply_1(v_h__1_90_, v___x_92_);
return v___x_93_;
}
else
{
lean_object* v_val_94_; lean_object* v___x_95_; 
lean_dec(v_h__1_90_);
v_val_94_ = lean_ctor_get(v_best_89_, 0);
lean_inc(v_val_94_);
lean_dec_ref_known(v_best_89_, 1);
v___x_95_ = lean_apply_1(v_h__2_91_, v_val_94_);
return v___x_95_;
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TimerRank(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_TimerMinimum(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TimerRank(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
