import Proofs

example : Approved.timer_progress := Proofs.timer_progress
#print axioms Proofs.timer_progress
example : Approved.rollback_error := Proofs.rollback_error
#print axioms Proofs.rollback_error
example : Approved.initial_valid_0 := Proofs.initial_valid_0
#print axioms Proofs.initial_valid_0
example : Approved.execution_0_0 := Proofs.execution_0_0
#print axioms Proofs.execution_0_0
example : Approved.witness_0_0 := Proofs.witness_0_0
#print axioms Proofs.witness_0_0
example : Approved.execution_0_1 := Proofs.execution_0_1
#print axioms Proofs.execution_0_1
example : Approved.witness_0_1 := Proofs.witness_0_1
#print axioms Proofs.witness_0_1
example : Approved.execution_0_2 := Proofs.execution_0_2
#print axioms Proofs.execution_0_2
example : Approved.witness_0_2 := Proofs.witness_0_2
#print axioms Proofs.witness_0_2
example : Approved.initial_valid_1 := Proofs.initial_valid_1
#print axioms Proofs.initial_valid_1
example : Approved.execution_1_0 := Proofs.execution_1_0
#print axioms Proofs.execution_1_0
example : Approved.witness_1_0 := Proofs.witness_1_0
#print axioms Proofs.witness_1_0
example : Approved.execution_1_1 := Proofs.execution_1_1
#print axioms Proofs.execution_1_1
example : Approved.witness_1_1 := Proofs.witness_1_1
#print axioms Proofs.witness_1_1
example : Approved.execution_1_2 := Proofs.execution_1_2
#print axioms Proofs.execution_1_2
example : Approved.witness_1_2 := Proofs.witness_1_2
#print axioms Proofs.witness_1_2
example : Approved.initial_valid_2 := Proofs.initial_valid_2
#print axioms Proofs.initial_valid_2
example : Approved.execution_2_0 := Proofs.execution_2_0
#print axioms Proofs.execution_2_0
example : Approved.witness_2_0 := Proofs.witness_2_0
#print axioms Proofs.witness_2_0
example : Approved.execution_2_1 := Proofs.execution_2_1
#print axioms Proofs.execution_2_1
example : Approved.witness_2_1 := Proofs.witness_2_1
#print axioms Proofs.witness_2_1
example : Approved.execution_2_2 := Proofs.execution_2_2
#print axioms Proofs.execution_2_2
example : Approved.witness_2_2 := Proofs.witness_2_2
#print axioms Proofs.witness_2_2
example : Approved.execution_2_3 := Proofs.execution_2_3
#print axioms Proofs.execution_2_3
example : Approved.witness_2_3 := Proofs.witness_2_3
#print axioms Proofs.witness_2_3
example : Approved.execution_2_4 := Proofs.execution_2_4
#print axioms Proofs.execution_2_4
example : Approved.witness_2_4 := Proofs.witness_2_4
#print axioms Proofs.witness_2_4
example : Approved.initial_valid_3 := Proofs.initial_valid_3
#print axioms Proofs.initial_valid_3
example : Approved.execution_3_0 := Proofs.execution_3_0
#print axioms Proofs.execution_3_0
example : Approved.witness_3_0 := Proofs.witness_3_0
#print axioms Proofs.witness_3_0
example : Approved.execution_3_1 := Proofs.execution_3_1
#print axioms Proofs.execution_3_1
example : Approved.witness_3_1 := Proofs.witness_3_1
#print axioms Proofs.witness_3_1
example : Approved.execution_3_2 := Proofs.execution_3_2
#print axioms Proofs.execution_3_2
example : Approved.witness_3_2 := Proofs.witness_3_2
#print axioms Proofs.witness_3_2
example : Approved.initial_valid_4 := Proofs.initial_valid_4
#print axioms Proofs.initial_valid_4
example : Approved.execution_4_0 := Proofs.execution_4_0
#print axioms Proofs.execution_4_0
example : Approved.witness_4_0 := Proofs.witness_4_0
#print axioms Proofs.witness_4_0
example : Approved.execution_4_1 := Proofs.execution_4_1
#print axioms Proofs.execution_4_1
example : Approved.witness_4_1 := Proofs.witness_4_1
#print axioms Proofs.witness_4_1
example : Approved.execution_4_2 := Proofs.execution_4_2
#print axioms Proofs.execution_4_2
example : Approved.witness_4_2 := Proofs.witness_4_2
#print axioms Proofs.witness_4_2
example : Approved.execution_4_3 := Proofs.execution_4_3
#print axioms Proofs.execution_4_3
example : Approved.witness_4_3 := Proofs.witness_4_3
#print axioms Proofs.witness_4_3
example : Approved.initial_valid_5 := Proofs.initial_valid_5
#print axioms Proofs.initial_valid_5
example : Approved.execution_5_0 := Proofs.execution_5_0
#print axioms Proofs.execution_5_0
example : Approved.witness_5_0 := Proofs.witness_5_0
#print axioms Proofs.witness_5_0
example : Approved.execution_5_1 := Proofs.execution_5_1
#print axioms Proofs.execution_5_1
example : Approved.witness_5_1 := Proofs.witness_5_1
#print axioms Proofs.witness_5_1
example : Approved.initial_valid_6 := Proofs.initial_valid_6
#print axioms Proofs.initial_valid_6
example : Approved.buffer_length_6_0 := Proofs.buffer_length_6_0
#print axioms Proofs.buffer_length_6_0
example : Approved.buffer_execution_6_0 := Proofs.buffer_execution_6_0
#print axioms Proofs.buffer_execution_6_0
example : Approved.execution_6_0 := Proofs.execution_6_0
#print axioms Proofs.execution_6_0
example : Approved.witness_6_0 := Proofs.witness_6_0
#print axioms Proofs.witness_6_0
example : Approved.buffer_length_6_1 := Proofs.buffer_length_6_1
#print axioms Proofs.buffer_length_6_1
example : Approved.buffer_execution_6_1 := Proofs.buffer_execution_6_1
#print axioms Proofs.buffer_execution_6_1
example : Approved.execution_6_1 := Proofs.execution_6_1
#print axioms Proofs.execution_6_1
example : Approved.witness_6_1 := Proofs.witness_6_1
#print axioms Proofs.witness_6_1
#print axioms FormalSpecAgent.TimerMinimum.next_info
#print axioms FormalSpecAgent.TimerEffects.work_summary
#print axioms FormalSpecAgent.TimerProgress.step_progress
#print axioms FormalSpecAgent.BatchMachine.advanceAux
#print axioms FormalSpecAgent.BatchMachine.advance
#print axioms FormalSpecAgent.BatchMachine.tick
#print axioms FormalSpecAgent.BatchMachine.dispatch
#print axioms FormalSpecAgent.BatchMachine.rollback
#print axioms FormalSpecAgent.BatchReplay.sound
#print axioms FormalSpecAgent.BatchReplay.advance_equation
#print axioms FormalSpecAgent.BatchReplay.advance_past
#print axioms FormalSpecAgent.BatchReplay.advance_result
#print axioms FormalSpecAgent.BatchReplay.tick_failure
#print axioms FormalSpecAgent.BatchReplay.tick_success
#print axioms FormalSpecAgent.BatchReplay.dispatch_timer_failure
#print axioms FormalSpecAgent.BatchReplay.dispatch_after_timers
#print axioms FormalSpecAgent.BatchReplay.prefix_failure_rolls_back
