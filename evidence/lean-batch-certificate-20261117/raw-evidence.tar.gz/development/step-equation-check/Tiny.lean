import Approved
open FormalSpecAgent.TypedMachine FormalSpecAgent.TimerRank FormalSpecAgent.BatchMachine
set_option trace.Meta.Tactic.simp.rewrite true
set_option trace.Meta.Tactic.simp.discharge true
example : advance Approved.model Approved.initial_0 0 =
    .ok { after := { Approved.initial_0 with now := 0 }, trace := [] } := by
  simp (disch := decide) [FormalSpecAgent.BatchReplay.advance_equation, WellTimed,
    Approved.initial_0, nextTimer]
