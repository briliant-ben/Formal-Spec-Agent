import Approved
open FormalSpecAgent.TypedMachine FormalSpecAgent.TimerRank FormalSpecAgent.BatchMachine
example : WellTimed Approved.initial_0 := by decide
example : WellTimed Approved.initial_0 := by simp [WellTimed, Approved.initial_0]
example : advance Approved.model Approved.initial_0 0 =
    .ok { after := { Approved.initial_0 with now := 0 }, trace := [] } := by
  simp (disch := simp [WellTimed]) [FormalSpecAgent.BatchReplay.advance_equation,
    Approved.initial_0, nextTimer]
