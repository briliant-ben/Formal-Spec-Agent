import Approved

set_option maxRecDepth 16384

namespace Proofs

theorem timer_progress : Approved.timer_progress := by
  exact FormalSpecAgent.TimerProgress.step_progress

theorem rollback_error : Approved.rollback_error := by
  exact FormalSpecAgent.BatchMachine.rollback_error

theorem initial_valid_0 : Approved.initial_valid_0 := by
  simp only [Approved.initial_valid_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem execution_0_0 : Approved.execution_0_0 := by
  unfold Approved.execution_0_0
  simp only [Approved.result_0_0, Approved.initial_0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_0_0 : Approved.witness_0_0 := by
  have replay := Proofs.execution_0_0
  unfold Approved.execution_0_0 at replay
  unfold Approved.witness_0_0
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_0_1 : Approved.execution_0_1 := by
  have replay0 := Proofs.execution_0_0
  unfold Approved.execution_0_0 at replay0
  unfold Approved.execution_0_1
  simp only [Approved.result_0_1, Approved.initial_0, Approved.after_0_0, replay0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_0_1 : Approved.witness_0_1 := by
  have replay := Proofs.execution_0_1
  unfold Approved.execution_0_1 at replay
  unfold Approved.witness_0_1
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_0_2 : Approved.execution_0_2 := by
  have replay0 := Proofs.execution_0_0
  unfold Approved.execution_0_0 at replay0
  have replay1 := Proofs.execution_0_1
  unfold Approved.execution_0_1 at replay1
  unfold Approved.execution_0_2
  simp only [Approved.result_0_2, Approved.initial_0, Approved.after_0_0, Approved.after_0_1, replay0, replay1, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_0_2 : Approved.witness_0_2 := by
  have replay := Proofs.execution_0_2
  unfold Approved.execution_0_2 at replay
  unfold Approved.witness_0_2
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem initial_valid_1 : Approved.initial_valid_1 := by
  simp only [Approved.initial_valid_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem execution_1_0 : Approved.execution_1_0 := by
  unfold Approved.execution_1_0
  simp only [Approved.result_1_0, Approved.initial_1, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_1_0 : Approved.witness_1_0 := by
  have replay := Proofs.execution_1_0
  unfold Approved.execution_1_0 at replay
  unfold Approved.witness_1_0
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_1_1 : Approved.execution_1_1 := by
  have replay0 := Proofs.execution_1_0
  unfold Approved.execution_1_0 at replay0
  unfold Approved.execution_1_1
  simp only [Approved.result_1_1, Approved.initial_1, Approved.after_1_0, replay0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_1_1 : Approved.witness_1_1 := by
  have replay := Proofs.execution_1_1
  unfold Approved.execution_1_1 at replay
  unfold Approved.witness_1_1
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_1_2 : Approved.execution_1_2 := by
  have replay0 := Proofs.execution_1_0
  unfold Approved.execution_1_0 at replay0
  have replay1 := Proofs.execution_1_1
  unfold Approved.execution_1_1 at replay1
  unfold Approved.execution_1_2
  simp only [Approved.result_1_2, Approved.initial_1, Approved.after_1_0, Approved.after_1_1, replay0, replay1, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_1_2 : Approved.witness_1_2 := by
  have replay := Proofs.execution_1_2
  unfold Approved.execution_1_2 at replay
  unfold Approved.witness_1_2
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem initial_valid_2 : Approved.initial_valid_2 := by
  simp only [Approved.initial_valid_2, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem execution_2_0 : Approved.execution_2_0 := by
  unfold Approved.execution_2_0
  simp only [Approved.result_2_0, Approved.initial_2, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_2_0 : Approved.witness_2_0 := by
  have replay := Proofs.execution_2_0
  unfold Approved.execution_2_0 at replay
  unfold Approved.witness_2_0
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_2_1 : Approved.execution_2_1 := by
  have replay0 := Proofs.execution_2_0
  unfold Approved.execution_2_0 at replay0
  unfold Approved.execution_2_1
  simp only [Approved.result_2_1, Approved.initial_2, Approved.after_2_0, replay0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_2_1 : Approved.witness_2_1 := by
  have replay := Proofs.execution_2_1
  unfold Approved.execution_2_1 at replay
  unfold Approved.witness_2_1
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_2_2 : Approved.execution_2_2 := by
  have replay0 := Proofs.execution_2_0
  unfold Approved.execution_2_0 at replay0
  have replay1 := Proofs.execution_2_1
  unfold Approved.execution_2_1 at replay1
  unfold Approved.execution_2_2
  simp only [Approved.result_2_2, Approved.initial_2, Approved.after_2_0, Approved.after_2_1, replay0, replay1, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_2_2 : Approved.witness_2_2 := by
  have replay := Proofs.execution_2_2
  unfold Approved.execution_2_2 at replay
  unfold Approved.witness_2_2
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_2_3 : Approved.execution_2_3 := by
  have replay0 := Proofs.execution_2_0
  unfold Approved.execution_2_0 at replay0
  have replay1 := Proofs.execution_2_1
  unfold Approved.execution_2_1 at replay1
  have replay2 := Proofs.execution_2_2
  unfold Approved.execution_2_2 at replay2
  unfold Approved.execution_2_3
  simp only [Approved.result_2_3, Approved.initial_2, Approved.after_2_0, Approved.after_2_1, Approved.after_2_2, replay0, replay1, replay2, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_2_3 : Approved.witness_2_3 := by
  have replay := Proofs.execution_2_3
  unfold Approved.execution_2_3 at replay
  unfold Approved.witness_2_3
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_2_4 : Approved.execution_2_4 := by
  have replay0 := Proofs.execution_2_0
  unfold Approved.execution_2_0 at replay0
  have replay1 := Proofs.execution_2_1
  unfold Approved.execution_2_1 at replay1
  have replay2 := Proofs.execution_2_2
  unfold Approved.execution_2_2 at replay2
  have replay3 := Proofs.execution_2_3
  unfold Approved.execution_2_3 at replay3
  unfold Approved.execution_2_4
  simp only [Approved.result_2_4, Approved.initial_2, Approved.after_2_0, Approved.after_2_1, Approved.after_2_2, Approved.after_2_3, replay0, replay1, replay2, replay3, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_2_4 : Approved.witness_2_4 := by
  have replay := Proofs.execution_2_4
  unfold Approved.execution_2_4 at replay
  unfold Approved.witness_2_4
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem initial_valid_3 : Approved.initial_valid_3 := by
  simp only [Approved.initial_valid_3, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem execution_3_0 : Approved.execution_3_0 := by
  unfold Approved.execution_3_0
  simp only [Approved.result_3_0, Approved.initial_3, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_3_0 : Approved.witness_3_0 := by
  have replay := Proofs.execution_3_0
  unfold Approved.execution_3_0 at replay
  unfold Approved.witness_3_0
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_3_1 : Approved.execution_3_1 := by
  have replay0 := Proofs.execution_3_0
  unfold Approved.execution_3_0 at replay0
  unfold Approved.execution_3_1
  simp only [Approved.result_3_1, Approved.initial_3, Approved.after_3_0, replay0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_3_1 : Approved.witness_3_1 := by
  have replay := Proofs.execution_3_1
  unfold Approved.execution_3_1 at replay
  unfold Approved.witness_3_1
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_3_2 : Approved.execution_3_2 := by
  have replay0 := Proofs.execution_3_0
  unfold Approved.execution_3_0 at replay0
  have replay1 := Proofs.execution_3_1
  unfold Approved.execution_3_1 at replay1
  unfold Approved.execution_3_2
  simp only [Approved.result_3_2, Approved.initial_3, Approved.after_3_0, Approved.after_3_1, replay0, replay1, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_3_2 : Approved.witness_3_2 := by
  have replay := Proofs.execution_3_2
  unfold Approved.execution_3_2 at replay
  unfold Approved.witness_3_2
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem initial_valid_4 : Approved.initial_valid_4 := by
  simp only [Approved.initial_valid_4, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem execution_4_0 : Approved.execution_4_0 := by
  unfold Approved.execution_4_0
  simp only [Approved.result_4_0, Approved.initial_4, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_4_0 : Approved.witness_4_0 := by
  have replay := Proofs.execution_4_0
  unfold Approved.execution_4_0 at replay
  unfold Approved.witness_4_0
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_4_1 : Approved.execution_4_1 := by
  have replay0 := Proofs.execution_4_0
  unfold Approved.execution_4_0 at replay0
  unfold Approved.execution_4_1
  simp only [Approved.result_4_1, Approved.initial_4, Approved.after_4_0, replay0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_4_1 : Approved.witness_4_1 := by
  have replay := Proofs.execution_4_1
  unfold Approved.execution_4_1 at replay
  unfold Approved.witness_4_1
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_4_2 : Approved.execution_4_2 := by
  have replay0 := Proofs.execution_4_0
  unfold Approved.execution_4_0 at replay0
  have replay1 := Proofs.execution_4_1
  unfold Approved.execution_4_1 at replay1
  unfold Approved.execution_4_2
  simp only [Approved.result_4_2, Approved.initial_4, Approved.after_4_0, Approved.after_4_1, replay0, replay1, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_4_2 : Approved.witness_4_2 := by
  have replay := Proofs.execution_4_2
  unfold Approved.execution_4_2 at replay
  unfold Approved.witness_4_2
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_4_3 : Approved.execution_4_3 := by
  have replay0 := Proofs.execution_4_0
  unfold Approved.execution_4_0 at replay0
  have replay1 := Proofs.execution_4_1
  unfold Approved.execution_4_1 at replay1
  have replay2 := Proofs.execution_4_2
  unfold Approved.execution_4_2 at replay2
  unfold Approved.execution_4_3
  simp only [Approved.result_4_3, Approved.initial_4, Approved.after_4_0, Approved.after_4_1, Approved.after_4_2, replay0, replay1, replay2, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_4_3 : Approved.witness_4_3 := by
  have replay := Proofs.execution_4_3
  unfold Approved.execution_4_3 at replay
  unfold Approved.witness_4_3
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem initial_valid_5 : Approved.initial_valid_5 := by
  simp only [Approved.initial_valid_5, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem execution_5_0 : Approved.execution_5_0 := by
  unfold Approved.execution_5_0
  simp only [Approved.result_5_0, Approved.initial_5, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_5_0 : Approved.witness_5_0 := by
  have replay := Proofs.execution_5_0
  unfold Approved.execution_5_0 at replay
  unfold Approved.witness_5_0
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_5_1 : Approved.execution_5_1 := by
  have replay0 := Proofs.execution_5_0
  unfold Approved.execution_5_0 at replay0
  unfold Approved.execution_5_1
  simp only [Approved.result_5_1, Approved.initial_5, Approved.after_5_0, replay0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_5_1 : Approved.witness_5_1 := by
  have replay := Proofs.execution_5_1
  unfold Approved.execution_5_1 at replay
  unfold Approved.witness_5_1
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem initial_valid_6 : Approved.initial_valid_6 := by
  simp only [Approved.initial_valid_6, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem execution_6_0 : Approved.execution_6_0 := by
  unfold Approved.execution_6_0
  simp only [Approved.result_6_0, Approved.initial_6, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_6_0 : Approved.witness_6_0 := by
  have replay := Proofs.execution_6_0
  unfold Approved.execution_6_0 at replay
  unfold Approved.witness_6_0
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem execution_6_1 : Approved.execution_6_1 := by
  have replay0 := Proofs.execution_6_0
  unfold Approved.execution_6_0 at replay0
  unfold Approved.execution_6_1
  simp only [Approved.result_6_1, Approved.initial_6, Approved.after_6_0, replay0, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.BatchMachine.dispatch, FormalSpecAgent.BatchMachine.tick, FormalSpecAgent.BatchMachine.rollback, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.stepTimer, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.cancelTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TimerRank.WellTimed, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, List.length_replicate, List.length_append, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, Approved.schema, Approved.eventSchemas, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.model_timer_event, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.rule_8, Approved.rule_9, Approved.rule_10, Approved.rule_11, Approved.rule_12, Approved.rule_13, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

theorem witness_6_1 : Approved.witness_6_1 := by
  have replay := Proofs.execution_6_1
  unfold Approved.execution_6_1 at replay
  unfold Approved.witness_6_1
  simp only [replay, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchMachine.rollback]
  try
    simp (disch := decide) [Approved.schema, Approved.eventSchemas, FormalSpecAgent.BatchObserve.outcome, FormalSpecAgent.BatchObserve.transition, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.MachineObserve.ordered, FormalSpecAgent.MachineObserve.insertBySlot, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.BatchReplay.advance_equation, FormalSpecAgent.BatchReplay.advance_past, FormalSpecAgent.BatchReplay.prepend]
  try
    rfl
  try
    decide

end Proofs
