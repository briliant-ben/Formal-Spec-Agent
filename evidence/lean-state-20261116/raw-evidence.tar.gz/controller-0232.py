from pathlib import Path
import json,sys,os,time,hashlib,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/lean-state-transaction-20261116-0232';O.mkdir(exist_ok=False)
save=lambda n,x:(O/n).write_text(json.dumps(x,indent=2)+'\n')
def st(s,**kw):save('status.json',dict(status=s,pid=os.getpid(),updated_at=time.time(),**kw))
(O/'controller.py').write_bytes(Path(__file__).read_bytes())
try:
 data=(P/'incoming/fsa-state-0232-input.json').read_bytes();(O/'input.json').write_bytes(data);save('input-hash.json',dict(sha256=hashlib.sha256(data).hexdigest()))
 ms=[dict(role='system',content='Propose proof data only for frozen Lean statements. No execution or spec changes. Controller and actual kernel decide acceptance.'),dict(role='user',content=data.decode())]
 st('running',stage='DeepSeek_state_proof_proposal');sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 a=request(ms,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=6500,thinking='disabled',reasoning_effort=None,timeout=900)
 r=json.loads((P/'private/api-ledger'/a['response_file']).read_text())['response'];save('response.json',r);save('usage.json',{k:a.get(k)for k in ['usage','cached','request_sha256']})
 assert set(r)=={'proofs','findings','limitations'} and type(r['proofs'])is dict and all(type(r[k])is list for k in ['findings','limitations'])
 save('proofs.json',r['proofs']);st('proposal_received_requires_kernel_check',proofs=len(r['proofs']))
except Exception as e:(O/'traceback.txt').write_text(traceback.format_exc());st('failed_or_rejected_no_retry',error_type=type(e).__name__)
