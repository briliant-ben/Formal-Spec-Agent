import Proofs

example : Approved.failure_rolls_back := Proofs.failure_rolls_back
#print axioms Proofs.failure_rolls_back
example : Approved.success_checks_invariants := Proofs.success_checks_invariants
#print axioms Proofs.success_checks_invariants
example : Approved.assignment_then_emission := Proofs.assignment_then_emission
#print axioms Proofs.assignment_then_emission
example : Approved.witness_success := Proofs.witness_success
#print axioms Proofs.witness_success
example : Approved.witness_success_admitted := Proofs.witness_success_admitted
#print axioms Proofs.witness_success_admitted
example : Approved.witness_negative := Proofs.witness_negative
#print axioms Proofs.witness_negative
example : Approved.witness_negative_admitted := Proofs.witness_negative_admitted
#print axioms Proofs.witness_negative_admitted
example : Approved.witness_over_bound := Proofs.witness_over_bound
#print axioms Proofs.witness_over_bound
example : Approved.witness_over_bound_admitted := Proofs.witness_over_bound_admitted
#print axioms Proofs.witness_over_bound_admitted
example : Approved.witness_zero := Proofs.witness_zero
#print axioms Proofs.witness_zero
example : Approved.witness_zero_admitted := Proofs.witness_zero_admitted
#print axioms Proofs.witness_zero_admitted
