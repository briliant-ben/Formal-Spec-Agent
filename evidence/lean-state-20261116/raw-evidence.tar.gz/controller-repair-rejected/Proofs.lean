import Approved

namespace Proofs

theorem failure_rolls_back : Approved.failure_rolls_back := by
  unfold Approved.failure_rolls_back
  intro actions invariants s env
  unfold FormalSpecAgent.StateSubset.execute
  split
  ·
    simp_all
  ·
    simp_all

theorem success_checks_invariants : Approved.success_checks_invariants := by
  unfold Approved.success_checks_invariants
  intro actions invariants s env
  unfold FormalSpecAgent.StateSubset.execute
  split
  ·
    simp_all
  ·
    simp_all

theorem assignment_then_emission : Approved.assignment_then_emission := by
  unfold Approved.assignment_then_emission
  intro s env n value h
  simp [FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger, List.getD_eq_getElem?_getD, List.getElem?_set_self]

theorem witness_success : Approved.witness_success := by
  unfold Approved.witness_success
  rfl

theorem witness_success_admitted : Approved.witness_success_admitted := by
  unfold Approved.witness_success_admitted
  decide

theorem witness_negative : Approved.witness_negative := by
  unfold Approved.witness_negative
  rfl

theorem witness_negative_admitted : Approved.witness_negative_admitted := by
  unfold Approved.witness_negative_admitted
  decide

theorem witness_over_bound : Approved.witness_over_bound := by
  unfold Approved.witness_over_bound
  rfl

theorem witness_over_bound_admitted : Approved.witness_over_bound_admitted := by
  unfold Approved.witness_over_bound_admitted
  decide

theorem witness_zero : Approved.witness_zero := by
  unfold Approved.witness_zero
  rfl

theorem witness_zero_admitted : Approved.witness_zero_admitted := by
  unfold Approved.witness_zero_admitted
  decide

end Proofs
