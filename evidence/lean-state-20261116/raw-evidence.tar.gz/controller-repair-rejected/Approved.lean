import StateSubset

namespace Approved

def actions : List FormalSpecAgent.StateSubset.Action :=
  [(FormalSpecAgent.StateSubset.Action.assign 0 (FormalSpecAgent.StateSubset.IntegerExpr.field 0)), (FormalSpecAgent.StateSubset.Action.emit 0 (FormalSpecAgent.StateSubset.IntegerExpr.variable 0)), (FormalSpecAgent.StateSubset.Action.assign 1 (FormalSpecAgent.StateSubset.IntegerExpr.variable 0)), (FormalSpecAgent.StateSubset.Action.emit 0 (FormalSpecAgent.StateSubset.IntegerExpr.variable 1))]

def invariants : List FormalSpecAgent.StateSubset.Predicate :=
  [(FormalSpecAgent.StateSubset.Predicate.conjunction (FormalSpecAgent.StateSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.literal (0)) (FormalSpecAgent.StateSubset.IntegerExpr.variable 0)) (FormalSpecAgent.StateSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.variable 0) (FormalSpecAgent.StateSubset.IntegerExpr.literal (255)))), (FormalSpecAgent.StateSubset.Predicate.conjunction (FormalSpecAgent.StateSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.literal (0)) (FormalSpecAgent.StateSubset.IntegerExpr.variable 1)) (FormalSpecAgent.StateSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.variable 1) (FormalSpecAgent.StateSubset.IntegerExpr.literal (255))))]

def failure_rolls_back : Prop :=
  ∀ (actions : List FormalSpecAgent.StateSubset.Action) (invariants : List FormalSpecAgent.StateSubset.Predicate) (s env : List Int), (FormalSpecAgent.StateSubset.execute actions invariants s env).accepted = false → FormalSpecAgent.StateSubset.execute actions invariants s env = ⟨false, s, []⟩

def success_checks_invariants : Prop :=
  ∀ (actions : List FormalSpecAgent.StateSubset.Action) (invariants : List FormalSpecAgent.StateSubset.Predicate) (s env : List Int), (FormalSpecAgent.StateSubset.execute actions invariants s env).accepted = true → FormalSpecAgent.StateSubset.invariantsHold invariants (FormalSpecAgent.StateSubset.execute actions invariants s env).values = true

def assignment_then_emission : Prop :=
  ∀ (s env : List Int) (n : Nat) (value : Int), n < s.length → FormalSpecAgent.StateSubset.work [FormalSpecAgent.StateSubset.Action.assign n (FormalSpecAgent.StateSubset.IntegerExpr.literal value), FormalSpecAgent.StateSubset.Action.emit 0 (FormalSpecAgent.StateSubset.IntegerExpr.variable n)] s env [] = (s.set n value, [(0, value)])

def witness_success : Prop :=
  FormalSpecAgent.StateSubset.execute actions invariants [(7), (3)] [(65)] = ⟨true, [(65), (65)], [(0, (65)), (0, (65))]⟩

def witness_success_admitted : Prop :=
  FormalSpecAgent.StateSubset.invariantsHold invariants [(7), (3)] = true

def witness_negative : Prop :=
  FormalSpecAgent.StateSubset.execute actions invariants [(7), (3)] [(-1)] = ⟨false, [(7), (3)], []⟩

def witness_negative_admitted : Prop :=
  FormalSpecAgent.StateSubset.invariantsHold invariants [(7), (3)] = true

def witness_over_bound : Prop :=
  FormalSpecAgent.StateSubset.execute actions invariants [(7), (3)] [(256)] = ⟨false, [(7), (3)], []⟩

def witness_over_bound_admitted : Prop :=
  FormalSpecAgent.StateSubset.invariantsHold invariants [(7), (3)] = true

def witness_zero : Prop :=
  FormalSpecAgent.StateSubset.execute actions invariants [(7), (3)] [(0)] = ⟨true, [(0), (0)], [(0, (0)), (0, (0))]⟩

def witness_zero_admitted : Prop :=
  FormalSpecAgent.StateSubset.invariantsHold invariants [(7), (3)] = true

end Approved
