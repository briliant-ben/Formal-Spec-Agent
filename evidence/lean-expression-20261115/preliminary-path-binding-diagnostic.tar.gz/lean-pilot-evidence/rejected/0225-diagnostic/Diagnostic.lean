import Approved
namespace Proofs
theorem byte_at_range : Approved.byte_at_range := by
  intro xs i
  unfold FormalSpecAgent.byteAt
  split
  ·
    omega
  ·
    have hlt := (xs.getD i.toNat 0).isLt
    omega
theorem negative_read : Approved.negative_read := by
  intro xs i hi
  unfold FormalSpecAgent.byteAt
  split
  ·
    rfl
  ·
    omega
theorem witness_valid : Approved.witness_valid := by
  unfold expression
  decide
end Proofs
