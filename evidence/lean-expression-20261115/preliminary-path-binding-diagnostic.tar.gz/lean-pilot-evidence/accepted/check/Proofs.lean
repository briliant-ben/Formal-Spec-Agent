import Approved

namespace Proofs

theorem byte_at_range : Approved.byte_at_range := by
  intro xs i
  unfold FormalSpecAgent.byteAt
  split
  ·
    omega
  ·
    have hlt := (xs.getD i.toNat 0).isLt
    constructor
    ·
      exact Int.natCast_nonneg _
    ·
      exact Int.ofNat_lt.mpr hlt

theorem negative_read : Approved.negative_read := by
  intro xs i hi
  unfold FormalSpecAgent.byteAt
  simp [hi]

theorem slice_length : Approved.slice_length := by
  intro xs offset count
  unfold FormalSpecAgent.byteSlice
  simp [List.length_take, List.length_drop]
  omega

theorem expression_range : Approved.expression_range := by
  intro f0 f1 f2 f3 f4
  unfold Approved.expression
  simp [FormalSpecAgent.byteAt]
  have hbyte := Proofs.byte_at_range (FormalSpecAgent.byteSlice f0 f1 f2) f3
  omega

theorem witness_valid : Approved.witness_valid := by
  unfold Approved.witness_valid
  decide

theorem witness_negative : Approved.witness_negative := by
  unfold Approved.witness_negative
  decide

theorem witness_outside : Approved.witness_outside := by
  unfold Approved.witness_outside
  decide

theorem witness_disabled : Approved.witness_disabled := by
  unfold Approved.witness_disabled
  decide

theorem witness_maximum : Approved.witness_maximum := by
  unfold Approved.witness_maximum
  decide

end Proofs
