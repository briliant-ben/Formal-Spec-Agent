import Proofs

example : Approved.byte_at_range := Proofs.byte_at_range
#print axioms Proofs.byte_at_range
example : Approved.negative_read := Proofs.negative_read
#print axioms Proofs.negative_read
example : Approved.slice_length := Proofs.slice_length
#print axioms Proofs.slice_length
example : Approved.expression_range := Proofs.expression_range
#print axioms Proofs.expression_range
example : Approved.witness_valid := Proofs.witness_valid
#print axioms Proofs.witness_valid
example : Approved.witness_negative := Proofs.witness_negative
#print axioms Proofs.witness_negative
example : Approved.witness_outside := Proofs.witness_outside
#print axioms Proofs.witness_outside
example : Approved.witness_disabled := Proofs.witness_disabled
#print axioms Proofs.witness_disabled
example : Approved.witness_maximum := Proofs.witness_maximum
#print axioms Proofs.witness_maximum
