import Foundation

namespace Approved

def expression (f0 : FormalSpecAgent.Bytes) (f1 : Int) (f2 : Int) (f3 : Int) (f4 : Bool) : Int :=
  (if f4 then (FormalSpecAgent.byteAt (FormalSpecAgent.byteSlice f0 f1 f2) f3) else (0))

def byte_at_range : Prop :=
  ∀ (xs : FormalSpecAgent.Bytes) (i : Int), 0 <= FormalSpecAgent.byteAt xs i ∧ FormalSpecAgent.byteAt xs i < 256

def negative_read : Prop :=
  ∀ (xs : FormalSpecAgent.Bytes) (i : Int), i < 0 → FormalSpecAgent.byteAt xs i = 0

def slice_length : Prop :=
  ∀ (xs : FormalSpecAgent.Bytes) (offset count : Int), (FormalSpecAgent.byteSlice xs offset count).length <= xs.length ∧ (FormalSpecAgent.byteSlice xs offset count).length <= count.toNat

def expression_range : Prop :=
  ∀ (f0 : FormalSpecAgent.Bytes) (f1 : Int) (f2 : Int) (f3 : Int) (f4 : Bool), (0) <= expression f0 f1 f2 f3 f4 ∧ expression f0 f1 f2 f3 f4 <= (255)

def witness_valid : Prop :=
  expression ([⟨65, by decide⟩, ⟨128, by decide⟩]) ((0)) ((2)) ((0)) (true) = (65)

def witness_negative : Prop :=
  expression ([⟨65, by decide⟩]) ((0)) ((1)) ((-1)) (true) = (0)

def witness_outside : Prop :=
  expression ([⟨65, by decide⟩]) ((0)) ((1)) ((3)) (true) = (0)

def witness_disabled : Prop :=
  expression ([⟨65, by decide⟩]) ((0)) ((1)) ((0)) (false) = (0)

def witness_maximum : Prop :=
  expression ([⟨255, by decide⟩]) ((-1)) ((1)) ((0)) (true) = (255)

end Approved
