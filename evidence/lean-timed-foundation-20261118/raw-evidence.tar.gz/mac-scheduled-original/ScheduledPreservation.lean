import TypedFiringContracts
import TimerMinimum

namespace FormalSpecAgent.ScheduledPreservation

open FormalSpecAgent.TypedMachine
open FormalSpecAgent.TypedIR
open FormalSpecAgent.TypedContracts
open FormalSpecAgent.TypedFiringContracts
open FormalSpecAgent.TimerRank
open FormalSpecAgent.TimerMinimum

/-- MatchingRaw: for a given event and optional firing, every rule in the model
whose event matches has the raw firing preservation property for that firing.
This is a precondition on the model, not a postcondition. -/
def MatchingRaw (model : Model) (event : Nat) (firing : Option Nat) : Prop :=
  ∀ r ∈ model.rules, r.event = event → FiringPreserves model r firing

/-- If fire returns ok, then it must have selected a single enabled rule.
This inversion is used in the bridge to obtain the rule and its properties. -/
private lemma fire_ok_singleton (model : Model) (snapshot : Snapshot) (event : Nat)
    (fields : Values) (firing : Option Nat) (t : Transition) :
    fire model snapshot event fields firing = .ok t →
    ∃ r : Rule,
      enabled model snapshot event fields = [r] ∧
      r.source = snapshot.state ∧
      r.event = event ∧
      eval snapshot fields r.guard = true ∧
      runRule model snapshot r fields event firing = .ok t :=
by
  intro hfire
  unfold fire at hfire
  cases hen : enabled model snapshot event fields with
  | nil => simp [hen] at hfire
  | cons r1 rest =>
      cases hrest : rest with
      | nil =>
          -- enabled = [r1]
          have henabled : enabled model snapshot event fields = [r1] := by
            rw [hen, hrest]
          -- From the definition of enabled, r1 is in the list, so it satisfies the filter.
          have hmem : r1 ∈ enabled model snapshot event fields := by
            rw [henabled]
            exact List.mem_singleton_self r1
          have hfilter := (List.mem_filter.mp hmem).2
          simp only [Bool.and_eq_true, beq_iff_eq] at hfilter
          obtain ⟨hsrc, hev, hgd⟩ := hfilter
          -- Since enabled is singleton, fire reduces to runRule r1 with event and firing.
          have hrun_ok : runRule model snapshot r1 fields event firing = .ok t := by
            rw [henabled] at hfire
            -- hfire : match [r1] with ... => ...
            simpa only [hsrc, hev] using hfire
          exact ⟨r1, henabled, hsrc, hev, hgd, hrun_ok⟩
      | cons r2 rest2 =>
          -- enabled has at least two rules, fire returns error conflict
          have hconf : fire model snapshot event fields firing = .error .conflict := by
            rw [hen, hrest]
            rfl
          rw [hconf] at hfire
          contradiction

/-- Direct bridge from MatchingRaw to fire success invariant. We do not rely on runRule's
internal invariant filtering; instead we use the raw preservation property to construct a
witness transition and then unify it with the actual runRule result. -/
theorem fire_success_invariant_from_raw (model : Model) (snapshot : Snapshot) (event : Nat)
    (fields : Values) (firing : Option Nat) :
    MatchingRaw model event firing →
    invariantsHold model snapshot = true →
    fire model snapshot event fields firing = .ok ?t →
    invariantsHold model ?t.after = true :=
by
  intro hMatch hInv hfire
  -- Invert fire ok to get a rule r and its properties.
  obtain ⟨r, henabled, hsrc, hev, hgd, hrun⟩ := fire_ok_singleton model snapshot event fields firing _ hfire
  -- Since MatchingRaw holds for r, we have FiringPreserves model r firing.
  have hFiringPres : FiringPreserves model r firing := hMatch r (by
    -- show r ∈ model.rules
    have hmemEnabled : r ∈ enabled model snapshot event fields := by
      rw [henabled]
      exact List.mem_singleton_self r
    have hmemRules := (List.mem_filter.mp hmemEnabled).1
    exact hmemRules
  ) hev
  -- Use FiringPreserves to get a raw candidate transition t0 with invariant after.
  have hRaw := hFiringPres snapshot fields hInv hsrc hgd
  rcases hRaw with ⟨t0, hcand0, hAfter0⟩
  -- Show that runRule also returns the same transition, because actual runRule = candidate filtered by invariant,
  -- but candidate is ok and invariant holds, so the filter passes.
  have hrun_eq : runRule model snapshot r fields event firing = .ok t0 := by
    rw [runRule_eq_filter]
    rw [hcand0]
    simp [hAfter0]
  -- Unify with hrun: both are ok, so the transitions must be equal.
  have ht_eq : t0 = ?t := Option.some.inj (hrun_eq.trans hrun.symm)
  -- Then the invariant after is the same.
  rwa [← ht_eq]

/-- Bridge for external events: if the model provides MatchingRaw for none firing
when the event is external, and the external call succeeds, then invariants hold after.
We must first check time and pending timer conditions, then use clock irrelevance to
convert the snapshot to one with updated now, and apply the fire bridge. -/
theorem external_success_invariant_from_raw (model : Model) (snapshot : Snapshot) (event : Nat)
    (fields : Values) (time : Int) :
    (event ∈ model.externalEvents → MatchingRaw model event none) →
    invariantsHold model snapshot = true →
    external model snapshot event fields time = .ok ?t →
    invariantsHold model ?t.after = true :=
by
  intro hExtMatch hInv hExt
  unfold external at hExt
  -- The external function first checks time, then event membership, then pending timer.
  by_cases htime : time < snapshot.now
  · simp [htime] at hExt
  · -- time is valid, so continue
    simp only [htime, false_or] at hExt
    by_cases hext : event ∈ model.externalEvents
    · -- event is external, so we get MatchingRaw none
      have hMatch : MatchingRaw model event none := hExtMatch hext
      -- Check pending timer: if there is a timer due <= time, external would error pendingTimer.
      -- So we need to split on nextTimer snapshot.
      cases hnext : nextTimer snapshot with
      | none =>
          -- no next timer, so external proceeds to fire with now updated to time
          simp only [hext, hnext, if_true, if_false, Option.getD, none] at hExt
          -- After firing, we have an updated snapshot with now := time.
          -- The invariants are clock-irrelevant, so we can transfer.
          have hInvTime : invariantsHold model { snapshot with now := time } = true := by
            rw [← invariants_clock_irrelevant model snapshot time]
            exact hInv
          -- Fire call in external: fire model {snapshot with now := time} event fields none
          have hFireFromExt : fire model { snapshot with now := time } event fields none = .ok ?t := by
            simpa [hext, hnext, htime] using hExt
          -- Apply fire bridge to the updated snapshot
          have hFireInv := fire_success_invariant_from_raw model {snapshot with now := time} event fields none hMatch hInvTime hFireFromExt
          -- The transition after is the same, so invariant holds.
          exact hFireInv
      | some entry =>
          -- There is a next timer entry. If entry.due <= time, external would error pendingTimer.
          -- So we must have entry.due > time. We need to show that.
          have hnotDue : ¬ (entry.due ≤ time) := by
            intro hdue
            have hpend : (match nextTimer snapshot with | some te => decide (te.due <= time) | none => false) = true := by
              rw [hnext]
              simp [hdue]
            -- Then external would go to the pendingTimer branch and return error.
            have hExtErr : external model snapshot event fields time = .error .pendingTimer := by
              unfold external
              simp [htime, hext, hpend]
            rw [hExtErr] at hExt
            contradiction
          -- So entry.due > time, hence the pendingTimer condition is false.
          have hnotpend : (match nextTimer snapshot with | some te => decide (te.due <= time) | none => false) = false := by
            rw [hnext]
            simp [hnotDue]
          -- Now external proceeds to fire.
          simp only [hext, hnotpend, if_true, if_false] at hExt
          have hFireFromExt : fire model { snapshot with now := time } event fields none = .ok ?t := by
            simpa [hext, hnotpend, htime] using hExt
          have hInvTime : invariantsHold model { snapshot with now := time } = true := by
            rw [← invariants_clock_irrelevant model snapshot time]
            exact hInv
          have hFireInv := fire_success_invariant_from_raw model {snapshot with now := time} event fields none hMatch hInvTime hFireFromExt
          exact hFireInv
    · -- event not in externalEvents: external would error timerInjection.
      -- Since hExt is ok, this case is impossible.
      have hExtErr : external model snapshot event fields time = .error .timerInjection := by
        unfold external
        simp [htime, hext]
      rw [hExtErr] at hExt
      contradiction

/-- Bridge for timer events: if for every timer entry in the snapshot, the model provides
MatchingRaw for its timer event with firing (some entry.timer), then a successful stepTimer
preserves invariants. We use next_info to get the selected timer entry's membership and
the fact that it is the minimum. -/
theorem timer_success_invariant_from_raw (model : Model) (snapshot : Snapshot) (time : Int) :
    (∀ entry ∈ snapshot.timers, MatchingRaw model (model.timerEvents entry.timer) (some entry.timer)) →
    invariantsHold model snapshot = true →
    stepTimer model snapshot time = .ok ?t →
    invariantsHold model ?t.after = true :=
by
  intro hTimerMatch hInv hStep
  unfold stepTimer at hStep
  by_cases htime : time < snapshot.now
  · simp [htime] at hStep
  · -- time is not less than now
    simp only [htime, false_or] at hStep
    -- Need a timer to be due at time.
    cases hnext : nextTimer snapshot with
    | none =>
        -- no timer, error noTimer
        have hErr : stepTimer model snapshot time = .error .noTimer := by
          unfold stepTimer
          simp [htime, hnext]
        rw [hErr] at hStep
        contradiction
    | some entry =>
        -- There is a selected entry.
        -- It must be due at exactly time, else error time.
        by_cases hdue : entry.due = time
        · -- due exactly, proceed to fire
          simp only [hdue, if_true] at hStep
          -- After the due check, stepTimer calls fire with snapshot{now := time} and firing some entry.timer.
          have hFireFromStep : fire model { snapshot with now := time } (model.timerEvents entry.timer) zeroValues (some entry.timer) = .ok ?t := by
            simpa [htime, hnext, hdue] using hStep
          -- We need MatchingRaw for this entry's event and firing.
          -- From next_info, entry ∈ snapshot.timers.
          have hEntryMem : entry ∈ snapshot.timers := (next_info snapshot entry hnext).1
          have hMatch := hTimerMatch entry hEntryMem
          -- Invariants on updated snapshot:
          have hInvTime : invariantsHold model { snapshot with now := time } = true := by
            rw [← invariants_clock_irrelevant model snapshot time]
            exact hInv
          -- Apply fire bridge.
          have hFireInv := fire_success_invariant_from_raw model {snapshot with now := time} (model.timerEvents entry.timer) zeroValues (some entry.timer) hMatch hInvTime hFireFromStep
          exact hFireInv
        · -- due not equal time, so stepTimer would error time.
          have hErr : stepTimer model snapshot time = .error .time := by
            unfold stepTimer
            simp [htime, hnext, hdue]
          rw [hErr] at hStep
          contradiction

end FormalSpecAgent.ScheduledPreservation