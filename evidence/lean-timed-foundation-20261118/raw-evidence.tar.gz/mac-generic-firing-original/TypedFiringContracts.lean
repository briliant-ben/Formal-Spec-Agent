import TypedContracts

namespace FormalSpecAgent.TypedFiringContracts

open FormalSpecAgent.TypedMachine
open FormalSpecAgent.TypedIR
open FormalSpecAgent.TypedContracts

/-- FiringPreserves: raw preservation allowing an optional timer firing to be
removed before candidate. Mirrors RulePreserves, but with firing parameter. -/
def FiringPreserves (model : Model) (rule : Rule) (firing : Option Nat) : Prop :=
  ∀ (snapshot : Snapshot) (fields : Values),
    invariantsHold model snapshot = true →
    snapshot.state = rule.source →
    eval snapshot fields rule.guard = true →
    ∃ t : Transition,
      candidate snapshot rule fields rule.event firing = .ok t ∧
      invariantsHold model t.after = true

/-- none_equivalence: FiringPreserves with none equals RulePreserves. -/
theorem none_equivalence (model : Model) (rule : Rule) :
    FiringPreserves model rule none ↔ RulePreserves model rule := by
  unfold FiringPreserves RulePreserves
  simp only [forall_and]
  constructor
  · intro h s f hInv hSrc hGrd
    exact h s f hInv hSrc hGrd
  · intro h s f hInv hSrc hGrd
    exact h s f hInv hSrc hGrd

/-- eval_clock_irrelevant: expression evaluation does not depend on snapshot.now. -/
theorem eval_clock_irrelevant {k : Kind} (e : Expr k) (snapshot : Snapshot) (fields : Values) (now : Int) :
    eval snapshot fields e = eval { snapshot with now := now } fields e := by
  rfl

/-- invariants_clock_irrelevant: invariant satisfaction does not depend on now. -/
theorem invariants_clock_irrelevant (model : Model) (snapshot : Snapshot) (now : Int) :
    invariantsHold model snapshot = invariantsHold model { snapshot with now := now } := by
  unfold invariantsHold
  congr 1
  · apply List.all_congr
    intro inv _
    exact eval_clock_irrelevant inv snapshot zeroValues now

/-- preserving_firing_succeeds: FiringPreserves plus initial facts yields actual runRule success. -/
theorem preserving_firing_succeeds (model : Model) (rule : Rule) (snapshot : Snapshot)
    (fields : Values) (firing : Option Nat) :
    FiringPreserves model rule firing →
    invariantsHold model snapshot = true →
    snapshot.state = rule.source →
    eval snapshot fields rule.guard = true →
    ∃ t : Transition,
      runRule model snapshot rule fields rule.event firing = .ok t ∧
      invariantsHold model t.after = true := by
  intro hPres hInv hSrc hGuard
  have hRaw : ∃ t : Transition,
      candidate snapshot rule fields rule.event firing = .ok t ∧
      invariantsHold model t.after = true :=
    hPres snapshot fields hInv hSrc hGuard
  rcases hRaw with ⟨t, hcand, hAfter⟩
  have hrun : runRule model snapshot rule fields rule.event firing = .ok t := by
    rw [runRule_eq_filter]
    rw [hcand]
    simp [hAfter]
  exact ⟨t, hrun, hAfter⟩

/-- fire_singleton_succeeds: if enabled yields exactly [rule] and FiringPreserves holds,
then actual fire succeeds and final invariant holds. -/
theorem fire_singleton_succeeds (model : Model) (snapshot : Snapshot) (event : Nat)
    (fields : Values) (firing : Option Nat) (rule : Rule) :
    enabled model snapshot event fields = [rule] →
    FiringPreserves model rule firing →
    invariantsHold model snapshot = true →
    snapshot.state = rule.source →
    eval snapshot fields rule.guard = true →
    ∃ t : Transition,
      fire model snapshot event fields firing = .ok t ∧
      invariantsHold model t.after = true := by
  intro hEnabled hPres hInv hSrc hGuard
  have hRun : ∃ t : Transition,
      runRule model snapshot rule fields event firing = .ok t ∧
      invariantsHold model t.after = true := by
    have hPres' : FiringPreserves model rule firing := hPres
    have hRes := preserving_firing_succeeds model rule snapshot fields firing hPres' hInv hSrc hGuard
    -- need to match event: rule.event must equal event for enabled to be [rule]; from hEnabled
    -- enabled filter uses r.source == snapshot.state, r.event == event, guard true
    -- Since enabled = [rule], we know rule.event = event and rule.source = snapshot.state and eval guard true
    -- But those are already given as hSrc and hGuard, except event equality may not be assumed.
    -- However, we use fire which calls runRule with event. If rule.event ≠ event, enabled might still be [rule]?
    -- The filter checks r.event == event, so to be included rule.event must equal event.
    -- We can prove from hEnabled using list membership.
    have hEvent : rule.event = event := by
      have h_mem : rule ∈ enabled model snapshot event fields := by
        rw [hEnabled]
        simp
      unfold enabled at h_mem
      rw [List.mem_filter] at h_mem
      have hcond : rule.source == snapshot.state && rule.event == event && eval snapshot fields rule.guard := h_mem.2
      -- beq properties
      have h_event_eq : rule.event == event := by
        -- beq simplifies to Decidable equality?
        -- Since Nat has DecidableEq, == is decidable equality, but beq may be bool equality.
        -- In Lean, Nat's BEq instance is decidable equality, so rule.event == event means decide (rule.event = event)
        -- We need to extract equality.
        -- Actually, `rule.event == event` is `(rule.event == event) = true`? In filter condition it is boolean expression, so
        -- the condition is a Bool. We can use cases on beq.
        have h_event_beq : (rule.event == event) = true := by
          -- from hcond, we have conjunction of three bools, so we can use `simp at hcond` maybe
          -- Let's extract carefully.
          -- hcond : rule.source == snapshot.state && rule.event == event && eval snapshot fields rule.guard = true
          -- The && is boolean and, so we can apply `and_true_iff` etc.
          -- Simpler: use `by_cases` on equality
          by
            by_cases hEq : rule.event = event
            · simp [hEq]
            · exfalso
              have hFalse : (rule.source == snapshot.state && rule.event == event && eval snapshot fields rule.guard) = false := by
                simp [hEq, hGuard]
              rw [hFalse] at hcond
              contradiction
        exact eq_of_beq_eq_true h_event_beq
    -- Now use hRun with event = rule.event? Our runRule uses event param, so we need runRule with event = event.
    -- We got hRun from preserving_firing_succeeds with rule.event. Since rule.event = event, we can rw.
    rw [← hEvent] at hRun
    exact hRun
  rcases hRun with ⟨t, hRunOk, hAfter⟩
  unfold fire
  rw [hEnabled]
  exact ⟨t, hRunOk, hAfter⟩

end FormalSpecAgent.TypedFiringContracts