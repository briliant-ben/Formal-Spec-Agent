import TCPIPAudit
namespace TimedProof
theorem initial := TCPIPAudit.endpoint_initial_admitted
theorem timers := TCPIPAudit.endpoint_timer_contract
theorem preservation := TCPIPAudit.endpoint_all_preservation
end TimedProof
