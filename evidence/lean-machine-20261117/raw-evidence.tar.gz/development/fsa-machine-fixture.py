from pathlib import Path
import json,hashlib
r=Path('/Users/xubenling/Documents/ChatGPT/Protocol_Form/Formal-Spec-Agent/examples/lean-machine');r.mkdir()
w=lambda n,x:(r/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
op=lambda n,*a:dict(op=n,args=list(a));v=lambda n:dict(var=n);f=lambda n:dict(event=n);active=lambda n:dict(timer_active=n)
assign=lambda n,e:dict(set=dict(var=n,value=e));arm=lambda n,e:dict(arm=dict(timer=n,delay_ms=e))
fields=dict(n=v('n'),flag=v('flag'),seq=v('seq'),data=v('data'),text=v('text'),source_idle=dict(state='IDLE'),fired_active=active('a'),other_active=active('z'))
emit=dict(emit=dict(message='observed',fields=fields))
events={'start':dict(origin='application',fields={'payload':'bytes'}),'bad_delay':dict(origin='application',fields={'delay':'int'}),'bad_final':dict(origin='application',fields={}), 'rearm':dict(origin='application',fields={}), 'ambiguous':dict(origin='application',fields={}), 'gap':dict(origin='network',fields={}), 'a.expired':dict(origin='timer',fields={}), 'z.expired':dict(origin='timer',fields={})}
rules=[]
def rule(i,src,tgt,event,guard,actions):rules.append(dict(id=i,**{'from':src,'to':tgt},event=event,guard=guard,actions=actions,requirements=['TRANSACTION']))
rule('START','IDLE','BUSY','start',True,[assign('data',f('payload')),assign('n',4),assign('n',op('add',v('n'),1)),assign('flag',True),assign('seq',op('seq_add',v('seq'),1)),assign('text','开\n\0'),emit,arm('z',5),arm('a',5)])
rule('BAD-DELAY','IDLE','BUSY','bad_delay',True,[assign('n',10),emit,arm('a',f('delay'))])
rule('BAD-FINAL','IDLE','DONE','bad_final',True,[assign('n',-1),arm('a',5),emit])
rule('A','BUSY','BUSY','a.expired',active('a'),[assign('n',op('add',v('n'),1)),emit])
rule('Z','BUSY','DONE','z.expired',active('z'),[assign('n',op('add',v('n'),1)),emit,{'cancel':'a'}])
rule('REARM','BUSY','BUSY','rearm',True,[arm('a',3),arm('a',7),{'cancel':'z'},emit])
rule('CONFLICT-1','IDLE','IDLE','ambiguous',True,[]);rule('CONFLICT-2','IDLE','BUSY','ambiguous',True,[])
m=dict(ir_version='0.6',semantics='flat-efsm-atomic-ordered-v1',protocol='typed-scheduled-microstep-contract',scope=dict(terminal_states=[],excluded=['batch advance/dispatch rollback','protocol specification correctness','native overflow and compiler proof']),states=['IDLE','BUSY','DONE'],initial_state='IDLE',requirements={'TRANSACTION':dict(source='spec.md#contract',interpretation='Explicit admitted IR ordered transaction and scheduled microstep contract.')},variables={'n':dict(type='int',initial=0),'flag':dict(type='bool',initial=False),'seq':dict(type='seq32',initial=4294967295),'data':dict(type='bytes',initial=[]),'text':dict(type='string',initial='start')},events=events,messages={'observed':dict(fields={'n':'int','flag':'bool','seq':'seq32','data':'bytes','text':'string','source_idle':'bool','fired_active':'bool','other_active':'bool'})},timers={'z':dict(event='z.expired'),'a':dict(event='a.expired')},transitions=rules,invariants=[dict(id='NONNEGATIVE',assertion='placeholder')])
m['invariants']=[{'id':'NONNEGATIVE','assert':op('ge',v('n'),0),'requirements':['TRANSACTION']},{'id':'BUFFER','assert':op('le',op('bytes_len',v('data')),4096),'requirements':['TRANSACTION']}]
w('model.json',m)
initial=dict(state='IDLE',now_ms=0,variables={n:x['initial']for n,x in m['variables'].items()},timers={})
def state(n,control,timers,data=[0,128,255,7]):return dict(state=control,now_ms=5 if control=='DONE'else 0,variables=dict(n=n,flag=True,seq=0,data=data,text='开\n\0'),timers=timers)
def row(n,data,idle,a,z):return dict(message='observed',fields=dict(n=n,flag=True,seq=0,data=data,text='开\n\0',source_idle=idle,fired_active=a,other_active=z))
def ok(rule,s,out):return dict(status='ok',rule=rule,after=s,emitted=out)
def err(fault):return dict(status='error',fault=fault)
def ex(event,fields={},at=0,expected=None):return dict(kind='external',event=event,fields=fields,at_ms=at,expected=expected)
def ti(at,expected):return dict(kind='timer',at_ms=at,expected=expected)
after_start=state(5,'BUSY',{'a':5,'z':5});after_a=state(6,'BUSY',{'z':5});after_a['now_ms']=5;after_z=state(7,'DONE',{});rearmed=state(5,'BUSY',{'a':7});after_rearm_tick=state(6,'BUSY',{});after_rearm_tick['now_ms']=7
cases=[dict(id='ordered-and-tied-timers',initial=initial,steps=[ex('start',{'payload':[0,128,255,7]},expected=ok('START',after_start,[row(5,[0,128,255,7],True,False,False)])),ex('rearm',at=5,expected=err('pendingTimer')),ti(5,ok('A',after_a,[row(6,[0,128,255,7],False,False,True)])),ti(5,ok('Z',after_z,[row(7,[0,128,255,7],False,False,False)]))]),dict(id='replace-and-cancel',initial=after_start,steps=[ex('rearm',expected=ok('REARM',rearmed,[row(5,[0,128,255,7],False,True,False)])),ti(5,err('time')),ti(7,ok('A',after_rearm_tick,[row(6,[0,128,255,7],False,False,False)])),ti(7,err('noTimer'))]),dict(id='bad-delay-rollback',initial=initial,steps=[ex('bad_delay',{'delay':0},expected=err('badDelay')),ex('bad_delay',{'delay':-1},at=3,expected=err('badDelay'))]),dict(id='final-invariant-rollback',initial=initial,steps=[ex('bad_final',expected=err('invariant'))]),dict(id='conflict-and-gap',initial=initial,steps=[ex('ambiguous',expected=err('conflict')),ex('gap',expected=err('uncovered')),ex('a.expired',expected=err('timerInjection'))]),dict(id='backwards-time',initial=after_a,steps=[ex('gap',at=4,expected=err('time')),ti(4,err('time')),ti(6,err('time'))])]
buf=[7]*4090+[0,128,255,6,2,0];large=state(5,'BUSY',{'a':5,'z':5},buf);cases.append(dict(id='complete-buffer',initial=initial,steps=[ex('start',{'payload':buf},expected=ok('START',large,[row(5,buf,True,False,False)]))]))
w('cases.json',cases)
(r/'spec.md').write_text('''# Ordered typed scheduled microsteps\n\n## Contract\n\nThis generic benchmark fixes five value types, typed ordered assignment/emission,\npositive timer delays, unique guard selection, exact-deadline timer firing and\nfinal-invariant failure rollback. Timer ties use lexicographic names; declaration\norder is deliberately reversed. A firing timer is active for guard selection and\nremoved before actions. The state remains the source until actions finish.\n\nExternal microsteps require all due timers to have been explicitly processed.\nThis is not the automatic batched dispatch/tick API: pending timers yield an\nexplicit pendingTimer result. No modeled protocol, scheduler fuel, native integer\noverflow theorem, interpreter refinement or compiler proof is claimed.\n\nExpected literals were written independently before running the candidate.\nThe large buffer retains4096 exact bytes and text includes Unicode/newline/NUL.\nErrors preserve the entire caller snapshot and expose no emissions.\n''')
print(hashlib.sha256((r/'cases.json').read_bytes()).hexdigest())
