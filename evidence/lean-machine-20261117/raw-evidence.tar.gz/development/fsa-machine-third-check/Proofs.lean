import Approved

set_option maxRecDepth 16384

namespace Proofs

theorem get_set_same : Approved.get_set_same := by
  exact FormalSpecAgent.TypedMachine.get_set_same

theorem rollback_error : Approved.rollback_error := by
  exact FormalSpecAgent.TypedMachine.rollback_error

theorem cancel_membership : Approved.cancel_membership := by
  exact FormalSpecAgent.TypedMachine.cancel_membership

theorem fire_invariant : Approved.fire_invariant := by
  exact FormalSpecAgent.TypedMachine.fire_invariant

theorem initial_valid_0 : Approved.initial_valid_0 := by
  decide

theorem witness_0_0 : Approved.witness_0_0 := by
  decide

theorem witness_0_1 : Approved.witness_0_1 := by
  decide

theorem witness_0_2 : Approved.witness_0_2 := by
  decide

theorem witness_0_3 : Approved.witness_0_3 := by
  decide

theorem initial_valid_1 : Approved.initial_valid_1 := by
  decide

theorem witness_1_0 : Approved.witness_1_0 := by
  decide

theorem witness_1_1 : Approved.witness_1_1 := by
  decide

theorem witness_1_2 : Approved.witness_1_2 := by
  decide

theorem witness_1_3 : Approved.witness_1_3 := by
  decide

theorem initial_valid_2 : Approved.initial_valid_2 := by
  decide

theorem witness_2_0 : Approved.witness_2_0 := by
  decide

theorem witness_2_1 : Approved.witness_2_1 := by
  decide

theorem initial_valid_3 : Approved.initial_valid_3 := by
  decide

theorem witness_3_0 : Approved.witness_3_0 := by
  decide

theorem initial_valid_4 : Approved.initial_valid_4 := by
  decide

theorem witness_4_0 : Approved.witness_4_0 := by
  decide

theorem witness_4_1 : Approved.witness_4_1 := by
  decide

theorem witness_4_2 : Approved.witness_4_2 := by
  decide

theorem initial_valid_5 : Approved.initial_valid_5 := by
  decide

theorem witness_5_0 : Approved.witness_5_0 := by
  decide

theorem witness_5_1 : Approved.witness_5_1 := by
  decide

theorem witness_5_2 : Approved.witness_5_2 := by
  decide

theorem initial_valid_6 : Approved.initial_valid_6 := by
  decide

theorem witness_6_0 : Approved.witness_6_0 := by
  simp [Approved.witness_6_0, Approved.result_6_0, Approved.initial_6, Approved.model, Approved.schema, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, Approved.rule_6, Approved.rule_7, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.armTimer, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.MachineObserve.outcome, FormalSpecAgent.MachineObserve.snapshot, FormalSpecAgent.MachineObserve.message, FormalSpecAgent.MachineObserve.packed, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.seqAdd, List.length_replicate, List.length_append]
  decide

end Proofs
