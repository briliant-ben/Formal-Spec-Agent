import Approved

set_option maxRecDepth 16384

namespace Proofs

theorem get_set_same : Approved.get_set_same := by
  exact FormalSpecAgent.TypedMachine.get_set_same

theorem rollback_error : Approved.rollback_error := by
  exact FormalSpecAgent.TypedMachine.rollback_error

theorem cancel_membership : Approved.cancel_membership := by
  exact FormalSpecAgent.TypedMachine.cancel_membership

theorem fire_invariant : Approved.fire_invariant := by
  exact FormalSpecAgent.TypedMachine.fire_invariant

theorem initial_valid_0 : Approved.initial_valid_0 := by
  rfl

theorem witness_0_0 : Approved.witness_0_0 := by
  rfl

theorem witness_0_1 : Approved.witness_0_1 := by
  rfl

theorem witness_0_2 : Approved.witness_0_2 := by
  rfl

theorem witness_0_3 : Approved.witness_0_3 := by
  rfl

theorem initial_valid_1 : Approved.initial_valid_1 := by
  rfl

theorem witness_1_0 : Approved.witness_1_0 := by
  rfl

theorem witness_1_1 : Approved.witness_1_1 := by
  rfl

theorem witness_1_2 : Approved.witness_1_2 := by
  rfl

theorem witness_1_3 : Approved.witness_1_3 := by
  rfl

theorem initial_valid_2 : Approved.initial_valid_2 := by
  rfl

theorem witness_2_0 : Approved.witness_2_0 := by
  rfl

theorem witness_2_1 : Approved.witness_2_1 := by
  rfl

theorem initial_valid_3 : Approved.initial_valid_3 := by
  rfl

theorem witness_3_0 : Approved.witness_3_0 := by
  rfl

theorem initial_valid_4 : Approved.initial_valid_4 := by
  rfl

theorem witness_4_0 : Approved.witness_4_0 := by
  rfl

theorem witness_4_1 : Approved.witness_4_1 := by
  rfl

theorem witness_4_2 : Approved.witness_4_2 := by
  rfl

theorem initial_valid_5 : Approved.initial_valid_5 := by
  rfl

theorem witness_5_0 : Approved.witness_5_0 := by
  rfl

theorem witness_5_1 : Approved.witness_5_1 := by
  rfl

theorem witness_5_2 : Approved.witness_5_2 := by
  rfl

theorem initial_valid_6 : Approved.initial_valid_6 := by
  rfl

theorem witness_6_0 : Approved.witness_6_0 := by
  rfl

end Proofs
