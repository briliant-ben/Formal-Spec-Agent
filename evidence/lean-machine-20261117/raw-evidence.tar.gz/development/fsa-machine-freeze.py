from pathlib import Path
import json,hashlib,sys
r=Path('/Users/xubenling/Documents/ChatGPT/Protocol_Form/Formal-Spec-Agent');sys.path.insert(0,str(r))
from formal_spec_agent import lean_machine as machine
from formal_spec_agent import lean_backend as g
w=r/'examples/lean-machine';p=w/'task.json'
t=dict(schema='fsa-lean-machine-task-v1',id='typed_scheduled_microsteps',model='model.json',model_sha256=g.sha(w/'model.json'),sources=[dict(path=n,sha256=g.sha(w/n))for n in ['spec.md','cases.json']],cases=json.loads((w/'cases.json').read_text()),lean_version=g.VERSION,semantics_sha256={n:g.sha(r/('formal_spec_agent/lean/'+n+'.lean'))for n in machine.MODULES},adapter_sha256=g.sha(r/'formal_spec_agent/lean_machine.py'),approved_sha256='0'*64)
p.write_text(json.dumps(t,ensure_ascii=False,indent=2)+'\n');source,goals,inputs=machine.prepare(p,w,g.sha(p),draft=True);t['approved_sha256']=hashlib.sha256(source.encode()).hexdigest();p.write_text(json.dumps(t,ensure_ascii=False,indent=2)+'\n')
proofs={n:[{'exact':'FormalSpecAgent.TypedMachine.'+n}]if n in ['get_set_same','rollback_error','cancel_membership','fire_invariant']else [{'rfl':True}]for n in goals}
if not (w/'proofs.json').exists():(w/'proofs.json').write_text(json.dumps(proofs,indent=2)+'\n')
print('goals',len(goals),'sourcebytes',len(source));(Path('/tmp')/'fsa-machine-approved-initial.lean').write_text(source)
