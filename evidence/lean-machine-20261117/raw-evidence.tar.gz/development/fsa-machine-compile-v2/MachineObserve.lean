import TypedMachine

/- Finite, complete schema observations of function-valued stores. Nothing here
   supplies expected outputs to the transition implementation. -/
namespace FormalSpecAgent.MachineObserve
open TypedIR TypedMachine

inductive Packed where
  | integer : Int → Packed
  | boolean : Bool → Packed
  | text : String → Packed
  | octets : Bytes → Packed
  | sequence : Nat → Packed
  deriving DecidableEq, Repr

def packed (k : Kind) (v : Value k) : Packed :=
  match k with
  | .integer => .integer v
  | .boolean => .boolean v
  | .text => .text v
  | .octets => .octets v
  | .sequence => .sequence v.val

structure SeenSnapshot where
  state : Nat
  now : Int
  values : List Packed
  timers : List (Nat × Int)
  deriving DecidableEq, Repr

def snapshot (schema : List (Kind × Nat)) (s : Snapshot) : SeenSnapshot :=
  { state := s.state, now := s.now,
    values := schema.map fun (k, n) => packed k (getValue k s.values n),
    timers := (s.timers.map fun t => (t.timer, t.due)).mergeSort (fun a b => a.1 ≤ b.1) }

abbrev SeenMessage := Nat × List (Nat × Packed)

def message (m : Message) : SeenMessage :=
  (m.name, (m.fields.map fun f => (f.slot, packed f.kind f.value)).mergeSort (fun a b => a.1 ≤ b.1))

inductive Outcome where
  | success : Nat → Nat → SeenSnapshot → List SeenMessage → Outcome
  | error : Fault → SeenSnapshot → Outcome
  deriving DecidableEq

def outcome (schema : List (Kind × Nat)) (initial : Snapshot)
    (result : Except Fault Transition) : Outcome :=
  match result with
  | .error fault => .error fault (snapshot schema (rollback initial result))
  | .ok result => .success result.rule result.event (snapshot schema result.after)
      (result.emitted.map message)

end FormalSpecAgent.MachineObserve
