// Lean compiler output
// Module: TypedMachine
// Imports: public import Init public meta import Init public import TypedIR
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Repr_addAppParen(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedIR_eval(uint8_t, lean_object*, lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_length(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* l_Int_repr(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry___boxed(lean_object*, lean_object*);
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "{ "};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__0_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "timer"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__1 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__1_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__1_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__2 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__2_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__2_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__3 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__3_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = " := "};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__4 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__4_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__4_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__5 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__5_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__3_value),((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__5_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__6 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__6_value;
static lean_once_cell_t l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__7;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__8 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__8_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__8_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__9 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__9_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "due"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__10 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__10_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__10_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__11 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__11_value;
static lean_once_cell_t l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__12;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = " }"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__13 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__13_value;
static lean_once_cell_t l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__14;
static lean_once_cell_t l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__15;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__0_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__16 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__16_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__13_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__17 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__17_value;
static lean_once_cell_t l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_TypedMachine_instReprTimerEntry___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry___closed__0_value;
LEAN_EXPORT const lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprTimerEntry___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_assign_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_assign_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_emit_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_emit_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_arm_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_arm_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_cancel_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_cancel_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_Fault_ofNat(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ofNat___boxed(lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_instDecidableEqFault(uint8_t, uint8_t);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instDecidableEqFault___boxed(lean_object*, lean_object*);
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 45, .m_capacity = 45, .m_length = 44, .m_data = "FormalSpecAgent.TypedMachine.Fault.uncovered"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__0_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__0_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__1 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__1_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "FormalSpecAgent.TypedMachine.Fault.conflict"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__2 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__2_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__2_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__3 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__3_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "FormalSpecAgent.TypedMachine.Fault.badDelay"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__4 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__4_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__4_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__5 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__5_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 45, .m_capacity = 45, .m_length = 44, .m_data = "FormalSpecAgent.TypedMachine.Fault.invariant"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__6 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__6_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__6_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__7 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__7_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 40, .m_capacity = 40, .m_length = 39, .m_data = "FormalSpecAgent.TypedMachine.Fault.time"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__8 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__8_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__8_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__9 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__9_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 50, .m_capacity = 50, .m_length = 49, .m_data = "FormalSpecAgent.TypedMachine.Fault.timerInjection"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__10 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__10_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__10_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__11 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__11_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 48, .m_capacity = 48, .m_length = 47, .m_data = "FormalSpecAgent.TypedMachine.Fault.pendingTimer"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__12 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__12_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__12_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__13 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__13_value;
static const lean_string_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 43, .m_capacity = 43, .m_length = 42, .m_data = "FormalSpecAgent.TypedMachine.Fault.noTimer"};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__14 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__14_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__14_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__15 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__15_value;
static lean_once_cell_t l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16;
static lean_once_cell_t l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_TypedMachine_instReprFault___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_TypedMachine_instReprFault_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault___closed__0_value;
LEAN_EXPORT const lean_object* l_FormalSpecAgent_TypedMachine_instReprFault = (const lean_object*)&l_FormalSpecAgent_TypedMachine_instReprFault___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_setValue___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__4(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue(uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_TypedMachine_context_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_context(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_cancelTimer_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_cancelTimer_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_cancelTimer(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_cancelTimer___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_armTimer_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_armTimer_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_armTimer___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_armTimer___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_armTimer___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_armTimer(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_armTimer___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_eval(lean_object*, lean_object*, uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_eval___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_TypedMachine_work_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_work___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_work___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_work___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_work(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__0___boxed(lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_zeroValues___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__1___boxed(lean_object*);
static const lean_string_object l_FormalSpecAgent_TypedMachine_zeroValues___lam__2___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__2___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___lam__2___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__2(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__2___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__3(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__3___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__4(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__4___boxed(lean_object*);
static const lean_closure_object l_FormalSpecAgent_TypedMachine_zeroValues___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_TypedMachine_zeroValues___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__0_value;
static const lean_closure_object l_FormalSpecAgent_TypedMachine_zeroValues___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_TypedMachine_zeroValues___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___closed__1 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__1_value;
static const lean_closure_object l_FormalSpecAgent_TypedMachine_zeroValues___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_TypedMachine_zeroValues___lam__2___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___closed__2 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__2_value;
static const lean_closure_object l_FormalSpecAgent_TypedMachine_zeroValues___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_TypedMachine_zeroValues___lam__3___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___closed__3 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__3_value;
static const lean_closure_object l_FormalSpecAgent_TypedMachine_zeroValues___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_TypedMachine_zeroValues___lam__4___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___closed__4 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__4_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_zeroValues___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__0_value),((lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__1_value),((lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__2_value),((lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__3_value),((lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__4_value)}};
static const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___closed__5 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__5_value;
LEAN_EXPORT const lean_object* l_FormalSpecAgent_TypedMachine_zeroValues = (const lean_object*)&l_FormalSpecAgent_TypedMachine_zeroValues___closed__5_value;
LEAN_EXPORT uint8_t l_List_all___at___00FormalSpecAgent_TypedMachine_invariantsHold_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00FormalSpecAgent_TypedMachine_invariantsHold_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_invariantsHold(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_invariantsHold___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_withoutFiring(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_withoutFiring___boxed(lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_runRule___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_runRule___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_runRule___closed__0_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_runRule___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_runRule___closed__1 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_runRule___closed__1_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_runRule(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_runRule___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_enabled_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_enabled_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_enabled(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_enabled___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_fire___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_fire___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_fire___closed__0_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_fire___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_fire___closed__1 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_fire___closed__1_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_fire(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_fire___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00FormalSpecAgent_TypedMachine_nextTimer_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00FormalSpecAgent_TypedMachine_nextTimer_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_nextTimer(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_nextTimer___boxed(lean_object*);
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_stepTimer___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_stepTimer___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_stepTimer___closed__0_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_stepTimer___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_stepTimer___closed__1 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_stepTimer___closed__1_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_stepTimer(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_external___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_external___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_external___closed__0_value;
static const lean_ctor_object l_FormalSpecAgent_TypedMachine_external___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(6) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_TypedMachine_external___closed__1 = (const lean_object*)&l_FormalSpecAgent_TypedMachine_external___closed__1_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_external(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_external___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_rollback(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_rollback___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_rollback_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_rollback_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry_decEq(lean_object* v_x_1_, lean_object* v_x_2_){
_start:
{
lean_object* v_timer_3_; lean_object* v_due_4_; lean_object* v_timer_5_; lean_object* v_due_6_; uint8_t v___x_7_; 
v_timer_3_ = lean_ctor_get(v_x_1_, 0);
v_due_4_ = lean_ctor_get(v_x_1_, 1);
v_timer_5_ = lean_ctor_get(v_x_2_, 0);
v_due_6_ = lean_ctor_get(v_x_2_, 1);
v___x_7_ = lean_nat_dec_eq(v_timer_3_, v_timer_5_);
if (v___x_7_ == 0)
{
return v___x_7_;
}
else
{
uint8_t v___x_8_; 
v___x_8_ = lean_int_dec_eq(v_due_4_, v_due_6_);
return v___x_8_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry_decEq___boxed(lean_object* v_x_9_, lean_object* v_x_10_){
_start:
{
uint8_t v_res_11_; lean_object* v_r_12_; 
v_res_11_ = l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry_decEq(v_x_9_, v_x_10_);
lean_dec_ref(v_x_10_);
lean_dec_ref(v_x_9_);
v_r_12_ = lean_box(v_res_11_);
return v_r_12_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry(lean_object* v_x_13_, lean_object* v_x_14_){
_start:
{
uint8_t v___x_15_; 
v___x_15_ = l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry_decEq(v_x_13_, v_x_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry___boxed(lean_object* v_x_16_, lean_object* v_x_17_){
_start:
{
uint8_t v_res_18_; lean_object* v_r_19_; 
v_res_18_ = l_FormalSpecAgent_TypedMachine_instDecidableEqTimerEntry(v_x_16_, v_x_17_);
lean_dec_ref(v_x_17_);
lean_dec_ref(v_x_16_);
v_r_19_ = lean_box(v_res_18_);
return v_r_19_;
}
}
static lean_object* _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__7(void){
_start:
{
lean_object* v___x_33_; lean_object* v___x_34_; 
v___x_33_ = lean_unsigned_to_nat(9u);
v___x_34_ = lean_nat_to_int(v___x_33_);
return v___x_34_;
}
}
static lean_object* _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__12(void){
_start:
{
lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_41_ = lean_unsigned_to_nat(7u);
v___x_42_ = lean_nat_to_int(v___x_41_);
return v___x_42_;
}
}
static lean_object* _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__14(void){
_start:
{
lean_object* v___x_44_; lean_object* v___x_45_; 
v___x_44_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__0));
v___x_45_ = lean_string_length(v___x_44_);
return v___x_45_;
}
}
static lean_object* _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__15(void){
_start:
{
lean_object* v___x_46_; lean_object* v___x_47_; 
v___x_46_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__14, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__14_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__14);
v___x_47_ = lean_nat_to_int(v___x_46_);
return v___x_47_;
}
}
static lean_object* _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18(void){
_start:
{
lean_object* v___x_52_; lean_object* v___x_53_; 
v___x_52_ = lean_unsigned_to_nat(0u);
v___x_53_ = lean_nat_to_int(v___x_52_);
return v___x_53_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg(lean_object* v_x_54_){
_start:
{
lean_object* v_timer_55_; lean_object* v_due_56_; lean_object* v___x_58_; uint8_t v_isShared_59_; uint8_t v_isSharedCheck_99_; 
v_timer_55_ = lean_ctor_get(v_x_54_, 0);
v_due_56_ = lean_ctor_get(v_x_54_, 1);
v_isSharedCheck_99_ = !lean_is_exclusive(v_x_54_);
if (v_isSharedCheck_99_ == 0)
{
v___x_58_ = v_x_54_;
v_isShared_59_ = v_isSharedCheck_99_;
goto v_resetjp_57_;
}
else
{
lean_inc(v_due_56_);
lean_inc(v_timer_55_);
lean_dec(v_x_54_);
v___x_58_ = lean_box(0);
v_isShared_59_ = v_isSharedCheck_99_;
goto v_resetjp_57_;
}
v_resetjp_57_:
{
lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; lean_object* v___x_66_; 
v___x_60_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__5));
v___x_61_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__6));
v___x_62_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__7, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__7_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__7);
v___x_63_ = l_Nat_reprFast(v_timer_55_);
v___x_64_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_64_, 0, v___x_63_);
if (v_isShared_59_ == 0)
{
lean_ctor_set_tag(v___x_58_, 4);
lean_ctor_set(v___x_58_, 1, v___x_64_);
lean_ctor_set(v___x_58_, 0, v___x_62_);
v___x_66_ = v___x_58_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_98_; 
v_reuseFailAlloc_98_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v_reuseFailAlloc_98_, 0, v___x_62_);
lean_ctor_set(v_reuseFailAlloc_98_, 1, v___x_64_);
v___x_66_ = v_reuseFailAlloc_98_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
uint8_t v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; lean_object* v___x_72_; lean_object* v___x_73_; lean_object* v___x_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___y_79_; lean_object* v___x_90_; lean_object* v___x_91_; uint8_t v___x_92_; 
v___x_67_ = 0;
v___x_68_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_68_, 0, v___x_66_);
lean_ctor_set_uint8(v___x_68_, sizeof(void*)*1, v___x_67_);
v___x_69_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_69_, 0, v___x_61_);
lean_ctor_set(v___x_69_, 1, v___x_68_);
v___x_70_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__9));
v___x_71_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_71_, 0, v___x_69_);
lean_ctor_set(v___x_71_, 1, v___x_70_);
v___x_72_ = lean_box(1);
v___x_73_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_73_, 0, v___x_71_);
lean_ctor_set(v___x_73_, 1, v___x_72_);
v___x_74_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__11));
v___x_75_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_75_, 0, v___x_73_);
lean_ctor_set(v___x_75_, 1, v___x_74_);
v___x_76_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_76_, 0, v___x_75_);
lean_ctor_set(v___x_76_, 1, v___x_60_);
v___x_77_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__12, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__12_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__12);
v___x_90_ = lean_unsigned_to_nat(0u);
v___x_91_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18);
v___x_92_ = lean_int_dec_lt(v_due_56_, v___x_91_);
if (v___x_92_ == 0)
{
lean_object* v___x_93_; lean_object* v___x_94_; 
v___x_93_ = l_Int_repr(v_due_56_);
lean_dec(v_due_56_);
v___x_94_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_94_, 0, v___x_93_);
v___y_79_ = v___x_94_;
goto v___jp_78_;
}
else
{
lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; 
v___x_95_ = l_Int_repr(v_due_56_);
lean_dec(v_due_56_);
v___x_96_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_96_, 0, v___x_95_);
v___x_97_ = l_Repr_addAppParen(v___x_96_, v___x_90_);
v___y_79_ = v___x_97_;
goto v___jp_78_;
}
v___jp_78_:
{
lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; lean_object* v___x_88_; lean_object* v___x_89_; 
v___x_80_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_80_, 0, v___x_77_);
lean_ctor_set(v___x_80_, 1, v___y_79_);
v___x_81_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_81_, 0, v___x_80_);
lean_ctor_set_uint8(v___x_81_, sizeof(void*)*1, v___x_67_);
v___x_82_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_82_, 0, v___x_76_);
lean_ctor_set(v___x_82_, 1, v___x_81_);
v___x_83_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__15, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__15_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__15);
v___x_84_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__16));
v___x_85_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_85_, 0, v___x_84_);
lean_ctor_set(v___x_85_, 1, v___x_82_);
v___x_86_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__17));
v___x_87_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_87_, 0, v___x_85_);
lean_ctor_set(v___x_87_, 1, v___x_86_);
v___x_88_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_88_, 0, v___x_83_);
lean_ctor_set(v___x_88_, 1, v___x_87_);
v___x_89_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_89_, 0, v___x_88_);
lean_ctor_set_uint8(v___x_89_, sizeof(void*)*1, v___x_67_);
return v___x_89_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr(lean_object* v_x_100_, lean_object* v_prec_101_){
_start:
{
lean_object* v___x_102_; 
v___x_102_ = l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg(v_x_100_);
return v___x_102_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___boxed(lean_object* v_x_103_, lean_object* v_prec_104_){
_start:
{
lean_object* v_res_105_; 
v_res_105_ = l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr(v_x_103_, v_prec_104_);
lean_dec(v_prec_104_);
return v_res_105_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorIdx(lean_object* v_x_108_){
_start:
{
switch(lean_obj_tag(v_x_108_))
{
case 0:
{
lean_object* v___x_109_; 
v___x_109_ = lean_unsigned_to_nat(0u);
return v___x_109_;
}
case 1:
{
lean_object* v___x_110_; 
v___x_110_ = lean_unsigned_to_nat(1u);
return v___x_110_;
}
case 2:
{
lean_object* v___x_111_; 
v___x_111_ = lean_unsigned_to_nat(2u);
return v___x_111_;
}
default: 
{
lean_object* v___x_112_; 
v___x_112_ = lean_unsigned_to_nat(3u);
return v___x_112_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorIdx___boxed(lean_object* v_x_113_){
_start:
{
lean_object* v_res_114_; 
v_res_114_ = l_FormalSpecAgent_TypedMachine_Action_ctorIdx(v_x_113_);
lean_dec_ref(v_x_113_);
return v_res_114_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(lean_object* v_t_115_, lean_object* v_k_116_){
_start:
{
switch(lean_obj_tag(v_t_115_))
{
case 0:
{
uint8_t v_kind_117_; lean_object* v_slot_118_; lean_object* v_expr_119_; lean_object* v___x_120_; lean_object* v___x_121_; 
v_kind_117_ = lean_ctor_get_uint8(v_t_115_, sizeof(void*)*2);
v_slot_118_ = lean_ctor_get(v_t_115_, 0);
lean_inc(v_slot_118_);
v_expr_119_ = lean_ctor_get(v_t_115_, 1);
lean_inc_ref(v_expr_119_);
lean_dec_ref_known(v_t_115_, 2);
v___x_120_ = lean_box(v_kind_117_);
v___x_121_ = lean_apply_3(v_k_116_, v___x_120_, v_slot_118_, v_expr_119_);
return v___x_121_;
}
case 1:
{
lean_object* v_message_122_; lean_object* v_fields_123_; lean_object* v___x_124_; 
v_message_122_ = lean_ctor_get(v_t_115_, 0);
lean_inc(v_message_122_);
v_fields_123_ = lean_ctor_get(v_t_115_, 1);
lean_inc(v_fields_123_);
lean_dec_ref_known(v_t_115_, 2);
v___x_124_ = lean_apply_2(v_k_116_, v_message_122_, v_fields_123_);
return v___x_124_;
}
case 2:
{
lean_object* v_timer_125_; lean_object* v_delay_126_; lean_object* v___x_127_; 
v_timer_125_ = lean_ctor_get(v_t_115_, 0);
lean_inc(v_timer_125_);
v_delay_126_ = lean_ctor_get(v_t_115_, 1);
lean_inc_ref(v_delay_126_);
lean_dec_ref_known(v_t_115_, 2);
v___x_127_ = lean_apply_2(v_k_116_, v_timer_125_, v_delay_126_);
return v___x_127_;
}
default: 
{
lean_object* v_timer_128_; lean_object* v___x_129_; 
v_timer_128_ = lean_ctor_get(v_t_115_, 0);
lean_inc(v_timer_128_);
lean_dec_ref_known(v_t_115_, 1);
v___x_129_ = lean_apply_1(v_k_116_, v_timer_128_);
return v___x_129_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorElim(lean_object* v_motive_130_, lean_object* v_ctorIdx_131_, lean_object* v_t_132_, lean_object* v_h_133_, lean_object* v_k_134_){
_start:
{
lean_object* v___x_135_; 
v___x_135_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_132_, v_k_134_);
return v___x_135_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_ctorElim___boxed(lean_object* v_motive_136_, lean_object* v_ctorIdx_137_, lean_object* v_t_138_, lean_object* v_h_139_, lean_object* v_k_140_){
_start:
{
lean_object* v_res_141_; 
v_res_141_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim(v_motive_136_, v_ctorIdx_137_, v_t_138_, v_h_139_, v_k_140_);
lean_dec(v_ctorIdx_137_);
return v_res_141_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_assign_elim___redArg(lean_object* v_t_142_, lean_object* v_assign_143_){
_start:
{
lean_object* v___x_144_; 
v___x_144_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_142_, v_assign_143_);
return v___x_144_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_assign_elim(lean_object* v_motive_145_, lean_object* v_t_146_, lean_object* v_h_147_, lean_object* v_assign_148_){
_start:
{
lean_object* v___x_149_; 
v___x_149_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_146_, v_assign_148_);
return v___x_149_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_emit_elim___redArg(lean_object* v_t_150_, lean_object* v_emit_151_){
_start:
{
lean_object* v___x_152_; 
v___x_152_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_150_, v_emit_151_);
return v___x_152_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_emit_elim(lean_object* v_motive_153_, lean_object* v_t_154_, lean_object* v_h_155_, lean_object* v_emit_156_){
_start:
{
lean_object* v___x_157_; 
v___x_157_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_154_, v_emit_156_);
return v___x_157_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_arm_elim___redArg(lean_object* v_t_158_, lean_object* v_arm_159_){
_start:
{
lean_object* v___x_160_; 
v___x_160_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_158_, v_arm_159_);
return v___x_160_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_arm_elim(lean_object* v_motive_161_, lean_object* v_t_162_, lean_object* v_h_163_, lean_object* v_arm_164_){
_start:
{
lean_object* v___x_165_; 
v___x_165_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_162_, v_arm_164_);
return v___x_165_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_cancel_elim___redArg(lean_object* v_t_166_, lean_object* v_cancel_167_){
_start:
{
lean_object* v___x_168_; 
v___x_168_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_166_, v_cancel_167_);
return v___x_168_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Action_cancel_elim(lean_object* v_motive_169_, lean_object* v_t_170_, lean_object* v_h_171_, lean_object* v_cancel_172_){
_start:
{
lean_object* v___x_173_; 
v___x_173_ = l_FormalSpecAgent_TypedMachine_Action_ctorElim___redArg(v_t_170_, v_cancel_172_);
return v___x_173_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(uint8_t v_x_174_){
_start:
{
switch(v_x_174_)
{
case 0:
{
lean_object* v___x_175_; 
v___x_175_ = lean_unsigned_to_nat(0u);
return v___x_175_;
}
case 1:
{
lean_object* v___x_176_; 
v___x_176_ = lean_unsigned_to_nat(1u);
return v___x_176_;
}
case 2:
{
lean_object* v___x_177_; 
v___x_177_ = lean_unsigned_to_nat(2u);
return v___x_177_;
}
case 3:
{
lean_object* v___x_178_; 
v___x_178_ = lean_unsigned_to_nat(3u);
return v___x_178_;
}
case 4:
{
lean_object* v___x_179_; 
v___x_179_ = lean_unsigned_to_nat(4u);
return v___x_179_;
}
case 5:
{
lean_object* v___x_180_; 
v___x_180_ = lean_unsigned_to_nat(5u);
return v___x_180_;
}
case 6:
{
lean_object* v___x_181_; 
v___x_181_ = lean_unsigned_to_nat(6u);
return v___x_181_;
}
default: 
{
lean_object* v___x_182_; 
v___x_182_ = lean_unsigned_to_nat(7u);
return v___x_182_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorIdx___boxed(lean_object* v_x_183_){
_start:
{
uint8_t v_x_boxed_184_; lean_object* v_res_185_; 
v_x_boxed_184_ = lean_unbox(v_x_183_);
v_res_185_ = l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(v_x_boxed_184_);
return v_res_185_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim___redArg(lean_object* v_k_186_){
_start:
{
lean_inc(v_k_186_);
return v_k_186_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim___redArg___boxed(lean_object* v_k_187_){
_start:
{
lean_object* v_res_188_; 
v_res_188_ = l_FormalSpecAgent_TypedMachine_Fault_ctorElim___redArg(v_k_187_);
lean_dec(v_k_187_);
return v_res_188_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim(lean_object* v_motive_189_, lean_object* v_ctorIdx_190_, uint8_t v_t_191_, lean_object* v_h_192_, lean_object* v_k_193_){
_start:
{
lean_inc(v_k_193_);
return v_k_193_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorElim___boxed(lean_object* v_motive_194_, lean_object* v_ctorIdx_195_, lean_object* v_t_196_, lean_object* v_h_197_, lean_object* v_k_198_){
_start:
{
uint8_t v_t_boxed_199_; lean_object* v_res_200_; 
v_t_boxed_199_ = lean_unbox(v_t_196_);
v_res_200_ = l_FormalSpecAgent_TypedMachine_Fault_ctorElim(v_motive_194_, v_ctorIdx_195_, v_t_boxed_199_, v_h_197_, v_k_198_);
lean_dec(v_k_198_);
lean_dec(v_ctorIdx_195_);
return v_res_200_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim___redArg(lean_object* v_uncovered_201_){
_start:
{
lean_inc(v_uncovered_201_);
return v_uncovered_201_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim___redArg___boxed(lean_object* v_uncovered_202_){
_start:
{
lean_object* v_res_203_; 
v_res_203_ = l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim___redArg(v_uncovered_202_);
lean_dec(v_uncovered_202_);
return v_res_203_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim(lean_object* v_motive_204_, uint8_t v_t_205_, lean_object* v_h_206_, lean_object* v_uncovered_207_){
_start:
{
lean_inc(v_uncovered_207_);
return v_uncovered_207_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim___boxed(lean_object* v_motive_208_, lean_object* v_t_209_, lean_object* v_h_210_, lean_object* v_uncovered_211_){
_start:
{
uint8_t v_t_boxed_212_; lean_object* v_res_213_; 
v_t_boxed_212_ = lean_unbox(v_t_209_);
v_res_213_ = l_FormalSpecAgent_TypedMachine_Fault_uncovered_elim(v_motive_208_, v_t_boxed_212_, v_h_210_, v_uncovered_211_);
lean_dec(v_uncovered_211_);
return v_res_213_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim___redArg(lean_object* v_conflict_214_){
_start:
{
lean_inc(v_conflict_214_);
return v_conflict_214_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim___redArg___boxed(lean_object* v_conflict_215_){
_start:
{
lean_object* v_res_216_; 
v_res_216_ = l_FormalSpecAgent_TypedMachine_Fault_conflict_elim___redArg(v_conflict_215_);
lean_dec(v_conflict_215_);
return v_res_216_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim(lean_object* v_motive_217_, uint8_t v_t_218_, lean_object* v_h_219_, lean_object* v_conflict_220_){
_start:
{
lean_inc(v_conflict_220_);
return v_conflict_220_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_conflict_elim___boxed(lean_object* v_motive_221_, lean_object* v_t_222_, lean_object* v_h_223_, lean_object* v_conflict_224_){
_start:
{
uint8_t v_t_boxed_225_; lean_object* v_res_226_; 
v_t_boxed_225_ = lean_unbox(v_t_222_);
v_res_226_ = l_FormalSpecAgent_TypedMachine_Fault_conflict_elim(v_motive_221_, v_t_boxed_225_, v_h_223_, v_conflict_224_);
lean_dec(v_conflict_224_);
return v_res_226_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim___redArg(lean_object* v_badDelay_227_){
_start:
{
lean_inc(v_badDelay_227_);
return v_badDelay_227_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim___redArg___boxed(lean_object* v_badDelay_228_){
_start:
{
lean_object* v_res_229_; 
v_res_229_ = l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim___redArg(v_badDelay_228_);
lean_dec(v_badDelay_228_);
return v_res_229_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim(lean_object* v_motive_230_, uint8_t v_t_231_, lean_object* v_h_232_, lean_object* v_badDelay_233_){
_start:
{
lean_inc(v_badDelay_233_);
return v_badDelay_233_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim___boxed(lean_object* v_motive_234_, lean_object* v_t_235_, lean_object* v_h_236_, lean_object* v_badDelay_237_){
_start:
{
uint8_t v_t_boxed_238_; lean_object* v_res_239_; 
v_t_boxed_238_ = lean_unbox(v_t_235_);
v_res_239_ = l_FormalSpecAgent_TypedMachine_Fault_badDelay_elim(v_motive_234_, v_t_boxed_238_, v_h_236_, v_badDelay_237_);
lean_dec(v_badDelay_237_);
return v_res_239_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim___redArg(lean_object* v_invariant_240_){
_start:
{
lean_inc(v_invariant_240_);
return v_invariant_240_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim___redArg___boxed(lean_object* v_invariant_241_){
_start:
{
lean_object* v_res_242_; 
v_res_242_ = l_FormalSpecAgent_TypedMachine_Fault_invariant_elim___redArg(v_invariant_241_);
lean_dec(v_invariant_241_);
return v_res_242_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim(lean_object* v_motive_243_, uint8_t v_t_244_, lean_object* v_h_245_, lean_object* v_invariant_246_){
_start:
{
lean_inc(v_invariant_246_);
return v_invariant_246_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_invariant_elim___boxed(lean_object* v_motive_247_, lean_object* v_t_248_, lean_object* v_h_249_, lean_object* v_invariant_250_){
_start:
{
uint8_t v_t_boxed_251_; lean_object* v_res_252_; 
v_t_boxed_251_ = lean_unbox(v_t_248_);
v_res_252_ = l_FormalSpecAgent_TypedMachine_Fault_invariant_elim(v_motive_247_, v_t_boxed_251_, v_h_249_, v_invariant_250_);
lean_dec(v_invariant_250_);
return v_res_252_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim___redArg(lean_object* v_time_253_){
_start:
{
lean_inc(v_time_253_);
return v_time_253_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim___redArg___boxed(lean_object* v_time_254_){
_start:
{
lean_object* v_res_255_; 
v_res_255_ = l_FormalSpecAgent_TypedMachine_Fault_time_elim___redArg(v_time_254_);
lean_dec(v_time_254_);
return v_res_255_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim(lean_object* v_motive_256_, uint8_t v_t_257_, lean_object* v_h_258_, lean_object* v_time_259_){
_start:
{
lean_inc(v_time_259_);
return v_time_259_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_time_elim___boxed(lean_object* v_motive_260_, lean_object* v_t_261_, lean_object* v_h_262_, lean_object* v_time_263_){
_start:
{
uint8_t v_t_boxed_264_; lean_object* v_res_265_; 
v_t_boxed_264_ = lean_unbox(v_t_261_);
v_res_265_ = l_FormalSpecAgent_TypedMachine_Fault_time_elim(v_motive_260_, v_t_boxed_264_, v_h_262_, v_time_263_);
lean_dec(v_time_263_);
return v_res_265_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim___redArg(lean_object* v_timerInjection_266_){
_start:
{
lean_inc(v_timerInjection_266_);
return v_timerInjection_266_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim___redArg___boxed(lean_object* v_timerInjection_267_){
_start:
{
lean_object* v_res_268_; 
v_res_268_ = l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim___redArg(v_timerInjection_267_);
lean_dec(v_timerInjection_267_);
return v_res_268_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim(lean_object* v_motive_269_, uint8_t v_t_270_, lean_object* v_h_271_, lean_object* v_timerInjection_272_){
_start:
{
lean_inc(v_timerInjection_272_);
return v_timerInjection_272_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim___boxed(lean_object* v_motive_273_, lean_object* v_t_274_, lean_object* v_h_275_, lean_object* v_timerInjection_276_){
_start:
{
uint8_t v_t_boxed_277_; lean_object* v_res_278_; 
v_t_boxed_277_ = lean_unbox(v_t_274_);
v_res_278_ = l_FormalSpecAgent_TypedMachine_Fault_timerInjection_elim(v_motive_273_, v_t_boxed_277_, v_h_275_, v_timerInjection_276_);
lean_dec(v_timerInjection_276_);
return v_res_278_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim___redArg(lean_object* v_pendingTimer_279_){
_start:
{
lean_inc(v_pendingTimer_279_);
return v_pendingTimer_279_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim___redArg___boxed(lean_object* v_pendingTimer_280_){
_start:
{
lean_object* v_res_281_; 
v_res_281_ = l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim___redArg(v_pendingTimer_280_);
lean_dec(v_pendingTimer_280_);
return v_res_281_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim(lean_object* v_motive_282_, uint8_t v_t_283_, lean_object* v_h_284_, lean_object* v_pendingTimer_285_){
_start:
{
lean_inc(v_pendingTimer_285_);
return v_pendingTimer_285_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim___boxed(lean_object* v_motive_286_, lean_object* v_t_287_, lean_object* v_h_288_, lean_object* v_pendingTimer_289_){
_start:
{
uint8_t v_t_boxed_290_; lean_object* v_res_291_; 
v_t_boxed_290_ = lean_unbox(v_t_287_);
v_res_291_ = l_FormalSpecAgent_TypedMachine_Fault_pendingTimer_elim(v_motive_286_, v_t_boxed_290_, v_h_288_, v_pendingTimer_289_);
lean_dec(v_pendingTimer_289_);
return v_res_291_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim___redArg(lean_object* v_noTimer_292_){
_start:
{
lean_inc(v_noTimer_292_);
return v_noTimer_292_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim___redArg___boxed(lean_object* v_noTimer_293_){
_start:
{
lean_object* v_res_294_; 
v_res_294_ = l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim___redArg(v_noTimer_293_);
lean_dec(v_noTimer_293_);
return v_res_294_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim(lean_object* v_motive_295_, uint8_t v_t_296_, lean_object* v_h_297_, lean_object* v_noTimer_298_){
_start:
{
lean_inc(v_noTimer_298_);
return v_noTimer_298_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim___boxed(lean_object* v_motive_299_, lean_object* v_t_300_, lean_object* v_h_301_, lean_object* v_noTimer_302_){
_start:
{
uint8_t v_t_boxed_303_; lean_object* v_res_304_; 
v_t_boxed_303_ = lean_unbox(v_t_300_);
v_res_304_ = l_FormalSpecAgent_TypedMachine_Fault_noTimer_elim(v_motive_299_, v_t_boxed_303_, v_h_301_, v_noTimer_302_);
lean_dec(v_noTimer_302_);
return v_res_304_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_Fault_ofNat(lean_object* v_n_305_){
_start:
{
lean_object* v___x_306_; uint8_t v___x_307_; 
v___x_306_ = lean_unsigned_to_nat(3u);
v___x_307_ = lean_nat_dec_le(v_n_305_, v___x_306_);
if (v___x_307_ == 0)
{
lean_object* v___x_308_; uint8_t v___x_309_; 
v___x_308_ = lean_unsigned_to_nat(5u);
v___x_309_ = lean_nat_dec_le(v_n_305_, v___x_308_);
if (v___x_309_ == 0)
{
lean_object* v___x_310_; uint8_t v___x_311_; 
v___x_310_ = lean_unsigned_to_nat(6u);
v___x_311_ = lean_nat_dec_le(v_n_305_, v___x_310_);
if (v___x_311_ == 0)
{
uint8_t v___x_312_; 
v___x_312_ = 7;
return v___x_312_;
}
else
{
uint8_t v___x_313_; 
v___x_313_ = 6;
return v___x_313_;
}
}
else
{
lean_object* v___x_314_; uint8_t v___x_315_; 
v___x_314_ = lean_unsigned_to_nat(4u);
v___x_315_ = lean_nat_dec_le(v_n_305_, v___x_314_);
if (v___x_315_ == 0)
{
uint8_t v___x_316_; 
v___x_316_ = 5;
return v___x_316_;
}
else
{
uint8_t v___x_317_; 
v___x_317_ = 4;
return v___x_317_;
}
}
}
else
{
lean_object* v___x_318_; uint8_t v___x_319_; 
v___x_318_ = lean_unsigned_to_nat(1u);
v___x_319_ = lean_nat_dec_le(v_n_305_, v___x_318_);
if (v___x_319_ == 0)
{
lean_object* v___x_320_; uint8_t v___x_321_; 
v___x_320_ = lean_unsigned_to_nat(2u);
v___x_321_ = lean_nat_dec_le(v_n_305_, v___x_320_);
if (v___x_321_ == 0)
{
uint8_t v___x_322_; 
v___x_322_ = 3;
return v___x_322_;
}
else
{
uint8_t v___x_323_; 
v___x_323_ = 2;
return v___x_323_;
}
}
else
{
lean_object* v___x_324_; uint8_t v___x_325_; 
v___x_324_ = lean_unsigned_to_nat(0u);
v___x_325_ = lean_nat_dec_le(v_n_305_, v___x_324_);
if (v___x_325_ == 0)
{
uint8_t v___x_326_; 
v___x_326_ = 1;
return v___x_326_;
}
else
{
uint8_t v___x_327_; 
v___x_327_ = 0;
return v___x_327_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_Fault_ofNat___boxed(lean_object* v_n_328_){
_start:
{
uint8_t v_res_329_; lean_object* v_r_330_; 
v_res_329_ = l_FormalSpecAgent_TypedMachine_Fault_ofNat(v_n_328_);
lean_dec(v_n_328_);
v_r_330_ = lean_box(v_res_329_);
return v_r_330_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_instDecidableEqFault(uint8_t v_x_331_, uint8_t v_y_332_){
_start:
{
lean_object* v___x_333_; lean_object* v___x_334_; uint8_t v___x_335_; 
v___x_333_ = l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(v_x_331_);
v___x_334_ = l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(v_y_332_);
v___x_335_ = lean_nat_dec_eq(v___x_333_, v___x_334_);
lean_dec(v___x_334_);
lean_dec(v___x_333_);
return v___x_335_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instDecidableEqFault___boxed(lean_object* v_x_336_, lean_object* v_y_337_){
_start:
{
uint8_t v_x_20__boxed_338_; uint8_t v_y_21__boxed_339_; uint8_t v_res_340_; lean_object* v_r_341_; 
v_x_20__boxed_338_ = lean_unbox(v_x_336_);
v_y_21__boxed_339_ = lean_unbox(v_y_337_);
v_res_340_ = l_FormalSpecAgent_TypedMachine_instDecidableEqFault(v_x_20__boxed_338_, v_y_21__boxed_339_);
v_r_341_ = lean_box(v_res_340_);
return v_r_341_;
}
}
static lean_object* _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16(void){
_start:
{
lean_object* v___x_366_; lean_object* v___x_367_; 
v___x_366_ = lean_unsigned_to_nat(2u);
v___x_367_ = lean_nat_to_int(v___x_366_);
return v___x_367_;
}
}
static lean_object* _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17(void){
_start:
{
lean_object* v___x_368_; lean_object* v___x_369_; 
v___x_368_ = lean_unsigned_to_nat(1u);
v___x_369_ = lean_nat_to_int(v___x_368_);
return v___x_369_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr(uint8_t v_x_370_, lean_object* v_prec_371_){
_start:
{
lean_object* v___y_373_; lean_object* v___y_380_; lean_object* v___y_387_; lean_object* v___y_394_; lean_object* v___y_401_; lean_object* v___y_408_; lean_object* v___y_415_; lean_object* v___y_422_; 
switch(v_x_370_)
{
case 0:
{
lean_object* v___x_428_; uint8_t v___x_429_; 
v___x_428_ = lean_unsigned_to_nat(1024u);
v___x_429_ = lean_nat_dec_le(v___x_428_, v_prec_371_);
if (v___x_429_ == 0)
{
lean_object* v___x_430_; 
v___x_430_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_373_ = v___x_430_;
goto v___jp_372_;
}
else
{
lean_object* v___x_431_; 
v___x_431_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_373_ = v___x_431_;
goto v___jp_372_;
}
}
case 1:
{
lean_object* v___x_432_; uint8_t v___x_433_; 
v___x_432_ = lean_unsigned_to_nat(1024u);
v___x_433_ = lean_nat_dec_le(v___x_432_, v_prec_371_);
if (v___x_433_ == 0)
{
lean_object* v___x_434_; 
v___x_434_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_380_ = v___x_434_;
goto v___jp_379_;
}
else
{
lean_object* v___x_435_; 
v___x_435_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_380_ = v___x_435_;
goto v___jp_379_;
}
}
case 2:
{
lean_object* v___x_436_; uint8_t v___x_437_; 
v___x_436_ = lean_unsigned_to_nat(1024u);
v___x_437_ = lean_nat_dec_le(v___x_436_, v_prec_371_);
if (v___x_437_ == 0)
{
lean_object* v___x_438_; 
v___x_438_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_387_ = v___x_438_;
goto v___jp_386_;
}
else
{
lean_object* v___x_439_; 
v___x_439_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_387_ = v___x_439_;
goto v___jp_386_;
}
}
case 3:
{
lean_object* v___x_440_; uint8_t v___x_441_; 
v___x_440_ = lean_unsigned_to_nat(1024u);
v___x_441_ = lean_nat_dec_le(v___x_440_, v_prec_371_);
if (v___x_441_ == 0)
{
lean_object* v___x_442_; 
v___x_442_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_394_ = v___x_442_;
goto v___jp_393_;
}
else
{
lean_object* v___x_443_; 
v___x_443_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_394_ = v___x_443_;
goto v___jp_393_;
}
}
case 4:
{
lean_object* v___x_444_; uint8_t v___x_445_; 
v___x_444_ = lean_unsigned_to_nat(1024u);
v___x_445_ = lean_nat_dec_le(v___x_444_, v_prec_371_);
if (v___x_445_ == 0)
{
lean_object* v___x_446_; 
v___x_446_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_401_ = v___x_446_;
goto v___jp_400_;
}
else
{
lean_object* v___x_447_; 
v___x_447_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_401_ = v___x_447_;
goto v___jp_400_;
}
}
case 5:
{
lean_object* v___x_448_; uint8_t v___x_449_; 
v___x_448_ = lean_unsigned_to_nat(1024u);
v___x_449_ = lean_nat_dec_le(v___x_448_, v_prec_371_);
if (v___x_449_ == 0)
{
lean_object* v___x_450_; 
v___x_450_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_408_ = v___x_450_;
goto v___jp_407_;
}
else
{
lean_object* v___x_451_; 
v___x_451_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_408_ = v___x_451_;
goto v___jp_407_;
}
}
case 6:
{
lean_object* v___x_452_; uint8_t v___x_453_; 
v___x_452_ = lean_unsigned_to_nat(1024u);
v___x_453_ = lean_nat_dec_le(v___x_452_, v_prec_371_);
if (v___x_453_ == 0)
{
lean_object* v___x_454_; 
v___x_454_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_415_ = v___x_454_;
goto v___jp_414_;
}
else
{
lean_object* v___x_455_; 
v___x_455_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_415_ = v___x_455_;
goto v___jp_414_;
}
}
default: 
{
lean_object* v___x_456_; uint8_t v___x_457_; 
v___x_456_ = lean_unsigned_to_nat(1024u);
v___x_457_ = lean_nat_dec_le(v___x_456_, v_prec_371_);
if (v___x_457_ == 0)
{
lean_object* v___x_458_; 
v___x_458_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__16);
v___y_422_ = v___x_458_;
goto v___jp_421_;
}
else
{
lean_object* v___x_459_; 
v___x_459_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17, &l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17_once, _init_l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__17);
v___y_422_ = v___x_459_;
goto v___jp_421_;
}
}
}
v___jp_372_:
{
lean_object* v___x_374_; lean_object* v___x_375_; uint8_t v___x_376_; lean_object* v___x_377_; lean_object* v___x_378_; 
v___x_374_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__1));
lean_inc(v___y_373_);
v___x_375_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_375_, 0, v___y_373_);
lean_ctor_set(v___x_375_, 1, v___x_374_);
v___x_376_ = 0;
v___x_377_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_377_, 0, v___x_375_);
lean_ctor_set_uint8(v___x_377_, sizeof(void*)*1, v___x_376_);
v___x_378_ = l_Repr_addAppParen(v___x_377_, v_prec_371_);
return v___x_378_;
}
v___jp_379_:
{
lean_object* v___x_381_; lean_object* v___x_382_; uint8_t v___x_383_; lean_object* v___x_384_; lean_object* v___x_385_; 
v___x_381_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__3));
lean_inc(v___y_380_);
v___x_382_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_382_, 0, v___y_380_);
lean_ctor_set(v___x_382_, 1, v___x_381_);
v___x_383_ = 0;
v___x_384_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_384_, 0, v___x_382_);
lean_ctor_set_uint8(v___x_384_, sizeof(void*)*1, v___x_383_);
v___x_385_ = l_Repr_addAppParen(v___x_384_, v_prec_371_);
return v___x_385_;
}
v___jp_386_:
{
lean_object* v___x_388_; lean_object* v___x_389_; uint8_t v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; 
v___x_388_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__5));
lean_inc(v___y_387_);
v___x_389_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_389_, 0, v___y_387_);
lean_ctor_set(v___x_389_, 1, v___x_388_);
v___x_390_ = 0;
v___x_391_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_391_, 0, v___x_389_);
lean_ctor_set_uint8(v___x_391_, sizeof(void*)*1, v___x_390_);
v___x_392_ = l_Repr_addAppParen(v___x_391_, v_prec_371_);
return v___x_392_;
}
v___jp_393_:
{
lean_object* v___x_395_; lean_object* v___x_396_; uint8_t v___x_397_; lean_object* v___x_398_; lean_object* v___x_399_; 
v___x_395_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__7));
lean_inc(v___y_394_);
v___x_396_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_396_, 0, v___y_394_);
lean_ctor_set(v___x_396_, 1, v___x_395_);
v___x_397_ = 0;
v___x_398_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_398_, 0, v___x_396_);
lean_ctor_set_uint8(v___x_398_, sizeof(void*)*1, v___x_397_);
v___x_399_ = l_Repr_addAppParen(v___x_398_, v_prec_371_);
return v___x_399_;
}
v___jp_400_:
{
lean_object* v___x_402_; lean_object* v___x_403_; uint8_t v___x_404_; lean_object* v___x_405_; lean_object* v___x_406_; 
v___x_402_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__9));
lean_inc(v___y_401_);
v___x_403_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_403_, 0, v___y_401_);
lean_ctor_set(v___x_403_, 1, v___x_402_);
v___x_404_ = 0;
v___x_405_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_405_, 0, v___x_403_);
lean_ctor_set_uint8(v___x_405_, sizeof(void*)*1, v___x_404_);
v___x_406_ = l_Repr_addAppParen(v___x_405_, v_prec_371_);
return v___x_406_;
}
v___jp_407_:
{
lean_object* v___x_409_; lean_object* v___x_410_; uint8_t v___x_411_; lean_object* v___x_412_; lean_object* v___x_413_; 
v___x_409_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__11));
lean_inc(v___y_408_);
v___x_410_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_410_, 0, v___y_408_);
lean_ctor_set(v___x_410_, 1, v___x_409_);
v___x_411_ = 0;
v___x_412_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_412_, 0, v___x_410_);
lean_ctor_set_uint8(v___x_412_, sizeof(void*)*1, v___x_411_);
v___x_413_ = l_Repr_addAppParen(v___x_412_, v_prec_371_);
return v___x_413_;
}
v___jp_414_:
{
lean_object* v___x_416_; lean_object* v___x_417_; uint8_t v___x_418_; lean_object* v___x_419_; lean_object* v___x_420_; 
v___x_416_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__13));
lean_inc(v___y_415_);
v___x_417_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_417_, 0, v___y_415_);
lean_ctor_set(v___x_417_, 1, v___x_416_);
v___x_418_ = 0;
v___x_419_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_419_, 0, v___x_417_);
lean_ctor_set_uint8(v___x_419_, sizeof(void*)*1, v___x_418_);
v___x_420_ = l_Repr_addAppParen(v___x_419_, v_prec_371_);
return v___x_420_;
}
v___jp_421_:
{
lean_object* v___x_423_; lean_object* v___x_424_; uint8_t v___x_425_; lean_object* v___x_426_; lean_object* v___x_427_; 
v___x_423_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_instReprFault_repr___closed__15));
lean_inc(v___y_422_);
v___x_424_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_424_, 0, v___y_422_);
lean_ctor_set(v___x_424_, 1, v___x_423_);
v___x_425_ = 0;
v___x_426_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_426_, 0, v___x_424_);
lean_ctor_set_uint8(v___x_426_, sizeof(void*)*1, v___x_425_);
v___x_427_ = l_Repr_addAppParen(v___x_426_, v_prec_371_);
return v___x_427_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_instReprFault_repr___boxed(lean_object* v_x_460_, lean_object* v_prec_461_){
_start:
{
uint8_t v_x_441__boxed_462_; lean_object* v_res_463_; 
v_x_441__boxed_462_ = lean_unbox(v_x_460_);
v_res_463_ = l_FormalSpecAgent_TypedMachine_instReprFault_repr(v_x_441__boxed_462_, v_prec_461_);
lean_dec(v_prec_461_);
return v_res_463_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__0(lean_object* v_slot_466_, lean_object* v_integers_467_, lean_object* v_v_468_, lean_object* v_n_469_){
_start:
{
uint8_t v___x_470_; 
v___x_470_ = lean_nat_dec_eq(v_n_469_, v_slot_466_);
if (v___x_470_ == 0)
{
lean_object* v___x_471_; 
v___x_471_ = lean_apply_1(v_integers_467_, v_n_469_);
return v___x_471_;
}
else
{
lean_dec(v_n_469_);
lean_dec_ref(v_integers_467_);
lean_inc(v_v_468_);
return v_v_468_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__0___boxed(lean_object* v_slot_472_, lean_object* v_integers_473_, lean_object* v_v_474_, lean_object* v_n_475_){
_start:
{
lean_object* v_res_476_; 
v_res_476_ = l_FormalSpecAgent_TypedMachine_setValue___lam__0(v_slot_472_, v_integers_473_, v_v_474_, v_n_475_);
lean_dec(v_v_474_);
lean_dec(v_slot_472_);
return v_res_476_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_setValue___lam__1(lean_object* v_slot_477_, lean_object* v_booleans_478_, lean_object* v_v_479_, lean_object* v_n_480_){
_start:
{
uint8_t v___x_481_; 
v___x_481_ = lean_nat_dec_eq(v_n_480_, v_slot_477_);
if (v___x_481_ == 0)
{
lean_object* v___x_482_; uint8_t v___x_483_; 
v___x_482_ = lean_apply_1(v_booleans_478_, v_n_480_);
v___x_483_ = lean_unbox(v___x_482_);
return v___x_483_;
}
else
{
uint8_t v___x_484_; 
lean_dec(v_n_480_);
lean_dec_ref(v_booleans_478_);
v___x_484_ = lean_unbox(v_v_479_);
return v___x_484_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__1___boxed(lean_object* v_slot_485_, lean_object* v_booleans_486_, lean_object* v_v_487_, lean_object* v_n_488_){
_start:
{
uint8_t v_res_489_; lean_object* v_r_490_; 
v_res_489_ = l_FormalSpecAgent_TypedMachine_setValue___lam__1(v_slot_485_, v_booleans_486_, v_v_487_, v_n_488_);
lean_dec(v_v_487_);
lean_dec(v_slot_485_);
v_r_490_ = lean_box(v_res_489_);
return v_r_490_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__2(lean_object* v_slot_491_, lean_object* v_texts_492_, lean_object* v_v_493_, lean_object* v_n_494_){
_start:
{
uint8_t v___x_495_; 
v___x_495_ = lean_nat_dec_eq(v_n_494_, v_slot_491_);
if (v___x_495_ == 0)
{
lean_object* v___x_496_; 
v___x_496_ = lean_apply_1(v_texts_492_, v_n_494_);
return v___x_496_;
}
else
{
lean_dec(v_n_494_);
lean_dec_ref(v_texts_492_);
lean_inc(v_v_493_);
return v_v_493_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__2___boxed(lean_object* v_slot_497_, lean_object* v_texts_498_, lean_object* v_v_499_, lean_object* v_n_500_){
_start:
{
lean_object* v_res_501_; 
v_res_501_ = l_FormalSpecAgent_TypedMachine_setValue___lam__2(v_slot_497_, v_texts_498_, v_v_499_, v_n_500_);
lean_dec(v_v_499_);
lean_dec(v_slot_497_);
return v_res_501_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__3(lean_object* v_slot_502_, lean_object* v_buffers_503_, lean_object* v_v_504_, lean_object* v_n_505_){
_start:
{
uint8_t v___x_506_; 
v___x_506_ = lean_nat_dec_eq(v_n_505_, v_slot_502_);
if (v___x_506_ == 0)
{
lean_object* v___x_507_; 
v___x_507_ = lean_apply_1(v_buffers_503_, v_n_505_);
return v___x_507_;
}
else
{
lean_dec(v_n_505_);
lean_dec_ref(v_buffers_503_);
lean_inc(v_v_504_);
return v_v_504_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__3___boxed(lean_object* v_slot_508_, lean_object* v_buffers_509_, lean_object* v_v_510_, lean_object* v_n_511_){
_start:
{
lean_object* v_res_512_; 
v_res_512_ = l_FormalSpecAgent_TypedMachine_setValue___lam__3(v_slot_508_, v_buffers_509_, v_v_510_, v_n_511_);
lean_dec(v_v_510_);
lean_dec(v_slot_508_);
return v_res_512_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__4(lean_object* v_slot_513_, lean_object* v_sequences_514_, lean_object* v_v_515_, lean_object* v_n_516_){
_start:
{
uint8_t v___x_517_; 
v___x_517_ = lean_nat_dec_eq(v_n_516_, v_slot_513_);
if (v___x_517_ == 0)
{
lean_object* v___x_518_; 
v___x_518_ = lean_apply_1(v_sequences_514_, v_n_516_);
return v___x_518_;
}
else
{
lean_dec(v_n_516_);
lean_dec_ref(v_sequences_514_);
lean_inc(v_v_515_);
return v_v_515_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___lam__4___boxed(lean_object* v_slot_519_, lean_object* v_sequences_520_, lean_object* v_v_521_, lean_object* v_n_522_){
_start:
{
lean_object* v_res_523_; 
v_res_523_ = l_FormalSpecAgent_TypedMachine_setValue___lam__4(v_slot_519_, v_sequences_520_, v_v_521_, v_n_522_);
lean_dec(v_v_521_);
lean_dec(v_slot_519_);
return v_res_523_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue(uint8_t v_k_524_, lean_object* v_slot_525_, lean_object* v_v_526_, lean_object* v_s_527_){
_start:
{
switch(v_k_524_)
{
case 0:
{
lean_object* v_integers_528_; lean_object* v_booleans_529_; lean_object* v_texts_530_; lean_object* v_buffers_531_; lean_object* v_sequences_532_; lean_object* v___x_534_; uint8_t v_isShared_535_; uint8_t v_isSharedCheck_540_; 
v_integers_528_ = lean_ctor_get(v_s_527_, 0);
v_booleans_529_ = lean_ctor_get(v_s_527_, 1);
v_texts_530_ = lean_ctor_get(v_s_527_, 2);
v_buffers_531_ = lean_ctor_get(v_s_527_, 3);
v_sequences_532_ = lean_ctor_get(v_s_527_, 4);
v_isSharedCheck_540_ = !lean_is_exclusive(v_s_527_);
if (v_isSharedCheck_540_ == 0)
{
v___x_534_ = v_s_527_;
v_isShared_535_ = v_isSharedCheck_540_;
goto v_resetjp_533_;
}
else
{
lean_inc(v_sequences_532_);
lean_inc(v_buffers_531_);
lean_inc(v_texts_530_);
lean_inc(v_booleans_529_);
lean_inc(v_integers_528_);
lean_dec(v_s_527_);
v___x_534_ = lean_box(0);
v_isShared_535_ = v_isSharedCheck_540_;
goto v_resetjp_533_;
}
v_resetjp_533_:
{
lean_object* v___f_536_; lean_object* v___x_538_; 
v___f_536_ = lean_alloc_closure((void*)(l_FormalSpecAgent_TypedMachine_setValue___lam__0___boxed), 4, 3);
lean_closure_set(v___f_536_, 0, v_slot_525_);
lean_closure_set(v___f_536_, 1, v_integers_528_);
lean_closure_set(v___f_536_, 2, v_v_526_);
if (v_isShared_535_ == 0)
{
lean_ctor_set(v___x_534_, 0, v___f_536_);
v___x_538_ = v___x_534_;
goto v_reusejp_537_;
}
else
{
lean_object* v_reuseFailAlloc_539_; 
v_reuseFailAlloc_539_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v_reuseFailAlloc_539_, 0, v___f_536_);
lean_ctor_set(v_reuseFailAlloc_539_, 1, v_booleans_529_);
lean_ctor_set(v_reuseFailAlloc_539_, 2, v_texts_530_);
lean_ctor_set(v_reuseFailAlloc_539_, 3, v_buffers_531_);
lean_ctor_set(v_reuseFailAlloc_539_, 4, v_sequences_532_);
v___x_538_ = v_reuseFailAlloc_539_;
goto v_reusejp_537_;
}
v_reusejp_537_:
{
return v___x_538_;
}
}
}
case 1:
{
lean_object* v_integers_541_; lean_object* v_booleans_542_; lean_object* v_texts_543_; lean_object* v_buffers_544_; lean_object* v_sequences_545_; lean_object* v___x_547_; uint8_t v_isShared_548_; uint8_t v_isSharedCheck_553_; 
v_integers_541_ = lean_ctor_get(v_s_527_, 0);
v_booleans_542_ = lean_ctor_get(v_s_527_, 1);
v_texts_543_ = lean_ctor_get(v_s_527_, 2);
v_buffers_544_ = lean_ctor_get(v_s_527_, 3);
v_sequences_545_ = lean_ctor_get(v_s_527_, 4);
v_isSharedCheck_553_ = !lean_is_exclusive(v_s_527_);
if (v_isSharedCheck_553_ == 0)
{
v___x_547_ = v_s_527_;
v_isShared_548_ = v_isSharedCheck_553_;
goto v_resetjp_546_;
}
else
{
lean_inc(v_sequences_545_);
lean_inc(v_buffers_544_);
lean_inc(v_texts_543_);
lean_inc(v_booleans_542_);
lean_inc(v_integers_541_);
lean_dec(v_s_527_);
v___x_547_ = lean_box(0);
v_isShared_548_ = v_isSharedCheck_553_;
goto v_resetjp_546_;
}
v_resetjp_546_:
{
lean_object* v___f_549_; lean_object* v___x_551_; 
v___f_549_ = lean_alloc_closure((void*)(l_FormalSpecAgent_TypedMachine_setValue___lam__1___boxed), 4, 3);
lean_closure_set(v___f_549_, 0, v_slot_525_);
lean_closure_set(v___f_549_, 1, v_booleans_542_);
lean_closure_set(v___f_549_, 2, v_v_526_);
if (v_isShared_548_ == 0)
{
lean_ctor_set(v___x_547_, 1, v___f_549_);
v___x_551_ = v___x_547_;
goto v_reusejp_550_;
}
else
{
lean_object* v_reuseFailAlloc_552_; 
v_reuseFailAlloc_552_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v_reuseFailAlloc_552_, 0, v_integers_541_);
lean_ctor_set(v_reuseFailAlloc_552_, 1, v___f_549_);
lean_ctor_set(v_reuseFailAlloc_552_, 2, v_texts_543_);
lean_ctor_set(v_reuseFailAlloc_552_, 3, v_buffers_544_);
lean_ctor_set(v_reuseFailAlloc_552_, 4, v_sequences_545_);
v___x_551_ = v_reuseFailAlloc_552_;
goto v_reusejp_550_;
}
v_reusejp_550_:
{
return v___x_551_;
}
}
}
case 2:
{
lean_object* v_integers_554_; lean_object* v_booleans_555_; lean_object* v_texts_556_; lean_object* v_buffers_557_; lean_object* v_sequences_558_; lean_object* v___x_560_; uint8_t v_isShared_561_; uint8_t v_isSharedCheck_566_; 
v_integers_554_ = lean_ctor_get(v_s_527_, 0);
v_booleans_555_ = lean_ctor_get(v_s_527_, 1);
v_texts_556_ = lean_ctor_get(v_s_527_, 2);
v_buffers_557_ = lean_ctor_get(v_s_527_, 3);
v_sequences_558_ = lean_ctor_get(v_s_527_, 4);
v_isSharedCheck_566_ = !lean_is_exclusive(v_s_527_);
if (v_isSharedCheck_566_ == 0)
{
v___x_560_ = v_s_527_;
v_isShared_561_ = v_isSharedCheck_566_;
goto v_resetjp_559_;
}
else
{
lean_inc(v_sequences_558_);
lean_inc(v_buffers_557_);
lean_inc(v_texts_556_);
lean_inc(v_booleans_555_);
lean_inc(v_integers_554_);
lean_dec(v_s_527_);
v___x_560_ = lean_box(0);
v_isShared_561_ = v_isSharedCheck_566_;
goto v_resetjp_559_;
}
v_resetjp_559_:
{
lean_object* v___f_562_; lean_object* v___x_564_; 
v___f_562_ = lean_alloc_closure((void*)(l_FormalSpecAgent_TypedMachine_setValue___lam__2___boxed), 4, 3);
lean_closure_set(v___f_562_, 0, v_slot_525_);
lean_closure_set(v___f_562_, 1, v_texts_556_);
lean_closure_set(v___f_562_, 2, v_v_526_);
if (v_isShared_561_ == 0)
{
lean_ctor_set(v___x_560_, 2, v___f_562_);
v___x_564_ = v___x_560_;
goto v_reusejp_563_;
}
else
{
lean_object* v_reuseFailAlloc_565_; 
v_reuseFailAlloc_565_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v_reuseFailAlloc_565_, 0, v_integers_554_);
lean_ctor_set(v_reuseFailAlloc_565_, 1, v_booleans_555_);
lean_ctor_set(v_reuseFailAlloc_565_, 2, v___f_562_);
lean_ctor_set(v_reuseFailAlloc_565_, 3, v_buffers_557_);
lean_ctor_set(v_reuseFailAlloc_565_, 4, v_sequences_558_);
v___x_564_ = v_reuseFailAlloc_565_;
goto v_reusejp_563_;
}
v_reusejp_563_:
{
return v___x_564_;
}
}
}
case 3:
{
lean_object* v_integers_567_; lean_object* v_booleans_568_; lean_object* v_texts_569_; lean_object* v_buffers_570_; lean_object* v_sequences_571_; lean_object* v___x_573_; uint8_t v_isShared_574_; uint8_t v_isSharedCheck_579_; 
v_integers_567_ = lean_ctor_get(v_s_527_, 0);
v_booleans_568_ = lean_ctor_get(v_s_527_, 1);
v_texts_569_ = lean_ctor_get(v_s_527_, 2);
v_buffers_570_ = lean_ctor_get(v_s_527_, 3);
v_sequences_571_ = lean_ctor_get(v_s_527_, 4);
v_isSharedCheck_579_ = !lean_is_exclusive(v_s_527_);
if (v_isSharedCheck_579_ == 0)
{
v___x_573_ = v_s_527_;
v_isShared_574_ = v_isSharedCheck_579_;
goto v_resetjp_572_;
}
else
{
lean_inc(v_sequences_571_);
lean_inc(v_buffers_570_);
lean_inc(v_texts_569_);
lean_inc(v_booleans_568_);
lean_inc(v_integers_567_);
lean_dec(v_s_527_);
v___x_573_ = lean_box(0);
v_isShared_574_ = v_isSharedCheck_579_;
goto v_resetjp_572_;
}
v_resetjp_572_:
{
lean_object* v___f_575_; lean_object* v___x_577_; 
v___f_575_ = lean_alloc_closure((void*)(l_FormalSpecAgent_TypedMachine_setValue___lam__3___boxed), 4, 3);
lean_closure_set(v___f_575_, 0, v_slot_525_);
lean_closure_set(v___f_575_, 1, v_buffers_570_);
lean_closure_set(v___f_575_, 2, v_v_526_);
if (v_isShared_574_ == 0)
{
lean_ctor_set(v___x_573_, 3, v___f_575_);
v___x_577_ = v___x_573_;
goto v_reusejp_576_;
}
else
{
lean_object* v_reuseFailAlloc_578_; 
v_reuseFailAlloc_578_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v_reuseFailAlloc_578_, 0, v_integers_567_);
lean_ctor_set(v_reuseFailAlloc_578_, 1, v_booleans_568_);
lean_ctor_set(v_reuseFailAlloc_578_, 2, v_texts_569_);
lean_ctor_set(v_reuseFailAlloc_578_, 3, v___f_575_);
lean_ctor_set(v_reuseFailAlloc_578_, 4, v_sequences_571_);
v___x_577_ = v_reuseFailAlloc_578_;
goto v_reusejp_576_;
}
v_reusejp_576_:
{
return v___x_577_;
}
}
}
default: 
{
lean_object* v_integers_580_; lean_object* v_booleans_581_; lean_object* v_texts_582_; lean_object* v_buffers_583_; lean_object* v_sequences_584_; lean_object* v___x_586_; uint8_t v_isShared_587_; uint8_t v_isSharedCheck_592_; 
v_integers_580_ = lean_ctor_get(v_s_527_, 0);
v_booleans_581_ = lean_ctor_get(v_s_527_, 1);
v_texts_582_ = lean_ctor_get(v_s_527_, 2);
v_buffers_583_ = lean_ctor_get(v_s_527_, 3);
v_sequences_584_ = lean_ctor_get(v_s_527_, 4);
v_isSharedCheck_592_ = !lean_is_exclusive(v_s_527_);
if (v_isSharedCheck_592_ == 0)
{
v___x_586_ = v_s_527_;
v_isShared_587_ = v_isSharedCheck_592_;
goto v_resetjp_585_;
}
else
{
lean_inc(v_sequences_584_);
lean_inc(v_buffers_583_);
lean_inc(v_texts_582_);
lean_inc(v_booleans_581_);
lean_inc(v_integers_580_);
lean_dec(v_s_527_);
v___x_586_ = lean_box(0);
v_isShared_587_ = v_isSharedCheck_592_;
goto v_resetjp_585_;
}
v_resetjp_585_:
{
lean_object* v___f_588_; lean_object* v___x_590_; 
v___f_588_ = lean_alloc_closure((void*)(l_FormalSpecAgent_TypedMachine_setValue___lam__4___boxed), 4, 3);
lean_closure_set(v___f_588_, 0, v_slot_525_);
lean_closure_set(v___f_588_, 1, v_sequences_584_);
lean_closure_set(v___f_588_, 2, v_v_526_);
if (v_isShared_587_ == 0)
{
lean_ctor_set(v___x_586_, 4, v___f_588_);
v___x_590_ = v___x_586_;
goto v_reusejp_589_;
}
else
{
lean_object* v_reuseFailAlloc_591_; 
v_reuseFailAlloc_591_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v_reuseFailAlloc_591_, 0, v_integers_580_);
lean_ctor_set(v_reuseFailAlloc_591_, 1, v_booleans_581_);
lean_ctor_set(v_reuseFailAlloc_591_, 2, v_texts_582_);
lean_ctor_set(v_reuseFailAlloc_591_, 3, v_buffers_583_);
lean_ctor_set(v_reuseFailAlloc_591_, 4, v___f_588_);
v___x_590_ = v_reuseFailAlloc_591_;
goto v_reusejp_589_;
}
v_reusejp_589_:
{
return v___x_590_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_setValue___boxed(lean_object* v_k_593_, lean_object* v_slot_594_, lean_object* v_v_595_, lean_object* v_s_596_){
_start:
{
uint8_t v_k_boxed_597_; lean_object* v_res_598_; 
v_k_boxed_597_ = lean_unbox(v_k_593_);
v_res_598_ = l_FormalSpecAgent_TypedMachine_setValue(v_k_boxed_597_, v_slot_594_, v_v_595_, v_s_596_);
return v_res_598_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_TypedMachine_context_spec__0(lean_object* v_a_599_, lean_object* v_a_600_){
_start:
{
if (lean_obj_tag(v_a_599_) == 0)
{
lean_object* v___x_601_; 
v___x_601_ = l_List_reverse___redArg(v_a_600_);
return v___x_601_;
}
else
{
lean_object* v_head_602_; lean_object* v_tail_603_; lean_object* v___x_605_; uint8_t v_isShared_606_; uint8_t v_isSharedCheck_612_; 
v_head_602_ = lean_ctor_get(v_a_599_, 0);
v_tail_603_ = lean_ctor_get(v_a_599_, 1);
v_isSharedCheck_612_ = !lean_is_exclusive(v_a_599_);
if (v_isSharedCheck_612_ == 0)
{
v___x_605_ = v_a_599_;
v_isShared_606_ = v_isSharedCheck_612_;
goto v_resetjp_604_;
}
else
{
lean_inc(v_tail_603_);
lean_inc(v_head_602_);
lean_dec(v_a_599_);
v___x_605_ = lean_box(0);
v_isShared_606_ = v_isSharedCheck_612_;
goto v_resetjp_604_;
}
v_resetjp_604_:
{
lean_object* v_timer_607_; lean_object* v___x_609_; 
v_timer_607_ = lean_ctor_get(v_head_602_, 0);
lean_inc(v_timer_607_);
lean_dec(v_head_602_);
if (v_isShared_606_ == 0)
{
lean_ctor_set(v___x_605_, 1, v_a_600_);
lean_ctor_set(v___x_605_, 0, v_timer_607_);
v___x_609_ = v___x_605_;
goto v_reusejp_608_;
}
else
{
lean_object* v_reuseFailAlloc_611_; 
v_reuseFailAlloc_611_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_611_, 0, v_timer_607_);
lean_ctor_set(v_reuseFailAlloc_611_, 1, v_a_600_);
v___x_609_ = v_reuseFailAlloc_611_;
goto v_reusejp_608_;
}
v_reusejp_608_:
{
v_a_599_ = v_tail_603_;
v_a_600_ = v___x_609_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_context(lean_object* v_snapshot_613_, lean_object* v_fields_614_){
_start:
{
lean_object* v_values_615_; lean_object* v_state_616_; lean_object* v_timers_617_; lean_object* v___x_619_; uint8_t v_isShared_620_; uint8_t v_isSharedCheck_626_; 
v_values_615_ = lean_ctor_get(v_snapshot_613_, 0);
v_state_616_ = lean_ctor_get(v_snapshot_613_, 1);
v_timers_617_ = lean_ctor_get(v_snapshot_613_, 3);
v_isSharedCheck_626_ = !lean_is_exclusive(v_snapshot_613_);
if (v_isSharedCheck_626_ == 0)
{
lean_object* v_unused_627_; 
v_unused_627_ = lean_ctor_get(v_snapshot_613_, 2);
lean_dec(v_unused_627_);
v___x_619_ = v_snapshot_613_;
v_isShared_620_ = v_isSharedCheck_626_;
goto v_resetjp_618_;
}
else
{
lean_inc(v_timers_617_);
lean_inc(v_state_616_);
lean_inc(v_values_615_);
lean_dec(v_snapshot_613_);
v___x_619_ = lean_box(0);
v_isShared_620_ = v_isSharedCheck_626_;
goto v_resetjp_618_;
}
v_resetjp_618_:
{
lean_object* v___x_621_; lean_object* v___x_622_; lean_object* v___x_624_; 
v___x_621_ = lean_box(0);
v___x_622_ = l_List_mapTR_loop___at___00FormalSpecAgent_TypedMachine_context_spec__0(v_timers_617_, v___x_621_);
if (v_isShared_620_ == 0)
{
lean_ctor_set(v___x_619_, 3, v___x_622_);
lean_ctor_set(v___x_619_, 2, v_state_616_);
lean_ctor_set(v___x_619_, 1, v_fields_614_);
v___x_624_ = v___x_619_;
goto v_reusejp_623_;
}
else
{
lean_object* v_reuseFailAlloc_625_; 
v_reuseFailAlloc_625_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_625_, 0, v_values_615_);
lean_ctor_set(v_reuseFailAlloc_625_, 1, v_fields_614_);
lean_ctor_set(v_reuseFailAlloc_625_, 2, v_state_616_);
lean_ctor_set(v_reuseFailAlloc_625_, 3, v___x_622_);
v___x_624_ = v_reuseFailAlloc_625_;
goto v_reusejp_623_;
}
v_reusejp_623_:
{
return v___x_624_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_cancelTimer_spec__0(lean_object* v_timer_628_, lean_object* v_a_629_, lean_object* v_a_630_){
_start:
{
if (lean_obj_tag(v_a_629_) == 0)
{
lean_object* v___x_631_; 
v___x_631_ = l_List_reverse___redArg(v_a_630_);
return v___x_631_;
}
else
{
lean_object* v_head_632_; lean_object* v_tail_633_; lean_object* v___x_635_; uint8_t v_isShared_636_; uint8_t v_isSharedCheck_644_; 
v_head_632_ = lean_ctor_get(v_a_629_, 0);
v_tail_633_ = lean_ctor_get(v_a_629_, 1);
v_isSharedCheck_644_ = !lean_is_exclusive(v_a_629_);
if (v_isSharedCheck_644_ == 0)
{
v___x_635_ = v_a_629_;
v_isShared_636_ = v_isSharedCheck_644_;
goto v_resetjp_634_;
}
else
{
lean_inc(v_tail_633_);
lean_inc(v_head_632_);
lean_dec(v_a_629_);
v___x_635_ = lean_box(0);
v_isShared_636_ = v_isSharedCheck_644_;
goto v_resetjp_634_;
}
v_resetjp_634_:
{
lean_object* v_timer_637_; uint8_t v___x_638_; 
v_timer_637_ = lean_ctor_get(v_head_632_, 0);
v___x_638_ = lean_nat_dec_eq(v_timer_637_, v_timer_628_);
if (v___x_638_ == 0)
{
lean_object* v___x_640_; 
if (v_isShared_636_ == 0)
{
lean_ctor_set(v___x_635_, 1, v_a_630_);
v___x_640_ = v___x_635_;
goto v_reusejp_639_;
}
else
{
lean_object* v_reuseFailAlloc_642_; 
v_reuseFailAlloc_642_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_642_, 0, v_head_632_);
lean_ctor_set(v_reuseFailAlloc_642_, 1, v_a_630_);
v___x_640_ = v_reuseFailAlloc_642_;
goto v_reusejp_639_;
}
v_reusejp_639_:
{
v_a_629_ = v_tail_633_;
v_a_630_ = v___x_640_;
goto _start;
}
}
else
{
lean_del_object(v___x_635_);
lean_dec(v_head_632_);
v_a_629_ = v_tail_633_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_cancelTimer_spec__0___boxed(lean_object* v_timer_645_, lean_object* v_a_646_, lean_object* v_a_647_){
_start:
{
lean_object* v_res_648_; 
v_res_648_ = l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_cancelTimer_spec__0(v_timer_645_, v_a_646_, v_a_647_);
lean_dec(v_timer_645_);
return v_res_648_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_cancelTimer(lean_object* v_snapshot_649_, lean_object* v_timer_650_){
_start:
{
lean_object* v_values_651_; lean_object* v_state_652_; lean_object* v_now_653_; lean_object* v_timers_654_; lean_object* v___x_656_; uint8_t v_isShared_657_; uint8_t v_isSharedCheck_663_; 
v_values_651_ = lean_ctor_get(v_snapshot_649_, 0);
v_state_652_ = lean_ctor_get(v_snapshot_649_, 1);
v_now_653_ = lean_ctor_get(v_snapshot_649_, 2);
v_timers_654_ = lean_ctor_get(v_snapshot_649_, 3);
v_isSharedCheck_663_ = !lean_is_exclusive(v_snapshot_649_);
if (v_isSharedCheck_663_ == 0)
{
v___x_656_ = v_snapshot_649_;
v_isShared_657_ = v_isSharedCheck_663_;
goto v_resetjp_655_;
}
else
{
lean_inc(v_timers_654_);
lean_inc(v_now_653_);
lean_inc(v_state_652_);
lean_inc(v_values_651_);
lean_dec(v_snapshot_649_);
v___x_656_ = lean_box(0);
v_isShared_657_ = v_isSharedCheck_663_;
goto v_resetjp_655_;
}
v_resetjp_655_:
{
lean_object* v___x_658_; lean_object* v___x_659_; lean_object* v___x_661_; 
v___x_658_ = lean_box(0);
v___x_659_ = l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_cancelTimer_spec__0(v_timer_650_, v_timers_654_, v___x_658_);
if (v_isShared_657_ == 0)
{
lean_ctor_set(v___x_656_, 3, v___x_659_);
v___x_661_ = v___x_656_;
goto v_reusejp_660_;
}
else
{
lean_object* v_reuseFailAlloc_662_; 
v_reuseFailAlloc_662_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_662_, 0, v_values_651_);
lean_ctor_set(v_reuseFailAlloc_662_, 1, v_state_652_);
lean_ctor_set(v_reuseFailAlloc_662_, 2, v_now_653_);
lean_ctor_set(v_reuseFailAlloc_662_, 3, v___x_659_);
v___x_661_ = v_reuseFailAlloc_662_;
goto v_reusejp_660_;
}
v_reusejp_660_:
{
return v___x_661_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_cancelTimer___boxed(lean_object* v_snapshot_664_, lean_object* v_timer_665_){
_start:
{
lean_object* v_res_666_; 
v_res_666_ = l_FormalSpecAgent_TypedMachine_cancelTimer(v_snapshot_664_, v_timer_665_);
lean_dec(v_timer_665_);
return v_res_666_;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_armTimer_spec__0(lean_object* v_timer_667_, lean_object* v_delay_668_, lean_object* v_a_669_, lean_object* v_a_670_){
_start:
{
if (lean_obj_tag(v_a_669_) == 0)
{
lean_object* v___x_671_; 
v___x_671_ = l_List_reverse___redArg(v_a_670_);
return v___x_671_;
}
else
{
lean_object* v_head_672_; lean_object* v_tail_673_; lean_object* v___x_675_; uint8_t v_isShared_676_; uint8_t v_isSharedCheck_687_; 
v_head_672_ = lean_ctor_get(v_a_669_, 0);
v_tail_673_ = lean_ctor_get(v_a_669_, 1);
v_isSharedCheck_687_ = !lean_is_exclusive(v_a_669_);
if (v_isSharedCheck_687_ == 0)
{
v___x_675_ = v_a_669_;
v_isShared_676_ = v_isSharedCheck_687_;
goto v_resetjp_674_;
}
else
{
lean_inc(v_tail_673_);
lean_inc(v_head_672_);
lean_dec(v_a_669_);
v___x_675_ = lean_box(0);
v_isShared_676_ = v_isSharedCheck_687_;
goto v_resetjp_674_;
}
v_resetjp_674_:
{
lean_object* v_timer_682_; uint8_t v___x_683_; 
v_timer_682_ = lean_ctor_get(v_head_672_, 0);
v___x_683_ = lean_nat_dec_eq(v_timer_682_, v_timer_667_);
if (v___x_683_ == 0)
{
goto v___jp_677_;
}
else
{
lean_object* v___x_684_; uint8_t v___x_685_; 
v___x_684_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18);
v___x_685_ = lean_int_dec_le(v_delay_668_, v___x_684_);
if (v___x_685_ == 0)
{
lean_del_object(v___x_675_);
lean_dec(v_head_672_);
v_a_669_ = v_tail_673_;
goto _start;
}
else
{
goto v___jp_677_;
}
}
v___jp_677_:
{
lean_object* v___x_679_; 
if (v_isShared_676_ == 0)
{
lean_ctor_set(v___x_675_, 1, v_a_670_);
v___x_679_ = v___x_675_;
goto v_reusejp_678_;
}
else
{
lean_object* v_reuseFailAlloc_681_; 
v_reuseFailAlloc_681_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_681_, 0, v_head_672_);
lean_ctor_set(v_reuseFailAlloc_681_, 1, v_a_670_);
v___x_679_ = v_reuseFailAlloc_681_;
goto v_reusejp_678_;
}
v_reusejp_678_:
{
v_a_669_ = v_tail_673_;
v_a_670_ = v___x_679_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_armTimer_spec__0___boxed(lean_object* v_timer_688_, lean_object* v_delay_689_, lean_object* v_a_690_, lean_object* v_a_691_){
_start:
{
lean_object* v_res_692_; 
v_res_692_ = l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_armTimer_spec__0(v_timer_688_, v_delay_689_, v_a_690_, v_a_691_);
lean_dec(v_delay_689_);
lean_dec(v_timer_688_);
return v_res_692_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_armTimer(lean_object* v_snapshot_696_, lean_object* v_timer_697_, lean_object* v_delay_698_){
_start:
{
lean_object* v___x_699_; uint8_t v___x_700_; 
v___x_699_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18);
v___x_700_ = lean_int_dec_le(v_delay_698_, v___x_699_);
if (v___x_700_ == 0)
{
lean_object* v_values_701_; lean_object* v_state_702_; lean_object* v_now_703_; lean_object* v_timers_704_; lean_object* v___x_706_; uint8_t v_isShared_707_; uint8_t v_isSharedCheck_718_; 
v_values_701_ = lean_ctor_get(v_snapshot_696_, 0);
v_state_702_ = lean_ctor_get(v_snapshot_696_, 1);
v_now_703_ = lean_ctor_get(v_snapshot_696_, 2);
v_timers_704_ = lean_ctor_get(v_snapshot_696_, 3);
v_isSharedCheck_718_ = !lean_is_exclusive(v_snapshot_696_);
if (v_isSharedCheck_718_ == 0)
{
v___x_706_ = v_snapshot_696_;
v_isShared_707_ = v_isSharedCheck_718_;
goto v_resetjp_705_;
}
else
{
lean_inc(v_timers_704_);
lean_inc(v_now_703_);
lean_inc(v_state_702_);
lean_inc(v_values_701_);
lean_dec(v_snapshot_696_);
v___x_706_ = lean_box(0);
v_isShared_707_ = v_isSharedCheck_718_;
goto v_resetjp_705_;
}
v_resetjp_705_:
{
lean_object* v___x_708_; lean_object* v_timers_x27_709_; lean_object* v___x_710_; lean_object* v___x_711_; lean_object* v___x_712_; lean_object* v___x_713_; lean_object* v___x_715_; 
v___x_708_ = lean_box(0);
v_timers_x27_709_ = l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_armTimer_spec__0(v_timer_697_, v_delay_698_, v_timers_704_, v___x_708_);
v___x_710_ = lean_int_add(v_now_703_, v_delay_698_);
v___x_711_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_711_, 0, v_timer_697_);
lean_ctor_set(v___x_711_, 1, v___x_710_);
v___x_712_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_712_, 0, v___x_711_);
lean_ctor_set(v___x_712_, 1, v___x_708_);
v___x_713_ = l_List_appendTR___redArg(v_timers_x27_709_, v___x_712_);
if (v_isShared_707_ == 0)
{
lean_ctor_set(v___x_706_, 3, v___x_713_);
v___x_715_ = v___x_706_;
goto v_reusejp_714_;
}
else
{
lean_object* v_reuseFailAlloc_717_; 
v_reuseFailAlloc_717_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_717_, 0, v_values_701_);
lean_ctor_set(v_reuseFailAlloc_717_, 1, v_state_702_);
lean_ctor_set(v_reuseFailAlloc_717_, 2, v_now_703_);
lean_ctor_set(v_reuseFailAlloc_717_, 3, v___x_713_);
v___x_715_ = v_reuseFailAlloc_717_;
goto v_reusejp_714_;
}
v_reusejp_714_:
{
lean_object* v___x_716_; 
v___x_716_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_716_, 0, v___x_715_);
return v___x_716_;
}
}
}
else
{
lean_object* v___x_719_; 
lean_dec(v_timer_697_);
lean_dec_ref(v_snapshot_696_);
v___x_719_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_armTimer___closed__0));
return v___x_719_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_armTimer___boxed(lean_object* v_snapshot_720_, lean_object* v_timer_721_, lean_object* v_delay_722_){
_start:
{
lean_object* v_res_723_; 
v_res_723_ = l_FormalSpecAgent_TypedMachine_armTimer(v_snapshot_720_, v_timer_721_, v_delay_722_);
lean_dec(v_delay_722_);
return v_res_723_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_eval(lean_object* v_snapshot_724_, lean_object* v_fields_725_, uint8_t v_k_726_, lean_object* v_e_727_){
_start:
{
lean_object* v___x_728_; lean_object* v___x_729_; 
v___x_728_ = l_FormalSpecAgent_TypedMachine_context(v_snapshot_724_, v_fields_725_);
v___x_729_ = l_FormalSpecAgent_TypedIR_eval(v_k_726_, v_e_727_, v___x_728_);
return v___x_729_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_eval___boxed(lean_object* v_snapshot_730_, lean_object* v_fields_731_, lean_object* v_k_732_, lean_object* v_e_733_){
_start:
{
uint8_t v_k_boxed_734_; lean_object* v_res_735_; 
v_k_boxed_734_ = lean_unbox(v_k_732_);
v_res_735_ = l_FormalSpecAgent_TypedMachine_eval(v_snapshot_730_, v_fields_731_, v_k_boxed_734_, v_e_733_);
return v_res_735_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_TypedMachine_work_spec__0(lean_object* v_snapshot_736_, lean_object* v_fields_737_, lean_object* v_a_738_, lean_object* v_a_739_){
_start:
{
if (lean_obj_tag(v_a_738_) == 0)
{
lean_object* v___x_740_; 
lean_dec_ref(v_fields_737_);
lean_dec_ref(v_snapshot_736_);
v___x_740_ = l_List_reverse___redArg(v_a_739_);
return v___x_740_;
}
else
{
lean_object* v_head_741_; lean_object* v_tail_742_; lean_object* v___x_744_; uint8_t v_isShared_745_; uint8_t v_isSharedCheck_761_; 
v_head_741_ = lean_ctor_get(v_a_738_, 0);
v_tail_742_ = lean_ctor_get(v_a_738_, 1);
v_isSharedCheck_761_ = !lean_is_exclusive(v_a_738_);
if (v_isSharedCheck_761_ == 0)
{
v___x_744_ = v_a_738_;
v_isShared_745_ = v_isSharedCheck_761_;
goto v_resetjp_743_;
}
else
{
lean_inc(v_tail_742_);
lean_inc(v_head_741_);
lean_dec(v_a_738_);
v___x_744_ = lean_box(0);
v_isShared_745_ = v_isSharedCheck_761_;
goto v_resetjp_743_;
}
v_resetjp_743_:
{
lean_object* v_slot_746_; uint8_t v_kind_747_; lean_object* v_expression_748_; lean_object* v___x_750_; uint8_t v_isShared_751_; uint8_t v_isSharedCheck_760_; 
v_slot_746_ = lean_ctor_get(v_head_741_, 0);
v_kind_747_ = lean_ctor_get_uint8(v_head_741_, sizeof(void*)*2);
v_expression_748_ = lean_ctor_get(v_head_741_, 1);
v_isSharedCheck_760_ = !lean_is_exclusive(v_head_741_);
if (v_isSharedCheck_760_ == 0)
{
v___x_750_ = v_head_741_;
v_isShared_751_ = v_isSharedCheck_760_;
goto v_resetjp_749_;
}
else
{
lean_inc(v_expression_748_);
lean_inc(v_slot_746_);
lean_dec(v_head_741_);
v___x_750_ = lean_box(0);
v_isShared_751_ = v_isSharedCheck_760_;
goto v_resetjp_749_;
}
v_resetjp_749_:
{
lean_object* v___x_752_; lean_object* v___x_754_; 
lean_inc_ref(v_fields_737_);
lean_inc_ref(v_snapshot_736_);
v___x_752_ = l_FormalSpecAgent_TypedMachine_eval(v_snapshot_736_, v_fields_737_, v_kind_747_, v_expression_748_);
if (v_isShared_751_ == 0)
{
lean_ctor_set(v___x_750_, 1, v___x_752_);
v___x_754_ = v___x_750_;
goto v_reusejp_753_;
}
else
{
lean_object* v_reuseFailAlloc_759_; 
v_reuseFailAlloc_759_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v_reuseFailAlloc_759_, 0, v_slot_746_);
lean_ctor_set(v_reuseFailAlloc_759_, 1, v___x_752_);
lean_ctor_set_uint8(v_reuseFailAlloc_759_, sizeof(void*)*2, v_kind_747_);
v___x_754_ = v_reuseFailAlloc_759_;
goto v_reusejp_753_;
}
v_reusejp_753_:
{
lean_object* v___x_756_; 
if (v_isShared_745_ == 0)
{
lean_ctor_set(v___x_744_, 1, v_a_739_);
lean_ctor_set(v___x_744_, 0, v___x_754_);
v___x_756_ = v___x_744_;
goto v_reusejp_755_;
}
else
{
lean_object* v_reuseFailAlloc_758_; 
v_reuseFailAlloc_758_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_758_, 0, v___x_754_);
lean_ctor_set(v_reuseFailAlloc_758_, 1, v_a_739_);
v___x_756_ = v_reuseFailAlloc_758_;
goto v_reusejp_755_;
}
v_reusejp_755_:
{
v_a_738_ = v_tail_742_;
v_a_739_ = v___x_756_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_work(lean_object* v_actions_765_, lean_object* v_snapshot_766_, lean_object* v_fields_767_, lean_object* v_out_768_){
_start:
{
if (lean_obj_tag(v_actions_765_) == 0)
{
lean_object* v___x_769_; lean_object* v___x_770_; 
lean_dec_ref(v_fields_767_);
v___x_769_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_769_, 0, v_snapshot_766_);
lean_ctor_set(v___x_769_, 1, v_out_768_);
v___x_770_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_770_, 0, v___x_769_);
return v___x_770_;
}
else
{
lean_object* v_head_771_; 
v_head_771_ = lean_ctor_get(v_actions_765_, 0);
lean_inc(v_head_771_);
switch(lean_obj_tag(v_head_771_))
{
case 0:
{
lean_object* v_tail_772_; uint8_t v_kind_773_; lean_object* v_slot_774_; lean_object* v_expr_775_; lean_object* v_values_776_; lean_object* v_state_777_; lean_object* v_now_778_; lean_object* v_timers_779_; lean_object* v_v_780_; lean_object* v___x_781_; lean_object* v___x_782_; 
v_tail_772_ = lean_ctor_get(v_actions_765_, 1);
lean_inc(v_tail_772_);
lean_dec_ref_known(v_actions_765_, 2);
v_kind_773_ = lean_ctor_get_uint8(v_head_771_, sizeof(void*)*2);
v_slot_774_ = lean_ctor_get(v_head_771_, 0);
lean_inc(v_slot_774_);
v_expr_775_ = lean_ctor_get(v_head_771_, 1);
lean_inc_ref(v_expr_775_);
lean_dec_ref_known(v_head_771_, 2);
v_values_776_ = lean_ctor_get(v_snapshot_766_, 0);
lean_inc_ref(v_values_776_);
v_state_777_ = lean_ctor_get(v_snapshot_766_, 1);
lean_inc(v_state_777_);
v_now_778_ = lean_ctor_get(v_snapshot_766_, 2);
lean_inc(v_now_778_);
v_timers_779_ = lean_ctor_get(v_snapshot_766_, 3);
lean_inc(v_timers_779_);
lean_inc_ref(v_fields_767_);
v_v_780_ = l_FormalSpecAgent_TypedMachine_eval(v_snapshot_766_, v_fields_767_, v_kind_773_, v_expr_775_);
v___x_781_ = l_FormalSpecAgent_TypedMachine_setValue(v_kind_773_, v_slot_774_, v_v_780_, v_values_776_);
v___x_782_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_782_, 0, v___x_781_);
lean_ctor_set(v___x_782_, 1, v_state_777_);
lean_ctor_set(v___x_782_, 2, v_now_778_);
lean_ctor_set(v___x_782_, 3, v_timers_779_);
v_actions_765_ = v_tail_772_;
v_snapshot_766_ = v___x_782_;
goto _start;
}
case 1:
{
lean_object* v_tail_784_; lean_object* v___x_786_; uint8_t v_isShared_787_; uint8_t v_isSharedCheck_804_; 
v_tail_784_ = lean_ctor_get(v_actions_765_, 1);
v_isSharedCheck_804_ = !lean_is_exclusive(v_actions_765_);
if (v_isSharedCheck_804_ == 0)
{
lean_object* v_unused_805_; 
v_unused_805_ = lean_ctor_get(v_actions_765_, 0);
lean_dec(v_unused_805_);
v___x_786_ = v_actions_765_;
v_isShared_787_ = v_isSharedCheck_804_;
goto v_resetjp_785_;
}
else
{
lean_inc(v_tail_784_);
lean_dec(v_actions_765_);
v___x_786_ = lean_box(0);
v_isShared_787_ = v_isSharedCheck_804_;
goto v_resetjp_785_;
}
v_resetjp_785_:
{
lean_object* v_message_788_; lean_object* v_fields_789_; lean_object* v___x_791_; uint8_t v_isShared_792_; uint8_t v_isSharedCheck_803_; 
v_message_788_ = lean_ctor_get(v_head_771_, 0);
v_fields_789_ = lean_ctor_get(v_head_771_, 1);
v_isSharedCheck_803_ = !lean_is_exclusive(v_head_771_);
if (v_isSharedCheck_803_ == 0)
{
v___x_791_ = v_head_771_;
v_isShared_792_ = v_isSharedCheck_803_;
goto v_resetjp_790_;
}
else
{
lean_inc(v_fields_789_);
lean_inc(v_message_788_);
lean_dec(v_head_771_);
v___x_791_ = lean_box(0);
v_isShared_792_ = v_isSharedCheck_803_;
goto v_resetjp_790_;
}
v_resetjp_790_:
{
lean_object* v___x_793_; lean_object* v_fvals_794_; lean_object* v_msg_796_; 
v___x_793_ = lean_box(0);
lean_inc_ref(v_fields_767_);
lean_inc_ref(v_snapshot_766_);
v_fvals_794_ = l_List_mapTR_loop___at___00FormalSpecAgent_TypedMachine_work_spec__0(v_snapshot_766_, v_fields_767_, v_fields_789_, v___x_793_);
if (v_isShared_792_ == 0)
{
lean_ctor_set_tag(v___x_791_, 0);
lean_ctor_set(v___x_791_, 1, v_fvals_794_);
v_msg_796_ = v___x_791_;
goto v_reusejp_795_;
}
else
{
lean_object* v_reuseFailAlloc_802_; 
v_reuseFailAlloc_802_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_802_, 0, v_message_788_);
lean_ctor_set(v_reuseFailAlloc_802_, 1, v_fvals_794_);
v_msg_796_ = v_reuseFailAlloc_802_;
goto v_reusejp_795_;
}
v_reusejp_795_:
{
lean_object* v___x_798_; 
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v___x_793_);
lean_ctor_set(v___x_786_, 0, v_msg_796_);
v___x_798_ = v___x_786_;
goto v_reusejp_797_;
}
else
{
lean_object* v_reuseFailAlloc_801_; 
v_reuseFailAlloc_801_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_801_, 0, v_msg_796_);
lean_ctor_set(v_reuseFailAlloc_801_, 1, v___x_793_);
v___x_798_ = v_reuseFailAlloc_801_;
goto v_reusejp_797_;
}
v_reusejp_797_:
{
lean_object* v___x_799_; 
v___x_799_ = l_List_appendTR___redArg(v_out_768_, v___x_798_);
v_actions_765_ = v_tail_784_;
v_out_768_ = v___x_799_;
goto _start;
}
}
}
}
}
case 2:
{
lean_object* v_tail_806_; lean_object* v_timer_807_; lean_object* v_delay_808_; uint8_t v___x_809_; lean_object* v_d_810_; lean_object* v___x_811_; 
v_tail_806_ = lean_ctor_get(v_actions_765_, 1);
lean_inc(v_tail_806_);
lean_dec_ref_known(v_actions_765_, 2);
v_timer_807_ = lean_ctor_get(v_head_771_, 0);
lean_inc(v_timer_807_);
v_delay_808_ = lean_ctor_get(v_head_771_, 1);
lean_inc_ref(v_delay_808_);
lean_dec_ref_known(v_head_771_, 2);
v___x_809_ = 0;
lean_inc_ref(v_fields_767_);
lean_inc_ref(v_snapshot_766_);
v_d_810_ = l_FormalSpecAgent_TypedMachine_eval(v_snapshot_766_, v_fields_767_, v___x_809_, v_delay_808_);
v___x_811_ = l_FormalSpecAgent_TypedMachine_armTimer(v_snapshot_766_, v_timer_807_, v_d_810_);
lean_dec(v_d_810_);
if (lean_obj_tag(v___x_811_) == 0)
{
lean_object* v___x_812_; 
lean_dec_ref_known(v___x_811_, 1);
lean_dec(v_tail_806_);
lean_dec(v_out_768_);
lean_dec_ref(v_fields_767_);
v___x_812_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_work___closed__0));
return v___x_812_;
}
else
{
lean_object* v_a_813_; 
v_a_813_ = lean_ctor_get(v___x_811_, 0);
lean_inc(v_a_813_);
lean_dec_ref_known(v___x_811_, 1);
v_actions_765_ = v_tail_806_;
v_snapshot_766_ = v_a_813_;
goto _start;
}
}
default: 
{
lean_object* v_tail_815_; lean_object* v_timer_816_; lean_object* v___x_817_; 
v_tail_815_ = lean_ctor_get(v_actions_765_, 1);
lean_inc(v_tail_815_);
lean_dec_ref_known(v_actions_765_, 2);
v_timer_816_ = lean_ctor_get(v_head_771_, 0);
lean_inc(v_timer_816_);
lean_dec_ref_known(v_head_771_, 1);
v___x_817_ = l_FormalSpecAgent_TypedMachine_cancelTimer(v_snapshot_766_, v_timer_816_);
lean_dec(v_timer_816_);
v_actions_765_ = v_tail_815_;
v_snapshot_766_ = v___x_817_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__0(lean_object* v_x_819_){
_start:
{
lean_object* v___x_820_; 
v___x_820_ = lean_obj_once(&l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18, &l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18_once, _init_l_FormalSpecAgent_TypedMachine_instReprTimerEntry_repr___redArg___closed__18);
return v___x_820_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__0___boxed(lean_object* v_x_821_){
_start:
{
lean_object* v_res_822_; 
v_res_822_ = l_FormalSpecAgent_TypedMachine_zeroValues___lam__0(v_x_821_);
lean_dec(v_x_821_);
return v_res_822_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_zeroValues___lam__1(lean_object* v_x_823_){
_start:
{
uint8_t v___x_824_; 
v___x_824_ = 0;
return v___x_824_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__1___boxed(lean_object* v_x_825_){
_start:
{
uint8_t v_res_826_; lean_object* v_r_827_; 
v_res_826_ = l_FormalSpecAgent_TypedMachine_zeroValues___lam__1(v_x_825_);
lean_dec(v_x_825_);
v_r_827_ = lean_box(v_res_826_);
return v_r_827_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__2(lean_object* v_x_829_){
_start:
{
lean_object* v___x_830_; 
v___x_830_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_zeroValues___lam__2___closed__0));
return v___x_830_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__2___boxed(lean_object* v_x_831_){
_start:
{
lean_object* v_res_832_; 
v_res_832_ = l_FormalSpecAgent_TypedMachine_zeroValues___lam__2(v_x_831_);
lean_dec(v_x_831_);
return v_res_832_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__3(lean_object* v_x_833_){
_start:
{
lean_object* v___x_834_; 
v___x_834_ = lean_box(0);
return v___x_834_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__3___boxed(lean_object* v_x_835_){
_start:
{
lean_object* v_res_836_; 
v_res_836_ = l_FormalSpecAgent_TypedMachine_zeroValues___lam__3(v_x_835_);
lean_dec(v_x_835_);
return v_res_836_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__4(lean_object* v_x_837_){
_start:
{
lean_object* v___x_838_; 
v___x_838_ = lean_unsigned_to_nat(0u);
return v___x_838_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_zeroValues___lam__4___boxed(lean_object* v_x_839_){
_start:
{
lean_object* v_res_840_; 
v_res_840_ = l_FormalSpecAgent_TypedMachine_zeroValues___lam__4(v_x_839_);
lean_dec(v_x_839_);
return v_res_840_;
}
}
LEAN_EXPORT uint8_t l_List_all___at___00FormalSpecAgent_TypedMachine_invariantsHold_spec__0(lean_object* v_snapshot_853_, lean_object* v_x_854_){
_start:
{
if (lean_obj_tag(v_x_854_) == 0)
{
uint8_t v___x_855_; 
lean_dec_ref(v_snapshot_853_);
v___x_855_ = 1;
return v___x_855_;
}
else
{
lean_object* v_head_856_; lean_object* v_tail_857_; lean_object* v___x_858_; uint8_t v___x_859_; lean_object* v___x_860_; uint8_t v___x_861_; 
v_head_856_ = lean_ctor_get(v_x_854_, 0);
lean_inc(v_head_856_);
v_tail_857_ = lean_ctor_get(v_x_854_, 1);
lean_inc(v_tail_857_);
lean_dec_ref_known(v_x_854_, 2);
v___x_858_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_zeroValues));
v___x_859_ = 1;
lean_inc_ref(v_snapshot_853_);
v___x_860_ = l_FormalSpecAgent_TypedMachine_eval(v_snapshot_853_, v___x_858_, v___x_859_, v_head_856_);
v___x_861_ = lean_unbox(v___x_860_);
if (v___x_861_ == 0)
{
uint8_t v___x_862_; 
lean_dec(v_tail_857_);
lean_dec_ref(v_snapshot_853_);
v___x_862_ = lean_unbox(v___x_860_);
lean_dec(v___x_860_);
return v___x_862_;
}
else
{
lean_dec(v___x_860_);
v_x_854_ = v_tail_857_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00FormalSpecAgent_TypedMachine_invariantsHold_spec__0___boxed(lean_object* v_snapshot_864_, lean_object* v_x_865_){
_start:
{
uint8_t v_res_866_; lean_object* v_r_867_; 
v_res_866_ = l_List_all___at___00FormalSpecAgent_TypedMachine_invariantsHold_spec__0(v_snapshot_864_, v_x_865_);
v_r_867_ = lean_box(v_res_866_);
return v_r_867_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedMachine_invariantsHold(lean_object* v_model_868_, lean_object* v_snapshot_869_){
_start:
{
lean_object* v_invariants_870_; uint8_t v___x_871_; 
v_invariants_870_ = lean_ctor_get(v_model_868_, 1);
lean_inc(v_invariants_870_);
lean_dec_ref(v_model_868_);
v___x_871_ = l_List_all___at___00FormalSpecAgent_TypedMachine_invariantsHold_spec__0(v_snapshot_869_, v_invariants_870_);
return v___x_871_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_invariantsHold___boxed(lean_object* v_model_872_, lean_object* v_snapshot_873_){
_start:
{
uint8_t v_res_874_; lean_object* v_r_875_; 
v_res_874_ = l_FormalSpecAgent_TypedMachine_invariantsHold(v_model_872_, v_snapshot_873_);
v_r_875_ = lean_box(v_res_874_);
return v_r_875_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_withoutFiring(lean_object* v_snapshot_876_, lean_object* v_firing_877_){
_start:
{
if (lean_obj_tag(v_firing_877_) == 0)
{
return v_snapshot_876_;
}
else
{
lean_object* v_val_878_; lean_object* v___x_879_; 
v_val_878_ = lean_ctor_get(v_firing_877_, 0);
v___x_879_ = l_FormalSpecAgent_TypedMachine_cancelTimer(v_snapshot_876_, v_val_878_);
return v___x_879_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_withoutFiring___boxed(lean_object* v_snapshot_880_, lean_object* v_firing_881_){
_start:
{
lean_object* v_res_882_; 
v_res_882_ = l_FormalSpecAgent_TypedMachine_withoutFiring(v_snapshot_880_, v_firing_881_);
lean_dec(v_firing_881_);
return v_res_882_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_runRule(lean_object* v_model_889_, lean_object* v_snapshot_890_, lean_object* v_r_891_, lean_object* v_fields_892_, lean_object* v_event_893_, lean_object* v_firing_894_){
_start:
{
lean_object* v_id_895_; lean_object* v_target_896_; lean_object* v_actions_897_; lean_object* v___x_898_; lean_object* v___x_899_; lean_object* v___x_900_; 
v_id_895_ = lean_ctor_get(v_r_891_, 0);
lean_inc(v_id_895_);
v_target_896_ = lean_ctor_get(v_r_891_, 2);
lean_inc(v_target_896_);
v_actions_897_ = lean_ctor_get(v_r_891_, 5);
lean_inc(v_actions_897_);
lean_dec_ref(v_r_891_);
v___x_898_ = l_FormalSpecAgent_TypedMachine_withoutFiring(v_snapshot_890_, v_firing_894_);
v___x_899_ = lean_box(0);
v___x_900_ = l_FormalSpecAgent_TypedMachine_work(v_actions_897_, v___x_898_, v_fields_892_, v___x_899_);
if (lean_obj_tag(v___x_900_) == 0)
{
lean_object* v___x_901_; 
lean_dec_ref_known(v___x_900_, 1);
lean_dec(v_target_896_);
lean_dec(v_id_895_);
lean_dec(v_event_893_);
lean_dec_ref(v_model_889_);
v___x_901_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_runRule___closed__0));
return v___x_901_;
}
else
{
lean_object* v_a_902_; lean_object* v___x_904_; uint8_t v_isShared_905_; uint8_t v_isSharedCheck_925_; 
v_a_902_ = lean_ctor_get(v___x_900_, 0);
v_isSharedCheck_925_ = !lean_is_exclusive(v___x_900_);
if (v_isSharedCheck_925_ == 0)
{
v___x_904_ = v___x_900_;
v_isShared_905_ = v_isSharedCheck_925_;
goto v_resetjp_903_;
}
else
{
lean_inc(v_a_902_);
lean_dec(v___x_900_);
v___x_904_ = lean_box(0);
v_isShared_905_ = v_isSharedCheck_925_;
goto v_resetjp_903_;
}
v_resetjp_903_:
{
lean_object* v_fst_906_; lean_object* v_snd_907_; lean_object* v_values_908_; lean_object* v_now_909_; lean_object* v_timers_910_; lean_object* v___x_912_; uint8_t v_isShared_913_; uint8_t v_isSharedCheck_923_; 
v_fst_906_ = lean_ctor_get(v_a_902_, 0);
lean_inc(v_fst_906_);
v_snd_907_ = lean_ctor_get(v_a_902_, 1);
lean_inc(v_snd_907_);
lean_dec(v_a_902_);
v_values_908_ = lean_ctor_get(v_fst_906_, 0);
v_now_909_ = lean_ctor_get(v_fst_906_, 2);
v_timers_910_ = lean_ctor_get(v_fst_906_, 3);
v_isSharedCheck_923_ = !lean_is_exclusive(v_fst_906_);
if (v_isSharedCheck_923_ == 0)
{
lean_object* v_unused_924_; 
v_unused_924_ = lean_ctor_get(v_fst_906_, 1);
lean_dec(v_unused_924_);
v___x_912_ = v_fst_906_;
v_isShared_913_ = v_isSharedCheck_923_;
goto v_resetjp_911_;
}
else
{
lean_inc(v_timers_910_);
lean_inc(v_now_909_);
lean_inc(v_values_908_);
lean_dec(v_fst_906_);
v___x_912_ = lean_box(0);
v_isShared_913_ = v_isSharedCheck_923_;
goto v_resetjp_911_;
}
v_resetjp_911_:
{
lean_object* v_after_915_; 
if (v_isShared_913_ == 0)
{
lean_ctor_set(v___x_912_, 1, v_target_896_);
v_after_915_ = v___x_912_;
goto v_reusejp_914_;
}
else
{
lean_object* v_reuseFailAlloc_922_; 
v_reuseFailAlloc_922_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_922_, 0, v_values_908_);
lean_ctor_set(v_reuseFailAlloc_922_, 1, v_target_896_);
lean_ctor_set(v_reuseFailAlloc_922_, 2, v_now_909_);
lean_ctor_set(v_reuseFailAlloc_922_, 3, v_timers_910_);
v_after_915_ = v_reuseFailAlloc_922_;
goto v_reusejp_914_;
}
v_reusejp_914_:
{
uint8_t v___x_916_; 
lean_inc_ref(v_after_915_);
v___x_916_ = l_FormalSpecAgent_TypedMachine_invariantsHold(v_model_889_, v_after_915_);
if (v___x_916_ == 0)
{
lean_object* v___x_917_; 
lean_dec_ref(v_after_915_);
lean_dec(v_snd_907_);
lean_del_object(v___x_904_);
lean_dec(v_id_895_);
lean_dec(v_event_893_);
v___x_917_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_runRule___closed__1));
return v___x_917_;
}
else
{
lean_object* v___x_918_; lean_object* v___x_920_; 
v___x_918_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_918_, 0, v_after_915_);
lean_ctor_set(v___x_918_, 1, v_id_895_);
lean_ctor_set(v___x_918_, 2, v_event_893_);
lean_ctor_set(v___x_918_, 3, v_snd_907_);
if (v_isShared_905_ == 0)
{
lean_ctor_set(v___x_904_, 0, v___x_918_);
v___x_920_ = v___x_904_;
goto v_reusejp_919_;
}
else
{
lean_object* v_reuseFailAlloc_921_; 
v_reuseFailAlloc_921_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_921_, 0, v___x_918_);
v___x_920_ = v_reuseFailAlloc_921_;
goto v_reusejp_919_;
}
v_reusejp_919_:
{
return v___x_920_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_runRule___boxed(lean_object* v_model_926_, lean_object* v_snapshot_927_, lean_object* v_r_928_, lean_object* v_fields_929_, lean_object* v_event_930_, lean_object* v_firing_931_){
_start:
{
lean_object* v_res_932_; 
v_res_932_ = l_FormalSpecAgent_TypedMachine_runRule(v_model_926_, v_snapshot_927_, v_r_928_, v_fields_929_, v_event_930_, v_firing_931_);
lean_dec(v_firing_931_);
return v_res_932_;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_enabled_spec__0(lean_object* v_snapshot_933_, lean_object* v_event_934_, lean_object* v_fields_935_, lean_object* v_a_936_, lean_object* v_a_937_){
_start:
{
if (lean_obj_tag(v_a_936_) == 0)
{
lean_object* v___x_938_; 
lean_dec_ref(v_fields_935_);
lean_dec_ref(v_snapshot_933_);
v___x_938_ = l_List_reverse___redArg(v_a_937_);
return v___x_938_;
}
else
{
lean_object* v_head_939_; lean_object* v_tail_940_; lean_object* v___x_942_; uint8_t v_isShared_943_; uint8_t v_isSharedCheck_960_; 
v_head_939_ = lean_ctor_get(v_a_936_, 0);
v_tail_940_ = lean_ctor_get(v_a_936_, 1);
v_isSharedCheck_960_ = !lean_is_exclusive(v_a_936_);
if (v_isSharedCheck_960_ == 0)
{
v___x_942_ = v_a_936_;
v_isShared_943_ = v_isSharedCheck_960_;
goto v_resetjp_941_;
}
else
{
lean_inc(v_tail_940_);
lean_inc(v_head_939_);
lean_dec(v_a_936_);
v___x_942_ = lean_box(0);
v_isShared_943_ = v_isSharedCheck_960_;
goto v_resetjp_941_;
}
v_resetjp_941_:
{
lean_object* v_source_944_; lean_object* v_event_945_; lean_object* v_guard_946_; lean_object* v_state_947_; uint8_t v___x_948_; 
v_source_944_ = lean_ctor_get(v_head_939_, 1);
v_event_945_ = lean_ctor_get(v_head_939_, 3);
v_guard_946_ = lean_ctor_get(v_head_939_, 4);
v_state_947_ = lean_ctor_get(v_snapshot_933_, 1);
v___x_948_ = lean_nat_dec_eq(v_source_944_, v_state_947_);
if (v___x_948_ == 0)
{
lean_del_object(v___x_942_);
lean_dec(v_head_939_);
v_a_936_ = v_tail_940_;
goto _start;
}
else
{
uint8_t v___x_950_; 
v___x_950_ = lean_nat_dec_eq(v_event_945_, v_event_934_);
if (v___x_950_ == 0)
{
lean_del_object(v___x_942_);
lean_dec(v_head_939_);
v_a_936_ = v_tail_940_;
goto _start;
}
else
{
uint8_t v___x_952_; lean_object* v___x_953_; uint8_t v___x_954_; 
v___x_952_ = 1;
lean_inc_ref(v_guard_946_);
lean_inc_ref(v_fields_935_);
lean_inc_ref(v_snapshot_933_);
v___x_953_ = l_FormalSpecAgent_TypedMachine_eval(v_snapshot_933_, v_fields_935_, v___x_952_, v_guard_946_);
v___x_954_ = lean_unbox(v___x_953_);
lean_dec(v___x_953_);
if (v___x_954_ == 0)
{
lean_del_object(v___x_942_);
lean_dec(v_head_939_);
v_a_936_ = v_tail_940_;
goto _start;
}
else
{
lean_object* v___x_957_; 
if (v_isShared_943_ == 0)
{
lean_ctor_set(v___x_942_, 1, v_a_937_);
v___x_957_ = v___x_942_;
goto v_reusejp_956_;
}
else
{
lean_object* v_reuseFailAlloc_959_; 
v_reuseFailAlloc_959_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_959_, 0, v_head_939_);
lean_ctor_set(v_reuseFailAlloc_959_, 1, v_a_937_);
v___x_957_ = v_reuseFailAlloc_959_;
goto v_reusejp_956_;
}
v_reusejp_956_:
{
v_a_936_ = v_tail_940_;
v_a_937_ = v___x_957_;
goto _start;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_enabled_spec__0___boxed(lean_object* v_snapshot_961_, lean_object* v_event_962_, lean_object* v_fields_963_, lean_object* v_a_964_, lean_object* v_a_965_){
_start:
{
lean_object* v_res_966_; 
v_res_966_ = l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_enabled_spec__0(v_snapshot_961_, v_event_962_, v_fields_963_, v_a_964_, v_a_965_);
lean_dec(v_event_962_);
return v_res_966_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_enabled(lean_object* v_model_967_, lean_object* v_snapshot_968_, lean_object* v_event_969_, lean_object* v_fields_970_){
_start:
{
lean_object* v_rules_971_; lean_object* v___x_972_; lean_object* v___x_973_; 
v_rules_971_ = lean_ctor_get(v_model_967_, 0);
lean_inc(v_rules_971_);
lean_dec_ref(v_model_967_);
v___x_972_ = lean_box(0);
v___x_973_ = l_List_filterTR_loop___at___00FormalSpecAgent_TypedMachine_enabled_spec__0(v_snapshot_968_, v_event_969_, v_fields_970_, v_rules_971_, v___x_972_);
return v___x_973_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_enabled___boxed(lean_object* v_model_974_, lean_object* v_snapshot_975_, lean_object* v_event_976_, lean_object* v_fields_977_){
_start:
{
lean_object* v_res_978_; 
v_res_978_ = l_FormalSpecAgent_TypedMachine_enabled(v_model_974_, v_snapshot_975_, v_event_976_, v_fields_977_);
lean_dec(v_event_976_);
return v_res_978_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_fire(lean_object* v_model_985_, lean_object* v_snapshot_986_, lean_object* v_event_987_, lean_object* v_fields_988_, lean_object* v_firing_989_){
_start:
{
lean_object* v___x_990_; 
lean_inc_ref(v_fields_988_);
lean_inc_ref(v_snapshot_986_);
lean_inc_ref(v_model_985_);
v___x_990_ = l_FormalSpecAgent_TypedMachine_enabled(v_model_985_, v_snapshot_986_, v_event_987_, v_fields_988_);
if (lean_obj_tag(v___x_990_) == 0)
{
lean_object* v___x_991_; 
lean_dec_ref(v_fields_988_);
lean_dec(v_event_987_);
lean_dec_ref(v_snapshot_986_);
lean_dec_ref(v_model_985_);
v___x_991_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_fire___closed__0));
return v___x_991_;
}
else
{
lean_object* v_tail_992_; 
v_tail_992_ = lean_ctor_get(v___x_990_, 1);
lean_inc(v_tail_992_);
if (lean_obj_tag(v_tail_992_) == 0)
{
lean_object* v_head_993_; lean_object* v___x_994_; 
v_head_993_ = lean_ctor_get(v___x_990_, 0);
lean_inc(v_head_993_);
lean_dec_ref_known(v___x_990_, 2);
v___x_994_ = l_FormalSpecAgent_TypedMachine_runRule(v_model_985_, v_snapshot_986_, v_head_993_, v_fields_988_, v_event_987_, v_firing_989_);
return v___x_994_;
}
else
{
lean_object* v___x_995_; 
lean_dec_ref_known(v___x_990_, 2);
lean_dec(v_tail_992_);
lean_dec_ref(v_fields_988_);
lean_dec(v_event_987_);
lean_dec_ref(v_snapshot_986_);
lean_dec_ref(v_model_985_);
v___x_995_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_fire___closed__1));
return v___x_995_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_fire___boxed(lean_object* v_model_996_, lean_object* v_snapshot_997_, lean_object* v_event_998_, lean_object* v_fields_999_, lean_object* v_firing_1000_){
_start:
{
lean_object* v_res_1001_; 
v_res_1001_ = l_FormalSpecAgent_TypedMachine_fire(v_model_996_, v_snapshot_997_, v_event_998_, v_fields_999_, v_firing_1000_);
lean_dec(v_firing_1000_);
return v_res_1001_;
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00FormalSpecAgent_TypedMachine_nextTimer_spec__0(lean_object* v_x_1002_, lean_object* v_x_1003_){
_start:
{
if (lean_obj_tag(v_x_1003_) == 0)
{
return v_x_1002_;
}
else
{
if (lean_obj_tag(v_x_1002_) == 0)
{
lean_object* v_head_1004_; lean_object* v_tail_1005_; lean_object* v___x_1006_; 
v_head_1004_ = lean_ctor_get(v_x_1003_, 0);
v_tail_1005_ = lean_ctor_get(v_x_1003_, 1);
lean_inc(v_head_1004_);
v___x_1006_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1006_, 0, v_head_1004_);
v_x_1002_ = v___x_1006_;
v_x_1003_ = v_tail_1005_;
goto _start;
}
else
{
lean_object* v_head_1008_; lean_object* v_val_1009_; lean_object* v_tail_1010_; lean_object* v_timer_1011_; lean_object* v_due_1012_; lean_object* v_timer_1013_; lean_object* v_due_1014_; uint8_t v___x_1015_; 
v_head_1008_ = lean_ctor_get(v_x_1003_, 0);
v_val_1009_ = lean_ctor_get(v_x_1002_, 0);
v_tail_1010_ = lean_ctor_get(v_x_1003_, 1);
v_timer_1011_ = lean_ctor_get(v_head_1008_, 0);
v_due_1012_ = lean_ctor_get(v_head_1008_, 1);
v_timer_1013_ = lean_ctor_get(v_val_1009_, 0);
v_due_1014_ = lean_ctor_get(v_val_1009_, 1);
v___x_1015_ = lean_int_dec_lt(v_due_1012_, v_due_1014_);
if (v___x_1015_ == 0)
{
uint8_t v___x_1016_; 
v___x_1016_ = lean_int_dec_eq(v_due_1012_, v_due_1014_);
if (v___x_1016_ == 0)
{
v_x_1003_ = v_tail_1010_;
goto _start;
}
else
{
uint8_t v___x_1018_; 
v___x_1018_ = lean_nat_dec_lt(v_timer_1011_, v_timer_1013_);
if (v___x_1018_ == 0)
{
v_x_1003_ = v_tail_1010_;
goto _start;
}
else
{
lean_object* v___x_1021_; uint8_t v_isShared_1022_; uint8_t v_isSharedCheck_1027_; 
v_isSharedCheck_1027_ = !lean_is_exclusive(v_x_1002_);
if (v_isSharedCheck_1027_ == 0)
{
lean_object* v_unused_1028_; 
v_unused_1028_ = lean_ctor_get(v_x_1002_, 0);
lean_dec(v_unused_1028_);
v___x_1021_ = v_x_1002_;
v_isShared_1022_ = v_isSharedCheck_1027_;
goto v_resetjp_1020_;
}
else
{
lean_dec(v_x_1002_);
v___x_1021_ = lean_box(0);
v_isShared_1022_ = v_isSharedCheck_1027_;
goto v_resetjp_1020_;
}
v_resetjp_1020_:
{
lean_object* v___x_1024_; 
lean_inc(v_head_1008_);
if (v_isShared_1022_ == 0)
{
lean_ctor_set(v___x_1021_, 0, v_head_1008_);
v___x_1024_ = v___x_1021_;
goto v_reusejp_1023_;
}
else
{
lean_object* v_reuseFailAlloc_1026_; 
v_reuseFailAlloc_1026_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1026_, 0, v_head_1008_);
v___x_1024_ = v_reuseFailAlloc_1026_;
goto v_reusejp_1023_;
}
v_reusejp_1023_:
{
v_x_1002_ = v___x_1024_;
v_x_1003_ = v_tail_1010_;
goto _start;
}
}
}
}
}
else
{
lean_object* v___x_1030_; uint8_t v_isShared_1031_; uint8_t v_isSharedCheck_1036_; 
v_isSharedCheck_1036_ = !lean_is_exclusive(v_x_1002_);
if (v_isSharedCheck_1036_ == 0)
{
lean_object* v_unused_1037_; 
v_unused_1037_ = lean_ctor_get(v_x_1002_, 0);
lean_dec(v_unused_1037_);
v___x_1030_ = v_x_1002_;
v_isShared_1031_ = v_isSharedCheck_1036_;
goto v_resetjp_1029_;
}
else
{
lean_dec(v_x_1002_);
v___x_1030_ = lean_box(0);
v_isShared_1031_ = v_isSharedCheck_1036_;
goto v_resetjp_1029_;
}
v_resetjp_1029_:
{
lean_object* v___x_1033_; 
lean_inc(v_head_1008_);
if (v_isShared_1031_ == 0)
{
lean_ctor_set(v___x_1030_, 0, v_head_1008_);
v___x_1033_ = v___x_1030_;
goto v_reusejp_1032_;
}
else
{
lean_object* v_reuseFailAlloc_1035_; 
v_reuseFailAlloc_1035_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1035_, 0, v_head_1008_);
v___x_1033_ = v_reuseFailAlloc_1035_;
goto v_reusejp_1032_;
}
v_reusejp_1032_:
{
v_x_1002_ = v___x_1033_;
v_x_1003_ = v_tail_1010_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00FormalSpecAgent_TypedMachine_nextTimer_spec__0___boxed(lean_object* v_x_1038_, lean_object* v_x_1039_){
_start:
{
lean_object* v_res_1040_; 
v_res_1040_ = l_List_foldl___at___00FormalSpecAgent_TypedMachine_nextTimer_spec__0(v_x_1038_, v_x_1039_);
lean_dec(v_x_1039_);
return v_res_1040_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_nextTimer(lean_object* v_snapshot_1041_){
_start:
{
lean_object* v_timers_1042_; lean_object* v___x_1043_; lean_object* v___x_1044_; 
v_timers_1042_ = lean_ctor_get(v_snapshot_1041_, 3);
v___x_1043_ = lean_box(0);
v___x_1044_ = l_List_foldl___at___00FormalSpecAgent_TypedMachine_nextTimer_spec__0(v___x_1043_, v_timers_1042_);
return v___x_1044_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_nextTimer___boxed(lean_object* v_snapshot_1045_){
_start:
{
lean_object* v_res_1046_; 
v_res_1046_ = l_FormalSpecAgent_TypedMachine_nextTimer(v_snapshot_1045_);
lean_dec_ref(v_snapshot_1045_);
return v_res_1046_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_stepTimer(lean_object* v_model_1053_, lean_object* v_snapshot_1054_, lean_object* v_time_1055_){
_start:
{
lean_object* v_values_1056_; lean_object* v_state_1057_; lean_object* v_now_1058_; lean_object* v_timers_1059_; uint8_t v___x_1060_; 
v_values_1056_ = lean_ctor_get(v_snapshot_1054_, 0);
lean_inc_ref(v_values_1056_);
v_state_1057_ = lean_ctor_get(v_snapshot_1054_, 1);
lean_inc(v_state_1057_);
v_now_1058_ = lean_ctor_get(v_snapshot_1054_, 2);
v_timers_1059_ = lean_ctor_get(v_snapshot_1054_, 3);
lean_inc(v_timers_1059_);
v___x_1060_ = lean_int_dec_lt(v_time_1055_, v_now_1058_);
if (v___x_1060_ == 0)
{
lean_object* v___x_1061_; lean_object* v___x_1063_; uint8_t v_isShared_1064_; uint8_t v_isSharedCheck_1085_; 
v___x_1061_ = l_FormalSpecAgent_TypedMachine_nextTimer(v_snapshot_1054_);
v_isSharedCheck_1085_ = !lean_is_exclusive(v_snapshot_1054_);
if (v_isSharedCheck_1085_ == 0)
{
lean_object* v_unused_1086_; lean_object* v_unused_1087_; lean_object* v_unused_1088_; lean_object* v_unused_1089_; 
v_unused_1086_ = lean_ctor_get(v_snapshot_1054_, 3);
lean_dec(v_unused_1086_);
v_unused_1087_ = lean_ctor_get(v_snapshot_1054_, 2);
lean_dec(v_unused_1087_);
v_unused_1088_ = lean_ctor_get(v_snapshot_1054_, 1);
lean_dec(v_unused_1088_);
v_unused_1089_ = lean_ctor_get(v_snapshot_1054_, 0);
lean_dec(v_unused_1089_);
v___x_1063_ = v_snapshot_1054_;
v_isShared_1064_ = v_isSharedCheck_1085_;
goto v_resetjp_1062_;
}
else
{
lean_dec(v_snapshot_1054_);
v___x_1063_ = lean_box(0);
v_isShared_1064_ = v_isSharedCheck_1085_;
goto v_resetjp_1062_;
}
v_resetjp_1062_:
{
if (lean_obj_tag(v___x_1061_) == 0)
{
lean_object* v___x_1065_; 
lean_del_object(v___x_1063_);
lean_dec(v_timers_1059_);
lean_dec(v_state_1057_);
lean_dec_ref(v_values_1056_);
lean_dec(v_time_1055_);
lean_dec_ref(v_model_1053_);
v___x_1065_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_stepTimer___closed__0));
return v___x_1065_;
}
else
{
lean_object* v_val_1066_; lean_object* v___x_1068_; uint8_t v_isShared_1069_; uint8_t v_isSharedCheck_1084_; 
v_val_1066_ = lean_ctor_get(v___x_1061_, 0);
v_isSharedCheck_1084_ = !lean_is_exclusive(v___x_1061_);
if (v_isSharedCheck_1084_ == 0)
{
v___x_1068_ = v___x_1061_;
v_isShared_1069_ = v_isSharedCheck_1084_;
goto v_resetjp_1067_;
}
else
{
lean_inc(v_val_1066_);
lean_dec(v___x_1061_);
v___x_1068_ = lean_box(0);
v_isShared_1069_ = v_isSharedCheck_1084_;
goto v_resetjp_1067_;
}
v_resetjp_1067_:
{
lean_object* v_timer_1070_; lean_object* v_due_1071_; uint8_t v___x_1072_; 
v_timer_1070_ = lean_ctor_get(v_val_1066_, 0);
lean_inc(v_timer_1070_);
v_due_1071_ = lean_ctor_get(v_val_1066_, 1);
lean_inc(v_due_1071_);
lean_dec(v_val_1066_);
v___x_1072_ = lean_int_dec_eq(v_due_1071_, v_time_1055_);
lean_dec(v_due_1071_);
if (v___x_1072_ == 0)
{
lean_object* v___x_1073_; 
lean_dec(v_timer_1070_);
lean_del_object(v___x_1068_);
lean_del_object(v___x_1063_);
lean_dec(v_timers_1059_);
lean_dec(v_state_1057_);
lean_dec_ref(v_values_1056_);
lean_dec(v_time_1055_);
lean_dec_ref(v_model_1053_);
v___x_1073_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_stepTimer___closed__1));
return v___x_1073_;
}
else
{
lean_object* v_timerEvents_1074_; lean_object* v_event_1075_; lean_object* v___x_1077_; 
v_timerEvents_1074_ = lean_ctor_get(v_model_1053_, 2);
lean_inc_ref(v_timerEvents_1074_);
lean_inc(v_timer_1070_);
v_event_1075_ = lean_apply_1(v_timerEvents_1074_, v_timer_1070_);
if (v_isShared_1064_ == 0)
{
lean_ctor_set(v___x_1063_, 2, v_time_1055_);
v___x_1077_ = v___x_1063_;
goto v_reusejp_1076_;
}
else
{
lean_object* v_reuseFailAlloc_1083_; 
v_reuseFailAlloc_1083_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_1083_, 0, v_values_1056_);
lean_ctor_set(v_reuseFailAlloc_1083_, 1, v_state_1057_);
lean_ctor_set(v_reuseFailAlloc_1083_, 2, v_time_1055_);
lean_ctor_set(v_reuseFailAlloc_1083_, 3, v_timers_1059_);
v___x_1077_ = v_reuseFailAlloc_1083_;
goto v_reusejp_1076_;
}
v_reusejp_1076_:
{
lean_object* v___x_1078_; lean_object* v___x_1080_; 
v___x_1078_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_zeroValues));
if (v_isShared_1069_ == 0)
{
lean_ctor_set(v___x_1068_, 0, v_timer_1070_);
v___x_1080_ = v___x_1068_;
goto v_reusejp_1079_;
}
else
{
lean_object* v_reuseFailAlloc_1082_; 
v_reuseFailAlloc_1082_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1082_, 0, v_timer_1070_);
v___x_1080_ = v_reuseFailAlloc_1082_;
goto v_reusejp_1079_;
}
v_reusejp_1079_:
{
lean_object* v___x_1081_; 
v___x_1081_ = l_FormalSpecAgent_TypedMachine_fire(v_model_1053_, v___x_1077_, v_event_1075_, v___x_1078_, v___x_1080_);
lean_dec_ref(v___x_1080_);
return v___x_1081_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_1090_; 
lean_dec(v_timers_1059_);
lean_dec(v_state_1057_);
lean_dec_ref(v_values_1056_);
lean_dec(v_time_1055_);
lean_dec_ref(v_snapshot_1054_);
lean_dec_ref(v_model_1053_);
v___x_1090_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_stepTimer___closed__1));
return v___x_1090_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_external(lean_object* v_model_1097_, lean_object* v_snapshot_1098_, lean_object* v_event_1099_, lean_object* v_fields_1100_, lean_object* v_time_1101_){
_start:
{
lean_object* v_values_1102_; lean_object* v_state_1103_; lean_object* v_now_1104_; lean_object* v_timers_1105_; uint8_t v___x_1110_; 
v_values_1102_ = lean_ctor_get(v_snapshot_1098_, 0);
v_state_1103_ = lean_ctor_get(v_snapshot_1098_, 1);
v_now_1104_ = lean_ctor_get(v_snapshot_1098_, 2);
v_timers_1105_ = lean_ctor_get(v_snapshot_1098_, 3);
v___x_1110_ = lean_int_dec_lt(v_time_1101_, v_now_1104_);
if (v___x_1110_ == 0)
{
lean_object* v_externalEvents_1111_; uint8_t v___x_1112_; 
v_externalEvents_1111_ = lean_ctor_get(v_model_1097_, 3);
v___x_1112_ = l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(v_event_1099_, v_externalEvents_1111_);
if (v___x_1112_ == 0)
{
lean_object* v___x_1113_; 
lean_dec(v_time_1101_);
lean_dec_ref(v_fields_1100_);
lean_dec(v_event_1099_);
lean_dec_ref(v_model_1097_);
v___x_1113_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_external___closed__0));
return v___x_1113_;
}
else
{
lean_object* v___x_1114_; 
v___x_1114_ = l_FormalSpecAgent_TypedMachine_nextTimer(v_snapshot_1098_);
if (lean_obj_tag(v___x_1114_) == 0)
{
goto v___jp_1106_;
}
else
{
lean_object* v_val_1115_; lean_object* v_due_1116_; uint8_t v___x_1117_; 
v_val_1115_ = lean_ctor_get(v___x_1114_, 0);
lean_inc(v_val_1115_);
lean_dec_ref_known(v___x_1114_, 1);
v_due_1116_ = lean_ctor_get(v_val_1115_, 1);
lean_inc(v_due_1116_);
lean_dec(v_val_1115_);
v___x_1117_ = lean_int_dec_le(v_due_1116_, v_time_1101_);
lean_dec(v_due_1116_);
if (v___x_1117_ == 0)
{
goto v___jp_1106_;
}
else
{
lean_object* v___x_1118_; 
lean_dec(v_time_1101_);
lean_dec_ref(v_fields_1100_);
lean_dec(v_event_1099_);
lean_dec_ref(v_model_1097_);
v___x_1118_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_external___closed__1));
return v___x_1118_;
}
}
}
}
else
{
lean_object* v___x_1119_; 
lean_dec(v_time_1101_);
lean_dec_ref(v_fields_1100_);
lean_dec(v_event_1099_);
lean_dec_ref(v_model_1097_);
v___x_1119_ = ((lean_object*)(l_FormalSpecAgent_TypedMachine_stepTimer___closed__1));
return v___x_1119_;
}
v___jp_1106_:
{
lean_object* v___x_1107_; lean_object* v___x_1108_; lean_object* v___x_1109_; 
lean_inc(v_timers_1105_);
lean_inc(v_state_1103_);
lean_inc_ref(v_values_1102_);
v___x_1107_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_1107_, 0, v_values_1102_);
lean_ctor_set(v___x_1107_, 1, v_state_1103_);
lean_ctor_set(v___x_1107_, 2, v_time_1101_);
lean_ctor_set(v___x_1107_, 3, v_timers_1105_);
v___x_1108_ = lean_box(0);
v___x_1109_ = l_FormalSpecAgent_TypedMachine_fire(v_model_1097_, v___x_1107_, v_event_1099_, v_fields_1100_, v___x_1108_);
return v___x_1109_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_external___boxed(lean_object* v_model_1120_, lean_object* v_snapshot_1121_, lean_object* v_event_1122_, lean_object* v_fields_1123_, lean_object* v_time_1124_){
_start:
{
lean_object* v_res_1125_; 
v_res_1125_ = l_FormalSpecAgent_TypedMachine_external(v_model_1120_, v_snapshot_1121_, v_event_1122_, v_fields_1123_, v_time_1124_);
lean_dec_ref(v_snapshot_1121_);
return v_res_1125_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_rollback(lean_object* v_initial_1126_, lean_object* v_result_1127_){
_start:
{
if (lean_obj_tag(v_result_1127_) == 0)
{
lean_inc_ref(v_initial_1126_);
return v_initial_1126_;
}
else
{
lean_object* v_a_1128_; lean_object* v_after_1129_; 
v_a_1128_ = lean_ctor_get(v_result_1127_, 0);
v_after_1129_ = lean_ctor_get(v_a_1128_, 0);
lean_inc_ref(v_after_1129_);
return v_after_1129_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedMachine_rollback___boxed(lean_object* v_initial_1130_, lean_object* v_result_1131_){
_start:
{
lean_object* v_res_1132_; 
v_res_1132_ = l_FormalSpecAgent_TypedMachine_rollback(v_initial_1130_, v_result_1131_);
lean_dec_ref(v_result_1131_);
lean_dec_ref(v_initial_1130_);
return v_res_1132_;
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter___redArg(uint8_t v_k_1133_, lean_object* v_v_1134_, lean_object* v_h__1_1135_, lean_object* v_h__2_1136_, lean_object* v_h__3_1137_, lean_object* v_h__4_1138_, lean_object* v_h__5_1139_){
_start:
{
switch(v_k_1133_)
{
case 0:
{
lean_object* v___x_1140_; 
lean_dec(v_h__5_1139_);
lean_dec(v_h__4_1138_);
lean_dec(v_h__3_1137_);
lean_dec(v_h__2_1136_);
v___x_1140_ = lean_apply_1(v_h__1_1135_, v_v_1134_);
return v___x_1140_;
}
case 1:
{
lean_object* v___x_1141_; 
lean_dec(v_h__5_1139_);
lean_dec(v_h__4_1138_);
lean_dec(v_h__3_1137_);
lean_dec(v_h__1_1135_);
v___x_1141_ = lean_apply_1(v_h__2_1136_, v_v_1134_);
return v___x_1141_;
}
case 2:
{
lean_object* v___x_1142_; 
lean_dec(v_h__5_1139_);
lean_dec(v_h__4_1138_);
lean_dec(v_h__2_1136_);
lean_dec(v_h__1_1135_);
v___x_1142_ = lean_apply_1(v_h__3_1137_, v_v_1134_);
return v___x_1142_;
}
case 3:
{
lean_object* v___x_1143_; 
lean_dec(v_h__5_1139_);
lean_dec(v_h__3_1137_);
lean_dec(v_h__2_1136_);
lean_dec(v_h__1_1135_);
v___x_1143_ = lean_apply_1(v_h__4_1138_, v_v_1134_);
return v___x_1143_;
}
default: 
{
lean_object* v___x_1144_; 
lean_dec(v_h__4_1138_);
lean_dec(v_h__3_1137_);
lean_dec(v_h__2_1136_);
lean_dec(v_h__1_1135_);
v___x_1144_ = lean_apply_1(v_h__5_1139_, v_v_1134_);
return v___x_1144_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter___redArg___boxed(lean_object* v_k_1145_, lean_object* v_v_1146_, lean_object* v_h__1_1147_, lean_object* v_h__2_1148_, lean_object* v_h__3_1149_, lean_object* v_h__4_1150_, lean_object* v_h__5_1151_){
_start:
{
uint8_t v_k_68__boxed_1152_; lean_object* v_res_1153_; 
v_k_68__boxed_1152_ = lean_unbox(v_k_1145_);
v_res_1153_ = l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter___redArg(v_k_68__boxed_1152_, v_v_1146_, v_h__1_1147_, v_h__2_1148_, v_h__3_1149_, v_h__4_1150_, v_h__5_1151_);
return v_res_1153_;
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter(lean_object* v_motive_1154_, uint8_t v_k_1155_, lean_object* v_v_1156_, lean_object* v_h__1_1157_, lean_object* v_h__2_1158_, lean_object* v_h__3_1159_, lean_object* v_h__4_1160_, lean_object* v_h__5_1161_){
_start:
{
switch(v_k_1155_)
{
case 0:
{
lean_object* v___x_1162_; 
lean_dec(v_h__5_1161_);
lean_dec(v_h__4_1160_);
lean_dec(v_h__3_1159_);
lean_dec(v_h__2_1158_);
v___x_1162_ = lean_apply_1(v_h__1_1157_, v_v_1156_);
return v___x_1162_;
}
case 1:
{
lean_object* v___x_1163_; 
lean_dec(v_h__5_1161_);
lean_dec(v_h__4_1160_);
lean_dec(v_h__3_1159_);
lean_dec(v_h__1_1157_);
v___x_1163_ = lean_apply_1(v_h__2_1158_, v_v_1156_);
return v___x_1163_;
}
case 2:
{
lean_object* v___x_1164_; 
lean_dec(v_h__5_1161_);
lean_dec(v_h__4_1160_);
lean_dec(v_h__2_1158_);
lean_dec(v_h__1_1157_);
v___x_1164_ = lean_apply_1(v_h__3_1159_, v_v_1156_);
return v___x_1164_;
}
case 3:
{
lean_object* v___x_1165_; 
lean_dec(v_h__5_1161_);
lean_dec(v_h__3_1159_);
lean_dec(v_h__2_1158_);
lean_dec(v_h__1_1157_);
v___x_1165_ = lean_apply_1(v_h__4_1160_, v_v_1156_);
return v___x_1165_;
}
default: 
{
lean_object* v___x_1166_; 
lean_dec(v_h__4_1160_);
lean_dec(v_h__3_1159_);
lean_dec(v_h__2_1158_);
lean_dec(v_h__1_1157_);
v___x_1166_ = lean_apply_1(v_h__5_1161_, v_v_1156_);
return v___x_1166_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter___boxed(lean_object* v_motive_1167_, lean_object* v_k_1168_, lean_object* v_v_1169_, lean_object* v_h__1_1170_, lean_object* v_h__2_1171_, lean_object* v_h__3_1172_, lean_object* v_h__4_1173_, lean_object* v_h__5_1174_){
_start:
{
uint8_t v_k_81__boxed_1175_; lean_object* v_res_1176_; 
v_k_81__boxed_1175_ = lean_unbox(v_k_1168_);
v_res_1176_ = l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_setValue_match__1_splitter(v_motive_1167_, v_k_81__boxed_1175_, v_v_1169_, v_h__1_1170_, v_h__2_1171_, v_h__3_1172_, v_h__4_1173_, v_h__5_1174_);
return v_res_1176_;
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter___redArg(uint8_t v_x_1177_, lean_object* v_h__1_1178_, lean_object* v_h__2_1179_, lean_object* v_h__3_1180_, lean_object* v_h__4_1181_, lean_object* v_h__5_1182_){
_start:
{
switch(v_x_1177_)
{
case 0:
{
lean_object* v___x_1183_; lean_object* v___x_1184_; 
lean_dec(v_h__5_1182_);
lean_dec(v_h__4_1181_);
lean_dec(v_h__3_1180_);
lean_dec(v_h__2_1179_);
v___x_1183_ = lean_box(0);
v___x_1184_ = lean_apply_1(v_h__1_1178_, v___x_1183_);
return v___x_1184_;
}
case 1:
{
lean_object* v___x_1185_; lean_object* v___x_1186_; 
lean_dec(v_h__5_1182_);
lean_dec(v_h__4_1181_);
lean_dec(v_h__3_1180_);
lean_dec(v_h__1_1178_);
v___x_1185_ = lean_box(0);
v___x_1186_ = lean_apply_1(v_h__2_1179_, v___x_1185_);
return v___x_1186_;
}
case 2:
{
lean_object* v___x_1187_; lean_object* v___x_1188_; 
lean_dec(v_h__5_1182_);
lean_dec(v_h__4_1181_);
lean_dec(v_h__2_1179_);
lean_dec(v_h__1_1178_);
v___x_1187_ = lean_box(0);
v___x_1188_ = lean_apply_1(v_h__3_1180_, v___x_1187_);
return v___x_1188_;
}
case 3:
{
lean_object* v___x_1189_; lean_object* v___x_1190_; 
lean_dec(v_h__5_1182_);
lean_dec(v_h__3_1180_);
lean_dec(v_h__2_1179_);
lean_dec(v_h__1_1178_);
v___x_1189_ = lean_box(0);
v___x_1190_ = lean_apply_1(v_h__4_1181_, v___x_1189_);
return v___x_1190_;
}
default: 
{
lean_object* v___x_1191_; lean_object* v___x_1192_; 
lean_dec(v_h__4_1181_);
lean_dec(v_h__3_1180_);
lean_dec(v_h__2_1179_);
lean_dec(v_h__1_1178_);
v___x_1191_ = lean_box(0);
v___x_1192_ = lean_apply_1(v_h__5_1182_, v___x_1191_);
return v___x_1192_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter___redArg___boxed(lean_object* v_x_1193_, lean_object* v_h__1_1194_, lean_object* v_h__2_1195_, lean_object* v_h__3_1196_, lean_object* v_h__4_1197_, lean_object* v_h__5_1198_){
_start:
{
uint8_t v_x_51__boxed_1199_; lean_object* v_res_1200_; 
v_x_51__boxed_1199_ = lean_unbox(v_x_1193_);
v_res_1200_ = l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter___redArg(v_x_51__boxed_1199_, v_h__1_1194_, v_h__2_1195_, v_h__3_1196_, v_h__4_1197_, v_h__5_1198_);
return v_res_1200_;
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter(lean_object* v_motive_1201_, uint8_t v_x_1202_, lean_object* v_h__1_1203_, lean_object* v_h__2_1204_, lean_object* v_h__3_1205_, lean_object* v_h__4_1206_, lean_object* v_h__5_1207_){
_start:
{
switch(v_x_1202_)
{
case 0:
{
lean_object* v___x_1208_; lean_object* v___x_1209_; 
lean_dec(v_h__5_1207_);
lean_dec(v_h__4_1206_);
lean_dec(v_h__3_1205_);
lean_dec(v_h__2_1204_);
v___x_1208_ = lean_box(0);
v___x_1209_ = lean_apply_1(v_h__1_1203_, v___x_1208_);
return v___x_1209_;
}
case 1:
{
lean_object* v___x_1210_; lean_object* v___x_1211_; 
lean_dec(v_h__5_1207_);
lean_dec(v_h__4_1206_);
lean_dec(v_h__3_1205_);
lean_dec(v_h__1_1203_);
v___x_1210_ = lean_box(0);
v___x_1211_ = lean_apply_1(v_h__2_1204_, v___x_1210_);
return v___x_1211_;
}
case 2:
{
lean_object* v___x_1212_; lean_object* v___x_1213_; 
lean_dec(v_h__5_1207_);
lean_dec(v_h__4_1206_);
lean_dec(v_h__2_1204_);
lean_dec(v_h__1_1203_);
v___x_1212_ = lean_box(0);
v___x_1213_ = lean_apply_1(v_h__3_1205_, v___x_1212_);
return v___x_1213_;
}
case 3:
{
lean_object* v___x_1214_; lean_object* v___x_1215_; 
lean_dec(v_h__5_1207_);
lean_dec(v_h__3_1205_);
lean_dec(v_h__2_1204_);
lean_dec(v_h__1_1203_);
v___x_1214_ = lean_box(0);
v___x_1215_ = lean_apply_1(v_h__4_1206_, v___x_1214_);
return v___x_1215_;
}
default: 
{
lean_object* v___x_1216_; lean_object* v___x_1217_; 
lean_dec(v_h__4_1206_);
lean_dec(v_h__3_1205_);
lean_dec(v_h__2_1204_);
lean_dec(v_h__1_1203_);
v___x_1216_ = lean_box(0);
v___x_1217_ = lean_apply_1(v_h__5_1207_, v___x_1216_);
return v___x_1217_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter___boxed(lean_object* v_motive_1218_, lean_object* v_x_1219_, lean_object* v_h__1_1220_, lean_object* v_h__2_1221_, lean_object* v_h__3_1222_, lean_object* v_h__4_1223_, lean_object* v_h__5_1224_){
_start:
{
uint8_t v_x_74__boxed_1225_; lean_object* v_res_1226_; 
v_x_74__boxed_1225_ = lean_unbox(v_x_1219_);
v_res_1226_ = l___private_TypedMachine_0__FormalSpecAgent_TypedIR_Value_match__1_splitter(v_motive_1218_, v_x_74__boxed_1225_, v_h__1_1220_, v_h__2_1221_, v_h__3_1222_, v_h__4_1223_, v_h__5_1224_);
return v_res_1226_;
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_rollback_match__1_splitter___redArg(lean_object* v_result_1227_, lean_object* v_h__1_1228_, lean_object* v_h__2_1229_){
_start:
{
if (lean_obj_tag(v_result_1227_) == 0)
{
lean_object* v_a_1230_; lean_object* v___x_1231_; 
lean_dec(v_h__1_1228_);
v_a_1230_ = lean_ctor_get(v_result_1227_, 0);
lean_inc(v_a_1230_);
lean_dec_ref_known(v_result_1227_, 1);
v___x_1231_ = lean_apply_1(v_h__2_1229_, v_a_1230_);
return v___x_1231_;
}
else
{
lean_object* v_a_1232_; lean_object* v___x_1233_; 
lean_dec(v_h__2_1229_);
v_a_1232_ = lean_ctor_get(v_result_1227_, 0);
lean_inc(v_a_1232_);
lean_dec_ref_known(v_result_1227_, 1);
v___x_1233_ = lean_apply_1(v_h__1_1228_, v_a_1232_);
return v___x_1233_;
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_rollback_match__1_splitter(lean_object* v_motive_1234_, lean_object* v_result_1235_, lean_object* v_h__1_1236_, lean_object* v_h__2_1237_){
_start:
{
if (lean_obj_tag(v_result_1235_) == 0)
{
lean_object* v_a_1238_; lean_object* v___x_1239_; 
lean_dec(v_h__1_1236_);
v_a_1238_ = lean_ctor_get(v_result_1235_, 0);
lean_inc(v_a_1238_);
lean_dec_ref_known(v_result_1235_, 1);
v___x_1239_ = lean_apply_1(v_h__2_1237_, v_a_1238_);
return v___x_1239_;
}
else
{
lean_object* v_a_1240_; lean_object* v___x_1241_; 
lean_dec(v_h__2_1237_);
v_a_1240_ = lean_ctor_get(v_result_1235_, 0);
lean_inc(v_a_1240_);
lean_dec_ref_known(v_result_1235_, 1);
v___x_1241_ = lean_apply_1(v_h__1_1236_, v_a_1240_);
return v___x_1241_;
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter___redArg(lean_object* v_x_1242_, lean_object* v_h__1_1243_, lean_object* v_h__2_1244_){
_start:
{
if (lean_obj_tag(v_x_1242_) == 0)
{
lean_object* v_a_1245_; lean_object* v___x_1246_; 
lean_dec(v_h__2_1244_);
v_a_1245_ = lean_ctor_get(v_x_1242_, 0);
lean_inc(v_a_1245_);
lean_dec_ref_known(v_x_1242_, 1);
v___x_1246_ = lean_apply_1(v_h__1_1243_, v_a_1245_);
return v___x_1246_;
}
else
{
lean_object* v_a_1247_; lean_object* v_fst_1248_; lean_object* v_snd_1249_; lean_object* v___x_1250_; 
lean_dec(v_h__1_1243_);
v_a_1247_ = lean_ctor_get(v_x_1242_, 0);
lean_inc(v_a_1247_);
lean_dec_ref_known(v_x_1242_, 1);
v_fst_1248_ = lean_ctor_get(v_a_1247_, 0);
lean_inc(v_fst_1248_);
v_snd_1249_ = lean_ctor_get(v_a_1247_, 1);
lean_inc(v_snd_1249_);
lean_dec(v_a_1247_);
v___x_1250_ = lean_apply_2(v_h__2_1244_, v_fst_1248_, v_snd_1249_);
return v___x_1250_;
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_runRule_match__1_splitter(lean_object* v_motive_1251_, lean_object* v_x_1252_, lean_object* v_h__1_1253_, lean_object* v_h__2_1254_){
_start:
{
if (lean_obj_tag(v_x_1252_) == 0)
{
lean_object* v_a_1255_; lean_object* v___x_1256_; 
lean_dec(v_h__2_1254_);
v_a_1255_ = lean_ctor_get(v_x_1252_, 0);
lean_inc(v_a_1255_);
lean_dec_ref_known(v_x_1252_, 1);
v___x_1256_ = lean_apply_1(v_h__1_1253_, v_a_1255_);
return v___x_1256_;
}
else
{
lean_object* v_a_1257_; lean_object* v_fst_1258_; lean_object* v_snd_1259_; lean_object* v___x_1260_; 
lean_dec(v_h__1_1253_);
v_a_1257_ = lean_ctor_get(v_x_1252_, 0);
lean_inc(v_a_1257_);
lean_dec_ref_known(v_x_1252_, 1);
v_fst_1258_ = lean_ctor_get(v_a_1257_, 0);
lean_inc(v_fst_1258_);
v_snd_1259_ = lean_ctor_get(v_a_1257_, 1);
lean_inc(v_snd_1259_);
lean_dec(v_a_1257_);
v___x_1260_ = lean_apply_2(v_h__2_1254_, v_fst_1258_, v_snd_1259_);
return v___x_1260_;
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter___redArg(lean_object* v_x_1261_, lean_object* v_h__1_1262_, lean_object* v_h__2_1263_, lean_object* v_h__3_1264_){
_start:
{
if (lean_obj_tag(v_x_1261_) == 0)
{
lean_object* v___x_1265_; lean_object* v___x_1266_; 
lean_dec(v_h__3_1264_);
lean_dec(v_h__2_1263_);
v___x_1265_ = lean_box(0);
v___x_1266_ = lean_apply_1(v_h__1_1262_, v___x_1265_);
return v___x_1266_;
}
else
{
lean_object* v_tail_1267_; 
lean_dec(v_h__1_1262_);
v_tail_1267_ = lean_ctor_get(v_x_1261_, 1);
if (lean_obj_tag(v_tail_1267_) == 0)
{
lean_object* v_head_1268_; lean_object* v___x_1269_; 
lean_dec(v_h__3_1264_);
v_head_1268_ = lean_ctor_get(v_x_1261_, 0);
lean_inc(v_head_1268_);
lean_dec_ref_known(v_x_1261_, 2);
v___x_1269_ = lean_apply_1(v_h__2_1263_, v_head_1268_);
return v___x_1269_;
}
else
{
lean_object* v___x_1270_; 
lean_dec(v_h__2_1263_);
v___x_1270_ = lean_apply_3(v_h__3_1264_, v_x_1261_, lean_box(0), lean_box(0));
return v___x_1270_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_TypedMachine_0__FormalSpecAgent_TypedMachine_fire_match__1_splitter(lean_object* v_motive_1271_, lean_object* v_x_1272_, lean_object* v_h__1_1273_, lean_object* v_h__2_1274_, lean_object* v_h__3_1275_){
_start:
{
if (lean_obj_tag(v_x_1272_) == 0)
{
lean_object* v___x_1276_; lean_object* v___x_1277_; 
lean_dec(v_h__3_1275_);
lean_dec(v_h__2_1274_);
v___x_1276_ = lean_box(0);
v___x_1277_ = lean_apply_1(v_h__1_1273_, v___x_1276_);
return v___x_1277_;
}
else
{
lean_object* v_tail_1278_; 
lean_dec(v_h__1_1273_);
v_tail_1278_ = lean_ctor_get(v_x_1272_, 1);
if (lean_obj_tag(v_tail_1278_) == 0)
{
lean_object* v_head_1279_; lean_object* v___x_1280_; 
lean_dec(v_h__3_1275_);
v_head_1279_ = lean_ctor_get(v_x_1272_, 0);
lean_inc(v_head_1279_);
lean_dec_ref_known(v_x_1272_, 2);
v___x_1280_ = lean_apply_1(v_h__2_1274_, v_head_1279_);
return v___x_1280_;
}
else
{
lean_object* v___x_1281_; 
lean_dec(v_h__2_1274_);
v___x_1281_ = lean_apply_3(v_h__3_1275_, v_x_1272_, lean_box(0), lean_box(0));
return v___x_1281_;
}
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TypedIR(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_TypedMachine(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TypedIR(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
