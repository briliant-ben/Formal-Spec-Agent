// Lean compiler output
// Module: ModelMachine
// Imports: public import Init public meta import Init public import MachineObserve
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_string_mk(lean_object*);
lean_object* lean_int_neg(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
static lean_once_cell_t l_MachineRuntime_e0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e0___closed__0;
static lean_once_cell_t l_MachineRuntime_e0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e0___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e0;
static const lean_ctor_object l_MachineRuntime_e1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e1___closed__0 = (const lean_object*)&l_MachineRuntime_e1___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e1 = (const lean_object*)&l_MachineRuntime_e1___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e2___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e2;
static const lean_ctor_object l_MachineRuntime_e3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e3___closed__0 = (const lean_object*)&l_MachineRuntime_e3___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e3 = (const lean_object*)&l_MachineRuntime_e3___closed__0_value;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__0___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__1___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__2___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__2;
static lean_once_cell_t l_MachineRuntime_e4___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__3;
LEAN_EXPORT lean_object* l_MachineRuntime_e4___closed__4___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e4___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__4;
static lean_once_cell_t l_MachineRuntime_e4___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__5;
static lean_once_cell_t l_MachineRuntime_e4___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e4___closed__6;
LEAN_EXPORT lean_object* l_MachineRuntime_e4;
static const lean_ctor_object l_MachineRuntime_e5___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e5___closed__0 = (const lean_object*)&l_MachineRuntime_e5___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e5 = (const lean_object*)&l_MachineRuntime_e5___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e6___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e6___closed__0 = (const lean_object*)&l_MachineRuntime_e6___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e6 = (const lean_object*)&l_MachineRuntime_e6___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e7___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e7___closed__0;
static lean_once_cell_t l_MachineRuntime_e7___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e7___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e7;
static const lean_ctor_object l_MachineRuntime_e8___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e8___closed__0 = (const lean_object*)&l_MachineRuntime_e8___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e8 = (const lean_object*)&l_MachineRuntime_e8___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e9___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e9___closed__0;
static lean_once_cell_t l_MachineRuntime_e9___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e9___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e9;
static lean_once_cell_t l_MachineRuntime_e10___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e10___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e10;
static const lean_ctor_object l_MachineRuntime_e11___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e11___closed__0 = (const lean_object*)&l_MachineRuntime_e11___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e11 = (const lean_object*)&l_MachineRuntime_e11___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e12___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e12___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e12;
LEAN_EXPORT lean_object* l_MachineRuntime_e13___closed__0___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e13___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e13___closed__1___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e13___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e13___closed__2___boxed__const__1;
static lean_once_cell_t l_MachineRuntime_e13___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__2;
static lean_once_cell_t l_MachineRuntime_e13___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__3;
static lean_once_cell_t l_MachineRuntime_e13___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e13___closed__4;
LEAN_EXPORT lean_object* l_MachineRuntime_e13;
static const lean_ctor_object l_MachineRuntime_e14___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e14___closed__0 = (const lean_object*)&l_MachineRuntime_e14___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e14 = (const lean_object*)&l_MachineRuntime_e14___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e15___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e15___closed__0 = (const lean_object*)&l_MachineRuntime_e15___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e15 = (const lean_object*)&l_MachineRuntime_e15___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e16___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e16___closed__0 = (const lean_object*)&l_MachineRuntime_e16___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e16 = (const lean_object*)&l_MachineRuntime_e16___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e17___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_e17___closed__0 = (const lean_object*)&l_MachineRuntime_e17___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e17 = (const lean_object*)&l_MachineRuntime_e17___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e18___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 4}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_e18___closed__0 = (const lean_object*)&l_MachineRuntime_e18___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e18 = (const lean_object*)&l_MachineRuntime_e18___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e19___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 4}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_MachineRuntime_e19___closed__0 = (const lean_object*)&l_MachineRuntime_e19___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e19 = (const lean_object*)&l_MachineRuntime_e19___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e20___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e20___closed__0;
static lean_once_cell_t l_MachineRuntime_e20___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e20___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e20;
static lean_once_cell_t l_MachineRuntime_e21___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e21___closed__0;
static lean_once_cell_t l_MachineRuntime_e21___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e21___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e21;
static const lean_ctor_object l_MachineRuntime_e22___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e22___closed__0 = (const lean_object*)&l_MachineRuntime_e22___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e22 = (const lean_object*)&l_MachineRuntime_e22___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e23___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e23___closed__0;
static lean_once_cell_t l_MachineRuntime_e23___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e23___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e23;
static lean_once_cell_t l_MachineRuntime_e24___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e24___closed__0;
static lean_once_cell_t l_MachineRuntime_e24___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e24___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e24;
static lean_once_cell_t l_MachineRuntime_e25___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e25___closed__0;
static lean_once_cell_t l_MachineRuntime_e25___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e25___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e25;
static lean_once_cell_t l_MachineRuntime_e26___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e26___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e26;
static const lean_ctor_object l_MachineRuntime_e27___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 23}, .m_objs = {((lean_object*)&l_MachineRuntime_e15___closed__0_value)}};
static const lean_object* l_MachineRuntime_e27___closed__0 = (const lean_object*)&l_MachineRuntime_e27___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e27 = (const lean_object*)&l_MachineRuntime_e27___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e28___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e28___closed__0;
static lean_once_cell_t l_MachineRuntime_e28___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e28___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e28;
static lean_once_cell_t l_MachineRuntime_e29___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e29___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e29;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_e6___closed__0_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__0 = (const lean_object*)&l_MachineRuntime_rule__0___closed__0_value;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__1;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__2;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__3 = (const lean_object*)&l_MachineRuntime_rule__0___closed__3_value;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__5;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_e8___closed__0_value),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__6 = (const lean_object*)&l_MachineRuntime_rule__0___closed__6_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_e14___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__7 = (const lean_object*)&l_MachineRuntime_rule__0___closed__7_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_MachineRuntime_e11___closed__0_value),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__8 = (const lean_object*)&l_MachineRuntime_rule__0___closed__8_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_e15___closed__0_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__9 = (const lean_object*)&l_MachineRuntime_rule__0___closed__9_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e16___closed__0_value),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__10 = (const lean_object*)&l_MachineRuntime_rule__0___closed__10_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)&l_MachineRuntime_e17___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__11 = (const lean_object*)&l_MachineRuntime_rule__0___closed__11_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(6) << 1) | 1)),((lean_object*)&l_MachineRuntime_e18___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__12 = (const lean_object*)&l_MachineRuntime_rule__0___closed__12_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)&l_MachineRuntime_e19___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__13 = (const lean_object*)&l_MachineRuntime_rule__0___closed__13_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__13_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__0___closed__14 = (const lean_object*)&l_MachineRuntime_rule__0___closed__14_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__12_value),((lean_object*)&l_MachineRuntime_rule__0___closed__14_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__15 = (const lean_object*)&l_MachineRuntime_rule__0___closed__15_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__11_value),((lean_object*)&l_MachineRuntime_rule__0___closed__15_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__16 = (const lean_object*)&l_MachineRuntime_rule__0___closed__16_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__10_value),((lean_object*)&l_MachineRuntime_rule__0___closed__16_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__17 = (const lean_object*)&l_MachineRuntime_rule__0___closed__17_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__9_value),((lean_object*)&l_MachineRuntime_rule__0___closed__17_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__18 = (const lean_object*)&l_MachineRuntime_rule__0___closed__18_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__8_value),((lean_object*)&l_MachineRuntime_rule__0___closed__18_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__19 = (const lean_object*)&l_MachineRuntime_rule__0___closed__19_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__7_value),((lean_object*)&l_MachineRuntime_rule__0___closed__19_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__20 = (const lean_object*)&l_MachineRuntime_rule__0___closed__20_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__6_value),((lean_object*)&l_MachineRuntime_rule__0___closed__20_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__21 = (const lean_object*)&l_MachineRuntime_rule__0___closed__21_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_rule__0___closed__21_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__22 = (const lean_object*)&l_MachineRuntime_rule__0___closed__22_value;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__23_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__23;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__24_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__24;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__25;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__26;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__27_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__27;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__28;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__29;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__30;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__31;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__32_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__32;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__33_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__33;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__34_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__34;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__0;
static lean_once_cell_t l_MachineRuntime_rule__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__1___closed__0;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_e22___closed__0_value)}};
static const lean_object* l_MachineRuntime_rule__1___closed__1 = (const lean_object*)&l_MachineRuntime_rule__1___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__1___closed__1_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__1___closed__2 = (const lean_object*)&l_MachineRuntime_rule__1___closed__2_value;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__22_value),((lean_object*)&l_MachineRuntime_rule__1___closed__2_value)}};
static const lean_object* l_MachineRuntime_rule__1___closed__3 = (const lean_object*)&l_MachineRuntime_rule__1___closed__3_value;
static lean_once_cell_t l_MachineRuntime_rule__1___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__1___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__1___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__1___closed__5;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__1;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__0;
static const lean_ctor_object l_MachineRuntime_rule__2___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__22_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__2___closed__1 = (const lean_object*)&l_MachineRuntime_rule__2___closed__1_value;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__2;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__3;
static lean_once_cell_t l_MachineRuntime_rule__2___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__2___closed__4;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__2;
static lean_once_cell_t l_MachineRuntime_rule__3___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__3___closed__0;
static lean_once_cell_t l_MachineRuntime_rule__3___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__3___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__3;
static const lean_ctor_object l_MachineRuntime_rule__4___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__4___closed__0 = (const lean_object*)&l_MachineRuntime_rule__4___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__4___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__4___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__4___closed__1 = (const lean_object*)&l_MachineRuntime_rule__4___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__4___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__22_value),((lean_object*)&l_MachineRuntime_rule__4___closed__1_value)}};
static const lean_object* l_MachineRuntime_rule__4___closed__2 = (const lean_object*)&l_MachineRuntime_rule__4___closed__2_value;
static lean_once_cell_t l_MachineRuntime_rule__4___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__4___closed__3;
static lean_once_cell_t l_MachineRuntime_rule__4___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__4___closed__4;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__4;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__0;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__1;
static const lean_ctor_object l_MachineRuntime_rule__5___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__5___closed__2 = (const lean_object*)&l_MachineRuntime_rule__5___closed__2_value;
static const lean_ctor_object l_MachineRuntime_rule__5___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__5___closed__2_value),((lean_object*)&l_MachineRuntime_rule__2___closed__1_value)}};
static const lean_object* l_MachineRuntime_rule__5___closed__3 = (const lean_object*)&l_MachineRuntime_rule__5___closed__3_value;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__4;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__5;
static lean_once_cell_t l_MachineRuntime_rule__5___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__5___closed__6;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__5;
static const lean_ctor_object l_MachineRuntime_rule__6___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*6 + 0, .m_other = 6, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(6) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__6___closed__0 = (const lean_object*)&l_MachineRuntime_rule__6___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_rule__6 = (const lean_object*)&l_MachineRuntime_rule__6___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__7___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*6 + 0, .m_other = 6, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e5___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__7___closed__0 = (const lean_object*)&l_MachineRuntime_rule__7___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_rule__7 = (const lean_object*)&l_MachineRuntime_rule__7___closed__0_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__0 = (const lean_object*)&l_MachineRuntime_schema___closed__0_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__1 = (const lean_object*)&l_MachineRuntime_schema___closed__1_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__2 = (const lean_object*)&l_MachineRuntime_schema___closed__2_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(3) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__3 = (const lean_object*)&l_MachineRuntime_schema___closed__3_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__4 = (const lean_object*)&l_MachineRuntime_schema___closed__4_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__4_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__5 = (const lean_object*)&l_MachineRuntime_schema___closed__5_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__3_value),((lean_object*)&l_MachineRuntime_schema___closed__5_value)}};
static const lean_object* l_MachineRuntime_schema___closed__6 = (const lean_object*)&l_MachineRuntime_schema___closed__6_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__2_value),((lean_object*)&l_MachineRuntime_schema___closed__6_value)}};
static const lean_object* l_MachineRuntime_schema___closed__7 = (const lean_object*)&l_MachineRuntime_schema___closed__7_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__1_value),((lean_object*)&l_MachineRuntime_schema___closed__7_value)}};
static const lean_object* l_MachineRuntime_schema___closed__8 = (const lean_object*)&l_MachineRuntime_schema___closed__8_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__0_value),((lean_object*)&l_MachineRuntime_schema___closed__8_value)}};
static const lean_object* l_MachineRuntime_schema___closed__9 = (const lean_object*)&l_MachineRuntime_schema___closed__9_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_schema = (const lean_object*)&l_MachineRuntime_schema___closed__9_value;
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0___boxed(lean_object*);
static const lean_closure_object l_MachineRuntime_model___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_MachineRuntime_model___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_MachineRuntime_model___closed__0 = (const lean_object*)&l_MachineRuntime_model___closed__0_value;
static const lean_ctor_object l_MachineRuntime_model___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__7___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_model___closed__1 = (const lean_object*)&l_MachineRuntime_model___closed__1_value;
static const lean_ctor_object l_MachineRuntime_model___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__6___closed__0_value),((lean_object*)&l_MachineRuntime_model___closed__1_value)}};
static const lean_object* l_MachineRuntime_model___closed__2 = (const lean_object*)&l_MachineRuntime_model___closed__2_value;
static lean_once_cell_t l_MachineRuntime_model___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__3;
static lean_once_cell_t l_MachineRuntime_model___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__4;
static lean_once_cell_t l_MachineRuntime_model___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__5;
static lean_once_cell_t l_MachineRuntime_model___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__6;
static lean_once_cell_t l_MachineRuntime_model___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__7;
static lean_once_cell_t l_MachineRuntime_model___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__8;
static lean_once_cell_t l_MachineRuntime_model___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__9;
static lean_once_cell_t l_MachineRuntime_model___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__10;
static const lean_ctor_object l_MachineRuntime_model___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_model___closed__11 = (const lean_object*)&l_MachineRuntime_model___closed__11_value;
static const lean_ctor_object l_MachineRuntime_model___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__11_value)}};
static const lean_object* l_MachineRuntime_model___closed__12 = (const lean_object*)&l_MachineRuntime_model___closed__12_value;
static const lean_ctor_object l_MachineRuntime_model___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__12_value)}};
static const lean_object* l_MachineRuntime_model___closed__13 = (const lean_object*)&l_MachineRuntime_model___closed__13_value;
static const lean_ctor_object l_MachineRuntime_model___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__13_value)}};
static const lean_object* l_MachineRuntime_model___closed__14 = (const lean_object*)&l_MachineRuntime_model___closed__14_value;
static const lean_ctor_object l_MachineRuntime_model___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__14_value)}};
static const lean_object* l_MachineRuntime_model___closed__15 = (const lean_object*)&l_MachineRuntime_model___closed__15_value;
static const lean_ctor_object l_MachineRuntime_model___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_model___closed__15_value)}};
static const lean_object* l_MachineRuntime_model___closed__16 = (const lean_object*)&l_MachineRuntime_model___closed__16_value;
static lean_once_cell_t l_MachineRuntime_model___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__17;
LEAN_EXPORT lean_object* l_MachineRuntime_model;
static lean_object* _init_l_MachineRuntime_e0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_l_MachineRuntime_e0___closed__1(void){
_start:
{
lean_object* v___x_3_; uint8_t v___x_4_; lean_object* v___x_5_; 
v___x_3_ = lean_obj_once(&l_MachineRuntime_e0___closed__0, &l_MachineRuntime_e0___closed__0_once, _init_l_MachineRuntime_e0___closed__0);
v___x_4_ = 0;
v___x_5_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5_, 0, v___x_3_);
lean_ctor_set_uint8(v___x_5_, sizeof(void*)*1, v___x_4_);
return v___x_5_;
}
}
static lean_object* _init_l_MachineRuntime_e0(void){
_start:
{
lean_object* v___x_6_; 
v___x_6_ = lean_obj_once(&l_MachineRuntime_e0___closed__1, &l_MachineRuntime_e0___closed__1_once, _init_l_MachineRuntime_e0___closed__1);
return v___x_6_;
}
}
static lean_object* _init_l_MachineRuntime_e2___closed__0(void){
_start:
{
lean_object* v___x_12_; uint8_t v___x_13_; lean_object* v___x_14_; 
v___x_12_ = lean_unsigned_to_nat(4294967295u);
v___x_13_ = 4;
v___x_14_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_14_, 0, v___x_12_);
lean_ctor_set_uint8(v___x_14_, sizeof(void*)*1, v___x_13_);
return v___x_14_;
}
}
static lean_object* _init_l_MachineRuntime_e2(void){
_start:
{
lean_object* v___x_15_; 
v___x_15_ = lean_obj_once(&l_MachineRuntime_e2___closed__0, &l_MachineRuntime_e2___closed__0_once, _init_l_MachineRuntime_e2___closed__0);
return v___x_15_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_20_; lean_object* v___x_21_; 
v___x_20_ = 116;
v___x_21_ = lean_box_uint32(v___x_20_);
return v___x_21_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__0(void){
_start:
{
lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; 
v___x_22_ = lean_box(0);
v___x_23_ = l_MachineRuntime_e4___closed__0___boxed__const__1;
v___x_24_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_24_, 0, v___x_23_);
lean_ctor_set(v___x_24_, 1, v___x_22_);
return v___x_24_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_25_; lean_object* v___x_26_; 
v___x_25_ = 114;
v___x_26_ = lean_box_uint32(v___x_25_);
return v___x_26_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__1(void){
_start:
{
lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; 
v___x_27_ = lean_obj_once(&l_MachineRuntime_e4___closed__0, &l_MachineRuntime_e4___closed__0_once, _init_l_MachineRuntime_e4___closed__0);
v___x_28_ = l_MachineRuntime_e4___closed__1___boxed__const__1;
v___x_29_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_29_, 0, v___x_28_);
lean_ctor_set(v___x_29_, 1, v___x_27_);
return v___x_29_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_30_; lean_object* v___x_31_; 
v___x_30_ = 97;
v___x_31_ = lean_box_uint32(v___x_30_);
return v___x_31_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__2(void){
_start:
{
lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; 
v___x_32_ = lean_obj_once(&l_MachineRuntime_e4___closed__1, &l_MachineRuntime_e4___closed__1_once, _init_l_MachineRuntime_e4___closed__1);
v___x_33_ = l_MachineRuntime_e4___closed__2___boxed__const__1;
v___x_34_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_34_, 0, v___x_33_);
lean_ctor_set(v___x_34_, 1, v___x_32_);
return v___x_34_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__3(void){
_start:
{
lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; 
v___x_35_ = lean_obj_once(&l_MachineRuntime_e4___closed__2, &l_MachineRuntime_e4___closed__2_once, _init_l_MachineRuntime_e4___closed__2);
v___x_36_ = l_MachineRuntime_e4___closed__0___boxed__const__1;
v___x_37_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_37_, 0, v___x_36_);
lean_ctor_set(v___x_37_, 1, v___x_35_);
return v___x_37_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__4___boxed__const__1(void){
_start:
{
uint32_t v___x_38_; lean_object* v___x_39_; 
v___x_38_ = 115;
v___x_39_ = lean_box_uint32(v___x_38_);
return v___x_39_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__4(void){
_start:
{
lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_40_ = lean_obj_once(&l_MachineRuntime_e4___closed__3, &l_MachineRuntime_e4___closed__3_once, _init_l_MachineRuntime_e4___closed__3);
v___x_41_ = l_MachineRuntime_e4___closed__4___boxed__const__1;
v___x_42_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_42_, 0, v___x_41_);
lean_ctor_set(v___x_42_, 1, v___x_40_);
return v___x_42_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__5(void){
_start:
{
lean_object* v___x_43_; lean_object* v___x_44_; 
v___x_43_ = lean_obj_once(&l_MachineRuntime_e4___closed__4, &l_MachineRuntime_e4___closed__4_once, _init_l_MachineRuntime_e4___closed__4);
v___x_44_ = lean_string_mk(v___x_43_);
return v___x_44_;
}
}
static lean_object* _init_l_MachineRuntime_e4___closed__6(void){
_start:
{
lean_object* v___x_45_; uint8_t v___x_46_; lean_object* v___x_47_; 
v___x_45_ = lean_obj_once(&l_MachineRuntime_e4___closed__5, &l_MachineRuntime_e4___closed__5_once, _init_l_MachineRuntime_e4___closed__5);
v___x_46_ = 2;
v___x_47_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_47_, 0, v___x_45_);
lean_ctor_set_uint8(v___x_47_, sizeof(void*)*1, v___x_46_);
return v___x_47_;
}
}
static lean_object* _init_l_MachineRuntime_e4(void){
_start:
{
lean_object* v___x_48_; 
v___x_48_ = lean_obj_once(&l_MachineRuntime_e4___closed__6, &l_MachineRuntime_e4___closed__6_once, _init_l_MachineRuntime_e4___closed__6);
return v___x_48_;
}
}
static lean_object* _init_l_MachineRuntime_e7___closed__0(void){
_start:
{
lean_object* v___x_58_; lean_object* v___x_59_; 
v___x_58_ = lean_unsigned_to_nat(4u);
v___x_59_ = lean_nat_to_int(v___x_58_);
return v___x_59_;
}
}
static lean_object* _init_l_MachineRuntime_e7___closed__1(void){
_start:
{
lean_object* v___x_60_; uint8_t v___x_61_; lean_object* v___x_62_; 
v___x_60_ = lean_obj_once(&l_MachineRuntime_e7___closed__0, &l_MachineRuntime_e7___closed__0_once, _init_l_MachineRuntime_e7___closed__0);
v___x_61_ = 0;
v___x_62_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_62_, 0, v___x_60_);
lean_ctor_set_uint8(v___x_62_, sizeof(void*)*1, v___x_61_);
return v___x_62_;
}
}
static lean_object* _init_l_MachineRuntime_e7(void){
_start:
{
lean_object* v___x_63_; 
v___x_63_ = lean_obj_once(&l_MachineRuntime_e7___closed__1, &l_MachineRuntime_e7___closed__1_once, _init_l_MachineRuntime_e7___closed__1);
return v___x_63_;
}
}
static lean_object* _init_l_MachineRuntime_e9___closed__0(void){
_start:
{
lean_object* v___x_68_; lean_object* v___x_69_; 
v___x_68_ = lean_unsigned_to_nat(1u);
v___x_69_ = lean_nat_to_int(v___x_68_);
return v___x_69_;
}
}
static lean_object* _init_l_MachineRuntime_e9___closed__1(void){
_start:
{
lean_object* v___x_70_; uint8_t v___x_71_; lean_object* v___x_72_; 
v___x_70_ = lean_obj_once(&l_MachineRuntime_e9___closed__0, &l_MachineRuntime_e9___closed__0_once, _init_l_MachineRuntime_e9___closed__0);
v___x_71_ = 0;
v___x_72_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_72_, 0, v___x_70_);
lean_ctor_set_uint8(v___x_72_, sizeof(void*)*1, v___x_71_);
return v___x_72_;
}
}
static lean_object* _init_l_MachineRuntime_e9(void){
_start:
{
lean_object* v___x_73_; 
v___x_73_ = lean_obj_once(&l_MachineRuntime_e9___closed__1, &l_MachineRuntime_e9___closed__1_once, _init_l_MachineRuntime_e9___closed__1);
return v___x_73_;
}
}
static lean_object* _init_l_MachineRuntime_e10___closed__0(void){
_start:
{
lean_object* v___x_74_; lean_object* v___x_75_; lean_object* v___x_76_; 
v___x_74_ = l_MachineRuntime_e9;
v___x_75_ = ((lean_object*)(l_MachineRuntime_e8));
v___x_76_ = lean_alloc_ctor(12, 2, 0);
lean_ctor_set(v___x_76_, 0, v___x_75_);
lean_ctor_set(v___x_76_, 1, v___x_74_);
return v___x_76_;
}
}
static lean_object* _init_l_MachineRuntime_e10(void){
_start:
{
lean_object* v___x_77_; 
v___x_77_ = lean_obj_once(&l_MachineRuntime_e10___closed__0, &l_MachineRuntime_e10___closed__0_once, _init_l_MachineRuntime_e10___closed__0);
return v___x_77_;
}
}
static lean_object* _init_l_MachineRuntime_e12___closed__0(void){
_start:
{
lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; 
v___x_82_ = l_MachineRuntime_e9;
v___x_83_ = ((lean_object*)(l_MachineRuntime_e11));
v___x_84_ = lean_alloc_ctor(18, 2, 0);
lean_ctor_set(v___x_84_, 0, v___x_83_);
lean_ctor_set(v___x_84_, 1, v___x_82_);
return v___x_84_;
}
}
static lean_object* _init_l_MachineRuntime_e12(void){
_start:
{
lean_object* v___x_85_; 
v___x_85_ = lean_obj_once(&l_MachineRuntime_e12___closed__0, &l_MachineRuntime_e12___closed__0_once, _init_l_MachineRuntime_e12___closed__0);
return v___x_85_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_86_; lean_object* v___x_87_; 
v___x_86_ = 0;
v___x_87_ = lean_box_uint32(v___x_86_);
return v___x_87_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__0(void){
_start:
{
lean_object* v___x_88_; lean_object* v___x_89_; lean_object* v___x_90_; 
v___x_88_ = lean_box(0);
v___x_89_ = l_MachineRuntime_e13___closed__0___boxed__const__1;
v___x_90_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_90_, 0, v___x_89_);
lean_ctor_set(v___x_90_, 1, v___x_88_);
return v___x_90_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_91_; lean_object* v___x_92_; 
v___x_91_ = 10;
v___x_92_ = lean_box_uint32(v___x_91_);
return v___x_92_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__1(void){
_start:
{
lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; 
v___x_93_ = lean_obj_once(&l_MachineRuntime_e13___closed__0, &l_MachineRuntime_e13___closed__0_once, _init_l_MachineRuntime_e13___closed__0);
v___x_94_ = l_MachineRuntime_e13___closed__1___boxed__const__1;
v___x_95_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_95_, 0, v___x_94_);
lean_ctor_set(v___x_95_, 1, v___x_93_);
return v___x_95_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_96_; lean_object* v___x_97_; 
v___x_96_ = 24320;
v___x_97_ = lean_box_uint32(v___x_96_);
return v___x_97_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__2(void){
_start:
{
lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; 
v___x_98_ = lean_obj_once(&l_MachineRuntime_e13___closed__1, &l_MachineRuntime_e13___closed__1_once, _init_l_MachineRuntime_e13___closed__1);
v___x_99_ = l_MachineRuntime_e13___closed__2___boxed__const__1;
v___x_100_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_100_, 0, v___x_99_);
lean_ctor_set(v___x_100_, 1, v___x_98_);
return v___x_100_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__3(void){
_start:
{
lean_object* v___x_101_; lean_object* v___x_102_; 
v___x_101_ = lean_obj_once(&l_MachineRuntime_e13___closed__2, &l_MachineRuntime_e13___closed__2_once, _init_l_MachineRuntime_e13___closed__2);
v___x_102_ = lean_string_mk(v___x_101_);
return v___x_102_;
}
}
static lean_object* _init_l_MachineRuntime_e13___closed__4(void){
_start:
{
lean_object* v___x_103_; uint8_t v___x_104_; lean_object* v___x_105_; 
v___x_103_ = lean_obj_once(&l_MachineRuntime_e13___closed__3, &l_MachineRuntime_e13___closed__3_once, _init_l_MachineRuntime_e13___closed__3);
v___x_104_ = 2;
v___x_105_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_105_, 0, v___x_103_);
lean_ctor_set_uint8(v___x_105_, sizeof(void*)*1, v___x_104_);
return v___x_105_;
}
}
static lean_object* _init_l_MachineRuntime_e13(void){
_start:
{
lean_object* v___x_106_; 
v___x_106_ = lean_obj_once(&l_MachineRuntime_e13___closed__4, &l_MachineRuntime_e13___closed__4_once, _init_l_MachineRuntime_e13___closed__4);
return v___x_106_;
}
}
static lean_object* _init_l_MachineRuntime_e20___closed__0(void){
_start:
{
lean_object* v___x_128_; lean_object* v___x_129_; 
v___x_128_ = lean_unsigned_to_nat(5u);
v___x_129_ = lean_nat_to_int(v___x_128_);
return v___x_129_;
}
}
static lean_object* _init_l_MachineRuntime_e20___closed__1(void){
_start:
{
lean_object* v___x_130_; uint8_t v___x_131_; lean_object* v___x_132_; 
v___x_130_ = lean_obj_once(&l_MachineRuntime_e20___closed__0, &l_MachineRuntime_e20___closed__0_once, _init_l_MachineRuntime_e20___closed__0);
v___x_131_ = 0;
v___x_132_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_132_, 0, v___x_130_);
lean_ctor_set_uint8(v___x_132_, sizeof(void*)*1, v___x_131_);
return v___x_132_;
}
}
static lean_object* _init_l_MachineRuntime_e20(void){
_start:
{
lean_object* v___x_133_; 
v___x_133_ = lean_obj_once(&l_MachineRuntime_e20___closed__1, &l_MachineRuntime_e20___closed__1_once, _init_l_MachineRuntime_e20___closed__1);
return v___x_133_;
}
}
static lean_object* _init_l_MachineRuntime_e21___closed__0(void){
_start:
{
lean_object* v___x_134_; lean_object* v___x_135_; 
v___x_134_ = lean_unsigned_to_nat(10u);
v___x_135_ = lean_nat_to_int(v___x_134_);
return v___x_135_;
}
}
static lean_object* _init_l_MachineRuntime_e21___closed__1(void){
_start:
{
lean_object* v___x_136_; uint8_t v___x_137_; lean_object* v___x_138_; 
v___x_136_ = lean_obj_once(&l_MachineRuntime_e21___closed__0, &l_MachineRuntime_e21___closed__0_once, _init_l_MachineRuntime_e21___closed__0);
v___x_137_ = 0;
v___x_138_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_138_, 0, v___x_136_);
lean_ctor_set_uint8(v___x_138_, sizeof(void*)*1, v___x_137_);
return v___x_138_;
}
}
static lean_object* _init_l_MachineRuntime_e21(void){
_start:
{
lean_object* v___x_139_; 
v___x_139_ = lean_obj_once(&l_MachineRuntime_e21___closed__1, &l_MachineRuntime_e21___closed__1_once, _init_l_MachineRuntime_e21___closed__1);
return v___x_139_;
}
}
static lean_object* _init_l_MachineRuntime_e23___closed__0(void){
_start:
{
lean_object* v___x_144_; lean_object* v___x_145_; 
v___x_144_ = lean_obj_once(&l_MachineRuntime_e9___closed__0, &l_MachineRuntime_e9___closed__0_once, _init_l_MachineRuntime_e9___closed__0);
v___x_145_ = lean_int_neg(v___x_144_);
return v___x_145_;
}
}
static lean_object* _init_l_MachineRuntime_e23___closed__1(void){
_start:
{
lean_object* v___x_146_; uint8_t v___x_147_; lean_object* v___x_148_; 
v___x_146_ = lean_obj_once(&l_MachineRuntime_e23___closed__0, &l_MachineRuntime_e23___closed__0_once, _init_l_MachineRuntime_e23___closed__0);
v___x_147_ = 0;
v___x_148_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_148_, 0, v___x_146_);
lean_ctor_set_uint8(v___x_148_, sizeof(void*)*1, v___x_147_);
return v___x_148_;
}
}
static lean_object* _init_l_MachineRuntime_e23(void){
_start:
{
lean_object* v___x_149_; 
v___x_149_ = lean_obj_once(&l_MachineRuntime_e23___closed__1, &l_MachineRuntime_e23___closed__1_once, _init_l_MachineRuntime_e23___closed__1);
return v___x_149_;
}
}
static lean_object* _init_l_MachineRuntime_e24___closed__0(void){
_start:
{
lean_object* v___x_150_; lean_object* v___x_151_; 
v___x_150_ = lean_unsigned_to_nat(3u);
v___x_151_ = lean_nat_to_int(v___x_150_);
return v___x_151_;
}
}
static lean_object* _init_l_MachineRuntime_e24___closed__1(void){
_start:
{
lean_object* v___x_152_; uint8_t v___x_153_; lean_object* v___x_154_; 
v___x_152_ = lean_obj_once(&l_MachineRuntime_e24___closed__0, &l_MachineRuntime_e24___closed__0_once, _init_l_MachineRuntime_e24___closed__0);
v___x_153_ = 0;
v___x_154_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_154_, 0, v___x_152_);
lean_ctor_set_uint8(v___x_154_, sizeof(void*)*1, v___x_153_);
return v___x_154_;
}
}
static lean_object* _init_l_MachineRuntime_e24(void){
_start:
{
lean_object* v___x_155_; 
v___x_155_ = lean_obj_once(&l_MachineRuntime_e24___closed__1, &l_MachineRuntime_e24___closed__1_once, _init_l_MachineRuntime_e24___closed__1);
return v___x_155_;
}
}
static lean_object* _init_l_MachineRuntime_e25___closed__0(void){
_start:
{
lean_object* v___x_156_; lean_object* v___x_157_; 
v___x_156_ = lean_unsigned_to_nat(7u);
v___x_157_ = lean_nat_to_int(v___x_156_);
return v___x_157_;
}
}
static lean_object* _init_l_MachineRuntime_e25___closed__1(void){
_start:
{
lean_object* v___x_158_; uint8_t v___x_159_; lean_object* v___x_160_; 
v___x_158_ = lean_obj_once(&l_MachineRuntime_e25___closed__0, &l_MachineRuntime_e25___closed__0_once, _init_l_MachineRuntime_e25___closed__0);
v___x_159_ = 0;
v___x_160_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_160_, 0, v___x_158_);
lean_ctor_set_uint8(v___x_160_, sizeof(void*)*1, v___x_159_);
return v___x_160_;
}
}
static lean_object* _init_l_MachineRuntime_e25(void){
_start:
{
lean_object* v___x_161_; 
v___x_161_ = lean_obj_once(&l_MachineRuntime_e25___closed__1, &l_MachineRuntime_e25___closed__1_once, _init_l_MachineRuntime_e25___closed__1);
return v___x_161_;
}
}
static lean_object* _init_l_MachineRuntime_e26___closed__0(void){
_start:
{
lean_object* v___x_162_; lean_object* v___x_163_; lean_object* v___x_164_; 
v___x_162_ = l_MachineRuntime_e0;
v___x_163_ = ((lean_object*)(l_MachineRuntime_e8));
v___x_164_ = lean_alloc_ctor(17, 2, 0);
lean_ctor_set(v___x_164_, 0, v___x_163_);
lean_ctor_set(v___x_164_, 1, v___x_162_);
return v___x_164_;
}
}
static lean_object* _init_l_MachineRuntime_e26(void){
_start:
{
lean_object* v___x_165_; 
v___x_165_ = lean_obj_once(&l_MachineRuntime_e26___closed__0, &l_MachineRuntime_e26___closed__0_once, _init_l_MachineRuntime_e26___closed__0);
return v___x_165_;
}
}
static lean_object* _init_l_MachineRuntime_e28___closed__0(void){
_start:
{
lean_object* v___x_169_; lean_object* v___x_170_; 
v___x_169_ = lean_unsigned_to_nat(4096u);
v___x_170_ = lean_nat_to_int(v___x_169_);
return v___x_170_;
}
}
static lean_object* _init_l_MachineRuntime_e28___closed__1(void){
_start:
{
lean_object* v___x_171_; uint8_t v___x_172_; lean_object* v___x_173_; 
v___x_171_ = lean_obj_once(&l_MachineRuntime_e28___closed__0, &l_MachineRuntime_e28___closed__0_once, _init_l_MachineRuntime_e28___closed__0);
v___x_172_ = 0;
v___x_173_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_173_, 0, v___x_171_);
lean_ctor_set_uint8(v___x_173_, sizeof(void*)*1, v___x_172_);
return v___x_173_;
}
}
static lean_object* _init_l_MachineRuntime_e28(void){
_start:
{
lean_object* v___x_174_; 
v___x_174_ = lean_obj_once(&l_MachineRuntime_e28___closed__1, &l_MachineRuntime_e28___closed__1_once, _init_l_MachineRuntime_e28___closed__1);
return v___x_174_;
}
}
static lean_object* _init_l_MachineRuntime_e29___closed__0(void){
_start:
{
lean_object* v___x_175_; lean_object* v___x_176_; lean_object* v___x_177_; 
v___x_175_ = l_MachineRuntime_e28;
v___x_176_ = ((lean_object*)(l_MachineRuntime_e27));
v___x_177_ = lean_alloc_ctor(16, 2, 0);
lean_ctor_set(v___x_177_, 0, v___x_176_);
lean_ctor_set(v___x_177_, 1, v___x_175_);
return v___x_177_;
}
}
static lean_object* _init_l_MachineRuntime_e29(void){
_start:
{
lean_object* v___x_178_; 
v___x_178_ = lean_obj_once(&l_MachineRuntime_e29___closed__0, &l_MachineRuntime_e29___closed__0_once, _init_l_MachineRuntime_e29___closed__0);
return v___x_178_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__1(void){
_start:
{
lean_object* v___x_183_; lean_object* v___x_184_; uint8_t v___x_185_; lean_object* v___x_186_; 
v___x_183_ = l_MachineRuntime_e7;
v___x_184_ = lean_unsigned_to_nat(0u);
v___x_185_ = 0;
v___x_186_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_186_, 0, v___x_184_);
lean_ctor_set(v___x_186_, 1, v___x_183_);
lean_ctor_set_uint8(v___x_186_, sizeof(void*)*2, v___x_185_);
return v___x_186_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__2(void){
_start:
{
lean_object* v___x_187_; lean_object* v___x_188_; uint8_t v___x_189_; lean_object* v___x_190_; 
v___x_187_ = l_MachineRuntime_e10;
v___x_188_ = lean_unsigned_to_nat(0u);
v___x_189_ = 0;
v___x_190_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_190_, 0, v___x_188_);
lean_ctor_set(v___x_190_, 1, v___x_187_);
lean_ctor_set_uint8(v___x_190_, sizeof(void*)*2, v___x_189_);
return v___x_190_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__4(void){
_start:
{
lean_object* v___x_195_; lean_object* v___x_196_; uint8_t v___x_197_; lean_object* v___x_198_; 
v___x_195_ = l_MachineRuntime_e12;
v___x_196_ = lean_unsigned_to_nat(2u);
v___x_197_ = 4;
v___x_198_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_198_, 0, v___x_196_);
lean_ctor_set(v___x_198_, 1, v___x_195_);
lean_ctor_set_uint8(v___x_198_, sizeof(void*)*2, v___x_197_);
return v___x_198_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__5(void){
_start:
{
lean_object* v___x_199_; lean_object* v___x_200_; uint8_t v___x_201_; lean_object* v___x_202_; 
v___x_199_ = l_MachineRuntime_e13;
v___x_200_ = lean_unsigned_to_nat(4u);
v___x_201_ = 2;
v___x_202_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_202_, 0, v___x_200_);
lean_ctor_set(v___x_202_, 1, v___x_199_);
lean_ctor_set_uint8(v___x_202_, sizeof(void*)*2, v___x_201_);
return v___x_202_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__23(void){
_start:
{
lean_object* v___x_262_; lean_object* v___x_263_; lean_object* v___x_264_; 
v___x_262_ = l_MachineRuntime_e20;
v___x_263_ = lean_unsigned_to_nat(1u);
v___x_264_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_264_, 0, v___x_263_);
lean_ctor_set(v___x_264_, 1, v___x_262_);
return v___x_264_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__24(void){
_start:
{
lean_object* v___x_265_; lean_object* v___x_266_; lean_object* v___x_267_; 
v___x_265_ = l_MachineRuntime_e20;
v___x_266_ = lean_unsigned_to_nat(0u);
v___x_267_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_267_, 0, v___x_266_);
lean_ctor_set(v___x_267_, 1, v___x_265_);
return v___x_267_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__25(void){
_start:
{
lean_object* v___x_268_; lean_object* v___x_269_; lean_object* v___x_270_; 
v___x_268_ = lean_box(0);
v___x_269_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__24, &l_MachineRuntime_rule__0___closed__24_once, _init_l_MachineRuntime_rule__0___closed__24);
v___x_270_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_270_, 0, v___x_269_);
lean_ctor_set(v___x_270_, 1, v___x_268_);
return v___x_270_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__26(void){
_start:
{
lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; 
v___x_271_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__25, &l_MachineRuntime_rule__0___closed__25_once, _init_l_MachineRuntime_rule__0___closed__25);
v___x_272_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__23, &l_MachineRuntime_rule__0___closed__23_once, _init_l_MachineRuntime_rule__0___closed__23);
v___x_273_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_273_, 0, v___x_272_);
lean_ctor_set(v___x_273_, 1, v___x_271_);
return v___x_273_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__27(void){
_start:
{
lean_object* v___x_274_; lean_object* v___x_275_; lean_object* v___x_276_; 
v___x_274_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__26, &l_MachineRuntime_rule__0___closed__26_once, _init_l_MachineRuntime_rule__0___closed__26);
v___x_275_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__22));
v___x_276_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_276_, 0, v___x_275_);
lean_ctor_set(v___x_276_, 1, v___x_274_);
return v___x_276_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__28(void){
_start:
{
lean_object* v___x_277_; lean_object* v___x_278_; lean_object* v___x_279_; 
v___x_277_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__27, &l_MachineRuntime_rule__0___closed__27_once, _init_l_MachineRuntime_rule__0___closed__27);
v___x_278_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__5, &l_MachineRuntime_rule__0___closed__5_once, _init_l_MachineRuntime_rule__0___closed__5);
v___x_279_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_279_, 0, v___x_278_);
lean_ctor_set(v___x_279_, 1, v___x_277_);
return v___x_279_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__29(void){
_start:
{
lean_object* v___x_280_; lean_object* v___x_281_; lean_object* v___x_282_; 
v___x_280_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__28, &l_MachineRuntime_rule__0___closed__28_once, _init_l_MachineRuntime_rule__0___closed__28);
v___x_281_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__4, &l_MachineRuntime_rule__0___closed__4_once, _init_l_MachineRuntime_rule__0___closed__4);
v___x_282_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_282_, 0, v___x_281_);
lean_ctor_set(v___x_282_, 1, v___x_280_);
return v___x_282_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__30(void){
_start:
{
lean_object* v___x_283_; lean_object* v___x_284_; lean_object* v___x_285_; 
v___x_283_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__29, &l_MachineRuntime_rule__0___closed__29_once, _init_l_MachineRuntime_rule__0___closed__29);
v___x_284_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__3));
v___x_285_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_285_, 0, v___x_284_);
lean_ctor_set(v___x_285_, 1, v___x_283_);
return v___x_285_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__31(void){
_start:
{
lean_object* v___x_286_; lean_object* v___x_287_; lean_object* v___x_288_; 
v___x_286_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__30, &l_MachineRuntime_rule__0___closed__30_once, _init_l_MachineRuntime_rule__0___closed__30);
v___x_287_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__2, &l_MachineRuntime_rule__0___closed__2_once, _init_l_MachineRuntime_rule__0___closed__2);
v___x_288_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_288_, 0, v___x_287_);
lean_ctor_set(v___x_288_, 1, v___x_286_);
return v___x_288_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__32(void){
_start:
{
lean_object* v___x_289_; lean_object* v___x_290_; lean_object* v___x_291_; 
v___x_289_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__31, &l_MachineRuntime_rule__0___closed__31_once, _init_l_MachineRuntime_rule__0___closed__31);
v___x_290_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__1, &l_MachineRuntime_rule__0___closed__1_once, _init_l_MachineRuntime_rule__0___closed__1);
v___x_291_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_291_, 0, v___x_290_);
lean_ctor_set(v___x_291_, 1, v___x_289_);
return v___x_291_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__33(void){
_start:
{
lean_object* v___x_292_; lean_object* v___x_293_; lean_object* v___x_294_; 
v___x_292_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__32, &l_MachineRuntime_rule__0___closed__32_once, _init_l_MachineRuntime_rule__0___closed__32);
v___x_293_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__0));
v___x_294_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_294_, 0, v___x_293_);
lean_ctor_set(v___x_294_, 1, v___x_292_);
return v___x_294_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__34(void){
_start:
{
lean_object* v___x_295_; lean_object* v___x_296_; lean_object* v___x_297_; lean_object* v___x_298_; lean_object* v___x_299_; 
v___x_295_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__33, &l_MachineRuntime_rule__0___closed__33_once, _init_l_MachineRuntime_rule__0___closed__33);
v___x_296_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_297_ = lean_unsigned_to_nat(1u);
v___x_298_ = lean_unsigned_to_nat(0u);
v___x_299_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_299_, 0, v___x_298_);
lean_ctor_set(v___x_299_, 1, v___x_298_);
lean_ctor_set(v___x_299_, 2, v___x_297_);
lean_ctor_set(v___x_299_, 3, v___x_298_);
lean_ctor_set(v___x_299_, 4, v___x_296_);
lean_ctor_set(v___x_299_, 5, v___x_295_);
return v___x_299_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0(void){
_start:
{
lean_object* v___x_300_; 
v___x_300_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__34, &l_MachineRuntime_rule__0___closed__34_once, _init_l_MachineRuntime_rule__0___closed__34);
return v___x_300_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1___closed__0(void){
_start:
{
lean_object* v___x_301_; lean_object* v___x_302_; uint8_t v___x_303_; lean_object* v___x_304_; 
v___x_301_ = l_MachineRuntime_e21;
v___x_302_ = lean_unsigned_to_nat(0u);
v___x_303_ = 0;
v___x_304_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_304_, 0, v___x_302_);
lean_ctor_set(v___x_304_, 1, v___x_301_);
lean_ctor_set_uint8(v___x_304_, sizeof(void*)*2, v___x_303_);
return v___x_304_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1___closed__4(void){
_start:
{
lean_object* v___x_314_; lean_object* v___x_315_; lean_object* v___x_316_; 
v___x_314_ = ((lean_object*)(l_MachineRuntime_rule__1___closed__3));
v___x_315_ = lean_obj_once(&l_MachineRuntime_rule__1___closed__0, &l_MachineRuntime_rule__1___closed__0_once, _init_l_MachineRuntime_rule__1___closed__0);
v___x_316_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_316_, 0, v___x_315_);
lean_ctor_set(v___x_316_, 1, v___x_314_);
return v___x_316_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1___closed__5(void){
_start:
{
lean_object* v___x_317_; lean_object* v___x_318_; lean_object* v___x_319_; lean_object* v___x_320_; lean_object* v___x_321_; 
v___x_317_ = lean_obj_once(&l_MachineRuntime_rule__1___closed__4, &l_MachineRuntime_rule__1___closed__4_once, _init_l_MachineRuntime_rule__1___closed__4);
v___x_318_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_319_ = lean_unsigned_to_nat(0u);
v___x_320_ = lean_unsigned_to_nat(1u);
v___x_321_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_321_, 0, v___x_320_);
lean_ctor_set(v___x_321_, 1, v___x_319_);
lean_ctor_set(v___x_321_, 2, v___x_320_);
lean_ctor_set(v___x_321_, 3, v___x_320_);
lean_ctor_set(v___x_321_, 4, v___x_318_);
lean_ctor_set(v___x_321_, 5, v___x_317_);
return v___x_321_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1(void){
_start:
{
lean_object* v___x_322_; 
v___x_322_ = lean_obj_once(&l_MachineRuntime_rule__1___closed__5, &l_MachineRuntime_rule__1___closed__5_once, _init_l_MachineRuntime_rule__1___closed__5);
return v___x_322_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__0(void){
_start:
{
lean_object* v___x_323_; lean_object* v___x_324_; uint8_t v___x_325_; lean_object* v___x_326_; 
v___x_323_ = l_MachineRuntime_e23;
v___x_324_ = lean_unsigned_to_nat(0u);
v___x_325_ = 0;
v___x_326_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_326_, 0, v___x_324_);
lean_ctor_set(v___x_326_, 1, v___x_323_);
lean_ctor_set_uint8(v___x_326_, sizeof(void*)*2, v___x_325_);
return v___x_326_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__2(void){
_start:
{
lean_object* v___x_330_; lean_object* v___x_331_; lean_object* v___x_332_; 
v___x_330_ = ((lean_object*)(l_MachineRuntime_rule__2___closed__1));
v___x_331_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__24, &l_MachineRuntime_rule__0___closed__24_once, _init_l_MachineRuntime_rule__0___closed__24);
v___x_332_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_332_, 0, v___x_331_);
lean_ctor_set(v___x_332_, 1, v___x_330_);
return v___x_332_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__3(void){
_start:
{
lean_object* v___x_333_; lean_object* v___x_334_; lean_object* v___x_335_; 
v___x_333_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__2, &l_MachineRuntime_rule__2___closed__2_once, _init_l_MachineRuntime_rule__2___closed__2);
v___x_334_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__0, &l_MachineRuntime_rule__2___closed__0_once, _init_l_MachineRuntime_rule__2___closed__0);
v___x_335_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_335_, 0, v___x_334_);
lean_ctor_set(v___x_335_, 1, v___x_333_);
return v___x_335_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2___closed__4(void){
_start:
{
lean_object* v___x_336_; lean_object* v___x_337_; lean_object* v___x_338_; lean_object* v___x_339_; lean_object* v___x_340_; 
v___x_336_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__3, &l_MachineRuntime_rule__2___closed__3_once, _init_l_MachineRuntime_rule__2___closed__3);
v___x_337_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_338_ = lean_unsigned_to_nat(0u);
v___x_339_ = lean_unsigned_to_nat(2u);
v___x_340_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_340_, 0, v___x_339_);
lean_ctor_set(v___x_340_, 1, v___x_338_);
lean_ctor_set(v___x_340_, 2, v___x_339_);
lean_ctor_set(v___x_340_, 3, v___x_339_);
lean_ctor_set(v___x_340_, 4, v___x_337_);
lean_ctor_set(v___x_340_, 5, v___x_336_);
return v___x_340_;
}
}
static lean_object* _init_l_MachineRuntime_rule__2(void){
_start:
{
lean_object* v___x_341_; 
v___x_341_ = lean_obj_once(&l_MachineRuntime_rule__2___closed__4, &l_MachineRuntime_rule__2___closed__4_once, _init_l_MachineRuntime_rule__2___closed__4);
return v___x_341_;
}
}
static lean_object* _init_l_MachineRuntime_rule__3___closed__0(void){
_start:
{
lean_object* v___x_342_; lean_object* v___x_343_; lean_object* v___x_344_; 
v___x_342_ = ((lean_object*)(l_MachineRuntime_rule__2___closed__1));
v___x_343_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__2, &l_MachineRuntime_rule__0___closed__2_once, _init_l_MachineRuntime_rule__0___closed__2);
v___x_344_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_344_, 0, v___x_343_);
lean_ctor_set(v___x_344_, 1, v___x_342_);
return v___x_344_;
}
}
static lean_object* _init_l_MachineRuntime_rule__3___closed__1(void){
_start:
{
lean_object* v___x_345_; lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v___x_348_; lean_object* v___x_349_; lean_object* v___x_350_; 
v___x_345_ = lean_obj_once(&l_MachineRuntime_rule__3___closed__0, &l_MachineRuntime_rule__3___closed__0_once, _init_l_MachineRuntime_rule__3___closed__0);
v___x_346_ = ((lean_object*)(l_MachineRuntime_e18));
v___x_347_ = lean_unsigned_to_nat(6u);
v___x_348_ = lean_unsigned_to_nat(1u);
v___x_349_ = lean_unsigned_to_nat(3u);
v___x_350_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_350_, 0, v___x_349_);
lean_ctor_set(v___x_350_, 1, v___x_348_);
lean_ctor_set(v___x_350_, 2, v___x_348_);
lean_ctor_set(v___x_350_, 3, v___x_347_);
lean_ctor_set(v___x_350_, 4, v___x_346_);
lean_ctor_set(v___x_350_, 5, v___x_345_);
return v___x_350_;
}
}
static lean_object* _init_l_MachineRuntime_rule__3(void){
_start:
{
lean_object* v___x_351_; 
v___x_351_ = lean_obj_once(&l_MachineRuntime_rule__3___closed__1, &l_MachineRuntime_rule__3___closed__1_once, _init_l_MachineRuntime_rule__3___closed__1);
return v___x_351_;
}
}
static lean_object* _init_l_MachineRuntime_rule__4___closed__3(void){
_start:
{
lean_object* v___x_360_; lean_object* v___x_361_; lean_object* v___x_362_; 
v___x_360_ = ((lean_object*)(l_MachineRuntime_rule__4___closed__2));
v___x_361_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__2, &l_MachineRuntime_rule__0___closed__2_once, _init_l_MachineRuntime_rule__0___closed__2);
v___x_362_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_362_, 0, v___x_361_);
lean_ctor_set(v___x_362_, 1, v___x_360_);
return v___x_362_;
}
}
static lean_object* _init_l_MachineRuntime_rule__4___closed__4(void){
_start:
{
lean_object* v___x_363_; lean_object* v___x_364_; lean_object* v___x_365_; lean_object* v___x_366_; lean_object* v___x_367_; lean_object* v___x_368_; lean_object* v___x_369_; 
v___x_363_ = lean_obj_once(&l_MachineRuntime_rule__4___closed__3, &l_MachineRuntime_rule__4___closed__3_once, _init_l_MachineRuntime_rule__4___closed__3);
v___x_364_ = ((lean_object*)(l_MachineRuntime_e19));
v___x_365_ = lean_unsigned_to_nat(7u);
v___x_366_ = lean_unsigned_to_nat(2u);
v___x_367_ = lean_unsigned_to_nat(1u);
v___x_368_ = lean_unsigned_to_nat(4u);
v___x_369_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_369_, 0, v___x_368_);
lean_ctor_set(v___x_369_, 1, v___x_367_);
lean_ctor_set(v___x_369_, 2, v___x_366_);
lean_ctor_set(v___x_369_, 3, v___x_365_);
lean_ctor_set(v___x_369_, 4, v___x_364_);
lean_ctor_set(v___x_369_, 5, v___x_363_);
return v___x_369_;
}
}
static lean_object* _init_l_MachineRuntime_rule__4(void){
_start:
{
lean_object* v___x_370_; 
v___x_370_ = lean_obj_once(&l_MachineRuntime_rule__4___closed__4, &l_MachineRuntime_rule__4___closed__4_once, _init_l_MachineRuntime_rule__4___closed__4);
return v___x_370_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__0(void){
_start:
{
lean_object* v___x_371_; lean_object* v___x_372_; lean_object* v___x_373_; 
v___x_371_ = l_MachineRuntime_e24;
v___x_372_ = lean_unsigned_to_nat(0u);
v___x_373_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_373_, 0, v___x_372_);
lean_ctor_set(v___x_373_, 1, v___x_371_);
return v___x_373_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__1(void){
_start:
{
lean_object* v___x_374_; lean_object* v___x_375_; lean_object* v___x_376_; 
v___x_374_ = l_MachineRuntime_e25;
v___x_375_ = lean_unsigned_to_nat(0u);
v___x_376_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_376_, 0, v___x_375_);
lean_ctor_set(v___x_376_, 1, v___x_374_);
return v___x_376_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__4(void){
_start:
{
lean_object* v___x_382_; lean_object* v___x_383_; lean_object* v___x_384_; 
v___x_382_ = ((lean_object*)(l_MachineRuntime_rule__5___closed__3));
v___x_383_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__1, &l_MachineRuntime_rule__5___closed__1_once, _init_l_MachineRuntime_rule__5___closed__1);
v___x_384_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_384_, 0, v___x_383_);
lean_ctor_set(v___x_384_, 1, v___x_382_);
return v___x_384_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__5(void){
_start:
{
lean_object* v___x_385_; lean_object* v___x_386_; lean_object* v___x_387_; 
v___x_385_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__4, &l_MachineRuntime_rule__5___closed__4_once, _init_l_MachineRuntime_rule__5___closed__4);
v___x_386_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__0, &l_MachineRuntime_rule__5___closed__0_once, _init_l_MachineRuntime_rule__5___closed__0);
v___x_387_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_387_, 0, v___x_386_);
lean_ctor_set(v___x_387_, 1, v___x_385_);
return v___x_387_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5___closed__6(void){
_start:
{
lean_object* v___x_388_; lean_object* v___x_389_; lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_393_; 
v___x_388_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__5, &l_MachineRuntime_rule__5___closed__5_once, _init_l_MachineRuntime_rule__5___closed__5);
v___x_389_ = ((lean_object*)(l_MachineRuntime_e5));
v___x_390_ = lean_unsigned_to_nat(3u);
v___x_391_ = lean_unsigned_to_nat(1u);
v___x_392_ = lean_unsigned_to_nat(5u);
v___x_393_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_393_, 0, v___x_392_);
lean_ctor_set(v___x_393_, 1, v___x_391_);
lean_ctor_set(v___x_393_, 2, v___x_391_);
lean_ctor_set(v___x_393_, 3, v___x_390_);
lean_ctor_set(v___x_393_, 4, v___x_389_);
lean_ctor_set(v___x_393_, 5, v___x_388_);
return v___x_393_;
}
}
static lean_object* _init_l_MachineRuntime_rule__5(void){
_start:
{
lean_object* v___x_394_; 
v___x_394_ = lean_obj_once(&l_MachineRuntime_rule__5___closed__6, &l_MachineRuntime_rule__5___closed__6_once, _init_l_MachineRuntime_rule__5___closed__6);
return v___x_394_;
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0(lean_object* v_n_446_){
_start:
{
lean_object* v___x_447_; uint8_t v___x_448_; 
v___x_447_ = lean_unsigned_to_nat(0u);
v___x_448_ = lean_nat_dec_eq(v_n_446_, v___x_447_);
if (v___x_448_ == 0)
{
lean_object* v___x_449_; uint8_t v___x_450_; 
v___x_449_ = lean_unsigned_to_nat(1u);
v___x_450_ = lean_nat_dec_eq(v_n_446_, v___x_449_);
if (v___x_450_ == 0)
{
return v___x_447_;
}
else
{
lean_object* v___x_451_; 
v___x_451_ = lean_unsigned_to_nat(7u);
return v___x_451_;
}
}
else
{
lean_object* v___x_452_; 
v___x_452_ = lean_unsigned_to_nat(6u);
return v___x_452_;
}
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0___boxed(lean_object* v_n_453_){
_start:
{
lean_object* v_res_454_; 
v_res_454_ = l_MachineRuntime_model___lam__0(v_n_453_);
lean_dec(v_n_453_);
return v_res_454_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__3(void){
_start:
{
lean_object* v___x_462_; lean_object* v___x_463_; lean_object* v___x_464_; 
v___x_462_ = ((lean_object*)(l_MachineRuntime_model___closed__2));
v___x_463_ = l_MachineRuntime_rule__5;
v___x_464_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_464_, 0, v___x_463_);
lean_ctor_set(v___x_464_, 1, v___x_462_);
return v___x_464_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__4(void){
_start:
{
lean_object* v___x_465_; lean_object* v___x_466_; lean_object* v___x_467_; 
v___x_465_ = lean_obj_once(&l_MachineRuntime_model___closed__3, &l_MachineRuntime_model___closed__3_once, _init_l_MachineRuntime_model___closed__3);
v___x_466_ = l_MachineRuntime_rule__4;
v___x_467_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_467_, 0, v___x_466_);
lean_ctor_set(v___x_467_, 1, v___x_465_);
return v___x_467_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__5(void){
_start:
{
lean_object* v___x_468_; lean_object* v___x_469_; lean_object* v___x_470_; 
v___x_468_ = lean_obj_once(&l_MachineRuntime_model___closed__4, &l_MachineRuntime_model___closed__4_once, _init_l_MachineRuntime_model___closed__4);
v___x_469_ = l_MachineRuntime_rule__3;
v___x_470_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_470_, 0, v___x_469_);
lean_ctor_set(v___x_470_, 1, v___x_468_);
return v___x_470_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__6(void){
_start:
{
lean_object* v___x_471_; lean_object* v___x_472_; lean_object* v___x_473_; 
v___x_471_ = lean_obj_once(&l_MachineRuntime_model___closed__5, &l_MachineRuntime_model___closed__5_once, _init_l_MachineRuntime_model___closed__5);
v___x_472_ = l_MachineRuntime_rule__2;
v___x_473_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_473_, 0, v___x_472_);
lean_ctor_set(v___x_473_, 1, v___x_471_);
return v___x_473_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__7(void){
_start:
{
lean_object* v___x_474_; lean_object* v___x_475_; lean_object* v___x_476_; 
v___x_474_ = lean_obj_once(&l_MachineRuntime_model___closed__6, &l_MachineRuntime_model___closed__6_once, _init_l_MachineRuntime_model___closed__6);
v___x_475_ = l_MachineRuntime_rule__1;
v___x_476_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_476_, 0, v___x_475_);
lean_ctor_set(v___x_476_, 1, v___x_474_);
return v___x_476_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__8(void){
_start:
{
lean_object* v___x_477_; lean_object* v___x_478_; lean_object* v___x_479_; 
v___x_477_ = lean_obj_once(&l_MachineRuntime_model___closed__7, &l_MachineRuntime_model___closed__7_once, _init_l_MachineRuntime_model___closed__7);
v___x_478_ = l_MachineRuntime_rule__0;
v___x_479_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_479_, 0, v___x_478_);
lean_ctor_set(v___x_479_, 1, v___x_477_);
return v___x_479_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__9(void){
_start:
{
lean_object* v___x_480_; lean_object* v___x_481_; lean_object* v___x_482_; 
v___x_480_ = lean_box(0);
v___x_481_ = l_MachineRuntime_e29;
v___x_482_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_482_, 0, v___x_481_);
lean_ctor_set(v___x_482_, 1, v___x_480_);
return v___x_482_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__10(void){
_start:
{
lean_object* v___x_483_; lean_object* v___x_484_; lean_object* v___x_485_; 
v___x_483_ = lean_obj_once(&l_MachineRuntime_model___closed__9, &l_MachineRuntime_model___closed__9_once, _init_l_MachineRuntime_model___closed__9);
v___x_484_ = l_MachineRuntime_e26;
v___x_485_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_485_, 0, v___x_484_);
lean_ctor_set(v___x_485_, 1, v___x_483_);
return v___x_485_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__17(void){
_start:
{
lean_object* v___x_504_; lean_object* v___f_505_; lean_object* v___x_506_; lean_object* v___x_507_; lean_object* v___x_508_; 
v___x_504_ = ((lean_object*)(l_MachineRuntime_model___closed__16));
v___f_505_ = ((lean_object*)(l_MachineRuntime_model___closed__0));
v___x_506_ = lean_obj_once(&l_MachineRuntime_model___closed__10, &l_MachineRuntime_model___closed__10_once, _init_l_MachineRuntime_model___closed__10);
v___x_507_ = lean_obj_once(&l_MachineRuntime_model___closed__8, &l_MachineRuntime_model___closed__8_once, _init_l_MachineRuntime_model___closed__8);
v___x_508_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_508_, 0, v___x_507_);
lean_ctor_set(v___x_508_, 1, v___x_506_);
lean_ctor_set(v___x_508_, 2, v___f_505_);
lean_ctor_set(v___x_508_, 3, v___x_504_);
return v___x_508_;
}
}
static lean_object* _init_l_MachineRuntime_model(void){
_start:
{
lean_object* v___x_509_; 
v___x_509_ = lean_obj_once(&l_MachineRuntime_model___closed__17, &l_MachineRuntime_model___closed__17_once, _init_l_MachineRuntime_model___closed__17);
return v___x_509_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_MachineObserve(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ModelMachine(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_MachineObserve(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_MachineRuntime_e0 = _init_l_MachineRuntime_e0();
lean_mark_persistent(l_MachineRuntime_e0);
l_MachineRuntime_e2 = _init_l_MachineRuntime_e2();
lean_mark_persistent(l_MachineRuntime_e2);
l_MachineRuntime_e4___closed__0___boxed__const__1 = _init_l_MachineRuntime_e4___closed__0___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__0___boxed__const__1);
l_MachineRuntime_e4___closed__1___boxed__const__1 = _init_l_MachineRuntime_e4___closed__1___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__1___boxed__const__1);
l_MachineRuntime_e4___closed__2___boxed__const__1 = _init_l_MachineRuntime_e4___closed__2___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__2___boxed__const__1);
l_MachineRuntime_e4___closed__4___boxed__const__1 = _init_l_MachineRuntime_e4___closed__4___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e4___closed__4___boxed__const__1);
l_MachineRuntime_e4 = _init_l_MachineRuntime_e4();
lean_mark_persistent(l_MachineRuntime_e4);
l_MachineRuntime_e7 = _init_l_MachineRuntime_e7();
lean_mark_persistent(l_MachineRuntime_e7);
l_MachineRuntime_e9 = _init_l_MachineRuntime_e9();
lean_mark_persistent(l_MachineRuntime_e9);
l_MachineRuntime_e10 = _init_l_MachineRuntime_e10();
lean_mark_persistent(l_MachineRuntime_e10);
l_MachineRuntime_e12 = _init_l_MachineRuntime_e12();
lean_mark_persistent(l_MachineRuntime_e12);
l_MachineRuntime_e13___closed__0___boxed__const__1 = _init_l_MachineRuntime_e13___closed__0___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e13___closed__0___boxed__const__1);
l_MachineRuntime_e13___closed__1___boxed__const__1 = _init_l_MachineRuntime_e13___closed__1___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e13___closed__1___boxed__const__1);
l_MachineRuntime_e13___closed__2___boxed__const__1 = _init_l_MachineRuntime_e13___closed__2___boxed__const__1();
lean_mark_persistent(l_MachineRuntime_e13___closed__2___boxed__const__1);
l_MachineRuntime_e13 = _init_l_MachineRuntime_e13();
lean_mark_persistent(l_MachineRuntime_e13);
l_MachineRuntime_e20 = _init_l_MachineRuntime_e20();
lean_mark_persistent(l_MachineRuntime_e20);
l_MachineRuntime_e21 = _init_l_MachineRuntime_e21();
lean_mark_persistent(l_MachineRuntime_e21);
l_MachineRuntime_e23 = _init_l_MachineRuntime_e23();
lean_mark_persistent(l_MachineRuntime_e23);
l_MachineRuntime_e24 = _init_l_MachineRuntime_e24();
lean_mark_persistent(l_MachineRuntime_e24);
l_MachineRuntime_e25 = _init_l_MachineRuntime_e25();
lean_mark_persistent(l_MachineRuntime_e25);
l_MachineRuntime_e26 = _init_l_MachineRuntime_e26();
lean_mark_persistent(l_MachineRuntime_e26);
l_MachineRuntime_e28 = _init_l_MachineRuntime_e28();
lean_mark_persistent(l_MachineRuntime_e28);
l_MachineRuntime_e29 = _init_l_MachineRuntime_e29();
lean_mark_persistent(l_MachineRuntime_e29);
l_MachineRuntime_rule__0 = _init_l_MachineRuntime_rule__0();
lean_mark_persistent(l_MachineRuntime_rule__0);
l_MachineRuntime_rule__1 = _init_l_MachineRuntime_rule__1();
lean_mark_persistent(l_MachineRuntime_rule__1);
l_MachineRuntime_rule__2 = _init_l_MachineRuntime_rule__2();
lean_mark_persistent(l_MachineRuntime_rule__2);
l_MachineRuntime_rule__3 = _init_l_MachineRuntime_rule__3();
lean_mark_persistent(l_MachineRuntime_rule__3);
l_MachineRuntime_rule__4 = _init_l_MachineRuntime_rule__4();
lean_mark_persistent(l_MachineRuntime_rule__4);
l_MachineRuntime_rule__5 = _init_l_MachineRuntime_rule__5();
lean_mark_persistent(l_MachineRuntime_rule__5);
l_MachineRuntime_model = _init_l_MachineRuntime_model();
lean_mark_persistent(l_MachineRuntime_model);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
