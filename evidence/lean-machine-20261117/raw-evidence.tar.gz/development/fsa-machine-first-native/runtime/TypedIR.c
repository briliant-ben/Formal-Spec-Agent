// Lean compiler output
// Module: TypedIR
// Imports: public import Init public meta import Init public import ValueOps
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
uint8_t l_instDecidableEqList___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_ValueOps_seqAdd(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_ValueOps_seqDistance(lean_object*, lean_object*);
uint8_t l_FormalSpecAgent_ValueOps_seqComparable(lean_object*, lean_object*);
uint8_t l_FormalSpecAgent_ValueOps_seqLt(lean_object*, lean_object*);
uint8_t l_FormalSpecAgent_ValueOps_seqLe(lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_byteSlice(lean_object*, lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_byteAt(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_ValueOps_pack8(lean_object*);
lean_object* l_FormalSpecAgent_ValueOps_pack16(lean_object*);
lean_object* l_FormalSpecAgent_ValueOps_pack32(lean_object*);
lean_object* l_FormalSpecAgent_ValueOps_checksum(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_getValue(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_getValue___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_TypedIR_equalValue___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instDecidableEqFin___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(256) << 1) | 1))} };
static const lean_object* l_FormalSpecAgent_TypedIR_equalValue___closed__0 = (const lean_object*)&l_FormalSpecAgent_TypedIR_equalValue___closed__0_value;
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedIR_equalValue(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_equalValue___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_literal_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_literal_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_literal_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_variable_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_variable_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_variable_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_field_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_field_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_field_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_stateIs_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_stateIs_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_stateIs_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_timerActive_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_timerActive_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_timerActive_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_equal_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_equal_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_equal_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_notEqual_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_notEqual_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_notEqual_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_choose_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_choose_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_choose_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolAnd_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolAnd_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolAnd_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolOr_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolOr_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolOr_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolNot_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolNot_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolNot_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_implies_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_implies_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_implies_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_add_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_add_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_add_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_mul_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_mul_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_mul_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_sub_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_sub_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_sub_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_minimum_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_minimum_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_minimum_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intLe_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intLe_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intLe_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intGe_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intGe_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intGe_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqAdd_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqAdd_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqAdd_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqDistance_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqDistance_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqDistance_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqComparable_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqComparable_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqComparable_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLt_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLt_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLt_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLe_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLe_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLe_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_bytesLength_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_bytesLength_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_bytesLength_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_concat_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_concat_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_concat_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_slice_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_slice_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_slice_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_byteAt_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_byteAt_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_byteAt_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack8_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack8_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack8_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack16_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack16_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack16_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack32_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack32_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack32_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_checksum_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_checksum_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_checksum_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_eval(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_eval___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorIdx(uint8_t v_x_1_){
_start:
{
switch(v_x_1_)
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
case 2:
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
case 3:
{
lean_object* v___x_5_; 
v___x_5_ = lean_unsigned_to_nat(3u);
return v___x_5_;
}
default: 
{
lean_object* v___x_6_; 
v___x_6_ = lean_unsigned_to_nat(4u);
return v___x_6_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorIdx___boxed(lean_object* v_x_7_){
_start:
{
uint8_t v_x_boxed_8_; lean_object* v_res_9_; 
v_x_boxed_8_ = lean_unbox(v_x_7_);
v_res_9_ = l_FormalSpecAgent_TypedIR_Kind_ctorIdx(v_x_boxed_8_);
return v_res_9_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim___redArg(lean_object* v_k_10_){
_start:
{
lean_inc(v_k_10_);
return v_k_10_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim___redArg___boxed(lean_object* v_k_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = l_FormalSpecAgent_TypedIR_Kind_ctorElim___redArg(v_k_11_);
lean_dec(v_k_11_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim(lean_object* v_motive_13_, lean_object* v_ctorIdx_14_, uint8_t v_t_15_, lean_object* v_h_16_, lean_object* v_k_17_){
_start:
{
lean_inc(v_k_17_);
return v_k_17_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_ctorElim___boxed(lean_object* v_motive_18_, lean_object* v_ctorIdx_19_, lean_object* v_t_20_, lean_object* v_h_21_, lean_object* v_k_22_){
_start:
{
uint8_t v_t_boxed_23_; lean_object* v_res_24_; 
v_t_boxed_23_ = lean_unbox(v_t_20_);
v_res_24_ = l_FormalSpecAgent_TypedIR_Kind_ctorElim(v_motive_18_, v_ctorIdx_19_, v_t_boxed_23_, v_h_21_, v_k_22_);
lean_dec(v_k_22_);
lean_dec(v_ctorIdx_19_);
return v_res_24_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim___redArg(lean_object* v_integer_25_){
_start:
{
lean_inc(v_integer_25_);
return v_integer_25_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim___redArg___boxed(lean_object* v_integer_26_){
_start:
{
lean_object* v_res_27_; 
v_res_27_ = l_FormalSpecAgent_TypedIR_Kind_integer_elim___redArg(v_integer_26_);
lean_dec(v_integer_26_);
return v_res_27_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim(lean_object* v_motive_28_, uint8_t v_t_29_, lean_object* v_h_30_, lean_object* v_integer_31_){
_start:
{
lean_inc(v_integer_31_);
return v_integer_31_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_integer_elim___boxed(lean_object* v_motive_32_, lean_object* v_t_33_, lean_object* v_h_34_, lean_object* v_integer_35_){
_start:
{
uint8_t v_t_boxed_36_; lean_object* v_res_37_; 
v_t_boxed_36_ = lean_unbox(v_t_33_);
v_res_37_ = l_FormalSpecAgent_TypedIR_Kind_integer_elim(v_motive_32_, v_t_boxed_36_, v_h_34_, v_integer_35_);
lean_dec(v_integer_35_);
return v_res_37_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim___redArg(lean_object* v_boolean_38_){
_start:
{
lean_inc(v_boolean_38_);
return v_boolean_38_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim___redArg___boxed(lean_object* v_boolean_39_){
_start:
{
lean_object* v_res_40_; 
v_res_40_ = l_FormalSpecAgent_TypedIR_Kind_boolean_elim___redArg(v_boolean_39_);
lean_dec(v_boolean_39_);
return v_res_40_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim(lean_object* v_motive_41_, uint8_t v_t_42_, lean_object* v_h_43_, lean_object* v_boolean_44_){
_start:
{
lean_inc(v_boolean_44_);
return v_boolean_44_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_boolean_elim___boxed(lean_object* v_motive_45_, lean_object* v_t_46_, lean_object* v_h_47_, lean_object* v_boolean_48_){
_start:
{
uint8_t v_t_boxed_49_; lean_object* v_res_50_; 
v_t_boxed_49_ = lean_unbox(v_t_46_);
v_res_50_ = l_FormalSpecAgent_TypedIR_Kind_boolean_elim(v_motive_45_, v_t_boxed_49_, v_h_47_, v_boolean_48_);
lean_dec(v_boolean_48_);
return v_res_50_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim___redArg(lean_object* v_text_51_){
_start:
{
lean_inc(v_text_51_);
return v_text_51_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim___redArg___boxed(lean_object* v_text_52_){
_start:
{
lean_object* v_res_53_; 
v_res_53_ = l_FormalSpecAgent_TypedIR_Kind_text_elim___redArg(v_text_52_);
lean_dec(v_text_52_);
return v_res_53_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim(lean_object* v_motive_54_, uint8_t v_t_55_, lean_object* v_h_56_, lean_object* v_text_57_){
_start:
{
lean_inc(v_text_57_);
return v_text_57_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_text_elim___boxed(lean_object* v_motive_58_, lean_object* v_t_59_, lean_object* v_h_60_, lean_object* v_text_61_){
_start:
{
uint8_t v_t_boxed_62_; lean_object* v_res_63_; 
v_t_boxed_62_ = lean_unbox(v_t_59_);
v_res_63_ = l_FormalSpecAgent_TypedIR_Kind_text_elim(v_motive_58_, v_t_boxed_62_, v_h_60_, v_text_61_);
lean_dec(v_text_61_);
return v_res_63_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim___redArg(lean_object* v_octets_64_){
_start:
{
lean_inc(v_octets_64_);
return v_octets_64_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim___redArg___boxed(lean_object* v_octets_65_){
_start:
{
lean_object* v_res_66_; 
v_res_66_ = l_FormalSpecAgent_TypedIR_Kind_octets_elim___redArg(v_octets_65_);
lean_dec(v_octets_65_);
return v_res_66_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim(lean_object* v_motive_67_, uint8_t v_t_68_, lean_object* v_h_69_, lean_object* v_octets_70_){
_start:
{
lean_inc(v_octets_70_);
return v_octets_70_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_octets_elim___boxed(lean_object* v_motive_71_, lean_object* v_t_72_, lean_object* v_h_73_, lean_object* v_octets_74_){
_start:
{
uint8_t v_t_boxed_75_; lean_object* v_res_76_; 
v_t_boxed_75_ = lean_unbox(v_t_72_);
v_res_76_ = l_FormalSpecAgent_TypedIR_Kind_octets_elim(v_motive_71_, v_t_boxed_75_, v_h_73_, v_octets_74_);
lean_dec(v_octets_74_);
return v_res_76_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim___redArg(lean_object* v_sequence_77_){
_start:
{
lean_inc(v_sequence_77_);
return v_sequence_77_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim___redArg___boxed(lean_object* v_sequence_78_){
_start:
{
lean_object* v_res_79_; 
v_res_79_ = l_FormalSpecAgent_TypedIR_Kind_sequence_elim___redArg(v_sequence_78_);
lean_dec(v_sequence_78_);
return v_res_79_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim(lean_object* v_motive_80_, uint8_t v_t_81_, lean_object* v_h_82_, lean_object* v_sequence_83_){
_start:
{
lean_inc(v_sequence_83_);
return v_sequence_83_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Kind_sequence_elim___boxed(lean_object* v_motive_84_, lean_object* v_t_85_, lean_object* v_h_86_, lean_object* v_sequence_87_){
_start:
{
uint8_t v_t_boxed_88_; lean_object* v_res_89_; 
v_t_boxed_88_ = lean_unbox(v_t_85_);
v_res_89_ = l_FormalSpecAgent_TypedIR_Kind_sequence_elim(v_motive_84_, v_t_boxed_88_, v_h_86_, v_sequence_87_);
lean_dec(v_sequence_87_);
return v_res_89_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_getValue(uint8_t v_k_90_, lean_object* v_v_91_, lean_object* v_n_92_){
_start:
{
switch(v_k_90_)
{
case 0:
{
lean_object* v_integers_93_; lean_object* v___x_94_; 
v_integers_93_ = lean_ctor_get(v_v_91_, 0);
lean_inc_ref(v_integers_93_);
lean_dec_ref(v_v_91_);
v___x_94_ = lean_apply_1(v_integers_93_, v_n_92_);
return v___x_94_;
}
case 1:
{
lean_object* v_booleans_95_; lean_object* v___x_96_; 
v_booleans_95_ = lean_ctor_get(v_v_91_, 1);
lean_inc_ref(v_booleans_95_);
lean_dec_ref(v_v_91_);
v___x_96_ = lean_apply_1(v_booleans_95_, v_n_92_);
return v___x_96_;
}
case 2:
{
lean_object* v_texts_97_; lean_object* v___x_98_; 
v_texts_97_ = lean_ctor_get(v_v_91_, 2);
lean_inc_ref(v_texts_97_);
lean_dec_ref(v_v_91_);
v___x_98_ = lean_apply_1(v_texts_97_, v_n_92_);
return v___x_98_;
}
case 3:
{
lean_object* v_buffers_99_; lean_object* v___x_100_; 
v_buffers_99_ = lean_ctor_get(v_v_91_, 3);
lean_inc_ref(v_buffers_99_);
lean_dec_ref(v_v_91_);
v___x_100_ = lean_apply_1(v_buffers_99_, v_n_92_);
return v___x_100_;
}
default: 
{
lean_object* v_sequences_101_; lean_object* v___x_102_; 
v_sequences_101_ = lean_ctor_get(v_v_91_, 4);
lean_inc_ref(v_sequences_101_);
lean_dec_ref(v_v_91_);
v___x_102_ = lean_apply_1(v_sequences_101_, v_n_92_);
return v___x_102_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_getValue___boxed(lean_object* v_k_103_, lean_object* v_v_104_, lean_object* v_n_105_){
_start:
{
uint8_t v_k_boxed_106_; lean_object* v_res_107_; 
v_k_boxed_106_ = lean_unbox(v_k_103_);
v_res_107_ = l_FormalSpecAgent_TypedIR_getValue(v_k_boxed_106_, v_v_104_, v_n_105_);
return v_res_107_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_TypedIR_equalValue(uint8_t v_k_110_, lean_object* v_a_111_, lean_object* v_b_112_){
_start:
{
switch(v_k_110_)
{
case 0:
{
uint8_t v___x_113_; 
v___x_113_ = lean_int_dec_eq(v_a_111_, v_b_112_);
lean_dec(v_b_112_);
lean_dec(v_a_111_);
return v___x_113_;
}
case 1:
{
uint8_t v___x_114_; 
v___x_114_ = lean_unbox(v_b_112_);
if (v___x_114_ == 0)
{
uint8_t v___x_115_; 
v___x_115_ = lean_unbox(v_a_111_);
lean_dec(v_a_111_);
if (v___x_115_ == 0)
{
uint8_t v___x_116_; 
lean_dec(v_b_112_);
v___x_116_ = 1;
return v___x_116_;
}
else
{
uint8_t v___x_117_; 
v___x_117_ = lean_unbox(v_b_112_);
lean_dec(v_b_112_);
return v___x_117_;
}
}
else
{
uint8_t v___x_118_; 
lean_dec(v_b_112_);
v___x_118_ = lean_unbox(v_a_111_);
lean_dec(v_a_111_);
return v___x_118_;
}
}
case 2:
{
uint8_t v___x_119_; 
v___x_119_ = lean_string_dec_eq(v_a_111_, v_b_112_);
lean_dec(v_b_112_);
lean_dec(v_a_111_);
return v___x_119_;
}
case 3:
{
lean_object* v___x_120_; uint8_t v___x_121_; 
v___x_120_ = ((lean_object*)(l_FormalSpecAgent_TypedIR_equalValue___closed__0));
v___x_121_ = l_instDecidableEqList___redArg(v___x_120_, v_a_111_, v_b_112_);
return v___x_121_;
}
default: 
{
uint8_t v___x_122_; 
v___x_122_ = lean_nat_dec_eq(v_a_111_, v_b_112_);
lean_dec(v_b_112_);
lean_dec(v_a_111_);
return v___x_122_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_equalValue___boxed(lean_object* v_k_123_, lean_object* v_a_124_, lean_object* v_b_125_){
_start:
{
uint8_t v_k_boxed_126_; uint8_t v_res_127_; lean_object* v_r_128_; 
v_k_boxed_126_ = lean_unbox(v_k_123_);
v_res_127_ = l_FormalSpecAgent_TypedIR_equalValue(v_k_boxed_126_, v_a_124_, v_b_125_);
v_r_128_ = lean_box(v_res_127_);
return v_r_128_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx___redArg(lean_object* v_x_129_){
_start:
{
switch(lean_obj_tag(v_x_129_))
{
case 0:
{
lean_object* v___x_130_; 
v___x_130_ = lean_unsigned_to_nat(0u);
return v___x_130_;
}
case 1:
{
lean_object* v___x_131_; 
v___x_131_ = lean_unsigned_to_nat(1u);
return v___x_131_;
}
case 2:
{
lean_object* v___x_132_; 
v___x_132_ = lean_unsigned_to_nat(2u);
return v___x_132_;
}
case 3:
{
lean_object* v___x_133_; 
v___x_133_ = lean_unsigned_to_nat(3u);
return v___x_133_;
}
case 4:
{
lean_object* v___x_134_; 
v___x_134_ = lean_unsigned_to_nat(4u);
return v___x_134_;
}
case 5:
{
lean_object* v___x_135_; 
v___x_135_ = lean_unsigned_to_nat(5u);
return v___x_135_;
}
case 6:
{
lean_object* v___x_136_; 
v___x_136_ = lean_unsigned_to_nat(6u);
return v___x_136_;
}
case 7:
{
lean_object* v___x_137_; 
v___x_137_ = lean_unsigned_to_nat(7u);
return v___x_137_;
}
case 8:
{
lean_object* v___x_138_; 
v___x_138_ = lean_unsigned_to_nat(8u);
return v___x_138_;
}
case 9:
{
lean_object* v___x_139_; 
v___x_139_ = lean_unsigned_to_nat(9u);
return v___x_139_;
}
case 10:
{
lean_object* v___x_140_; 
v___x_140_ = lean_unsigned_to_nat(10u);
return v___x_140_;
}
case 11:
{
lean_object* v___x_141_; 
v___x_141_ = lean_unsigned_to_nat(11u);
return v___x_141_;
}
case 12:
{
lean_object* v___x_142_; 
v___x_142_ = lean_unsigned_to_nat(12u);
return v___x_142_;
}
case 13:
{
lean_object* v___x_143_; 
v___x_143_ = lean_unsigned_to_nat(13u);
return v___x_143_;
}
case 14:
{
lean_object* v___x_144_; 
v___x_144_ = lean_unsigned_to_nat(14u);
return v___x_144_;
}
case 15:
{
lean_object* v___x_145_; 
v___x_145_ = lean_unsigned_to_nat(15u);
return v___x_145_;
}
case 16:
{
lean_object* v___x_146_; 
v___x_146_ = lean_unsigned_to_nat(16u);
return v___x_146_;
}
case 17:
{
lean_object* v___x_147_; 
v___x_147_ = lean_unsigned_to_nat(17u);
return v___x_147_;
}
case 18:
{
lean_object* v___x_148_; 
v___x_148_ = lean_unsigned_to_nat(18u);
return v___x_148_;
}
case 19:
{
lean_object* v___x_149_; 
v___x_149_ = lean_unsigned_to_nat(19u);
return v___x_149_;
}
case 20:
{
lean_object* v___x_150_; 
v___x_150_ = lean_unsigned_to_nat(20u);
return v___x_150_;
}
case 21:
{
lean_object* v___x_151_; 
v___x_151_ = lean_unsigned_to_nat(21u);
return v___x_151_;
}
case 22:
{
lean_object* v___x_152_; 
v___x_152_ = lean_unsigned_to_nat(22u);
return v___x_152_;
}
case 23:
{
lean_object* v___x_153_; 
v___x_153_ = lean_unsigned_to_nat(23u);
return v___x_153_;
}
case 24:
{
lean_object* v___x_154_; 
v___x_154_ = lean_unsigned_to_nat(24u);
return v___x_154_;
}
case 25:
{
lean_object* v___x_155_; 
v___x_155_ = lean_unsigned_to_nat(25u);
return v___x_155_;
}
case 26:
{
lean_object* v___x_156_; 
v___x_156_ = lean_unsigned_to_nat(26u);
return v___x_156_;
}
case 27:
{
lean_object* v___x_157_; 
v___x_157_ = lean_unsigned_to_nat(27u);
return v___x_157_;
}
case 28:
{
lean_object* v___x_158_; 
v___x_158_ = lean_unsigned_to_nat(28u);
return v___x_158_;
}
case 29:
{
lean_object* v___x_159_; 
v___x_159_ = lean_unsigned_to_nat(29u);
return v___x_159_;
}
default: 
{
lean_object* v___x_160_; 
v___x_160_ = lean_unsigned_to_nat(30u);
return v___x_160_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx___redArg___boxed(lean_object* v_x_161_){
_start:
{
lean_object* v_res_162_; 
v_res_162_ = l_FormalSpecAgent_TypedIR_Expr_ctorIdx___redArg(v_x_161_);
lean_dec_ref(v_x_161_);
return v_res_162_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx(uint8_t v_a_163_, lean_object* v_x_164_){
_start:
{
lean_object* v___x_165_; 
v___x_165_ = l_FormalSpecAgent_TypedIR_Expr_ctorIdx___redArg(v_x_164_);
return v___x_165_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorIdx___boxed(lean_object* v_a_166_, lean_object* v_x_167_){
_start:
{
uint8_t v_a_205__boxed_168_; lean_object* v_res_169_; 
v_a_205__boxed_168_ = lean_unbox(v_a_166_);
v_res_169_ = l_FormalSpecAgent_TypedIR_Expr_ctorIdx(v_a_205__boxed_168_, v_x_167_);
lean_dec_ref(v_x_167_);
return v_res_169_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(lean_object* v_t_170_, lean_object* v_k_171_){
_start:
{
switch(lean_obj_tag(v_t_170_))
{
case 0:
{
uint8_t v_k_172_; lean_object* v_a_173_; lean_object* v___x_174_; lean_object* v___x_175_; 
v_k_172_ = lean_ctor_get_uint8(v_t_170_, sizeof(void*)*1);
v_a_173_ = lean_ctor_get(v_t_170_, 0);
lean_inc(v_a_173_);
lean_dec_ref_known(v_t_170_, 1);
v___x_174_ = lean_box(v_k_172_);
v___x_175_ = lean_apply_2(v_k_171_, v___x_174_, v_a_173_);
return v___x_175_;
}
case 1:
{
uint8_t v_k_176_; lean_object* v_a_177_; lean_object* v___x_178_; lean_object* v___x_179_; 
v_k_176_ = lean_ctor_get_uint8(v_t_170_, sizeof(void*)*1);
v_a_177_ = lean_ctor_get(v_t_170_, 0);
lean_inc(v_a_177_);
lean_dec_ref_known(v_t_170_, 1);
v___x_178_ = lean_box(v_k_176_);
v___x_179_ = lean_apply_2(v_k_171_, v___x_178_, v_a_177_);
return v___x_179_;
}
case 2:
{
uint8_t v_k_180_; lean_object* v_a_181_; lean_object* v___x_182_; lean_object* v___x_183_; 
v_k_180_ = lean_ctor_get_uint8(v_t_170_, sizeof(void*)*1);
v_a_181_ = lean_ctor_get(v_t_170_, 0);
lean_inc(v_a_181_);
lean_dec_ref_known(v_t_170_, 1);
v___x_182_ = lean_box(v_k_180_);
v___x_183_ = lean_apply_2(v_k_171_, v___x_182_, v_a_181_);
return v___x_183_;
}
case 3:
{
lean_object* v_a_184_; lean_object* v___x_185_; 
v_a_184_ = lean_ctor_get(v_t_170_, 0);
lean_inc(v_a_184_);
lean_dec_ref_known(v_t_170_, 1);
v___x_185_ = lean_apply_1(v_k_171_, v_a_184_);
return v___x_185_;
}
case 4:
{
lean_object* v_a_186_; lean_object* v___x_187_; 
v_a_186_ = lean_ctor_get(v_t_170_, 0);
lean_inc(v_a_186_);
lean_dec_ref_known(v_t_170_, 1);
v___x_187_ = lean_apply_1(v_k_171_, v_a_186_);
return v___x_187_;
}
case 5:
{
uint8_t v_k_188_; lean_object* v_a_189_; lean_object* v_a_190_; lean_object* v___x_191_; lean_object* v___x_192_; 
v_k_188_ = lean_ctor_get_uint8(v_t_170_, sizeof(void*)*2);
v_a_189_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_189_);
v_a_190_ = lean_ctor_get(v_t_170_, 1);
lean_inc_ref(v_a_190_);
lean_dec_ref_known(v_t_170_, 2);
v___x_191_ = lean_box(v_k_188_);
v___x_192_ = lean_apply_3(v_k_171_, v___x_191_, v_a_189_, v_a_190_);
return v___x_192_;
}
case 6:
{
uint8_t v_k_193_; lean_object* v_a_194_; lean_object* v_a_195_; lean_object* v___x_196_; lean_object* v___x_197_; 
v_k_193_ = lean_ctor_get_uint8(v_t_170_, sizeof(void*)*2);
v_a_194_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_194_);
v_a_195_ = lean_ctor_get(v_t_170_, 1);
lean_inc_ref(v_a_195_);
lean_dec_ref_known(v_t_170_, 2);
v___x_196_ = lean_box(v_k_193_);
v___x_197_ = lean_apply_3(v_k_171_, v___x_196_, v_a_194_, v_a_195_);
return v___x_197_;
}
case 7:
{
uint8_t v_k_198_; lean_object* v_a_199_; lean_object* v_a_200_; lean_object* v_a_201_; lean_object* v___x_202_; lean_object* v___x_203_; 
v_k_198_ = lean_ctor_get_uint8(v_t_170_, sizeof(void*)*3);
v_a_199_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_199_);
v_a_200_ = lean_ctor_get(v_t_170_, 1);
lean_inc_ref(v_a_200_);
v_a_201_ = lean_ctor_get(v_t_170_, 2);
lean_inc_ref(v_a_201_);
lean_dec_ref_known(v_t_170_, 3);
v___x_202_ = lean_box(v_k_198_);
v___x_203_ = lean_apply_4(v_k_171_, v___x_202_, v_a_199_, v_a_200_, v_a_201_);
return v___x_203_;
}
case 10:
{
lean_object* v_a_204_; lean_object* v___x_205_; 
v_a_204_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_204_);
lean_dec_ref_known(v_t_170_, 1);
v___x_205_ = lean_apply_1(v_k_171_, v_a_204_);
return v___x_205_;
}
case 23:
{
lean_object* v_a_206_; lean_object* v___x_207_; 
v_a_206_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_206_);
lean_dec_ref_known(v_t_170_, 1);
v___x_207_ = lean_apply_1(v_k_171_, v_a_206_);
return v___x_207_;
}
case 25:
{
lean_object* v_a_208_; lean_object* v_a_209_; lean_object* v_a_210_; lean_object* v___x_211_; 
v_a_208_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_208_);
v_a_209_ = lean_ctor_get(v_t_170_, 1);
lean_inc_ref(v_a_209_);
v_a_210_ = lean_ctor_get(v_t_170_, 2);
lean_inc_ref(v_a_210_);
lean_dec_ref_known(v_t_170_, 3);
v___x_211_ = lean_apply_3(v_k_171_, v_a_208_, v_a_209_, v_a_210_);
return v___x_211_;
}
case 27:
{
lean_object* v_a_212_; lean_object* v___x_213_; 
v_a_212_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_212_);
lean_dec_ref_known(v_t_170_, 1);
v___x_213_ = lean_apply_1(v_k_171_, v_a_212_);
return v___x_213_;
}
case 28:
{
lean_object* v_a_214_; lean_object* v___x_215_; 
v_a_214_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_214_);
lean_dec_ref_known(v_t_170_, 1);
v___x_215_ = lean_apply_1(v_k_171_, v_a_214_);
return v___x_215_;
}
case 29:
{
lean_object* v_a_216_; lean_object* v___x_217_; 
v_a_216_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_216_);
lean_dec_ref_known(v_t_170_, 1);
v___x_217_ = lean_apply_1(v_k_171_, v_a_216_);
return v___x_217_;
}
case 30:
{
lean_object* v_a_218_; lean_object* v___x_219_; 
v_a_218_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_218_);
lean_dec_ref_known(v_t_170_, 1);
v___x_219_ = lean_apply_1(v_k_171_, v_a_218_);
return v___x_219_;
}
default: 
{
lean_object* v_a_220_; lean_object* v_a_221_; lean_object* v___x_222_; 
v_a_220_ = lean_ctor_get(v_t_170_, 0);
lean_inc_ref(v_a_220_);
v_a_221_ = lean_ctor_get(v_t_170_, 1);
lean_inc_ref(v_a_221_);
lean_dec_ref(v_t_170_);
v___x_222_ = lean_apply_2(v_k_171_, v_a_220_, v_a_221_);
return v___x_222_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorElim(lean_object* v_motive_223_, lean_object* v_ctorIdx_224_, uint8_t v_a_225_, lean_object* v_t_226_, lean_object* v_h_227_, lean_object* v_k_228_){
_start:
{
lean_object* v___x_229_; 
v___x_229_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_226_, v_k_228_);
return v___x_229_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_ctorElim___boxed(lean_object* v_motive_230_, lean_object* v_ctorIdx_231_, lean_object* v_a_232_, lean_object* v_t_233_, lean_object* v_h_234_, lean_object* v_k_235_){
_start:
{
uint8_t v_a_256__boxed_236_; lean_object* v_res_237_; 
v_a_256__boxed_236_ = lean_unbox(v_a_232_);
v_res_237_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim(v_motive_230_, v_ctorIdx_231_, v_a_256__boxed_236_, v_t_233_, v_h_234_, v_k_235_);
lean_dec(v_ctorIdx_231_);
return v_res_237_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_literal_elim___redArg(lean_object* v_t_238_, lean_object* v_literal_239_){
_start:
{
lean_object* v___x_240_; 
v___x_240_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_238_, v_literal_239_);
return v___x_240_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_literal_elim(lean_object* v_motive_241_, uint8_t v_a_242_, lean_object* v_t_243_, lean_object* v_h_244_, lean_object* v_literal_245_){
_start:
{
lean_object* v___x_246_; 
v___x_246_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_243_, v_literal_245_);
return v___x_246_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_literal_elim___boxed(lean_object* v_motive_247_, lean_object* v_a_248_, lean_object* v_t_249_, lean_object* v_h_250_, lean_object* v_literal_251_){
_start:
{
uint8_t v_a_12__boxed_252_; lean_object* v_res_253_; 
v_a_12__boxed_252_ = lean_unbox(v_a_248_);
v_res_253_ = l_FormalSpecAgent_TypedIR_Expr_literal_elim(v_motive_247_, v_a_12__boxed_252_, v_t_249_, v_h_250_, v_literal_251_);
return v_res_253_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_variable_elim___redArg(lean_object* v_t_254_, lean_object* v_variable_255_){
_start:
{
lean_object* v___x_256_; 
v___x_256_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_254_, v_variable_255_);
return v___x_256_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_variable_elim(lean_object* v_motive_257_, uint8_t v_a_258_, lean_object* v_t_259_, lean_object* v_h_260_, lean_object* v_variable_261_){
_start:
{
lean_object* v___x_262_; 
v___x_262_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_259_, v_variable_261_);
return v___x_262_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_variable_elim___boxed(lean_object* v_motive_263_, lean_object* v_a_264_, lean_object* v_t_265_, lean_object* v_h_266_, lean_object* v_variable_267_){
_start:
{
uint8_t v_a_12__boxed_268_; lean_object* v_res_269_; 
v_a_12__boxed_268_ = lean_unbox(v_a_264_);
v_res_269_ = l_FormalSpecAgent_TypedIR_Expr_variable_elim(v_motive_263_, v_a_12__boxed_268_, v_t_265_, v_h_266_, v_variable_267_);
return v_res_269_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_field_elim___redArg(lean_object* v_t_270_, lean_object* v_field_271_){
_start:
{
lean_object* v___x_272_; 
v___x_272_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_270_, v_field_271_);
return v___x_272_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_field_elim(lean_object* v_motive_273_, uint8_t v_a_274_, lean_object* v_t_275_, lean_object* v_h_276_, lean_object* v_field_277_){
_start:
{
lean_object* v___x_278_; 
v___x_278_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_275_, v_field_277_);
return v___x_278_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_field_elim___boxed(lean_object* v_motive_279_, lean_object* v_a_280_, lean_object* v_t_281_, lean_object* v_h_282_, lean_object* v_field_283_){
_start:
{
uint8_t v_a_12__boxed_284_; lean_object* v_res_285_; 
v_a_12__boxed_284_ = lean_unbox(v_a_280_);
v_res_285_ = l_FormalSpecAgent_TypedIR_Expr_field_elim(v_motive_279_, v_a_12__boxed_284_, v_t_281_, v_h_282_, v_field_283_);
return v_res_285_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_stateIs_elim___redArg(lean_object* v_t_286_, lean_object* v_stateIs_287_){
_start:
{
lean_object* v___x_288_; 
v___x_288_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_286_, v_stateIs_287_);
return v___x_288_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_stateIs_elim(lean_object* v_motive_289_, uint8_t v_a_290_, lean_object* v_t_291_, lean_object* v_h_292_, lean_object* v_stateIs_293_){
_start:
{
lean_object* v___x_294_; 
v___x_294_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_291_, v_stateIs_293_);
return v___x_294_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_stateIs_elim___boxed(lean_object* v_motive_295_, lean_object* v_a_296_, lean_object* v_t_297_, lean_object* v_h_298_, lean_object* v_stateIs_299_){
_start:
{
uint8_t v_a_12__boxed_300_; lean_object* v_res_301_; 
v_a_12__boxed_300_ = lean_unbox(v_a_296_);
v_res_301_ = l_FormalSpecAgent_TypedIR_Expr_stateIs_elim(v_motive_295_, v_a_12__boxed_300_, v_t_297_, v_h_298_, v_stateIs_299_);
return v_res_301_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_timerActive_elim___redArg(lean_object* v_t_302_, lean_object* v_timerActive_303_){
_start:
{
lean_object* v___x_304_; 
v___x_304_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_302_, v_timerActive_303_);
return v___x_304_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_timerActive_elim(lean_object* v_motive_305_, uint8_t v_a_306_, lean_object* v_t_307_, lean_object* v_h_308_, lean_object* v_timerActive_309_){
_start:
{
lean_object* v___x_310_; 
v___x_310_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_307_, v_timerActive_309_);
return v___x_310_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_timerActive_elim___boxed(lean_object* v_motive_311_, lean_object* v_a_312_, lean_object* v_t_313_, lean_object* v_h_314_, lean_object* v_timerActive_315_){
_start:
{
uint8_t v_a_12__boxed_316_; lean_object* v_res_317_; 
v_a_12__boxed_316_ = lean_unbox(v_a_312_);
v_res_317_ = l_FormalSpecAgent_TypedIR_Expr_timerActive_elim(v_motive_311_, v_a_12__boxed_316_, v_t_313_, v_h_314_, v_timerActive_315_);
return v_res_317_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_equal_elim___redArg(lean_object* v_t_318_, lean_object* v_equal_319_){
_start:
{
lean_object* v___x_320_; 
v___x_320_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_318_, v_equal_319_);
return v___x_320_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_equal_elim(lean_object* v_motive_321_, uint8_t v_a_322_, lean_object* v_t_323_, lean_object* v_h_324_, lean_object* v_equal_325_){
_start:
{
lean_object* v___x_326_; 
v___x_326_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_323_, v_equal_325_);
return v___x_326_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_equal_elim___boxed(lean_object* v_motive_327_, lean_object* v_a_328_, lean_object* v_t_329_, lean_object* v_h_330_, lean_object* v_equal_331_){
_start:
{
uint8_t v_a_12__boxed_332_; lean_object* v_res_333_; 
v_a_12__boxed_332_ = lean_unbox(v_a_328_);
v_res_333_ = l_FormalSpecAgent_TypedIR_Expr_equal_elim(v_motive_327_, v_a_12__boxed_332_, v_t_329_, v_h_330_, v_equal_331_);
return v_res_333_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_notEqual_elim___redArg(lean_object* v_t_334_, lean_object* v_notEqual_335_){
_start:
{
lean_object* v___x_336_; 
v___x_336_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_334_, v_notEqual_335_);
return v___x_336_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_notEqual_elim(lean_object* v_motive_337_, uint8_t v_a_338_, lean_object* v_t_339_, lean_object* v_h_340_, lean_object* v_notEqual_341_){
_start:
{
lean_object* v___x_342_; 
v___x_342_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_339_, v_notEqual_341_);
return v___x_342_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_notEqual_elim___boxed(lean_object* v_motive_343_, lean_object* v_a_344_, lean_object* v_t_345_, lean_object* v_h_346_, lean_object* v_notEqual_347_){
_start:
{
uint8_t v_a_12__boxed_348_; lean_object* v_res_349_; 
v_a_12__boxed_348_ = lean_unbox(v_a_344_);
v_res_349_ = l_FormalSpecAgent_TypedIR_Expr_notEqual_elim(v_motive_343_, v_a_12__boxed_348_, v_t_345_, v_h_346_, v_notEqual_347_);
return v_res_349_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_choose_elim___redArg(lean_object* v_t_350_, lean_object* v_choose_351_){
_start:
{
lean_object* v___x_352_; 
v___x_352_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_350_, v_choose_351_);
return v___x_352_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_choose_elim(lean_object* v_motive_353_, uint8_t v_a_354_, lean_object* v_t_355_, lean_object* v_h_356_, lean_object* v_choose_357_){
_start:
{
lean_object* v___x_358_; 
v___x_358_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_355_, v_choose_357_);
return v___x_358_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_choose_elim___boxed(lean_object* v_motive_359_, lean_object* v_a_360_, lean_object* v_t_361_, lean_object* v_h_362_, lean_object* v_choose_363_){
_start:
{
uint8_t v_a_12__boxed_364_; lean_object* v_res_365_; 
v_a_12__boxed_364_ = lean_unbox(v_a_360_);
v_res_365_ = l_FormalSpecAgent_TypedIR_Expr_choose_elim(v_motive_359_, v_a_12__boxed_364_, v_t_361_, v_h_362_, v_choose_363_);
return v_res_365_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolAnd_elim___redArg(lean_object* v_t_366_, lean_object* v_boolAnd_367_){
_start:
{
lean_object* v___x_368_; 
v___x_368_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_366_, v_boolAnd_367_);
return v___x_368_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolAnd_elim(lean_object* v_motive_369_, uint8_t v_a_370_, lean_object* v_t_371_, lean_object* v_h_372_, lean_object* v_boolAnd_373_){
_start:
{
lean_object* v___x_374_; 
v___x_374_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_371_, v_boolAnd_373_);
return v___x_374_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolAnd_elim___boxed(lean_object* v_motive_375_, lean_object* v_a_376_, lean_object* v_t_377_, lean_object* v_h_378_, lean_object* v_boolAnd_379_){
_start:
{
uint8_t v_a_12__boxed_380_; lean_object* v_res_381_; 
v_a_12__boxed_380_ = lean_unbox(v_a_376_);
v_res_381_ = l_FormalSpecAgent_TypedIR_Expr_boolAnd_elim(v_motive_375_, v_a_12__boxed_380_, v_t_377_, v_h_378_, v_boolAnd_379_);
return v_res_381_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolOr_elim___redArg(lean_object* v_t_382_, lean_object* v_boolOr_383_){
_start:
{
lean_object* v___x_384_; 
v___x_384_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_382_, v_boolOr_383_);
return v___x_384_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolOr_elim(lean_object* v_motive_385_, uint8_t v_a_386_, lean_object* v_t_387_, lean_object* v_h_388_, lean_object* v_boolOr_389_){
_start:
{
lean_object* v___x_390_; 
v___x_390_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_387_, v_boolOr_389_);
return v___x_390_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolOr_elim___boxed(lean_object* v_motive_391_, lean_object* v_a_392_, lean_object* v_t_393_, lean_object* v_h_394_, lean_object* v_boolOr_395_){
_start:
{
uint8_t v_a_12__boxed_396_; lean_object* v_res_397_; 
v_a_12__boxed_396_ = lean_unbox(v_a_392_);
v_res_397_ = l_FormalSpecAgent_TypedIR_Expr_boolOr_elim(v_motive_391_, v_a_12__boxed_396_, v_t_393_, v_h_394_, v_boolOr_395_);
return v_res_397_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolNot_elim___redArg(lean_object* v_t_398_, lean_object* v_boolNot_399_){
_start:
{
lean_object* v___x_400_; 
v___x_400_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_398_, v_boolNot_399_);
return v___x_400_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolNot_elim(lean_object* v_motive_401_, uint8_t v_a_402_, lean_object* v_t_403_, lean_object* v_h_404_, lean_object* v_boolNot_405_){
_start:
{
lean_object* v___x_406_; 
v___x_406_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_403_, v_boolNot_405_);
return v___x_406_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_boolNot_elim___boxed(lean_object* v_motive_407_, lean_object* v_a_408_, lean_object* v_t_409_, lean_object* v_h_410_, lean_object* v_boolNot_411_){
_start:
{
uint8_t v_a_12__boxed_412_; lean_object* v_res_413_; 
v_a_12__boxed_412_ = lean_unbox(v_a_408_);
v_res_413_ = l_FormalSpecAgent_TypedIR_Expr_boolNot_elim(v_motive_407_, v_a_12__boxed_412_, v_t_409_, v_h_410_, v_boolNot_411_);
return v_res_413_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_implies_elim___redArg(lean_object* v_t_414_, lean_object* v_implies_415_){
_start:
{
lean_object* v___x_416_; 
v___x_416_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_414_, v_implies_415_);
return v___x_416_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_implies_elim(lean_object* v_motive_417_, uint8_t v_a_418_, lean_object* v_t_419_, lean_object* v_h_420_, lean_object* v_implies_421_){
_start:
{
lean_object* v___x_422_; 
v___x_422_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_419_, v_implies_421_);
return v___x_422_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_implies_elim___boxed(lean_object* v_motive_423_, lean_object* v_a_424_, lean_object* v_t_425_, lean_object* v_h_426_, lean_object* v_implies_427_){
_start:
{
uint8_t v_a_12__boxed_428_; lean_object* v_res_429_; 
v_a_12__boxed_428_ = lean_unbox(v_a_424_);
v_res_429_ = l_FormalSpecAgent_TypedIR_Expr_implies_elim(v_motive_423_, v_a_12__boxed_428_, v_t_425_, v_h_426_, v_implies_427_);
return v_res_429_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_add_elim___redArg(lean_object* v_t_430_, lean_object* v_add_431_){
_start:
{
lean_object* v___x_432_; 
v___x_432_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_430_, v_add_431_);
return v___x_432_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_add_elim(lean_object* v_motive_433_, uint8_t v_a_434_, lean_object* v_t_435_, lean_object* v_h_436_, lean_object* v_add_437_){
_start:
{
lean_object* v___x_438_; 
v___x_438_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_435_, v_add_437_);
return v___x_438_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_add_elim___boxed(lean_object* v_motive_439_, lean_object* v_a_440_, lean_object* v_t_441_, lean_object* v_h_442_, lean_object* v_add_443_){
_start:
{
uint8_t v_a_12__boxed_444_; lean_object* v_res_445_; 
v_a_12__boxed_444_ = lean_unbox(v_a_440_);
v_res_445_ = l_FormalSpecAgent_TypedIR_Expr_add_elim(v_motive_439_, v_a_12__boxed_444_, v_t_441_, v_h_442_, v_add_443_);
return v_res_445_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_mul_elim___redArg(lean_object* v_t_446_, lean_object* v_mul_447_){
_start:
{
lean_object* v___x_448_; 
v___x_448_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_446_, v_mul_447_);
return v___x_448_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_mul_elim(lean_object* v_motive_449_, uint8_t v_a_450_, lean_object* v_t_451_, lean_object* v_h_452_, lean_object* v_mul_453_){
_start:
{
lean_object* v___x_454_; 
v___x_454_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_451_, v_mul_453_);
return v___x_454_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_mul_elim___boxed(lean_object* v_motive_455_, lean_object* v_a_456_, lean_object* v_t_457_, lean_object* v_h_458_, lean_object* v_mul_459_){
_start:
{
uint8_t v_a_12__boxed_460_; lean_object* v_res_461_; 
v_a_12__boxed_460_ = lean_unbox(v_a_456_);
v_res_461_ = l_FormalSpecAgent_TypedIR_Expr_mul_elim(v_motive_455_, v_a_12__boxed_460_, v_t_457_, v_h_458_, v_mul_459_);
return v_res_461_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_sub_elim___redArg(lean_object* v_t_462_, lean_object* v_sub_463_){
_start:
{
lean_object* v___x_464_; 
v___x_464_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_462_, v_sub_463_);
return v___x_464_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_sub_elim(lean_object* v_motive_465_, uint8_t v_a_466_, lean_object* v_t_467_, lean_object* v_h_468_, lean_object* v_sub_469_){
_start:
{
lean_object* v___x_470_; 
v___x_470_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_467_, v_sub_469_);
return v___x_470_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_sub_elim___boxed(lean_object* v_motive_471_, lean_object* v_a_472_, lean_object* v_t_473_, lean_object* v_h_474_, lean_object* v_sub_475_){
_start:
{
uint8_t v_a_12__boxed_476_; lean_object* v_res_477_; 
v_a_12__boxed_476_ = lean_unbox(v_a_472_);
v_res_477_ = l_FormalSpecAgent_TypedIR_Expr_sub_elim(v_motive_471_, v_a_12__boxed_476_, v_t_473_, v_h_474_, v_sub_475_);
return v_res_477_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_minimum_elim___redArg(lean_object* v_t_478_, lean_object* v_minimum_479_){
_start:
{
lean_object* v___x_480_; 
v___x_480_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_478_, v_minimum_479_);
return v___x_480_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_minimum_elim(lean_object* v_motive_481_, uint8_t v_a_482_, lean_object* v_t_483_, lean_object* v_h_484_, lean_object* v_minimum_485_){
_start:
{
lean_object* v___x_486_; 
v___x_486_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_483_, v_minimum_485_);
return v___x_486_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_minimum_elim___boxed(lean_object* v_motive_487_, lean_object* v_a_488_, lean_object* v_t_489_, lean_object* v_h_490_, lean_object* v_minimum_491_){
_start:
{
uint8_t v_a_12__boxed_492_; lean_object* v_res_493_; 
v_a_12__boxed_492_ = lean_unbox(v_a_488_);
v_res_493_ = l_FormalSpecAgent_TypedIR_Expr_minimum_elim(v_motive_487_, v_a_12__boxed_492_, v_t_489_, v_h_490_, v_minimum_491_);
return v_res_493_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intLe_elim___redArg(lean_object* v_t_494_, lean_object* v_intLe_495_){
_start:
{
lean_object* v___x_496_; 
v___x_496_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_494_, v_intLe_495_);
return v___x_496_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intLe_elim(lean_object* v_motive_497_, uint8_t v_a_498_, lean_object* v_t_499_, lean_object* v_h_500_, lean_object* v_intLe_501_){
_start:
{
lean_object* v___x_502_; 
v___x_502_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_499_, v_intLe_501_);
return v___x_502_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intLe_elim___boxed(lean_object* v_motive_503_, lean_object* v_a_504_, lean_object* v_t_505_, lean_object* v_h_506_, lean_object* v_intLe_507_){
_start:
{
uint8_t v_a_12__boxed_508_; lean_object* v_res_509_; 
v_a_12__boxed_508_ = lean_unbox(v_a_504_);
v_res_509_ = l_FormalSpecAgent_TypedIR_Expr_intLe_elim(v_motive_503_, v_a_12__boxed_508_, v_t_505_, v_h_506_, v_intLe_507_);
return v_res_509_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intGe_elim___redArg(lean_object* v_t_510_, lean_object* v_intGe_511_){
_start:
{
lean_object* v___x_512_; 
v___x_512_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_510_, v_intGe_511_);
return v___x_512_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intGe_elim(lean_object* v_motive_513_, uint8_t v_a_514_, lean_object* v_t_515_, lean_object* v_h_516_, lean_object* v_intGe_517_){
_start:
{
lean_object* v___x_518_; 
v___x_518_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_515_, v_intGe_517_);
return v___x_518_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_intGe_elim___boxed(lean_object* v_motive_519_, lean_object* v_a_520_, lean_object* v_t_521_, lean_object* v_h_522_, lean_object* v_intGe_523_){
_start:
{
uint8_t v_a_12__boxed_524_; lean_object* v_res_525_; 
v_a_12__boxed_524_ = lean_unbox(v_a_520_);
v_res_525_ = l_FormalSpecAgent_TypedIR_Expr_intGe_elim(v_motive_519_, v_a_12__boxed_524_, v_t_521_, v_h_522_, v_intGe_523_);
return v_res_525_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqAdd_elim___redArg(lean_object* v_t_526_, lean_object* v_seqAdd_527_){
_start:
{
lean_object* v___x_528_; 
v___x_528_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_526_, v_seqAdd_527_);
return v___x_528_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqAdd_elim(lean_object* v_motive_529_, uint8_t v_a_530_, lean_object* v_t_531_, lean_object* v_h_532_, lean_object* v_seqAdd_533_){
_start:
{
lean_object* v___x_534_; 
v___x_534_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_531_, v_seqAdd_533_);
return v___x_534_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqAdd_elim___boxed(lean_object* v_motive_535_, lean_object* v_a_536_, lean_object* v_t_537_, lean_object* v_h_538_, lean_object* v_seqAdd_539_){
_start:
{
uint8_t v_a_12__boxed_540_; lean_object* v_res_541_; 
v_a_12__boxed_540_ = lean_unbox(v_a_536_);
v_res_541_ = l_FormalSpecAgent_TypedIR_Expr_seqAdd_elim(v_motive_535_, v_a_12__boxed_540_, v_t_537_, v_h_538_, v_seqAdd_539_);
return v_res_541_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqDistance_elim___redArg(lean_object* v_t_542_, lean_object* v_seqDistance_543_){
_start:
{
lean_object* v___x_544_; 
v___x_544_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_542_, v_seqDistance_543_);
return v___x_544_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqDistance_elim(lean_object* v_motive_545_, uint8_t v_a_546_, lean_object* v_t_547_, lean_object* v_h_548_, lean_object* v_seqDistance_549_){
_start:
{
lean_object* v___x_550_; 
v___x_550_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_547_, v_seqDistance_549_);
return v___x_550_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqDistance_elim___boxed(lean_object* v_motive_551_, lean_object* v_a_552_, lean_object* v_t_553_, lean_object* v_h_554_, lean_object* v_seqDistance_555_){
_start:
{
uint8_t v_a_12__boxed_556_; lean_object* v_res_557_; 
v_a_12__boxed_556_ = lean_unbox(v_a_552_);
v_res_557_ = l_FormalSpecAgent_TypedIR_Expr_seqDistance_elim(v_motive_551_, v_a_12__boxed_556_, v_t_553_, v_h_554_, v_seqDistance_555_);
return v_res_557_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqComparable_elim___redArg(lean_object* v_t_558_, lean_object* v_seqComparable_559_){
_start:
{
lean_object* v___x_560_; 
v___x_560_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_558_, v_seqComparable_559_);
return v___x_560_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqComparable_elim(lean_object* v_motive_561_, uint8_t v_a_562_, lean_object* v_t_563_, lean_object* v_h_564_, lean_object* v_seqComparable_565_){
_start:
{
lean_object* v___x_566_; 
v___x_566_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_563_, v_seqComparable_565_);
return v___x_566_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqComparable_elim___boxed(lean_object* v_motive_567_, lean_object* v_a_568_, lean_object* v_t_569_, lean_object* v_h_570_, lean_object* v_seqComparable_571_){
_start:
{
uint8_t v_a_12__boxed_572_; lean_object* v_res_573_; 
v_a_12__boxed_572_ = lean_unbox(v_a_568_);
v_res_573_ = l_FormalSpecAgent_TypedIR_Expr_seqComparable_elim(v_motive_567_, v_a_12__boxed_572_, v_t_569_, v_h_570_, v_seqComparable_571_);
return v_res_573_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLt_elim___redArg(lean_object* v_t_574_, lean_object* v_seqLt_575_){
_start:
{
lean_object* v___x_576_; 
v___x_576_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_574_, v_seqLt_575_);
return v___x_576_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLt_elim(lean_object* v_motive_577_, uint8_t v_a_578_, lean_object* v_t_579_, lean_object* v_h_580_, lean_object* v_seqLt_581_){
_start:
{
lean_object* v___x_582_; 
v___x_582_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_579_, v_seqLt_581_);
return v___x_582_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLt_elim___boxed(lean_object* v_motive_583_, lean_object* v_a_584_, lean_object* v_t_585_, lean_object* v_h_586_, lean_object* v_seqLt_587_){
_start:
{
uint8_t v_a_12__boxed_588_; lean_object* v_res_589_; 
v_a_12__boxed_588_ = lean_unbox(v_a_584_);
v_res_589_ = l_FormalSpecAgent_TypedIR_Expr_seqLt_elim(v_motive_583_, v_a_12__boxed_588_, v_t_585_, v_h_586_, v_seqLt_587_);
return v_res_589_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLe_elim___redArg(lean_object* v_t_590_, lean_object* v_seqLe_591_){
_start:
{
lean_object* v___x_592_; 
v___x_592_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_590_, v_seqLe_591_);
return v___x_592_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLe_elim(lean_object* v_motive_593_, uint8_t v_a_594_, lean_object* v_t_595_, lean_object* v_h_596_, lean_object* v_seqLe_597_){
_start:
{
lean_object* v___x_598_; 
v___x_598_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_595_, v_seqLe_597_);
return v___x_598_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_seqLe_elim___boxed(lean_object* v_motive_599_, lean_object* v_a_600_, lean_object* v_t_601_, lean_object* v_h_602_, lean_object* v_seqLe_603_){
_start:
{
uint8_t v_a_12__boxed_604_; lean_object* v_res_605_; 
v_a_12__boxed_604_ = lean_unbox(v_a_600_);
v_res_605_ = l_FormalSpecAgent_TypedIR_Expr_seqLe_elim(v_motive_599_, v_a_12__boxed_604_, v_t_601_, v_h_602_, v_seqLe_603_);
return v_res_605_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_bytesLength_elim___redArg(lean_object* v_t_606_, lean_object* v_bytesLength_607_){
_start:
{
lean_object* v___x_608_; 
v___x_608_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_606_, v_bytesLength_607_);
return v___x_608_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_bytesLength_elim(lean_object* v_motive_609_, uint8_t v_a_610_, lean_object* v_t_611_, lean_object* v_h_612_, lean_object* v_bytesLength_613_){
_start:
{
lean_object* v___x_614_; 
v___x_614_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_611_, v_bytesLength_613_);
return v___x_614_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_bytesLength_elim___boxed(lean_object* v_motive_615_, lean_object* v_a_616_, lean_object* v_t_617_, lean_object* v_h_618_, lean_object* v_bytesLength_619_){
_start:
{
uint8_t v_a_12__boxed_620_; lean_object* v_res_621_; 
v_a_12__boxed_620_ = lean_unbox(v_a_616_);
v_res_621_ = l_FormalSpecAgent_TypedIR_Expr_bytesLength_elim(v_motive_615_, v_a_12__boxed_620_, v_t_617_, v_h_618_, v_bytesLength_619_);
return v_res_621_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_concat_elim___redArg(lean_object* v_t_622_, lean_object* v_concat_623_){
_start:
{
lean_object* v___x_624_; 
v___x_624_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_622_, v_concat_623_);
return v___x_624_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_concat_elim(lean_object* v_motive_625_, uint8_t v_a_626_, lean_object* v_t_627_, lean_object* v_h_628_, lean_object* v_concat_629_){
_start:
{
lean_object* v___x_630_; 
v___x_630_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_627_, v_concat_629_);
return v___x_630_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_concat_elim___boxed(lean_object* v_motive_631_, lean_object* v_a_632_, lean_object* v_t_633_, lean_object* v_h_634_, lean_object* v_concat_635_){
_start:
{
uint8_t v_a_12__boxed_636_; lean_object* v_res_637_; 
v_a_12__boxed_636_ = lean_unbox(v_a_632_);
v_res_637_ = l_FormalSpecAgent_TypedIR_Expr_concat_elim(v_motive_631_, v_a_12__boxed_636_, v_t_633_, v_h_634_, v_concat_635_);
return v_res_637_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_slice_elim___redArg(lean_object* v_t_638_, lean_object* v_slice_639_){
_start:
{
lean_object* v___x_640_; 
v___x_640_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_638_, v_slice_639_);
return v___x_640_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_slice_elim(lean_object* v_motive_641_, uint8_t v_a_642_, lean_object* v_t_643_, lean_object* v_h_644_, lean_object* v_slice_645_){
_start:
{
lean_object* v___x_646_; 
v___x_646_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_643_, v_slice_645_);
return v___x_646_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_slice_elim___boxed(lean_object* v_motive_647_, lean_object* v_a_648_, lean_object* v_t_649_, lean_object* v_h_650_, lean_object* v_slice_651_){
_start:
{
uint8_t v_a_12__boxed_652_; lean_object* v_res_653_; 
v_a_12__boxed_652_ = lean_unbox(v_a_648_);
v_res_653_ = l_FormalSpecAgent_TypedIR_Expr_slice_elim(v_motive_647_, v_a_12__boxed_652_, v_t_649_, v_h_650_, v_slice_651_);
return v_res_653_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_byteAt_elim___redArg(lean_object* v_t_654_, lean_object* v_byteAt_655_){
_start:
{
lean_object* v___x_656_; 
v___x_656_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_654_, v_byteAt_655_);
return v___x_656_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_byteAt_elim(lean_object* v_motive_657_, uint8_t v_a_658_, lean_object* v_t_659_, lean_object* v_h_660_, lean_object* v_byteAt_661_){
_start:
{
lean_object* v___x_662_; 
v___x_662_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_659_, v_byteAt_661_);
return v___x_662_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_byteAt_elim___boxed(lean_object* v_motive_663_, lean_object* v_a_664_, lean_object* v_t_665_, lean_object* v_h_666_, lean_object* v_byteAt_667_){
_start:
{
uint8_t v_a_12__boxed_668_; lean_object* v_res_669_; 
v_a_12__boxed_668_ = lean_unbox(v_a_664_);
v_res_669_ = l_FormalSpecAgent_TypedIR_Expr_byteAt_elim(v_motive_663_, v_a_12__boxed_668_, v_t_665_, v_h_666_, v_byteAt_667_);
return v_res_669_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack8_elim___redArg(lean_object* v_t_670_, lean_object* v_pack8_671_){
_start:
{
lean_object* v___x_672_; 
v___x_672_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_670_, v_pack8_671_);
return v___x_672_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack8_elim(lean_object* v_motive_673_, uint8_t v_a_674_, lean_object* v_t_675_, lean_object* v_h_676_, lean_object* v_pack8_677_){
_start:
{
lean_object* v___x_678_; 
v___x_678_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_675_, v_pack8_677_);
return v___x_678_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack8_elim___boxed(lean_object* v_motive_679_, lean_object* v_a_680_, lean_object* v_t_681_, lean_object* v_h_682_, lean_object* v_pack8_683_){
_start:
{
uint8_t v_a_12__boxed_684_; lean_object* v_res_685_; 
v_a_12__boxed_684_ = lean_unbox(v_a_680_);
v_res_685_ = l_FormalSpecAgent_TypedIR_Expr_pack8_elim(v_motive_679_, v_a_12__boxed_684_, v_t_681_, v_h_682_, v_pack8_683_);
return v_res_685_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack16_elim___redArg(lean_object* v_t_686_, lean_object* v_pack16_687_){
_start:
{
lean_object* v___x_688_; 
v___x_688_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_686_, v_pack16_687_);
return v___x_688_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack16_elim(lean_object* v_motive_689_, uint8_t v_a_690_, lean_object* v_t_691_, lean_object* v_h_692_, lean_object* v_pack16_693_){
_start:
{
lean_object* v___x_694_; 
v___x_694_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_691_, v_pack16_693_);
return v___x_694_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack16_elim___boxed(lean_object* v_motive_695_, lean_object* v_a_696_, lean_object* v_t_697_, lean_object* v_h_698_, lean_object* v_pack16_699_){
_start:
{
uint8_t v_a_12__boxed_700_; lean_object* v_res_701_; 
v_a_12__boxed_700_ = lean_unbox(v_a_696_);
v_res_701_ = l_FormalSpecAgent_TypedIR_Expr_pack16_elim(v_motive_695_, v_a_12__boxed_700_, v_t_697_, v_h_698_, v_pack16_699_);
return v_res_701_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack32_elim___redArg(lean_object* v_t_702_, lean_object* v_pack32_703_){
_start:
{
lean_object* v___x_704_; 
v___x_704_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_702_, v_pack32_703_);
return v___x_704_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack32_elim(lean_object* v_motive_705_, uint8_t v_a_706_, lean_object* v_t_707_, lean_object* v_h_708_, lean_object* v_pack32_709_){
_start:
{
lean_object* v___x_710_; 
v___x_710_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_707_, v_pack32_709_);
return v___x_710_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_pack32_elim___boxed(lean_object* v_motive_711_, lean_object* v_a_712_, lean_object* v_t_713_, lean_object* v_h_714_, lean_object* v_pack32_715_){
_start:
{
uint8_t v_a_12__boxed_716_; lean_object* v_res_717_; 
v_a_12__boxed_716_ = lean_unbox(v_a_712_);
v_res_717_ = l_FormalSpecAgent_TypedIR_Expr_pack32_elim(v_motive_711_, v_a_12__boxed_716_, v_t_713_, v_h_714_, v_pack32_715_);
return v_res_717_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_checksum_elim___redArg(lean_object* v_t_718_, lean_object* v_checksum_719_){
_start:
{
lean_object* v___x_720_; 
v___x_720_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_718_, v_checksum_719_);
return v___x_720_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_checksum_elim(lean_object* v_motive_721_, uint8_t v_a_722_, lean_object* v_t_723_, lean_object* v_h_724_, lean_object* v_checksum_725_){
_start:
{
lean_object* v___x_726_; 
v___x_726_ = l_FormalSpecAgent_TypedIR_Expr_ctorElim___redArg(v_t_723_, v_checksum_725_);
return v___x_726_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_Expr_checksum_elim___boxed(lean_object* v_motive_727_, lean_object* v_a_728_, lean_object* v_t_729_, lean_object* v_h_730_, lean_object* v_checksum_731_){
_start:
{
uint8_t v_a_12__boxed_732_; lean_object* v_res_733_; 
v_a_12__boxed_732_ = lean_unbox(v_a_728_);
v_res_733_ = l_FormalSpecAgent_TypedIR_Expr_checksum_elim(v_motive_727_, v_a_12__boxed_732_, v_t_729_, v_h_730_, v_checksum_731_);
return v_res_733_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_eval(uint8_t v_k_734_, lean_object* v_e_735_, lean_object* v_ctx_736_){
_start:
{
switch(lean_obj_tag(v_e_735_))
{
case 0:
{
lean_object* v_a_737_; 
lean_dec_ref(v_ctx_736_);
v_a_737_ = lean_ctor_get(v_e_735_, 0);
lean_inc(v_a_737_);
lean_dec_ref_known(v_e_735_, 1);
return v_a_737_;
}
case 1:
{
lean_object* v_a_738_; lean_object* v_store_739_; lean_object* v___x_740_; 
v_a_738_ = lean_ctor_get(v_e_735_, 0);
lean_inc(v_a_738_);
lean_dec_ref_known(v_e_735_, 1);
v_store_739_ = lean_ctor_get(v_ctx_736_, 0);
lean_inc_ref(v_store_739_);
lean_dec_ref(v_ctx_736_);
v___x_740_ = l_FormalSpecAgent_TypedIR_getValue(v_k_734_, v_store_739_, v_a_738_);
return v___x_740_;
}
case 2:
{
lean_object* v_a_741_; lean_object* v_fields_742_; lean_object* v___x_743_; 
v_a_741_ = lean_ctor_get(v_e_735_, 0);
lean_inc(v_a_741_);
lean_dec_ref_known(v_e_735_, 1);
v_fields_742_ = lean_ctor_get(v_ctx_736_, 1);
lean_inc_ref(v_fields_742_);
lean_dec_ref(v_ctx_736_);
v___x_743_ = l_FormalSpecAgent_TypedIR_getValue(v_k_734_, v_fields_742_, v_a_741_);
return v___x_743_;
}
case 3:
{
lean_object* v_a_744_; lean_object* v_state_745_; uint8_t v___x_746_; lean_object* v___x_747_; 
v_a_744_ = lean_ctor_get(v_e_735_, 0);
lean_inc(v_a_744_);
lean_dec_ref_known(v_e_735_, 1);
v_state_745_ = lean_ctor_get(v_ctx_736_, 2);
lean_inc(v_state_745_);
lean_dec_ref(v_ctx_736_);
v___x_746_ = lean_nat_dec_eq(v_state_745_, v_a_744_);
lean_dec(v_a_744_);
lean_dec(v_state_745_);
v___x_747_ = lean_box(v___x_746_);
return v___x_747_;
}
case 4:
{
lean_object* v_a_748_; lean_object* v_activeTimers_749_; uint8_t v___x_750_; lean_object* v___x_751_; 
v_a_748_ = lean_ctor_get(v_e_735_, 0);
lean_inc(v_a_748_);
lean_dec_ref_known(v_e_735_, 1);
v_activeTimers_749_ = lean_ctor_get(v_ctx_736_, 3);
lean_inc(v_activeTimers_749_);
lean_dec_ref(v_ctx_736_);
v___x_750_ = l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(v_a_748_, v_activeTimers_749_);
lean_dec(v_activeTimers_749_);
lean_dec(v_a_748_);
v___x_751_ = lean_box(v___x_750_);
return v___x_751_;
}
case 5:
{
uint8_t v_k_752_; lean_object* v_a_753_; lean_object* v_a_754_; lean_object* v___x_755_; lean_object* v___x_756_; uint8_t v___x_757_; lean_object* v___x_758_; 
v_k_752_ = lean_ctor_get_uint8(v_e_735_, sizeof(void*)*2);
v_a_753_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_753_);
v_a_754_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_754_);
lean_dec_ref_known(v_e_735_, 2);
lean_inc_ref(v_ctx_736_);
v___x_755_ = l_FormalSpecAgent_TypedIR_eval(v_k_752_, v_a_753_, v_ctx_736_);
v___x_756_ = l_FormalSpecAgent_TypedIR_eval(v_k_752_, v_a_754_, v_ctx_736_);
v___x_757_ = l_FormalSpecAgent_TypedIR_equalValue(v_k_752_, v___x_755_, v___x_756_);
v___x_758_ = lean_box(v___x_757_);
return v___x_758_;
}
case 6:
{
uint8_t v_k_759_; lean_object* v_a_760_; lean_object* v_a_761_; lean_object* v___x_762_; lean_object* v___x_763_; uint8_t v___x_764_; 
v_k_759_ = lean_ctor_get_uint8(v_e_735_, sizeof(void*)*2);
v_a_760_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_760_);
v_a_761_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_761_);
lean_dec_ref_known(v_e_735_, 2);
lean_inc_ref(v_ctx_736_);
v___x_762_ = l_FormalSpecAgent_TypedIR_eval(v_k_759_, v_a_760_, v_ctx_736_);
v___x_763_ = l_FormalSpecAgent_TypedIR_eval(v_k_759_, v_a_761_, v_ctx_736_);
v___x_764_ = l_FormalSpecAgent_TypedIR_equalValue(v_k_759_, v___x_762_, v___x_763_);
if (v___x_764_ == 0)
{
uint8_t v___x_765_; lean_object* v___x_766_; 
v___x_765_ = 1;
v___x_766_ = lean_box(v___x_765_);
return v___x_766_;
}
else
{
uint8_t v___x_767_; lean_object* v___x_768_; 
v___x_767_ = 0;
v___x_768_ = lean_box(v___x_767_);
return v___x_768_;
}
}
case 7:
{
lean_object* v_a_769_; lean_object* v_a_770_; lean_object* v_a_771_; uint8_t v___x_772_; lean_object* v___x_773_; uint8_t v___x_774_; 
v_a_769_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_769_);
v_a_770_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_770_);
v_a_771_ = lean_ctor_get(v_e_735_, 2);
lean_inc_ref(v_a_771_);
lean_dec_ref_known(v_e_735_, 3);
v___x_772_ = 1;
lean_inc_ref(v_ctx_736_);
v___x_773_ = l_FormalSpecAgent_TypedIR_eval(v___x_772_, v_a_769_, v_ctx_736_);
v___x_774_ = lean_unbox(v___x_773_);
lean_dec(v___x_773_);
if (v___x_774_ == 0)
{
lean_dec_ref(v_a_770_);
v_e_735_ = v_a_771_;
goto _start;
}
else
{
lean_dec_ref(v_a_771_);
v_e_735_ = v_a_770_;
goto _start;
}
}
case 8:
{
lean_object* v_a_777_; lean_object* v_a_778_; uint8_t v___x_779_; lean_object* v___x_780_; uint8_t v___x_781_; 
v_a_777_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_777_);
v_a_778_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_778_);
lean_dec_ref_known(v_e_735_, 2);
v___x_779_ = 1;
lean_inc_ref(v_ctx_736_);
v___x_780_ = l_FormalSpecAgent_TypedIR_eval(v___x_779_, v_a_777_, v_ctx_736_);
v___x_781_ = lean_unbox(v___x_780_);
lean_dec(v___x_780_);
if (v___x_781_ == 0)
{
uint8_t v___x_782_; lean_object* v___x_783_; 
lean_dec_ref(v_a_778_);
lean_dec_ref(v_ctx_736_);
v___x_782_ = 0;
v___x_783_ = lean_box(v___x_782_);
return v___x_783_;
}
else
{
v_k_734_ = v___x_779_;
v_e_735_ = v_a_778_;
goto _start;
}
}
case 9:
{
lean_object* v_a_785_; lean_object* v_a_786_; uint8_t v___x_787_; lean_object* v___x_788_; uint8_t v___x_789_; 
v_a_785_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_785_);
v_a_786_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_786_);
lean_dec_ref_known(v_e_735_, 2);
v___x_787_ = 1;
lean_inc_ref(v_ctx_736_);
v___x_788_ = l_FormalSpecAgent_TypedIR_eval(v___x_787_, v_a_785_, v_ctx_736_);
v___x_789_ = lean_unbox(v___x_788_);
lean_dec(v___x_788_);
if (v___x_789_ == 0)
{
v_k_734_ = v___x_787_;
v_e_735_ = v_a_786_;
goto _start;
}
else
{
uint8_t v___x_791_; lean_object* v___x_792_; 
lean_dec_ref(v_a_786_);
lean_dec_ref(v_ctx_736_);
v___x_791_ = 1;
v___x_792_ = lean_box(v___x_791_);
return v___x_792_;
}
}
case 10:
{
lean_object* v_a_793_; uint8_t v___x_794_; lean_object* v___x_795_; uint8_t v___x_796_; 
v_a_793_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_793_);
lean_dec_ref_known(v_e_735_, 1);
v___x_794_ = 1;
v___x_795_ = l_FormalSpecAgent_TypedIR_eval(v___x_794_, v_a_793_, v_ctx_736_);
v___x_796_ = lean_unbox(v___x_795_);
lean_dec(v___x_795_);
if (v___x_796_ == 0)
{
uint8_t v___x_797_; lean_object* v___x_798_; 
v___x_797_ = 1;
v___x_798_ = lean_box(v___x_797_);
return v___x_798_;
}
else
{
uint8_t v___x_799_; lean_object* v___x_800_; 
v___x_799_ = 0;
v___x_800_ = lean_box(v___x_799_);
return v___x_800_;
}
}
case 11:
{
lean_object* v_a_801_; lean_object* v_a_802_; uint8_t v___x_803_; lean_object* v___x_804_; uint8_t v___x_805_; 
v_a_801_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_801_);
v_a_802_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_802_);
lean_dec_ref_known(v_e_735_, 2);
v___x_803_ = 1;
lean_inc_ref(v_ctx_736_);
v___x_804_ = l_FormalSpecAgent_TypedIR_eval(v___x_803_, v_a_801_, v_ctx_736_);
v___x_805_ = lean_unbox(v___x_804_);
lean_dec(v___x_804_);
if (v___x_805_ == 0)
{
uint8_t v___x_806_; lean_object* v___x_807_; 
lean_dec_ref(v_a_802_);
lean_dec_ref(v_ctx_736_);
v___x_806_ = 1;
v___x_807_ = lean_box(v___x_806_);
return v___x_807_;
}
else
{
v_k_734_ = v___x_803_;
v_e_735_ = v_a_802_;
goto _start;
}
}
case 12:
{
lean_object* v_a_809_; lean_object* v_a_810_; uint8_t v___x_811_; lean_object* v___x_812_; lean_object* v___x_813_; lean_object* v___x_814_; 
v_a_809_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_809_);
v_a_810_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_810_);
lean_dec_ref_known(v_e_735_, 2);
v___x_811_ = 0;
lean_inc_ref(v_ctx_736_);
v___x_812_ = l_FormalSpecAgent_TypedIR_eval(v___x_811_, v_a_809_, v_ctx_736_);
v___x_813_ = l_FormalSpecAgent_TypedIR_eval(v___x_811_, v_a_810_, v_ctx_736_);
v___x_814_ = lean_int_add(v___x_812_, v___x_813_);
lean_dec(v___x_813_);
lean_dec(v___x_812_);
return v___x_814_;
}
case 13:
{
lean_object* v_a_815_; lean_object* v_a_816_; uint8_t v___x_817_; lean_object* v___x_818_; lean_object* v___x_819_; lean_object* v___x_820_; 
v_a_815_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_815_);
v_a_816_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_816_);
lean_dec_ref_known(v_e_735_, 2);
v___x_817_ = 0;
lean_inc_ref(v_ctx_736_);
v___x_818_ = l_FormalSpecAgent_TypedIR_eval(v___x_817_, v_a_815_, v_ctx_736_);
v___x_819_ = l_FormalSpecAgent_TypedIR_eval(v___x_817_, v_a_816_, v_ctx_736_);
v___x_820_ = lean_int_mul(v___x_818_, v___x_819_);
lean_dec(v___x_819_);
lean_dec(v___x_818_);
return v___x_820_;
}
case 14:
{
lean_object* v_a_821_; lean_object* v_a_822_; uint8_t v___x_823_; lean_object* v___x_824_; lean_object* v___x_825_; lean_object* v___x_826_; 
v_a_821_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_821_);
v_a_822_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_822_);
lean_dec_ref_known(v_e_735_, 2);
v___x_823_ = 0;
lean_inc_ref(v_ctx_736_);
v___x_824_ = l_FormalSpecAgent_TypedIR_eval(v___x_823_, v_a_821_, v_ctx_736_);
v___x_825_ = l_FormalSpecAgent_TypedIR_eval(v___x_823_, v_a_822_, v_ctx_736_);
v___x_826_ = lean_int_sub(v___x_824_, v___x_825_);
lean_dec(v___x_825_);
lean_dec(v___x_824_);
return v___x_826_;
}
case 15:
{
lean_object* v_a_827_; lean_object* v_a_828_; uint8_t v___x_829_; lean_object* v___x_830_; lean_object* v___x_831_; uint8_t v___x_832_; 
v_a_827_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_827_);
v_a_828_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_828_);
lean_dec_ref_known(v_e_735_, 2);
v___x_829_ = 0;
lean_inc_ref(v_ctx_736_);
v___x_830_ = l_FormalSpecAgent_TypedIR_eval(v___x_829_, v_a_827_, v_ctx_736_);
v___x_831_ = l_FormalSpecAgent_TypedIR_eval(v___x_829_, v_a_828_, v_ctx_736_);
v___x_832_ = lean_int_dec_le(v___x_830_, v___x_831_);
if (v___x_832_ == 0)
{
lean_dec(v___x_830_);
return v___x_831_;
}
else
{
lean_dec(v___x_831_);
return v___x_830_;
}
}
case 16:
{
lean_object* v_a_833_; lean_object* v_a_834_; uint8_t v___x_835_; lean_object* v___x_836_; lean_object* v___x_837_; uint8_t v___x_838_; lean_object* v___x_839_; 
v_a_833_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_833_);
v_a_834_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_834_);
lean_dec_ref_known(v_e_735_, 2);
v___x_835_ = 0;
lean_inc_ref(v_ctx_736_);
v___x_836_ = l_FormalSpecAgent_TypedIR_eval(v___x_835_, v_a_833_, v_ctx_736_);
v___x_837_ = l_FormalSpecAgent_TypedIR_eval(v___x_835_, v_a_834_, v_ctx_736_);
v___x_838_ = lean_int_dec_le(v___x_836_, v___x_837_);
lean_dec(v___x_837_);
lean_dec(v___x_836_);
v___x_839_ = lean_box(v___x_838_);
return v___x_839_;
}
case 17:
{
lean_object* v_a_840_; lean_object* v_a_841_; uint8_t v___x_842_; lean_object* v___x_843_; lean_object* v___x_844_; uint8_t v___x_845_; lean_object* v___x_846_; 
v_a_840_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_840_);
v_a_841_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_841_);
lean_dec_ref_known(v_e_735_, 2);
v___x_842_ = 0;
lean_inc_ref(v_ctx_736_);
v___x_843_ = l_FormalSpecAgent_TypedIR_eval(v___x_842_, v_a_841_, v_ctx_736_);
v___x_844_ = l_FormalSpecAgent_TypedIR_eval(v___x_842_, v_a_840_, v_ctx_736_);
v___x_845_ = lean_int_dec_le(v___x_843_, v___x_844_);
lean_dec(v___x_844_);
lean_dec(v___x_843_);
v___x_846_ = lean_box(v___x_845_);
return v___x_846_;
}
case 18:
{
lean_object* v_a_847_; lean_object* v_a_848_; uint8_t v___x_849_; lean_object* v___x_850_; uint8_t v___x_851_; lean_object* v___x_852_; lean_object* v___x_853_; 
v_a_847_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_847_);
v_a_848_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_848_);
lean_dec_ref_known(v_e_735_, 2);
v___x_849_ = 4;
lean_inc_ref(v_ctx_736_);
v___x_850_ = l_FormalSpecAgent_TypedIR_eval(v___x_849_, v_a_847_, v_ctx_736_);
v___x_851_ = 0;
v___x_852_ = l_FormalSpecAgent_TypedIR_eval(v___x_851_, v_a_848_, v_ctx_736_);
v___x_853_ = l_FormalSpecAgent_ValueOps_seqAdd(v___x_850_, v___x_852_);
lean_dec(v___x_852_);
return v___x_853_;
}
case 19:
{
lean_object* v_a_854_; lean_object* v_a_855_; uint8_t v___x_856_; lean_object* v___x_857_; lean_object* v___x_858_; lean_object* v___x_859_; 
v_a_854_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_854_);
v_a_855_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_855_);
lean_dec_ref_known(v_e_735_, 2);
v___x_856_ = 4;
lean_inc_ref(v_ctx_736_);
v___x_857_ = l_FormalSpecAgent_TypedIR_eval(v___x_856_, v_a_854_, v_ctx_736_);
v___x_858_ = l_FormalSpecAgent_TypedIR_eval(v___x_856_, v_a_855_, v_ctx_736_);
v___x_859_ = l_FormalSpecAgent_ValueOps_seqDistance(v___x_857_, v___x_858_);
return v___x_859_;
}
case 20:
{
lean_object* v_a_860_; lean_object* v_a_861_; uint8_t v___x_862_; lean_object* v___x_863_; lean_object* v___x_864_; uint8_t v___x_865_; lean_object* v___x_866_; 
v_a_860_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_860_);
v_a_861_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_861_);
lean_dec_ref_known(v_e_735_, 2);
v___x_862_ = 4;
lean_inc_ref(v_ctx_736_);
v___x_863_ = l_FormalSpecAgent_TypedIR_eval(v___x_862_, v_a_860_, v_ctx_736_);
v___x_864_ = l_FormalSpecAgent_TypedIR_eval(v___x_862_, v_a_861_, v_ctx_736_);
v___x_865_ = l_FormalSpecAgent_ValueOps_seqComparable(v___x_863_, v___x_864_);
v___x_866_ = lean_box(v___x_865_);
return v___x_866_;
}
case 21:
{
lean_object* v_a_867_; lean_object* v_a_868_; uint8_t v___x_869_; lean_object* v___x_870_; lean_object* v___x_871_; uint8_t v___x_872_; lean_object* v___x_873_; 
v_a_867_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_867_);
v_a_868_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_868_);
lean_dec_ref_known(v_e_735_, 2);
v___x_869_ = 4;
lean_inc_ref(v_ctx_736_);
v___x_870_ = l_FormalSpecAgent_TypedIR_eval(v___x_869_, v_a_867_, v_ctx_736_);
v___x_871_ = l_FormalSpecAgent_TypedIR_eval(v___x_869_, v_a_868_, v_ctx_736_);
v___x_872_ = l_FormalSpecAgent_ValueOps_seqLt(v___x_870_, v___x_871_);
v___x_873_ = lean_box(v___x_872_);
return v___x_873_;
}
case 22:
{
lean_object* v_a_874_; lean_object* v_a_875_; uint8_t v___x_876_; lean_object* v___x_877_; lean_object* v___x_878_; uint8_t v___x_879_; lean_object* v___x_880_; 
v_a_874_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_874_);
v_a_875_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_875_);
lean_dec_ref_known(v_e_735_, 2);
v___x_876_ = 4;
lean_inc_ref(v_ctx_736_);
v___x_877_ = l_FormalSpecAgent_TypedIR_eval(v___x_876_, v_a_874_, v_ctx_736_);
v___x_878_ = l_FormalSpecAgent_TypedIR_eval(v___x_876_, v_a_875_, v_ctx_736_);
v___x_879_ = l_FormalSpecAgent_ValueOps_seqLe(v___x_877_, v___x_878_);
v___x_880_ = lean_box(v___x_879_);
return v___x_880_;
}
case 23:
{
lean_object* v_a_881_; uint8_t v___x_882_; lean_object* v___x_883_; lean_object* v___x_884_; lean_object* v___x_885_; 
v_a_881_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_881_);
lean_dec_ref_known(v_e_735_, 1);
v___x_882_ = 3;
v___x_883_ = l_FormalSpecAgent_TypedIR_eval(v___x_882_, v_a_881_, v_ctx_736_);
v___x_884_ = l_List_lengthTR___redArg(v___x_883_);
lean_dec(v___x_883_);
v___x_885_ = lean_nat_to_int(v___x_884_);
return v___x_885_;
}
case 24:
{
lean_object* v_a_886_; lean_object* v_a_887_; uint8_t v___x_888_; lean_object* v___x_889_; lean_object* v___x_890_; lean_object* v___x_891_; 
v_a_886_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_886_);
v_a_887_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_887_);
lean_dec_ref_known(v_e_735_, 2);
v___x_888_ = 3;
lean_inc_ref(v_ctx_736_);
v___x_889_ = l_FormalSpecAgent_TypedIR_eval(v___x_888_, v_a_886_, v_ctx_736_);
v___x_890_ = l_FormalSpecAgent_TypedIR_eval(v___x_888_, v_a_887_, v_ctx_736_);
v___x_891_ = l_List_appendTR___redArg(v___x_889_, v___x_890_);
return v___x_891_;
}
case 25:
{
lean_object* v_a_892_; lean_object* v_a_893_; lean_object* v_a_894_; uint8_t v___x_895_; lean_object* v___x_896_; uint8_t v___x_897_; lean_object* v___x_898_; lean_object* v___x_899_; lean_object* v___x_900_; 
v_a_892_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_892_);
v_a_893_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_893_);
v_a_894_ = lean_ctor_get(v_e_735_, 2);
lean_inc_ref(v_a_894_);
lean_dec_ref_known(v_e_735_, 3);
v___x_895_ = 3;
lean_inc_ref_n(v_ctx_736_, 2);
v___x_896_ = l_FormalSpecAgent_TypedIR_eval(v___x_895_, v_a_892_, v_ctx_736_);
v___x_897_ = 0;
v___x_898_ = l_FormalSpecAgent_TypedIR_eval(v___x_897_, v_a_893_, v_ctx_736_);
v___x_899_ = l_FormalSpecAgent_TypedIR_eval(v___x_897_, v_a_894_, v_ctx_736_);
v___x_900_ = l_FormalSpecAgent_byteSlice(v___x_896_, v___x_898_, v___x_899_);
lean_dec(v___x_899_);
lean_dec(v___x_898_);
lean_dec(v___x_896_);
return v___x_900_;
}
case 26:
{
lean_object* v_a_901_; lean_object* v_a_902_; uint8_t v___x_903_; lean_object* v___x_904_; uint8_t v___x_905_; lean_object* v___x_906_; lean_object* v___x_907_; 
v_a_901_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_901_);
v_a_902_ = lean_ctor_get(v_e_735_, 1);
lean_inc_ref(v_a_902_);
lean_dec_ref_known(v_e_735_, 2);
v___x_903_ = 3;
lean_inc_ref(v_ctx_736_);
v___x_904_ = l_FormalSpecAgent_TypedIR_eval(v___x_903_, v_a_901_, v_ctx_736_);
v___x_905_ = 0;
v___x_906_ = l_FormalSpecAgent_TypedIR_eval(v___x_905_, v_a_902_, v_ctx_736_);
v___x_907_ = l_FormalSpecAgent_byteAt(v___x_904_, v___x_906_);
lean_dec(v___x_906_);
lean_dec(v___x_904_);
return v___x_907_;
}
case 27:
{
lean_object* v_a_908_; uint8_t v___x_909_; lean_object* v___x_910_; lean_object* v___x_911_; 
v_a_908_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_908_);
lean_dec_ref_known(v_e_735_, 1);
v___x_909_ = 0;
v___x_910_ = l_FormalSpecAgent_TypedIR_eval(v___x_909_, v_a_908_, v_ctx_736_);
v___x_911_ = l_FormalSpecAgent_ValueOps_pack8(v___x_910_);
lean_dec(v___x_910_);
return v___x_911_;
}
case 28:
{
lean_object* v_a_912_; uint8_t v___x_913_; lean_object* v___x_914_; lean_object* v___x_915_; 
v_a_912_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_912_);
lean_dec_ref_known(v_e_735_, 1);
v___x_913_ = 0;
v___x_914_ = l_FormalSpecAgent_TypedIR_eval(v___x_913_, v_a_912_, v_ctx_736_);
v___x_915_ = l_FormalSpecAgent_ValueOps_pack16(v___x_914_);
lean_dec(v___x_914_);
return v___x_915_;
}
case 29:
{
lean_object* v_a_916_; uint8_t v___x_917_; lean_object* v___x_918_; lean_object* v___x_919_; 
v_a_916_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_916_);
lean_dec_ref_known(v_e_735_, 1);
v___x_917_ = 0;
v___x_918_ = l_FormalSpecAgent_TypedIR_eval(v___x_917_, v_a_916_, v_ctx_736_);
v___x_919_ = l_FormalSpecAgent_ValueOps_pack32(v___x_918_);
lean_dec(v___x_918_);
return v___x_919_;
}
default: 
{
lean_object* v_a_920_; uint8_t v___x_921_; lean_object* v___x_922_; lean_object* v___x_923_; 
v_a_920_ = lean_ctor_get(v_e_735_, 0);
lean_inc_ref(v_a_920_);
lean_dec_ref_known(v_e_735_, 1);
v___x_921_ = 3;
v___x_922_ = l_FormalSpecAgent_TypedIR_eval(v___x_921_, v_a_920_, v_ctx_736_);
v___x_923_ = l_FormalSpecAgent_ValueOps_checksum(v___x_922_);
lean_dec(v___x_922_);
return v___x_923_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TypedIR_eval___boxed(lean_object* v_k_924_, lean_object* v_e_925_, lean_object* v_ctx_926_){
_start:
{
uint8_t v_k_boxed_927_; lean_object* v_res_928_; 
v_k_boxed_927_ = lean_unbox(v_k_924_);
v_res_928_ = l_FormalSpecAgent_TypedIR_eval(v_k_boxed_927_, v_e_925_, v_ctx_926_);
return v_res_928_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ValueOps(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_TypedIR(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ValueOps(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
