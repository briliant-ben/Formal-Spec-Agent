import ModelMachine
open FormalSpecAgent.MachineObserve

def array (xs : List String) : String := "[" ++ String.intercalate "," xs ++ "]"
def pvalue : Packed → String
  | .integer v => "{\"kind\":\"int\",\"value\":" ++ toString v ++ "}"
  | .boolean v => "{\"kind\":\"bool\",\"value\":" ++ toString v ++ "}"
  | .text v => "{\"kind\":\"string\",\"value\":" ++ array (v.toList.map fun c => toString c.toNat) ++ "}"
  | .octets v => "{\"kind\":\"bytes\",\"value\":" ++ array (v.map fun b => toString b.val) ++ "}"
  | .sequence v => "{\"kind\":\"seq32\",\"value\":" ++ toString v ++ "}"
def ss (s : SeenSnapshot) : String :=
  "{\"state\":" ++ toString s.state ++ ",\"now_ms\":" ++ toString s.now ++
  ",\"variables\":" ++ array (s.values.map pvalue) ++ ",\"timers\":" ++
  array (s.timers.map fun (n,t) => array [toString n,toString t]) ++ "}"
def msg (m : SeenMessage) : String :=
  "{\"message\":" ++ toString m.1 ++ ",\"fields\":" ++
  array (m.2.map fun (n,v) => array [toString n,pvalue v]) ++ "}"
def faultName : FormalSpecAgent.TypedMachine.Fault → String
  | .uncovered => "uncovered" | .conflict => "conflict" | .badDelay => "badDelay"
  | .invariant => "invariant" | .time => "time" | .timerInjection => "timerInjection"
  | .pendingTimer => "pendingTimer" | .noTimer => "noTimer"
def outcomeText : Outcome → String
  | .success r e s emitted => "{\"status\":\"ok\",\"rule\":" ++ toString r ++
      ",\"event\":" ++ toString e ++ ",\"after\":" ++ ss s ++
      ",\"emitted\":" ++ array (emitted.map msg) ++ "}"
  | .error f s => "{\"status\":\"error\",\"fault\":\"" ++ faultName f ++
      "\",\"after\":" ++ ss s ++ ",\"emitted\":[]}"

def main : IO Unit := do
  let s_0_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_0_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_0 r_0_0))
  let s_0_1 := FormalSpecAgent.TypedMachine.rollback s_0_0 r_0_0
  let r_0_1 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_1 3 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_1 r_0_1))
  let s_0_2 := FormalSpecAgent.TypedMachine.rollback s_0_1 r_0_1
  let r_0_2 := FormalSpecAgent.TypedMachine.stepTimer MachineRuntime.model s_0_2 (5)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_2 r_0_2))
  let s_0_3 := FormalSpecAgent.TypedMachine.rollback s_0_2 r_0_2
  let r_0_3 := FormalSpecAgent.TypedMachine.stepTimer MachineRuntime.model s_0_3 (5)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_3 r_0_3))
  let s_0_4 := FormalSpecAgent.TypedMachine.rollback s_0_3 r_0_3
  let s_1_0 := ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨1, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_1_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_1_0 3 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_1_0 r_1_0))
  let s_1_1 := FormalSpecAgent.TypedMachine.rollback s_1_0 r_1_0
  let r_1_1 := FormalSpecAgent.TypedMachine.stepTimer MachineRuntime.model s_1_1 (5)
  IO.println (outcomeText (outcome MachineRuntime.schema s_1_1 r_1_1))
  let s_1_2 := FormalSpecAgent.TypedMachine.rollback s_1_1 r_1_1
  let r_1_2 := FormalSpecAgent.TypedMachine.stepTimer MachineRuntime.model s_1_2 (7)
  IO.println (outcomeText (outcome MachineRuntime.schema s_1_2 r_1_2))
  let s_1_3 := FormalSpecAgent.TypedMachine.rollback s_1_2 r_1_2
  let r_1_3 := FormalSpecAgent.TypedMachine.stepTimer MachineRuntime.model s_1_3 (7)
  IO.println (outcomeText (outcome MachineRuntime.schema s_1_3 r_1_3))
  let s_1_4 := FormalSpecAgent.TypedMachine.rollback s_1_3 r_1_3
  let s_2_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_2_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_2_0 1 ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_2_0 r_2_0))
  let s_2_1 := FormalSpecAgent.TypedMachine.rollback s_2_0 r_2_0
  let r_2_1 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_2_1 1 ({ integers := fun n => if n = 0 then (-1) else (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (3)
  IO.println (outcomeText (outcome MachineRuntime.schema s_2_1 r_2_1))
  let s_2_2 := FormalSpecAgent.TypedMachine.rollback s_2_1 r_2_1
  let s_3_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_3_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_3_0 2 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_3_0 r_3_0))
  let s_3_1 := FormalSpecAgent.TypedMachine.rollback s_3_0 r_3_0
  let s_4_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_4_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_4_0 4 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_4_0 r_4_0))
  let s_4_1 := FormalSpecAgent.TypedMachine.rollback s_4_0 r_4_0
  let r_4_1 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_4_1 5 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_4_1 r_4_1))
  let s_4_2 := FormalSpecAgent.TypedMachine.rollback s_4_1 r_4_1
  let r_4_2 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_4_2 6 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_4_2 r_4_2))
  let s_4_3 := FormalSpecAgent.TypedMachine.rollback s_4_2 r_4_2
  let s_5_0 := ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨1, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_5_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_5_0 5 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (4)
  IO.println (outcomeText (outcome MachineRuntime.schema s_5_0 r_5_0))
  let s_5_1 := FormalSpecAgent.TypedMachine.rollback s_5_0 r_5_0
  let r_5_1 := FormalSpecAgent.TypedMachine.stepTimer MachineRuntime.model s_5_1 (4)
  IO.println (outcomeText (outcome MachineRuntime.schema s_5_1 r_5_1))
  let s_5_2 := FormalSpecAgent.TypedMachine.rollback s_5_1 r_5_1
  let r_5_2 := FormalSpecAgent.TypedMachine.stepTimer MachineRuntime.model s_5_2 (6)
  IO.println (outcomeText (outcome MachineRuntime.schema s_5_2 r_5_2))
  let s_5_3 := FormalSpecAgent.TypedMachine.rollback s_5_2 r_5_2
  let s_6_0 := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_6_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_6_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_6_0 r_6_0))
  let s_6_1 := FormalSpecAgent.TypedMachine.rollback s_6_0 r_6_0
