// Lean compiler output
// Module: Foundation
// Imports: public import Init public meta import Init public import Std
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* l_Int_toNat(lean_object*);
lean_object* l_List_getD___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_List_drop___redArg(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l___private_Init_Data_List_Impl_0__List_takeTR_go___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FormalSpecAgent_byteAt___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_byteAt___closed__0;
static lean_once_cell_t l_FormalSpecAgent_byteAt___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_byteAt___closed__1;
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteAt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteAt___boxed(lean_object*, lean_object*);
static const lean_array_object l_FormalSpecAgent_byteSlice___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_FormalSpecAgent_byteSlice___closed__0 = (const lean_object*)&l_FormalSpecAgent_byteSlice___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteSlice(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteSlice___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* _init_l_FormalSpecAgent_byteAt___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_l_FormalSpecAgent_byteAt___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; lean_object* v___x_5_; 
v___x_3_ = lean_unsigned_to_nat(256u);
v___x_4_ = lean_unsigned_to_nat(0u);
v___x_5_ = lean_nat_mod(v___x_4_, v___x_3_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteAt(lean_object* v_data_6_, lean_object* v_offset_7_){
_start:
{
lean_object* v___x_8_; uint8_t v___x_9_; 
v___x_8_ = lean_obj_once(&l_FormalSpecAgent_byteAt___closed__0, &l_FormalSpecAgent_byteAt___closed__0_once, _init_l_FormalSpecAgent_byteAt___closed__0);
v___x_9_ = lean_int_dec_lt(v_offset_7_, v___x_8_);
if (v___x_9_ == 0)
{
lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; 
v___x_10_ = l_Int_toNat(v_offset_7_);
v___x_11_ = lean_obj_once(&l_FormalSpecAgent_byteAt___closed__1, &l_FormalSpecAgent_byteAt___closed__1_once, _init_l_FormalSpecAgent_byteAt___closed__1);
v___x_12_ = l_List_getD___redArg(v_data_6_, v___x_10_, v___x_11_);
v___x_13_ = lean_nat_to_int(v___x_12_);
return v___x_13_;
}
else
{
return v___x_8_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteAt___boxed(lean_object* v_data_14_, lean_object* v_offset_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = l_FormalSpecAgent_byteAt(v_data_14_, v_offset_15_);
lean_dec(v_offset_15_);
lean_dec(v_data_14_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteSlice(lean_object* v_data_19_, lean_object* v_offset_20_, lean_object* v_count_21_){
_start:
{
lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; 
v___x_22_ = l_Int_toNat(v_count_21_);
v___x_23_ = l_Int_toNat(v_offset_20_);
v___x_24_ = l_List_drop___redArg(v___x_23_, v_data_19_);
v___x_25_ = ((lean_object*)(l_FormalSpecAgent_byteSlice___closed__0));
lean_inc(v___x_24_);
v___x_26_ = l___private_Init_Data_List_Impl_0__List_takeTR_go___redArg(v___x_24_, v___x_24_, v___x_22_, v___x_25_);
lean_dec(v___x_24_);
return v___x_26_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_byteSlice___boxed(lean_object* v_data_27_, lean_object* v_offset_28_, lean_object* v_count_29_){
_start:
{
lean_object* v_res_30_; 
v_res_30_ = l_FormalSpecAgent_byteSlice(v_data_27_, v_offset_28_, v_count_29_);
lean_dec(v_count_29_);
lean_dec(v_offset_28_);
lean_dec(v_data_27_);
return v_res_30_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Std(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Foundation(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
