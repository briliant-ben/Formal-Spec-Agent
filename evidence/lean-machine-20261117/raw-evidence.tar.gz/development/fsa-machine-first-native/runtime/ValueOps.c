// Lean compiler output
// Module: ValueOps
// Imports: public import Init public meta import Init public import Foundation
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* lean_int_emod(lean_object*, lean_object*);
lean_object* l_Int_toNat(lean_object*);
lean_object* lean_int_ediv(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
static lean_once_cell_t l_FormalSpecAgent_ValueOps_byteMod___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_ValueOps_byteMod___closed__0;
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_byteMod(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_byteMod___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack8(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack8___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack16(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack16___boxed(lean_object*);
static lean_once_cell_t l_FormalSpecAgent_ValueOps_pack32___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_ValueOps_pack32___closed__0;
static lean_once_cell_t l_FormalSpecAgent_ValueOps_pack32___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_ValueOps_pack32___closed__1;
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack32(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack32___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum_go(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum_go___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_fold16(lean_object*);
static lean_once_cell_t l_FormalSpecAgent_ValueOps_checksum___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_ValueOps_checksum___closed__0;
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_checksum(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_checksum___boxed(lean_object*);
static lean_once_cell_t l_FormalSpecAgent_ValueOps_seqAdd___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_ValueOps_seqAdd___closed__0;
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqAdd(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqAdd___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqDistance(lean_object*, lean_object*);
static lean_once_cell_t l_FormalSpecAgent_ValueOps_seqComparable___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_ValueOps_seqComparable___closed__0;
LEAN_EXPORT uint8_t l_FormalSpecAgent_ValueOps_seqComparable(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqComparable___boxed(lean_object*, lean_object*);
static lean_once_cell_t l_FormalSpecAgent_ValueOps_seqLt___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_ValueOps_seqLt___closed__0;
LEAN_EXPORT uint8_t l_FormalSpecAgent_ValueOps_seqLt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqLt___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_ValueOps_seqLe(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqLe___boxed(lean_object*, lean_object*);
static lean_object* _init_l_FormalSpecAgent_ValueOps_byteMod___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(256u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_byteMod(lean_object* v_n_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; 
v___x_4_ = lean_unsigned_to_nat(256u);
v___x_5_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_byteMod___closed__0, &l_FormalSpecAgent_ValueOps_byteMod___closed__0_once, _init_l_FormalSpecAgent_ValueOps_byteMod___closed__0);
v___x_6_ = lean_int_emod(v_n_3_, v___x_5_);
v___x_7_ = l_Int_toNat(v___x_6_);
lean_dec(v___x_6_);
v___x_8_ = lean_nat_mod(v___x_7_, v___x_4_);
lean_dec(v___x_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_byteMod___boxed(lean_object* v_n_9_){
_start:
{
lean_object* v_res_10_; 
v_res_10_ = l_FormalSpecAgent_ValueOps_byteMod(v_n_9_);
lean_dec(v_n_9_);
return v_res_10_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack8(lean_object* v_n_11_){
_start:
{
lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; 
v___x_12_ = l_FormalSpecAgent_ValueOps_byteMod(v_n_11_);
v___x_13_ = lean_box(0);
v___x_14_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_14_, 0, v___x_12_);
lean_ctor_set(v___x_14_, 1, v___x_13_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack8___boxed(lean_object* v_n_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = l_FormalSpecAgent_ValueOps_pack8(v_n_15_);
lean_dec(v_n_15_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack16(lean_object* v_n_17_){
_start:
{
lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; 
v___x_18_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_byteMod___closed__0, &l_FormalSpecAgent_ValueOps_byteMod___closed__0_once, _init_l_FormalSpecAgent_ValueOps_byteMod___closed__0);
v___x_19_ = lean_int_ediv(v_n_17_, v___x_18_);
v___x_20_ = l_FormalSpecAgent_ValueOps_byteMod(v___x_19_);
lean_dec(v___x_19_);
v___x_21_ = l_FormalSpecAgent_ValueOps_byteMod(v_n_17_);
v___x_22_ = lean_box(0);
v___x_23_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_23_, 0, v___x_21_);
lean_ctor_set(v___x_23_, 1, v___x_22_);
v___x_24_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_24_, 0, v___x_20_);
lean_ctor_set(v___x_24_, 1, v___x_23_);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack16___boxed(lean_object* v_n_25_){
_start:
{
lean_object* v_res_26_; 
v_res_26_ = l_FormalSpecAgent_ValueOps_pack16(v_n_25_);
lean_dec(v_n_25_);
return v_res_26_;
}
}
static lean_object* _init_l_FormalSpecAgent_ValueOps_pack32___closed__0(void){
_start:
{
lean_object* v___x_27_; lean_object* v___x_28_; 
v___x_27_ = lean_unsigned_to_nat(16777216u);
v___x_28_ = lean_nat_to_int(v___x_27_);
return v___x_28_;
}
}
static lean_object* _init_l_FormalSpecAgent_ValueOps_pack32___closed__1(void){
_start:
{
lean_object* v___x_29_; lean_object* v___x_30_; 
v___x_29_ = lean_unsigned_to_nat(65536u);
v___x_30_ = lean_nat_to_int(v___x_29_);
return v___x_30_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack32(lean_object* v_n_31_){
_start:
{
lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_46_; 
v___x_32_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_pack32___closed__0, &l_FormalSpecAgent_ValueOps_pack32___closed__0_once, _init_l_FormalSpecAgent_ValueOps_pack32___closed__0);
v___x_33_ = lean_int_ediv(v_n_31_, v___x_32_);
v___x_34_ = l_FormalSpecAgent_ValueOps_byteMod(v___x_33_);
lean_dec(v___x_33_);
v___x_35_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_pack32___closed__1, &l_FormalSpecAgent_ValueOps_pack32___closed__1_once, _init_l_FormalSpecAgent_ValueOps_pack32___closed__1);
v___x_36_ = lean_int_ediv(v_n_31_, v___x_35_);
v___x_37_ = l_FormalSpecAgent_ValueOps_byteMod(v___x_36_);
lean_dec(v___x_36_);
v___x_38_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_byteMod___closed__0, &l_FormalSpecAgent_ValueOps_byteMod___closed__0_once, _init_l_FormalSpecAgent_ValueOps_byteMod___closed__0);
v___x_39_ = lean_int_ediv(v_n_31_, v___x_38_);
v___x_40_ = l_FormalSpecAgent_ValueOps_byteMod(v___x_39_);
lean_dec(v___x_39_);
v___x_41_ = l_FormalSpecAgent_ValueOps_byteMod(v_n_31_);
v___x_42_ = lean_box(0);
v___x_43_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_43_, 0, v___x_41_);
lean_ctor_set(v___x_43_, 1, v___x_42_);
v___x_44_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_44_, 0, v___x_40_);
lean_ctor_set(v___x_44_, 1, v___x_43_);
v___x_45_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_45_, 0, v___x_37_);
lean_ctor_set(v___x_45_, 1, v___x_44_);
v___x_46_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_46_, 0, v___x_34_);
lean_ctor_set(v___x_46_, 1, v___x_45_);
return v___x_46_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_pack32___boxed(lean_object* v_n_47_){
_start:
{
lean_object* v_res_48_; 
v_res_48_ = l_FormalSpecAgent_ValueOps_pack32(v_n_47_);
lean_dec(v_n_47_);
return v_res_48_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum_go(lean_object* v_acc_49_, lean_object* v_a_50_){
_start:
{
if (lean_obj_tag(v_a_50_) == 0)
{
return v_acc_49_;
}
else
{
lean_object* v_tail_51_; 
v_tail_51_ = lean_ctor_get(v_a_50_, 1);
if (lean_obj_tag(v_tail_51_) == 0)
{
lean_object* v_head_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; 
v_head_52_ = lean_ctor_get(v_a_50_, 0);
v___x_53_ = lean_unsigned_to_nat(256u);
v___x_54_ = lean_nat_mul(v_head_52_, v___x_53_);
v___x_55_ = lean_nat_add(v_acc_49_, v___x_54_);
lean_dec(v___x_54_);
lean_dec(v_acc_49_);
return v___x_55_;
}
else
{
lean_object* v_head_56_; lean_object* v_head_57_; lean_object* v_tail_58_; lean_object* v___x_59_; lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; 
v_head_56_ = lean_ctor_get(v_a_50_, 0);
v_head_57_ = lean_ctor_get(v_tail_51_, 0);
v_tail_58_ = lean_ctor_get(v_tail_51_, 1);
v___x_59_ = lean_unsigned_to_nat(256u);
v___x_60_ = lean_nat_mul(v_head_56_, v___x_59_);
v___x_61_ = lean_nat_add(v_acc_49_, v___x_60_);
lean_dec(v___x_60_);
lean_dec(v_acc_49_);
v___x_62_ = lean_nat_add(v___x_61_, v_head_57_);
lean_dec(v___x_61_);
v_acc_49_ = v___x_62_;
v_a_50_ = v_tail_58_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum_go___boxed(lean_object* v_acc_64_, lean_object* v_a_65_){
_start:
{
lean_object* v_res_66_; 
v_res_66_ = l_FormalSpecAgent_ValueOps_wordSum_go(v_acc_64_, v_a_65_);
lean_dec(v_a_65_);
return v_res_66_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum(lean_object* v_data_67_){
_start:
{
lean_object* v___x_68_; lean_object* v___x_69_; 
v___x_68_ = lean_unsigned_to_nat(0u);
v___x_69_ = l_FormalSpecAgent_ValueOps_wordSum_go(v___x_68_, v_data_67_);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_wordSum___boxed(lean_object* v_data_70_){
_start:
{
lean_object* v_res_71_; 
v_res_71_ = l_FormalSpecAgent_ValueOps_wordSum(v_data_70_);
lean_dec(v_data_70_);
return v_res_71_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_fold16(lean_object* v_n_72_){
_start:
{
lean_object* v___x_73_; uint8_t v___x_74_; 
v___x_73_ = lean_unsigned_to_nat(65536u);
v___x_74_ = lean_nat_dec_lt(v_n_72_, v___x_73_);
if (v___x_74_ == 0)
{
lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; 
v___x_75_ = lean_nat_mod(v_n_72_, v___x_73_);
v___x_76_ = lean_unsigned_to_nat(16u);
v___x_77_ = lean_nat_shiftr(v_n_72_, v___x_76_);
lean_dec(v_n_72_);
v___x_78_ = lean_nat_add(v___x_75_, v___x_77_);
lean_dec(v___x_77_);
lean_dec(v___x_75_);
v_n_72_ = v___x_78_;
goto _start;
}
else
{
return v_n_72_;
}
}
}
static lean_object* _init_l_FormalSpecAgent_ValueOps_checksum___closed__0(void){
_start:
{
lean_object* v___x_80_; lean_object* v___x_81_; 
v___x_80_ = lean_unsigned_to_nat(65535u);
v___x_81_ = lean_nat_to_int(v___x_80_);
return v___x_81_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_checksum(lean_object* v_data_82_){
_start:
{
lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; 
v___x_83_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_checksum___closed__0, &l_FormalSpecAgent_ValueOps_checksum___closed__0_once, _init_l_FormalSpecAgent_ValueOps_checksum___closed__0);
v___x_84_ = l_FormalSpecAgent_ValueOps_wordSum(v_data_82_);
v___x_85_ = l_FormalSpecAgent_ValueOps_fold16(v___x_84_);
v___x_86_ = lean_nat_to_int(v___x_85_);
v___x_87_ = lean_int_sub(v___x_83_, v___x_86_);
lean_dec(v___x_86_);
return v___x_87_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_checksum___boxed(lean_object* v_data_88_){
_start:
{
lean_object* v_res_89_; 
v_res_89_ = l_FormalSpecAgent_ValueOps_checksum(v_data_88_);
lean_dec(v_data_88_);
return v_res_89_;
}
}
static lean_object* _init_l_FormalSpecAgent_ValueOps_seqAdd___closed__0(void){
_start:
{
lean_object* v___x_90_; lean_object* v___x_91_; 
v___x_90_ = lean_cstr_to_nat("4294967296");
v___x_91_ = lean_nat_to_int(v___x_90_);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqAdd(lean_object* v_s_92_, lean_object* v_offset_93_){
_start:
{
lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; 
v___x_94_ = lean_cstr_to_nat("4294967296");
v___x_95_ = lean_nat_to_int(v_s_92_);
v___x_96_ = lean_int_add(v___x_95_, v_offset_93_);
lean_dec(v___x_95_);
v___x_97_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_seqAdd___closed__0, &l_FormalSpecAgent_ValueOps_seqAdd___closed__0_once, _init_l_FormalSpecAgent_ValueOps_seqAdd___closed__0);
v___x_98_ = lean_int_emod(v___x_96_, v___x_97_);
lean_dec(v___x_96_);
v___x_99_ = l_Int_toNat(v___x_98_);
lean_dec(v___x_98_);
v___x_100_ = lean_nat_mod(v___x_99_, v___x_94_);
lean_dec(v___x_99_);
return v___x_100_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqAdd___boxed(lean_object* v_s_101_, lean_object* v_offset_102_){
_start:
{
lean_object* v_res_103_; 
v_res_103_ = l_FormalSpecAgent_ValueOps_seqAdd(v_s_101_, v_offset_102_);
lean_dec(v_offset_102_);
return v_res_103_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqDistance(lean_object* v_a_104_, lean_object* v_b_105_){
_start:
{
lean_object* v___x_106_; lean_object* v___x_107_; lean_object* v___x_108_; lean_object* v___x_109_; lean_object* v___x_110_; 
v___x_106_ = lean_nat_to_int(v_b_105_);
v___x_107_ = lean_nat_to_int(v_a_104_);
v___x_108_ = lean_int_sub(v___x_106_, v___x_107_);
lean_dec(v___x_107_);
lean_dec(v___x_106_);
v___x_109_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_seqAdd___closed__0, &l_FormalSpecAgent_ValueOps_seqAdd___closed__0_once, _init_l_FormalSpecAgent_ValueOps_seqAdd___closed__0);
v___x_110_ = lean_int_emod(v___x_108_, v___x_109_);
lean_dec(v___x_108_);
return v___x_110_;
}
}
static lean_object* _init_l_FormalSpecAgent_ValueOps_seqComparable___closed__0(void){
_start:
{
lean_object* v___x_111_; lean_object* v___x_112_; 
v___x_111_ = lean_unsigned_to_nat(2147483648u);
v___x_112_ = lean_nat_to_int(v___x_111_);
return v___x_112_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_ValueOps_seqComparable(lean_object* v_a_113_, lean_object* v_b_114_){
_start:
{
lean_object* v___x_115_; lean_object* v___x_116_; uint8_t v___x_117_; 
v___x_115_ = l_FormalSpecAgent_ValueOps_seqDistance(v_a_113_, v_b_114_);
v___x_116_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_seqComparable___closed__0, &l_FormalSpecAgent_ValueOps_seqComparable___closed__0_once, _init_l_FormalSpecAgent_ValueOps_seqComparable___closed__0);
v___x_117_ = lean_int_dec_eq(v___x_115_, v___x_116_);
lean_dec(v___x_115_);
if (v___x_117_ == 0)
{
uint8_t v___x_118_; 
v___x_118_ = 1;
return v___x_118_;
}
else
{
uint8_t v___x_119_; 
v___x_119_ = 0;
return v___x_119_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqComparable___boxed(lean_object* v_a_120_, lean_object* v_b_121_){
_start:
{
uint8_t v_res_122_; lean_object* v_r_123_; 
v_res_122_ = l_FormalSpecAgent_ValueOps_seqComparable(v_a_120_, v_b_121_);
v_r_123_ = lean_box(v_res_122_);
return v_r_123_;
}
}
static lean_object* _init_l_FormalSpecAgent_ValueOps_seqLt___closed__0(void){
_start:
{
lean_object* v___x_124_; lean_object* v___x_125_; 
v___x_124_ = lean_unsigned_to_nat(0u);
v___x_125_ = lean_nat_to_int(v___x_124_);
return v___x_125_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_ValueOps_seqLt(lean_object* v_a_126_, lean_object* v_b_127_){
_start:
{
lean_object* v___x_128_; lean_object* v___x_129_; uint8_t v___x_130_; 
v___x_128_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_seqLt___closed__0, &l_FormalSpecAgent_ValueOps_seqLt___closed__0_once, _init_l_FormalSpecAgent_ValueOps_seqLt___closed__0);
v___x_129_ = l_FormalSpecAgent_ValueOps_seqDistance(v_a_126_, v_b_127_);
v___x_130_ = lean_int_dec_lt(v___x_128_, v___x_129_);
if (v___x_130_ == 0)
{
lean_dec(v___x_129_);
return v___x_130_;
}
else
{
lean_object* v___x_131_; uint8_t v___x_132_; 
v___x_131_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_seqComparable___closed__0, &l_FormalSpecAgent_ValueOps_seqComparable___closed__0_once, _init_l_FormalSpecAgent_ValueOps_seqComparable___closed__0);
v___x_132_ = lean_int_dec_lt(v___x_129_, v___x_131_);
lean_dec(v___x_129_);
return v___x_132_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqLt___boxed(lean_object* v_a_133_, lean_object* v_b_134_){
_start:
{
uint8_t v_res_135_; lean_object* v_r_136_; 
v_res_135_ = l_FormalSpecAgent_ValueOps_seqLt(v_a_133_, v_b_134_);
v_r_136_ = lean_box(v_res_135_);
return v_r_136_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_ValueOps_seqLe(lean_object* v_a_137_, lean_object* v_b_138_){
_start:
{
lean_object* v___x_139_; lean_object* v___x_140_; uint8_t v___x_141_; 
v___x_139_ = l_FormalSpecAgent_ValueOps_seqDistance(v_a_137_, v_b_138_);
v___x_140_ = lean_obj_once(&l_FormalSpecAgent_ValueOps_seqComparable___closed__0, &l_FormalSpecAgent_ValueOps_seqComparable___closed__0_once, _init_l_FormalSpecAgent_ValueOps_seqComparable___closed__0);
v___x_141_ = lean_int_dec_lt(v___x_139_, v___x_140_);
lean_dec(v___x_139_);
return v___x_141_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_ValueOps_seqLe___boxed(lean_object* v_a_142_, lean_object* v_b_143_){
_start:
{
uint8_t v_res_144_; lean_object* v_r_145_; 
v_res_144_ = l_FormalSpecAgent_ValueOps_seqLe(v_a_142_, v_b_143_);
v_r_145_ = lean_box(v_res_144_);
return v_r_145_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Foundation(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ValueOps(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Foundation(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
