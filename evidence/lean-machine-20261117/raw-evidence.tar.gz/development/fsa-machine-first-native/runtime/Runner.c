// Lean compiler output
// Module: Runner
// Imports: public import Init public meta import Init public import ModelMachine
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_string_mk(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_neg(lean_object*);
extern lean_object* l_MachineRuntime_model;
lean_object* l_FormalSpecAgent_TypedMachine_external(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_MachineRuntime_schema;
lean_object* l_FormalSpecAgent_MachineObserve_outcome(lean_object*, lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_rollback(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_stepTimer(lean_object*, lean_object*, lean_object*);
lean_object* l_List_replicateTR___redArg(lean_object*, lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Int_repr(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_string_data(lean_object*);
lean_object* lean_uint32_to_nat(uint32_t);
lean_object* l_String_intercalate(lean_object*, lean_object*);
lean_object* lean_string_push(lean_object*, uint32_t);
lean_object* lean_get_stdout();
static const lean_string_object l_array___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "["};
static const lean_object* l_array___closed__0 = (const lean_object*)&l_array___closed__0_value;
static const lean_string_object l_array___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* l_array___closed__1 = (const lean_object*)&l_array___closed__1_value;
static const lean_string_object l_array___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "]"};
static const lean_object* l_array___closed__2 = (const lean_object*)&l_array___closed__2_value;
LEAN_EXPORT lean_object* l_array(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__1(lean_object*, lean_object*);
static const lean_string_object l_pvalue___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "{\"kind\":\"int\",\"value\":"};
static const lean_object* l_pvalue___closed__0 = (const lean_object*)&l_pvalue___closed__0_value;
static const lean_string_object l_pvalue___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "}"};
static const lean_object* l_pvalue___closed__1 = (const lean_object*)&l_pvalue___closed__1_value;
static const lean_string_object l_pvalue___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "{\"kind\":\"bool\",\"value\":"};
static const lean_object* l_pvalue___closed__2 = (const lean_object*)&l_pvalue___closed__2_value;
static const lean_string_object l_pvalue___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "false"};
static const lean_object* l_pvalue___closed__3 = (const lean_object*)&l_pvalue___closed__3_value;
static const lean_string_object l_pvalue___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "true"};
static const lean_object* l_pvalue___closed__4 = (const lean_object*)&l_pvalue___closed__4_value;
static const lean_string_object l_pvalue___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "{\"kind\":\"string\",\"value\":"};
static const lean_object* l_pvalue___closed__5 = (const lean_object*)&l_pvalue___closed__5_value;
static const lean_string_object l_pvalue___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "{\"kind\":\"bytes\",\"value\":"};
static const lean_object* l_pvalue___closed__6 = (const lean_object*)&l_pvalue___closed__6_value;
static const lean_string_object l_pvalue___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "{\"kind\":\"seq32\",\"value\":"};
static const lean_object* l_pvalue___closed__7 = (const lean_object*)&l_pvalue___closed__7_value;
LEAN_EXPORT lean_object* l_pvalue(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__0(lean_object*, lean_object*);
static const lean_string_object l_ss___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "{\"state\":"};
static const lean_object* l_ss___closed__0 = (const lean_object*)&l_ss___closed__0_value;
static const lean_string_object l_ss___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"now_ms\":"};
static const lean_object* l_ss___closed__1 = (const lean_object*)&l_ss___closed__1_value;
static const lean_string_object l_ss___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = ",\"variables\":"};
static const lean_object* l_ss___closed__2 = (const lean_object*)&l_ss___closed__2_value;
static const lean_string_object l_ss___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"timers\":"};
static const lean_object* l_ss___closed__3 = (const lean_object*)&l_ss___closed__3_value;
LEAN_EXPORT lean_object* l_ss(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00msg_spec__0(lean_object*, lean_object*);
static const lean_string_object l_msg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "{\"message\":"};
static const lean_object* l_msg___closed__0 = (const lean_object*)&l_msg___closed__0_value;
static const lean_string_object l_msg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"fields\":"};
static const lean_object* l_msg___closed__1 = (const lean_object*)&l_msg___closed__1_value;
LEAN_EXPORT lean_object* l_msg(lean_object*);
static const lean_string_object l_faultName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "uncovered"};
static const lean_object* l_faultName___closed__0 = (const lean_object*)&l_faultName___closed__0_value;
static const lean_string_object l_faultName___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "conflict"};
static const lean_object* l_faultName___closed__1 = (const lean_object*)&l_faultName___closed__1_value;
static const lean_string_object l_faultName___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "badDelay"};
static const lean_object* l_faultName___closed__2 = (const lean_object*)&l_faultName___closed__2_value;
static const lean_string_object l_faultName___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "invariant"};
static const lean_object* l_faultName___closed__3 = (const lean_object*)&l_faultName___closed__3_value;
static const lean_string_object l_faultName___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "time"};
static const lean_object* l_faultName___closed__4 = (const lean_object*)&l_faultName___closed__4_value;
static const lean_string_object l_faultName___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "timerInjection"};
static const lean_object* l_faultName___closed__5 = (const lean_object*)&l_faultName___closed__5_value;
static const lean_string_object l_faultName___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "pendingTimer"};
static const lean_object* l_faultName___closed__6 = (const lean_object*)&l_faultName___closed__6_value;
static const lean_string_object l_faultName___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "noTimer"};
static const lean_object* l_faultName___closed__7 = (const lean_object*)&l_faultName___closed__7_value;
LEAN_EXPORT lean_object* l_faultName(uint8_t);
LEAN_EXPORT lean_object* l_faultName___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00outcomeText_spec__0(lean_object*, lean_object*);
static const lean_string_object l_outcomeText___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "{\"status\":\"ok\",\"rule\":"};
static const lean_object* l_outcomeText___closed__0 = (const lean_object*)&l_outcomeText___closed__0_value;
static const lean_string_object l_outcomeText___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = ",\"event\":"};
static const lean_object* l_outcomeText___closed__1 = (const lean_object*)&l_outcomeText___closed__1_value;
static const lean_string_object l_outcomeText___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = ",\"after\":"};
static const lean_object* l_outcomeText___closed__2 = (const lean_object*)&l_outcomeText___closed__2_value;
static const lean_string_object l_outcomeText___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = ",\"emitted\":"};
static const lean_object* l_outcomeText___closed__3 = (const lean_object*)&l_outcomeText___closed__3_value;
static const lean_string_object l_outcomeText___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "{\"status\":\"error\",\"fault\":\""};
static const lean_object* l_outcomeText___closed__4 = (const lean_object*)&l_outcomeText___closed__4_value;
static const lean_string_object l_outcomeText___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "\",\"after\":"};
static const lean_object* l_outcomeText___closed__5 = (const lean_object*)&l_outcomeText___closed__5_value;
static const lean_string_object l_outcomeText___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = ",\"emitted\":[]}"};
static const lean_object* l_outcomeText___closed__6 = (const lean_object*)&l_outcomeText___closed__6_value;
LEAN_EXPORT lean_object* l_outcomeText(lean_object*);
static lean_once_cell_t l_main___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__0;
LEAN_EXPORT lean_object* l_main___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__0___boxed(lean_object*);
LEAN_EXPORT uint8_t l_main___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__1___boxed(lean_object*);
static lean_once_cell_t l_main___lam__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__0;
LEAN_EXPORT lean_object* l_main___lam__2___closed__1___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__1;
LEAN_EXPORT lean_object* l_main___lam__2___closed__2___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__2;
LEAN_EXPORT lean_object* l_main___lam__2___closed__3___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__3;
static lean_once_cell_t l_main___lam__2___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__4;
LEAN_EXPORT lean_object* l_main___lam__2___closed__5___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__5;
static lean_once_cell_t l_main___lam__2___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__6;
LEAN_EXPORT lean_object* l_main___lam__2(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__2___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__3(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__3___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__4(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__4___boxed(lean_object*);
LEAN_EXPORT uint8_t l_main___lam__5(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__5___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__6(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__6___boxed(lean_object*);
LEAN_EXPORT uint8_t l_main___lam__8(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__8___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__7___closed__0___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__0;
LEAN_EXPORT lean_object* l_main___lam__7___closed__1___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__1;
LEAN_EXPORT lean_object* l_main___lam__7___closed__2___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__2;
static lean_once_cell_t l_main___lam__7___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__3;
LEAN_EXPORT lean_object* l_main___lam__7(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__7___boxed(lean_object*);
static const lean_ctor_object l_main___lam__9___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___lam__9___closed__0 = (const lean_object*)&l_main___lam__9___closed__0_value;
static const lean_ctor_object l_main___lam__9___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(255) << 1) | 1)),((lean_object*)&l_main___lam__9___closed__0_value)}};
static const lean_object* l_main___lam__9___closed__1 = (const lean_object*)&l_main___lam__9___closed__1_value;
static const lean_ctor_object l_main___lam__9___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(128) << 1) | 1)),((lean_object*)&l_main___lam__9___closed__1_value)}};
static const lean_object* l_main___lam__9___closed__2 = (const lean_object*)&l_main___lam__9___closed__2_value;
LEAN_EXPORT lean_object* l_main___lam__9(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__9___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__10(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__10___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__12(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__12___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__11(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__11___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__13(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__14(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__14___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__15(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__15___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__16(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__16___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_closure_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_closure_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__2___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_closure_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__3___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_closure_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__4___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_closure_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__5___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_closure_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__6___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_closure_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__8___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_closure_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__7___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_ctor_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&l_main___closed__0_value),((lean_object*)&l_main___closed__1_value),((lean_object*)&l_main___closed__2_value),((lean_object*)&l_main___closed__3_value),((lean_object*)&l_main___closed__4_value)}};
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static const lean_closure_object l_main___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__9___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__10 = (const lean_object*)&l_main___closed__10_value;
static const lean_closure_object l_main___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__10___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__11 = (const lean_object*)&l_main___closed__11_value;
static lean_once_cell_t l_main___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__12;
static lean_once_cell_t l_main___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__13;
static lean_once_cell_t l_main___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__14;
static lean_once_cell_t l_main___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__15;
static lean_once_cell_t l_main___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__16;
static lean_once_cell_t l_main___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__17;
static lean_once_cell_t l_main___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__18;
static const lean_closure_object l_main___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__11___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__19 = (const lean_object*)&l_main___closed__19_value;
static lean_once_cell_t l_main___closed__20_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__20;
static lean_once_cell_t l_main___closed__21_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__21;
static lean_once_cell_t l_main___closed__22_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__22;
static lean_once_cell_t l_main___closed__23_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__23;
static lean_once_cell_t l_main___closed__24_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__24;
static lean_once_cell_t l_main___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__25;
static lean_once_cell_t l_main___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__26;
static lean_once_cell_t l_main___closed__27_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__27;
static lean_once_cell_t l_main___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__28;
static lean_once_cell_t l_main___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__29;
static lean_once_cell_t l_main___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__30;
static lean_once_cell_t l_main___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__31;
static lean_once_cell_t l_main___closed__32_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__32;
static lean_once_cell_t l_main___closed__33_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__33;
static lean_once_cell_t l_main___closed__34_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__34;
static lean_once_cell_t l_main___closed__35_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__35;
static lean_once_cell_t l_main___closed__36_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__36;
static lean_once_cell_t l_main___closed__37_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__37;
static lean_once_cell_t l_main___closed__38_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__38;
static lean_once_cell_t l_main___closed__39_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__39;
static lean_once_cell_t l_main___closed__40_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__40;
static lean_once_cell_t l_main___closed__41_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__41;
static lean_once_cell_t l_main___closed__42_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__42;
static lean_once_cell_t l_main___closed__43_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__43;
static lean_once_cell_t l_main___closed__44_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__44;
static lean_once_cell_t l_main___closed__45_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__45;
static lean_once_cell_t l_main___closed__46_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__46;
static lean_once_cell_t l_main___closed__47_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__47;
static lean_once_cell_t l_main___closed__48_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__48;
static lean_once_cell_t l_main___closed__49_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__49;
static lean_once_cell_t l_main___closed__50_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__50;
static lean_once_cell_t l_main___closed__51_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__51;
static lean_once_cell_t l_main___closed__52_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__52;
static lean_once_cell_t l_main___closed__53_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__53;
static lean_once_cell_t l_main___closed__54_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__54;
static lean_once_cell_t l_main___closed__55_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__55;
static lean_once_cell_t l_main___closed__56_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__56;
static const lean_ctor_object l_main___closed__57_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&l_main___closed__0_value),((lean_object*)&l_main___closed__5_value),((lean_object*)&l_main___closed__6_value),((lean_object*)&l_main___closed__3_value),((lean_object*)&l_main___closed__11_value)}};
static const lean_object* l_main___closed__57 = (const lean_object*)&l_main___closed__57_value;
static lean_once_cell_t l_main___closed__58_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__58;
static lean_once_cell_t l_main___closed__59_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__59;
static lean_once_cell_t l_main___closed__60_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__60;
static lean_once_cell_t l_main___closed__61_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__61;
static lean_once_cell_t l_main___closed__62_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__62;
static lean_once_cell_t l_main___closed__63_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__63;
static lean_once_cell_t l_main___closed__64_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__64;
static lean_once_cell_t l_main___closed__65_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__65;
static lean_once_cell_t l_main___closed__66_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__66;
static lean_once_cell_t l_main___closed__67_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__67;
static lean_once_cell_t l_main___closed__68_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__68;
static lean_once_cell_t l_main___closed__69_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__69;
static lean_once_cell_t l_main___closed__70_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__70;
static lean_once_cell_t l_main___closed__71_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__71;
static lean_once_cell_t l_main___closed__72_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__72;
static lean_once_cell_t l_main___closed__73_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__73;
static lean_once_cell_t l_main___closed__74_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__74;
static lean_once_cell_t l_main___closed__75_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__75;
static lean_once_cell_t l_main___closed__76_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__76;
static lean_once_cell_t l_main___closed__77_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__77;
static lean_once_cell_t l_main___closed__78_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__78;
static const lean_closure_object l_main___closed__79_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*4, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__16___boxed, .m_arity = 5, .m_num_fixed = 4, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(6) << 1) | 1))} };
static const lean_object* l_main___closed__79 = (const lean_object*)&l_main___closed__79_value;
static lean_once_cell_t l_main___closed__80_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__80;
static lean_once_cell_t l_main___closed__81_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__81;
static lean_once_cell_t l_main___closed__82_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__82;
static lean_once_cell_t l_main___closed__83_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__83;
static lean_once_cell_t l_main___closed__84_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__84;
static lean_once_cell_t l_main___closed__85_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__85;
static lean_once_cell_t l_main___closed__86_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__86;
static lean_once_cell_t l_main___closed__87_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__87;
static lean_once_cell_t l_main___closed__88_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__88;
static lean_once_cell_t l_main___closed__89_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__89;
static lean_once_cell_t l_main___closed__90_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__90;
static lean_once_cell_t l_main___closed__91_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__91;
static lean_once_cell_t l_main___closed__92_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__92;
static lean_once_cell_t l_main___closed__93_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__93;
static lean_once_cell_t l_main___closed__94_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__94;
static lean_once_cell_t l_main___closed__95_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__95;
static lean_once_cell_t l_main___closed__96_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__96;
static lean_once_cell_t l_main___closed__97_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__97;
static lean_once_cell_t l_main___closed__98_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__98;
static lean_once_cell_t l_main___closed__99_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__99;
static lean_once_cell_t l_main___closed__100_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__100;
static lean_once_cell_t l_main___closed__101_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__101;
LEAN_EXPORT lean_object* _lean_main();
LEAN_EXPORT lean_object* l_main___boxed(lean_object*);
LEAN_EXPORT lean_object* l_array(lean_object* v_xs_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; 
v___x_5_ = ((lean_object*)(l_array___closed__0));
v___x_6_ = ((lean_object*)(l_array___closed__1));
v___x_7_ = l_String_intercalate(v___x_6_, v_xs_4_);
v___x_8_ = lean_string_append(v___x_5_, v___x_7_);
lean_dec_ref(v___x_7_);
v___x_9_ = ((lean_object*)(l_array___closed__2));
v___x_10_ = lean_string_append(v___x_8_, v___x_9_);
return v___x_10_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__0(lean_object* v_a_11_, lean_object* v_a_12_){
_start:
{
if (lean_obj_tag(v_a_11_) == 0)
{
lean_object* v___x_13_; 
v___x_13_ = l_List_reverse___redArg(v_a_12_);
return v___x_13_;
}
else
{
lean_object* v_head_14_; lean_object* v_tail_15_; lean_object* v___x_17_; uint8_t v_isShared_18_; uint8_t v_isSharedCheck_26_; 
v_head_14_ = lean_ctor_get(v_a_11_, 0);
v_tail_15_ = lean_ctor_get(v_a_11_, 1);
v_isSharedCheck_26_ = !lean_is_exclusive(v_a_11_);
if (v_isSharedCheck_26_ == 0)
{
v___x_17_ = v_a_11_;
v_isShared_18_ = v_isSharedCheck_26_;
goto v_resetjp_16_;
}
else
{
lean_inc(v_tail_15_);
lean_inc(v_head_14_);
lean_dec(v_a_11_);
v___x_17_ = lean_box(0);
v_isShared_18_ = v_isSharedCheck_26_;
goto v_resetjp_16_;
}
v_resetjp_16_:
{
uint32_t v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_23_; 
v___x_19_ = lean_unbox_uint32(v_head_14_);
lean_dec(v_head_14_);
v___x_20_ = lean_uint32_to_nat(v___x_19_);
v___x_21_ = l_Nat_reprFast(v___x_20_);
if (v_isShared_18_ == 0)
{
lean_ctor_set(v___x_17_, 1, v_a_12_);
lean_ctor_set(v___x_17_, 0, v___x_21_);
v___x_23_ = v___x_17_;
goto v_reusejp_22_;
}
else
{
lean_object* v_reuseFailAlloc_25_; 
v_reuseFailAlloc_25_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_25_, 0, v___x_21_);
lean_ctor_set(v_reuseFailAlloc_25_, 1, v_a_12_);
v___x_23_ = v_reuseFailAlloc_25_;
goto v_reusejp_22_;
}
v_reusejp_22_:
{
v_a_11_ = v_tail_15_;
v_a_12_ = v___x_23_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__1(lean_object* v_a_27_, lean_object* v_a_28_){
_start:
{
if (lean_obj_tag(v_a_27_) == 0)
{
lean_object* v___x_29_; 
v___x_29_ = l_List_reverse___redArg(v_a_28_);
return v___x_29_;
}
else
{
lean_object* v_head_30_; lean_object* v_tail_31_; lean_object* v___x_33_; uint8_t v_isShared_34_; uint8_t v_isSharedCheck_40_; 
v_head_30_ = lean_ctor_get(v_a_27_, 0);
v_tail_31_ = lean_ctor_get(v_a_27_, 1);
v_isSharedCheck_40_ = !lean_is_exclusive(v_a_27_);
if (v_isSharedCheck_40_ == 0)
{
v___x_33_ = v_a_27_;
v_isShared_34_ = v_isSharedCheck_40_;
goto v_resetjp_32_;
}
else
{
lean_inc(v_tail_31_);
lean_inc(v_head_30_);
lean_dec(v_a_27_);
v___x_33_ = lean_box(0);
v_isShared_34_ = v_isSharedCheck_40_;
goto v_resetjp_32_;
}
v_resetjp_32_:
{
lean_object* v___x_35_; lean_object* v___x_37_; 
v___x_35_ = l_Nat_reprFast(v_head_30_);
if (v_isShared_34_ == 0)
{
lean_ctor_set(v___x_33_, 1, v_a_28_);
lean_ctor_set(v___x_33_, 0, v___x_35_);
v___x_37_ = v___x_33_;
goto v_reusejp_36_;
}
else
{
lean_object* v_reuseFailAlloc_39_; 
v_reuseFailAlloc_39_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_39_, 0, v___x_35_);
lean_ctor_set(v_reuseFailAlloc_39_, 1, v_a_28_);
v___x_37_ = v_reuseFailAlloc_39_;
goto v_reusejp_36_;
}
v_reusejp_36_:
{
v_a_27_ = v_tail_31_;
v_a_28_ = v___x_37_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_pvalue(lean_object* v_x_49_){
_start:
{
switch(lean_obj_tag(v_x_49_))
{
case 0:
{
lean_object* v_a_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; 
v_a_50_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_50_);
lean_dec_ref_known(v_x_49_, 1);
v___x_51_ = ((lean_object*)(l_pvalue___closed__0));
v___x_52_ = l_Int_repr(v_a_50_);
lean_dec(v_a_50_);
v___x_53_ = lean_string_append(v___x_51_, v___x_52_);
lean_dec_ref(v___x_52_);
v___x_54_ = ((lean_object*)(l_pvalue___closed__1));
v___x_55_ = lean_string_append(v___x_53_, v___x_54_);
return v___x_55_;
}
case 1:
{
uint8_t v_a_56_; lean_object* v___x_57_; lean_object* v___y_59_; 
v_a_56_ = lean_ctor_get_uint8(v_x_49_, 0);
lean_dec_ref_known(v_x_49_, 0);
v___x_57_ = ((lean_object*)(l_pvalue___closed__2));
if (v_a_56_ == 0)
{
lean_object* v___x_63_; 
v___x_63_ = ((lean_object*)(l_pvalue___closed__3));
v___y_59_ = v___x_63_;
goto v___jp_58_;
}
else
{
lean_object* v___x_64_; 
v___x_64_ = ((lean_object*)(l_pvalue___closed__4));
v___y_59_ = v___x_64_;
goto v___jp_58_;
}
v___jp_58_:
{
lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; 
v___x_60_ = lean_string_append(v___x_57_, v___y_59_);
v___x_61_ = ((lean_object*)(l_pvalue___closed__1));
v___x_62_ = lean_string_append(v___x_60_, v___x_61_);
return v___x_62_;
}
}
case 2:
{
lean_object* v_a_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; lean_object* v___x_72_; lean_object* v___x_73_; 
v_a_65_ = lean_ctor_get(v_x_49_, 0);
lean_inc_ref(v_a_65_);
lean_dec_ref_known(v_x_49_, 1);
v___x_66_ = ((lean_object*)(l_pvalue___closed__5));
v___x_67_ = lean_string_data(v_a_65_);
v___x_68_ = lean_box(0);
v___x_69_ = l_List_mapTR_loop___at___00pvalue_spec__0(v___x_67_, v___x_68_);
v___x_70_ = l_array(v___x_69_);
v___x_71_ = lean_string_append(v___x_66_, v___x_70_);
lean_dec_ref(v___x_70_);
v___x_72_ = ((lean_object*)(l_pvalue___closed__1));
v___x_73_ = lean_string_append(v___x_71_, v___x_72_);
return v___x_73_;
}
case 3:
{
lean_object* v_a_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; 
v_a_74_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_74_);
lean_dec_ref_known(v_x_49_, 1);
v___x_75_ = ((lean_object*)(l_pvalue___closed__6));
v___x_76_ = lean_box(0);
v___x_77_ = l_List_mapTR_loop___at___00pvalue_spec__1(v_a_74_, v___x_76_);
v___x_78_ = l_array(v___x_77_);
v___x_79_ = lean_string_append(v___x_75_, v___x_78_);
lean_dec_ref(v___x_78_);
v___x_80_ = ((lean_object*)(l_pvalue___closed__1));
v___x_81_ = lean_string_append(v___x_79_, v___x_80_);
return v___x_81_;
}
default: 
{
lean_object* v_a_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; 
v_a_82_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_82_);
lean_dec_ref_known(v_x_49_, 1);
v___x_83_ = ((lean_object*)(l_pvalue___closed__7));
v___x_84_ = l_Nat_reprFast(v_a_82_);
v___x_85_ = lean_string_append(v___x_83_, v___x_84_);
lean_dec_ref(v___x_84_);
v___x_86_ = ((lean_object*)(l_pvalue___closed__1));
v___x_87_ = lean_string_append(v___x_85_, v___x_86_);
return v___x_87_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__1(lean_object* v_a_88_, lean_object* v_a_89_){
_start:
{
if (lean_obj_tag(v_a_88_) == 0)
{
lean_object* v___x_90_; 
v___x_90_ = l_List_reverse___redArg(v_a_89_);
return v___x_90_;
}
else
{
lean_object* v_head_91_; lean_object* v_tail_92_; lean_object* v___x_94_; uint8_t v_isShared_95_; uint8_t v_isSharedCheck_114_; 
v_head_91_ = lean_ctor_get(v_a_88_, 0);
v_tail_92_ = lean_ctor_get(v_a_88_, 1);
v_isSharedCheck_114_ = !lean_is_exclusive(v_a_88_);
if (v_isSharedCheck_114_ == 0)
{
v___x_94_ = v_a_88_;
v_isShared_95_ = v_isSharedCheck_114_;
goto v_resetjp_93_;
}
else
{
lean_inc(v_tail_92_);
lean_inc(v_head_91_);
lean_dec(v_a_88_);
v___x_94_ = lean_box(0);
v_isShared_95_ = v_isSharedCheck_114_;
goto v_resetjp_93_;
}
v_resetjp_93_:
{
lean_object* v_fst_96_; lean_object* v_snd_97_; lean_object* v___x_99_; uint8_t v_isShared_100_; uint8_t v_isSharedCheck_113_; 
v_fst_96_ = lean_ctor_get(v_head_91_, 0);
v_snd_97_ = lean_ctor_get(v_head_91_, 1);
v_isSharedCheck_113_ = !lean_is_exclusive(v_head_91_);
if (v_isSharedCheck_113_ == 0)
{
v___x_99_ = v_head_91_;
v_isShared_100_ = v_isSharedCheck_113_;
goto v_resetjp_98_;
}
else
{
lean_inc(v_snd_97_);
lean_inc(v_fst_96_);
lean_dec(v_head_91_);
v___x_99_ = lean_box(0);
v_isShared_100_ = v_isSharedCheck_113_;
goto v_resetjp_98_;
}
v_resetjp_98_:
{
lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; lean_object* v___x_105_; 
v___x_101_ = l_Nat_reprFast(v_fst_96_);
v___x_102_ = l_Int_repr(v_snd_97_);
lean_dec(v_snd_97_);
v___x_103_ = lean_box(0);
if (v_isShared_95_ == 0)
{
lean_ctor_set(v___x_94_, 1, v___x_103_);
lean_ctor_set(v___x_94_, 0, v___x_102_);
v___x_105_ = v___x_94_;
goto v_reusejp_104_;
}
else
{
lean_object* v_reuseFailAlloc_112_; 
v_reuseFailAlloc_112_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_112_, 0, v___x_102_);
lean_ctor_set(v_reuseFailAlloc_112_, 1, v___x_103_);
v___x_105_ = v_reuseFailAlloc_112_;
goto v_reusejp_104_;
}
v_reusejp_104_:
{
lean_object* v___x_107_; 
if (v_isShared_100_ == 0)
{
lean_ctor_set_tag(v___x_99_, 1);
lean_ctor_set(v___x_99_, 1, v___x_105_);
lean_ctor_set(v___x_99_, 0, v___x_101_);
v___x_107_ = v___x_99_;
goto v_reusejp_106_;
}
else
{
lean_object* v_reuseFailAlloc_111_; 
v_reuseFailAlloc_111_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_111_, 0, v___x_101_);
lean_ctor_set(v_reuseFailAlloc_111_, 1, v___x_105_);
v___x_107_ = v_reuseFailAlloc_111_;
goto v_reusejp_106_;
}
v_reusejp_106_:
{
lean_object* v___x_108_; lean_object* v___x_109_; 
v___x_108_ = l_array(v___x_107_);
v___x_109_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_109_, 0, v___x_108_);
lean_ctor_set(v___x_109_, 1, v_a_89_);
v_a_88_ = v_tail_92_;
v_a_89_ = v___x_109_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__0(lean_object* v_a_115_, lean_object* v_a_116_){
_start:
{
if (lean_obj_tag(v_a_115_) == 0)
{
lean_object* v___x_117_; 
v___x_117_ = l_List_reverse___redArg(v_a_116_);
return v___x_117_;
}
else
{
lean_object* v_head_118_; lean_object* v_tail_119_; lean_object* v___x_121_; uint8_t v_isShared_122_; uint8_t v_isSharedCheck_128_; 
v_head_118_ = lean_ctor_get(v_a_115_, 0);
v_tail_119_ = lean_ctor_get(v_a_115_, 1);
v_isSharedCheck_128_ = !lean_is_exclusive(v_a_115_);
if (v_isSharedCheck_128_ == 0)
{
v___x_121_ = v_a_115_;
v_isShared_122_ = v_isSharedCheck_128_;
goto v_resetjp_120_;
}
else
{
lean_inc(v_tail_119_);
lean_inc(v_head_118_);
lean_dec(v_a_115_);
v___x_121_ = lean_box(0);
v_isShared_122_ = v_isSharedCheck_128_;
goto v_resetjp_120_;
}
v_resetjp_120_:
{
lean_object* v___x_123_; lean_object* v___x_125_; 
v___x_123_ = l_pvalue(v_head_118_);
if (v_isShared_122_ == 0)
{
lean_ctor_set(v___x_121_, 1, v_a_116_);
lean_ctor_set(v___x_121_, 0, v___x_123_);
v___x_125_ = v___x_121_;
goto v_reusejp_124_;
}
else
{
lean_object* v_reuseFailAlloc_127_; 
v_reuseFailAlloc_127_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_127_, 0, v___x_123_);
lean_ctor_set(v_reuseFailAlloc_127_, 1, v_a_116_);
v___x_125_ = v_reuseFailAlloc_127_;
goto v_reusejp_124_;
}
v_reusejp_124_:
{
v_a_115_ = v_tail_119_;
v_a_116_ = v___x_125_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ss(lean_object* v_s_133_){
_start:
{
lean_object* v_state_134_; lean_object* v_now_135_; lean_object* v_values_136_; lean_object* v_timers_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; lean_object* v___x_157_; 
v_state_134_ = lean_ctor_get(v_s_133_, 0);
lean_inc(v_state_134_);
v_now_135_ = lean_ctor_get(v_s_133_, 1);
lean_inc(v_now_135_);
v_values_136_ = lean_ctor_get(v_s_133_, 2);
lean_inc(v_values_136_);
v_timers_137_ = lean_ctor_get(v_s_133_, 3);
lean_inc(v_timers_137_);
lean_dec_ref(v_s_133_);
v___x_138_ = ((lean_object*)(l_ss___closed__0));
v___x_139_ = l_Nat_reprFast(v_state_134_);
v___x_140_ = lean_string_append(v___x_138_, v___x_139_);
lean_dec_ref(v___x_139_);
v___x_141_ = ((lean_object*)(l_ss___closed__1));
v___x_142_ = lean_string_append(v___x_140_, v___x_141_);
v___x_143_ = l_Int_repr(v_now_135_);
lean_dec(v_now_135_);
v___x_144_ = lean_string_append(v___x_142_, v___x_143_);
lean_dec_ref(v___x_143_);
v___x_145_ = ((lean_object*)(l_ss___closed__2));
v___x_146_ = lean_string_append(v___x_144_, v___x_145_);
v___x_147_ = lean_box(0);
v___x_148_ = l_List_mapTR_loop___at___00ss_spec__0(v_values_136_, v___x_147_);
v___x_149_ = l_array(v___x_148_);
v___x_150_ = lean_string_append(v___x_146_, v___x_149_);
lean_dec_ref(v___x_149_);
v___x_151_ = ((lean_object*)(l_ss___closed__3));
v___x_152_ = lean_string_append(v___x_150_, v___x_151_);
v___x_153_ = l_List_mapTR_loop___at___00ss_spec__1(v_timers_137_, v___x_147_);
v___x_154_ = l_array(v___x_153_);
v___x_155_ = lean_string_append(v___x_152_, v___x_154_);
lean_dec_ref(v___x_154_);
v___x_156_ = ((lean_object*)(l_pvalue___closed__1));
v___x_157_ = lean_string_append(v___x_155_, v___x_156_);
return v___x_157_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00msg_spec__0(lean_object* v_a_158_, lean_object* v_a_159_){
_start:
{
if (lean_obj_tag(v_a_158_) == 0)
{
lean_object* v___x_160_; 
v___x_160_ = l_List_reverse___redArg(v_a_159_);
return v___x_160_;
}
else
{
lean_object* v_head_161_; lean_object* v_tail_162_; lean_object* v___x_164_; uint8_t v_isShared_165_; uint8_t v_isSharedCheck_184_; 
v_head_161_ = lean_ctor_get(v_a_158_, 0);
v_tail_162_ = lean_ctor_get(v_a_158_, 1);
v_isSharedCheck_184_ = !lean_is_exclusive(v_a_158_);
if (v_isSharedCheck_184_ == 0)
{
v___x_164_ = v_a_158_;
v_isShared_165_ = v_isSharedCheck_184_;
goto v_resetjp_163_;
}
else
{
lean_inc(v_tail_162_);
lean_inc(v_head_161_);
lean_dec(v_a_158_);
v___x_164_ = lean_box(0);
v_isShared_165_ = v_isSharedCheck_184_;
goto v_resetjp_163_;
}
v_resetjp_163_:
{
lean_object* v_fst_166_; lean_object* v_snd_167_; lean_object* v___x_169_; uint8_t v_isShared_170_; uint8_t v_isSharedCheck_183_; 
v_fst_166_ = lean_ctor_get(v_head_161_, 0);
v_snd_167_ = lean_ctor_get(v_head_161_, 1);
v_isSharedCheck_183_ = !lean_is_exclusive(v_head_161_);
if (v_isSharedCheck_183_ == 0)
{
v___x_169_ = v_head_161_;
v_isShared_170_ = v_isSharedCheck_183_;
goto v_resetjp_168_;
}
else
{
lean_inc(v_snd_167_);
lean_inc(v_fst_166_);
lean_dec(v_head_161_);
v___x_169_ = lean_box(0);
v_isShared_170_ = v_isSharedCheck_183_;
goto v_resetjp_168_;
}
v_resetjp_168_:
{
lean_object* v___x_171_; lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_175_; 
v___x_171_ = l_Nat_reprFast(v_fst_166_);
v___x_172_ = l_pvalue(v_snd_167_);
v___x_173_ = lean_box(0);
if (v_isShared_165_ == 0)
{
lean_ctor_set(v___x_164_, 1, v___x_173_);
lean_ctor_set(v___x_164_, 0, v___x_172_);
v___x_175_ = v___x_164_;
goto v_reusejp_174_;
}
else
{
lean_object* v_reuseFailAlloc_182_; 
v_reuseFailAlloc_182_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_182_, 0, v___x_172_);
lean_ctor_set(v_reuseFailAlloc_182_, 1, v___x_173_);
v___x_175_ = v_reuseFailAlloc_182_;
goto v_reusejp_174_;
}
v_reusejp_174_:
{
lean_object* v___x_177_; 
if (v_isShared_170_ == 0)
{
lean_ctor_set_tag(v___x_169_, 1);
lean_ctor_set(v___x_169_, 1, v___x_175_);
lean_ctor_set(v___x_169_, 0, v___x_171_);
v___x_177_ = v___x_169_;
goto v_reusejp_176_;
}
else
{
lean_object* v_reuseFailAlloc_181_; 
v_reuseFailAlloc_181_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_181_, 0, v___x_171_);
lean_ctor_set(v_reuseFailAlloc_181_, 1, v___x_175_);
v___x_177_ = v_reuseFailAlloc_181_;
goto v_reusejp_176_;
}
v_reusejp_176_:
{
lean_object* v___x_178_; lean_object* v___x_179_; 
v___x_178_ = l_array(v___x_177_);
v___x_179_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_179_, 0, v___x_178_);
lean_ctor_set(v___x_179_, 1, v_a_159_);
v_a_158_ = v_tail_162_;
v_a_159_ = v___x_179_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_msg(lean_object* v_m_187_){
_start:
{
lean_object* v_fst_188_; lean_object* v_snd_189_; lean_object* v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; lean_object* v___x_200_; 
v_fst_188_ = lean_ctor_get(v_m_187_, 0);
lean_inc(v_fst_188_);
v_snd_189_ = lean_ctor_get(v_m_187_, 1);
lean_inc(v_snd_189_);
lean_dec_ref(v_m_187_);
v___x_190_ = ((lean_object*)(l_msg___closed__0));
v___x_191_ = l_Nat_reprFast(v_fst_188_);
v___x_192_ = lean_string_append(v___x_190_, v___x_191_);
lean_dec_ref(v___x_191_);
v___x_193_ = ((lean_object*)(l_msg___closed__1));
v___x_194_ = lean_string_append(v___x_192_, v___x_193_);
v___x_195_ = lean_box(0);
v___x_196_ = l_List_mapTR_loop___at___00msg_spec__0(v_snd_189_, v___x_195_);
v___x_197_ = l_array(v___x_196_);
v___x_198_ = lean_string_append(v___x_194_, v___x_197_);
lean_dec_ref(v___x_197_);
v___x_199_ = ((lean_object*)(l_pvalue___closed__1));
v___x_200_ = lean_string_append(v___x_198_, v___x_199_);
return v___x_200_;
}
}
LEAN_EXPORT lean_object* l_faultName(uint8_t v_x_209_){
_start:
{
switch(v_x_209_)
{
case 0:
{
lean_object* v___x_210_; 
v___x_210_ = ((lean_object*)(l_faultName___closed__0));
return v___x_210_;
}
case 1:
{
lean_object* v___x_211_; 
v___x_211_ = ((lean_object*)(l_faultName___closed__1));
return v___x_211_;
}
case 2:
{
lean_object* v___x_212_; 
v___x_212_ = ((lean_object*)(l_faultName___closed__2));
return v___x_212_;
}
case 3:
{
lean_object* v___x_213_; 
v___x_213_ = ((lean_object*)(l_faultName___closed__3));
return v___x_213_;
}
case 4:
{
lean_object* v___x_214_; 
v___x_214_ = ((lean_object*)(l_faultName___closed__4));
return v___x_214_;
}
case 5:
{
lean_object* v___x_215_; 
v___x_215_ = ((lean_object*)(l_faultName___closed__5));
return v___x_215_;
}
case 6:
{
lean_object* v___x_216_; 
v___x_216_ = ((lean_object*)(l_faultName___closed__6));
return v___x_216_;
}
default: 
{
lean_object* v___x_217_; 
v___x_217_ = ((lean_object*)(l_faultName___closed__7));
return v___x_217_;
}
}
}
}
LEAN_EXPORT lean_object* l_faultName___boxed(lean_object* v_x_218_){
_start:
{
uint8_t v_x_76__boxed_219_; lean_object* v_res_220_; 
v_x_76__boxed_219_ = lean_unbox(v_x_218_);
v_res_220_ = l_faultName(v_x_76__boxed_219_);
return v_res_220_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00outcomeText_spec__0(lean_object* v_a_221_, lean_object* v_a_222_){
_start:
{
if (lean_obj_tag(v_a_221_) == 0)
{
lean_object* v___x_223_; 
v___x_223_ = l_List_reverse___redArg(v_a_222_);
return v___x_223_;
}
else
{
lean_object* v_head_224_; lean_object* v_tail_225_; lean_object* v___x_227_; uint8_t v_isShared_228_; uint8_t v_isSharedCheck_234_; 
v_head_224_ = lean_ctor_get(v_a_221_, 0);
v_tail_225_ = lean_ctor_get(v_a_221_, 1);
v_isSharedCheck_234_ = !lean_is_exclusive(v_a_221_);
if (v_isSharedCheck_234_ == 0)
{
v___x_227_ = v_a_221_;
v_isShared_228_ = v_isSharedCheck_234_;
goto v_resetjp_226_;
}
else
{
lean_inc(v_tail_225_);
lean_inc(v_head_224_);
lean_dec(v_a_221_);
v___x_227_ = lean_box(0);
v_isShared_228_ = v_isSharedCheck_234_;
goto v_resetjp_226_;
}
v_resetjp_226_:
{
lean_object* v___x_229_; lean_object* v___x_231_; 
v___x_229_ = l_msg(v_head_224_);
if (v_isShared_228_ == 0)
{
lean_ctor_set(v___x_227_, 1, v_a_222_);
lean_ctor_set(v___x_227_, 0, v___x_229_);
v___x_231_ = v___x_227_;
goto v_reusejp_230_;
}
else
{
lean_object* v_reuseFailAlloc_233_; 
v_reuseFailAlloc_233_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_233_, 0, v___x_229_);
lean_ctor_set(v_reuseFailAlloc_233_, 1, v_a_222_);
v___x_231_ = v_reuseFailAlloc_233_;
goto v_reusejp_230_;
}
v_reusejp_230_:
{
v_a_221_ = v_tail_225_;
v_a_222_ = v___x_231_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_outcomeText(lean_object* v_x_242_){
_start:
{
if (lean_obj_tag(v_x_242_) == 0)
{
lean_object* v_a_243_; lean_object* v_a_244_; lean_object* v_a_245_; lean_object* v_a_246_; lean_object* v___x_247_; lean_object* v___x_248_; lean_object* v___x_249_; lean_object* v___x_250_; lean_object* v___x_251_; lean_object* v___x_252_; lean_object* v___x_253_; lean_object* v___x_254_; lean_object* v___x_255_; lean_object* v___x_256_; lean_object* v___x_257_; lean_object* v___x_258_; lean_object* v___x_259_; lean_object* v___x_260_; lean_object* v___x_261_; lean_object* v___x_262_; lean_object* v___x_263_; lean_object* v___x_264_; lean_object* v___x_265_; 
v_a_243_ = lean_ctor_get(v_x_242_, 0);
lean_inc(v_a_243_);
v_a_244_ = lean_ctor_get(v_x_242_, 1);
lean_inc(v_a_244_);
v_a_245_ = lean_ctor_get(v_x_242_, 2);
lean_inc_ref(v_a_245_);
v_a_246_ = lean_ctor_get(v_x_242_, 3);
lean_inc(v_a_246_);
lean_dec_ref_known(v_x_242_, 4);
v___x_247_ = ((lean_object*)(l_outcomeText___closed__0));
v___x_248_ = l_Nat_reprFast(v_a_243_);
v___x_249_ = lean_string_append(v___x_247_, v___x_248_);
lean_dec_ref(v___x_248_);
v___x_250_ = ((lean_object*)(l_outcomeText___closed__1));
v___x_251_ = lean_string_append(v___x_249_, v___x_250_);
v___x_252_ = l_Nat_reprFast(v_a_244_);
v___x_253_ = lean_string_append(v___x_251_, v___x_252_);
lean_dec_ref(v___x_252_);
v___x_254_ = ((lean_object*)(l_outcomeText___closed__2));
v___x_255_ = lean_string_append(v___x_253_, v___x_254_);
v___x_256_ = l_ss(v_a_245_);
v___x_257_ = lean_string_append(v___x_255_, v___x_256_);
lean_dec_ref(v___x_256_);
v___x_258_ = ((lean_object*)(l_outcomeText___closed__3));
v___x_259_ = lean_string_append(v___x_257_, v___x_258_);
v___x_260_ = lean_box(0);
v___x_261_ = l_List_mapTR_loop___at___00outcomeText_spec__0(v_a_246_, v___x_260_);
v___x_262_ = l_array(v___x_261_);
v___x_263_ = lean_string_append(v___x_259_, v___x_262_);
lean_dec_ref(v___x_262_);
v___x_264_ = ((lean_object*)(l_pvalue___closed__1));
v___x_265_ = lean_string_append(v___x_263_, v___x_264_);
return v___x_265_;
}
else
{
uint8_t v_a_266_; lean_object* v_a_267_; lean_object* v___x_268_; lean_object* v___x_269_; lean_object* v___x_270_; lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_275_; lean_object* v___x_276_; 
v_a_266_ = lean_ctor_get_uint8(v_x_242_, sizeof(void*)*1);
v_a_267_ = lean_ctor_get(v_x_242_, 0);
lean_inc_ref(v_a_267_);
lean_dec_ref_known(v_x_242_, 1);
v___x_268_ = ((lean_object*)(l_outcomeText___closed__4));
v___x_269_ = l_faultName(v_a_266_);
v___x_270_ = lean_string_append(v___x_268_, v___x_269_);
lean_dec_ref(v___x_269_);
v___x_271_ = ((lean_object*)(l_outcomeText___closed__5));
v___x_272_ = lean_string_append(v___x_270_, v___x_271_);
v___x_273_ = l_ss(v_a_267_);
v___x_274_ = lean_string_append(v___x_272_, v___x_273_);
lean_dec_ref(v___x_273_);
v___x_275_ = ((lean_object*)(l_outcomeText___closed__6));
v___x_276_ = lean_string_append(v___x_274_, v___x_275_);
return v___x_276_;
}
}
}
static lean_object* _init_l_main___lam__0___closed__0(void){
_start:
{
lean_object* v___x_277_; lean_object* v___x_278_; 
v___x_277_ = lean_unsigned_to_nat(0u);
v___x_278_ = lean_nat_to_int(v___x_277_);
return v___x_278_;
}
}
LEAN_EXPORT lean_object* l_main___lam__0(lean_object* v_n_279_){
_start:
{
lean_object* v___x_280_; 
v___x_280_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_280_;
}
}
LEAN_EXPORT lean_object* l_main___lam__0___boxed(lean_object* v_n_281_){
_start:
{
lean_object* v_res_282_; 
v_res_282_ = l_main___lam__0(v_n_281_);
lean_dec(v_n_281_);
return v_res_282_;
}
}
LEAN_EXPORT uint8_t l_main___lam__1(lean_object* v_n_283_){
_start:
{
lean_object* v___x_284_; uint8_t v___x_285_; 
v___x_284_ = lean_unsigned_to_nat(1u);
v___x_285_ = lean_nat_dec_eq(v_n_283_, v___x_284_);
if (v___x_285_ == 0)
{
return v___x_285_;
}
else
{
uint8_t v___x_286_; 
v___x_286_ = 0;
return v___x_286_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__1___boxed(lean_object* v_n_287_){
_start:
{
uint8_t v_res_288_; lean_object* v_r_289_; 
v_res_288_ = l_main___lam__1(v_n_287_);
lean_dec(v_n_287_);
v_r_289_ = lean_box(v_res_288_);
return v_r_289_;
}
}
static lean_object* _init_l_main___lam__2___closed__0(void){
_start:
{
lean_object* v___x_290_; lean_object* v___x_291_; 
v___x_290_ = lean_box(0);
v___x_291_ = lean_string_mk(v___x_290_);
return v___x_291_;
}
}
static lean_object* _init_l_main___lam__2___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_292_; lean_object* v___x_293_; 
v___x_292_ = 116;
v___x_293_ = lean_box_uint32(v___x_292_);
return v___x_293_;
}
}
static lean_object* _init_l_main___lam__2___closed__1(void){
_start:
{
lean_object* v___x_294_; lean_object* v___x_295_; lean_object* v___x_296_; 
v___x_294_ = lean_box(0);
v___x_295_ = l_main___lam__2___closed__1___boxed__const__1;
v___x_296_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_296_, 0, v___x_295_);
lean_ctor_set(v___x_296_, 1, v___x_294_);
return v___x_296_;
}
}
static lean_object* _init_l_main___lam__2___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_297_; lean_object* v___x_298_; 
v___x_297_ = 114;
v___x_298_ = lean_box_uint32(v___x_297_);
return v___x_298_;
}
}
static lean_object* _init_l_main___lam__2___closed__2(void){
_start:
{
lean_object* v___x_299_; lean_object* v___x_300_; lean_object* v___x_301_; 
v___x_299_ = lean_obj_once(&l_main___lam__2___closed__1, &l_main___lam__2___closed__1_once, _init_l_main___lam__2___closed__1);
v___x_300_ = l_main___lam__2___closed__2___boxed__const__1;
v___x_301_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_301_, 0, v___x_300_);
lean_ctor_set(v___x_301_, 1, v___x_299_);
return v___x_301_;
}
}
static lean_object* _init_l_main___lam__2___closed__3___boxed__const__1(void){
_start:
{
uint32_t v___x_302_; lean_object* v___x_303_; 
v___x_302_ = 97;
v___x_303_ = lean_box_uint32(v___x_302_);
return v___x_303_;
}
}
static lean_object* _init_l_main___lam__2___closed__3(void){
_start:
{
lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; 
v___x_304_ = lean_obj_once(&l_main___lam__2___closed__2, &l_main___lam__2___closed__2_once, _init_l_main___lam__2___closed__2);
v___x_305_ = l_main___lam__2___closed__3___boxed__const__1;
v___x_306_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_306_, 0, v___x_305_);
lean_ctor_set(v___x_306_, 1, v___x_304_);
return v___x_306_;
}
}
static lean_object* _init_l_main___lam__2___closed__4(void){
_start:
{
lean_object* v___x_307_; lean_object* v___x_308_; lean_object* v___x_309_; 
v___x_307_ = lean_obj_once(&l_main___lam__2___closed__3, &l_main___lam__2___closed__3_once, _init_l_main___lam__2___closed__3);
v___x_308_ = l_main___lam__2___closed__1___boxed__const__1;
v___x_309_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_309_, 0, v___x_308_);
lean_ctor_set(v___x_309_, 1, v___x_307_);
return v___x_309_;
}
}
static lean_object* _init_l_main___lam__2___closed__5___boxed__const__1(void){
_start:
{
uint32_t v___x_310_; lean_object* v___x_311_; 
v___x_310_ = 115;
v___x_311_ = lean_box_uint32(v___x_310_);
return v___x_311_;
}
}
static lean_object* _init_l_main___lam__2___closed__5(void){
_start:
{
lean_object* v___x_312_; lean_object* v___x_313_; lean_object* v___x_314_; 
v___x_312_ = lean_obj_once(&l_main___lam__2___closed__4, &l_main___lam__2___closed__4_once, _init_l_main___lam__2___closed__4);
v___x_313_ = l_main___lam__2___closed__5___boxed__const__1;
v___x_314_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_314_, 0, v___x_313_);
lean_ctor_set(v___x_314_, 1, v___x_312_);
return v___x_314_;
}
}
static lean_object* _init_l_main___lam__2___closed__6(void){
_start:
{
lean_object* v___x_315_; lean_object* v___x_316_; 
v___x_315_ = lean_obj_once(&l_main___lam__2___closed__5, &l_main___lam__2___closed__5_once, _init_l_main___lam__2___closed__5);
v___x_316_ = lean_string_mk(v___x_315_);
return v___x_316_;
}
}
LEAN_EXPORT lean_object* l_main___lam__2(lean_object* v_n_317_){
_start:
{
lean_object* v___x_318_; uint8_t v___x_319_; 
v___x_318_ = lean_unsigned_to_nat(4u);
v___x_319_ = lean_nat_dec_eq(v_n_317_, v___x_318_);
if (v___x_319_ == 0)
{
lean_object* v___x_320_; 
v___x_320_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_320_;
}
else
{
lean_object* v___x_321_; 
v___x_321_ = lean_obj_once(&l_main___lam__2___closed__6, &l_main___lam__2___closed__6_once, _init_l_main___lam__2___closed__6);
return v___x_321_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__2___boxed(lean_object* v_n_322_){
_start:
{
lean_object* v_res_323_; 
v_res_323_ = l_main___lam__2(v_n_322_);
lean_dec(v_n_322_);
return v_res_323_;
}
}
LEAN_EXPORT lean_object* l_main___lam__3(lean_object* v_n_324_){
_start:
{
lean_object* v___x_325_; 
v___x_325_ = lean_box(0);
return v___x_325_;
}
}
LEAN_EXPORT lean_object* l_main___lam__3___boxed(lean_object* v_n_326_){
_start:
{
lean_object* v_res_327_; 
v_res_327_ = l_main___lam__3(v_n_326_);
lean_dec(v_n_326_);
return v_res_327_;
}
}
LEAN_EXPORT lean_object* l_main___lam__4(lean_object* v_n_328_){
_start:
{
lean_object* v___x_329_; uint8_t v___x_330_; 
v___x_329_ = lean_unsigned_to_nat(2u);
v___x_330_ = lean_nat_dec_eq(v_n_328_, v___x_329_);
if (v___x_330_ == 0)
{
lean_object* v___x_331_; 
v___x_331_ = lean_unsigned_to_nat(0u);
return v___x_331_;
}
else
{
lean_object* v___x_332_; 
v___x_332_ = lean_unsigned_to_nat(4294967295u);
return v___x_332_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__4___boxed(lean_object* v_n_333_){
_start:
{
lean_object* v_res_334_; 
v_res_334_ = l_main___lam__4(v_n_333_);
lean_dec(v_n_333_);
return v_res_334_;
}
}
LEAN_EXPORT uint8_t l_main___lam__5(lean_object* v_n_335_){
_start:
{
uint8_t v___x_336_; 
v___x_336_ = 0;
return v___x_336_;
}
}
LEAN_EXPORT lean_object* l_main___lam__5___boxed(lean_object* v_n_337_){
_start:
{
uint8_t v_res_338_; lean_object* v_r_339_; 
v_res_338_ = l_main___lam__5(v_n_337_);
lean_dec(v_n_337_);
v_r_339_ = lean_box(v_res_338_);
return v_r_339_;
}
}
LEAN_EXPORT lean_object* l_main___lam__6(lean_object* v_n_340_){
_start:
{
lean_object* v___x_341_; 
v___x_341_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_341_;
}
}
LEAN_EXPORT lean_object* l_main___lam__6___boxed(lean_object* v_n_342_){
_start:
{
lean_object* v_res_343_; 
v_res_343_ = l_main___lam__6(v_n_342_);
lean_dec(v_n_342_);
return v_res_343_;
}
}
LEAN_EXPORT uint8_t l_main___lam__8(lean_object* v_n_344_){
_start:
{
lean_object* v___x_345_; uint8_t v___x_346_; 
v___x_345_ = lean_unsigned_to_nat(1u);
v___x_346_ = lean_nat_dec_eq(v_n_344_, v___x_345_);
return v___x_346_;
}
}
LEAN_EXPORT lean_object* l_main___lam__8___boxed(lean_object* v_n_347_){
_start:
{
uint8_t v_res_348_; lean_object* v_r_349_; 
v_res_348_ = l_main___lam__8(v_n_347_);
lean_dec(v_n_347_);
v_r_349_ = lean_box(v_res_348_);
return v_r_349_;
}
}
static lean_object* _init_l_main___lam__7___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_350_; lean_object* v___x_351_; 
v___x_350_ = 0;
v___x_351_ = lean_box_uint32(v___x_350_);
return v___x_351_;
}
}
static lean_object* _init_l_main___lam__7___closed__0(void){
_start:
{
lean_object* v___x_352_; lean_object* v___x_353_; lean_object* v___x_354_; 
v___x_352_ = lean_box(0);
v___x_353_ = l_main___lam__7___closed__0___boxed__const__1;
v___x_354_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_354_, 0, v___x_353_);
lean_ctor_set(v___x_354_, 1, v___x_352_);
return v___x_354_;
}
}
static lean_object* _init_l_main___lam__7___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_355_; lean_object* v___x_356_; 
v___x_355_ = 10;
v___x_356_ = lean_box_uint32(v___x_355_);
return v___x_356_;
}
}
static lean_object* _init_l_main___lam__7___closed__1(void){
_start:
{
lean_object* v___x_357_; lean_object* v___x_358_; lean_object* v___x_359_; 
v___x_357_ = lean_obj_once(&l_main___lam__7___closed__0, &l_main___lam__7___closed__0_once, _init_l_main___lam__7___closed__0);
v___x_358_ = l_main___lam__7___closed__1___boxed__const__1;
v___x_359_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_359_, 0, v___x_358_);
lean_ctor_set(v___x_359_, 1, v___x_357_);
return v___x_359_;
}
}
static lean_object* _init_l_main___lam__7___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_360_; lean_object* v___x_361_; 
v___x_360_ = 24320;
v___x_361_ = lean_box_uint32(v___x_360_);
return v___x_361_;
}
}
static lean_object* _init_l_main___lam__7___closed__2(void){
_start:
{
lean_object* v___x_362_; lean_object* v___x_363_; lean_object* v___x_364_; 
v___x_362_ = lean_obj_once(&l_main___lam__7___closed__1, &l_main___lam__7___closed__1_once, _init_l_main___lam__7___closed__1);
v___x_363_ = l_main___lam__7___closed__2___boxed__const__1;
v___x_364_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_364_, 0, v___x_363_);
lean_ctor_set(v___x_364_, 1, v___x_362_);
return v___x_364_;
}
}
static lean_object* _init_l_main___lam__7___closed__3(void){
_start:
{
lean_object* v___x_365_; lean_object* v___x_366_; 
v___x_365_ = lean_obj_once(&l_main___lam__7___closed__2, &l_main___lam__7___closed__2_once, _init_l_main___lam__7___closed__2);
v___x_366_ = lean_string_mk(v___x_365_);
return v___x_366_;
}
}
LEAN_EXPORT lean_object* l_main___lam__7(lean_object* v_n_367_){
_start:
{
lean_object* v___x_368_; uint8_t v___x_369_; 
v___x_368_ = lean_unsigned_to_nat(4u);
v___x_369_ = lean_nat_dec_eq(v_n_367_, v___x_368_);
if (v___x_369_ == 0)
{
lean_object* v___x_370_; 
v___x_370_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_370_;
}
else
{
lean_object* v___x_371_; 
v___x_371_ = lean_obj_once(&l_main___lam__7___closed__3, &l_main___lam__7___closed__3_once, _init_l_main___lam__7___closed__3);
return v___x_371_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__7___boxed(lean_object* v_n_372_){
_start:
{
lean_object* v_res_373_; 
v_res_373_ = l_main___lam__7(v_n_372_);
lean_dec(v_n_372_);
return v_res_373_;
}
}
LEAN_EXPORT lean_object* l_main___lam__9(lean_object* v___x_383_, lean_object* v_n_384_){
_start:
{
uint8_t v___x_385_; 
v___x_385_ = lean_nat_dec_eq(v_n_384_, v___x_383_);
if (v___x_385_ == 0)
{
lean_object* v___x_386_; 
lean_dec(v___x_383_);
v___x_386_ = lean_box(0);
return v___x_386_;
}
else
{
lean_object* v___x_387_; lean_object* v___x_388_; 
v___x_387_ = ((lean_object*)(l_main___lam__9___closed__2));
v___x_388_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_388_, 0, v___x_383_);
lean_ctor_set(v___x_388_, 1, v___x_387_);
return v___x_388_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__9___boxed(lean_object* v___x_389_, lean_object* v_n_390_){
_start:
{
lean_object* v_res_391_; 
v_res_391_ = l_main___lam__9(v___x_389_, v_n_390_);
lean_dec(v_n_390_);
return v_res_391_;
}
}
LEAN_EXPORT lean_object* l_main___lam__10(lean_object* v___x_392_, lean_object* v_n_393_){
_start:
{
lean_inc(v___x_392_);
return v___x_392_;
}
}
LEAN_EXPORT lean_object* l_main___lam__10___boxed(lean_object* v___x_394_, lean_object* v_n_395_){
_start:
{
lean_object* v_res_396_; 
v_res_396_ = l_main___lam__10(v___x_394_, v_n_395_);
lean_dec(v_n_395_);
lean_dec(v___x_394_);
return v_res_396_;
}
}
LEAN_EXPORT lean_object* l_main___lam__12(lean_object* v___x_397_, lean_object* v_n_398_){
_start:
{
lean_inc(v___x_397_);
return v___x_397_;
}
}
LEAN_EXPORT lean_object* l_main___lam__12___boxed(lean_object* v___x_399_, lean_object* v_n_400_){
_start:
{
lean_object* v_res_401_; 
v_res_401_ = l_main___lam__12(v___x_399_, v_n_400_);
lean_dec(v_n_400_);
lean_dec(v___x_399_);
return v_res_401_;
}
}
LEAN_EXPORT lean_object* l_main___lam__11(lean_object* v___x_402_, lean_object* v___x_403_, lean_object* v_n_404_){
_start:
{
uint8_t v___x_405_; 
v___x_405_ = lean_nat_dec_eq(v_n_404_, v___x_402_);
if (v___x_405_ == 0)
{
lean_object* v___x_406_; 
lean_dec(v___x_403_);
v___x_406_ = lean_box(0);
return v___x_406_;
}
else
{
lean_object* v___x_407_; lean_object* v___x_408_; 
v___x_407_ = ((lean_object*)(l_main___lam__9___closed__2));
v___x_408_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_408_, 0, v___x_403_);
lean_ctor_set(v___x_408_, 1, v___x_407_);
return v___x_408_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__11___boxed(lean_object* v___x_409_, lean_object* v___x_410_, lean_object* v_n_411_){
_start:
{
lean_object* v_res_412_; 
v_res_412_ = l_main___lam__11(v___x_409_, v___x_410_, v_n_411_);
lean_dec(v_n_411_);
lean_dec(v___x_409_);
return v_res_412_;
}
}
LEAN_EXPORT lean_object* l_main___lam__13(lean_object* v___x_413_, lean_object* v___x_414_, lean_object* v___x_415_, lean_object* v_n_416_){
_start:
{
uint8_t v___x_417_; 
v___x_417_ = lean_nat_dec_eq(v_n_416_, v___x_413_);
if (v___x_417_ == 0)
{
lean_inc(v___x_414_);
return v___x_414_;
}
else
{
lean_inc(v___x_415_);
return v___x_415_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__13___boxed(lean_object* v___x_418_, lean_object* v___x_419_, lean_object* v___x_420_, lean_object* v_n_421_){
_start:
{
lean_object* v_res_422_; 
v_res_422_ = l_main___lam__13(v___x_418_, v___x_419_, v___x_420_, v_n_421_);
lean_dec(v_n_421_);
lean_dec(v___x_420_);
lean_dec(v___x_419_);
lean_dec(v___x_418_);
return v_res_422_;
}
}
LEAN_EXPORT lean_object* l_main___lam__14(lean_object* v___x_423_, lean_object* v___x_424_, lean_object* v___x_425_, lean_object* v_n_426_){
_start:
{
uint8_t v___x_427_; 
v___x_427_ = lean_nat_dec_eq(v_n_426_, v___x_423_);
if (v___x_427_ == 0)
{
lean_dec(v___x_425_);
lean_inc(v___x_424_);
return v___x_424_;
}
else
{
lean_object* v___x_428_; lean_object* v___x_429_; 
v___x_428_ = lean_nat_to_int(v___x_425_);
v___x_429_ = lean_int_neg(v___x_428_);
lean_dec(v___x_428_);
return v___x_429_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__14___boxed(lean_object* v___x_430_, lean_object* v___x_431_, lean_object* v___x_432_, lean_object* v_n_433_){
_start:
{
lean_object* v_res_434_; 
v_res_434_ = l_main___lam__14(v___x_430_, v___x_431_, v___x_432_, v_n_433_);
lean_dec(v_n_433_);
lean_dec(v___x_431_);
lean_dec(v___x_430_);
return v_res_434_;
}
}
LEAN_EXPORT lean_object* l_main___lam__15(lean_object* v___x_435_, lean_object* v___x_436_, lean_object* v___x_437_, lean_object* v_n_438_){
_start:
{
uint8_t v___x_439_; 
v___x_439_ = lean_nat_dec_eq(v_n_438_, v___x_435_);
if (v___x_439_ == 0)
{
lean_dec(v___x_437_);
lean_inc(v___x_436_);
return v___x_436_;
}
else
{
lean_object* v___x_440_; 
v___x_440_ = lean_nat_to_int(v___x_437_);
return v___x_440_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__15___boxed(lean_object* v___x_441_, lean_object* v___x_442_, lean_object* v___x_443_, lean_object* v_n_444_){
_start:
{
lean_object* v_res_445_; 
v_res_445_ = l_main___lam__15(v___x_441_, v___x_442_, v___x_443_, v_n_444_);
lean_dec(v_n_444_);
lean_dec(v___x_442_);
lean_dec(v___x_441_);
return v_res_445_;
}
}
LEAN_EXPORT lean_object* l_main___lam__16(lean_object* v___x_446_, lean_object* v___x_447_, lean_object* v___x_448_, lean_object* v___x_449_, lean_object* v_n_450_){
_start:
{
uint8_t v___x_451_; 
v___x_451_ = lean_nat_dec_eq(v_n_450_, v___x_446_);
if (v___x_451_ == 0)
{
lean_object* v___x_452_; 
lean_dec(v___x_449_);
lean_dec(v___x_448_);
lean_dec(v___x_447_);
lean_dec(v___x_446_);
v___x_452_ = lean_box(0);
return v___x_452_;
}
else
{
lean_object* v___x_453_; lean_object* v___x_454_; lean_object* v___x_455_; lean_object* v___x_456_; lean_object* v___x_457_; lean_object* v___x_458_; lean_object* v___x_459_; lean_object* v___x_460_; lean_object* v___x_461_; lean_object* v___x_462_; lean_object* v___x_463_; lean_object* v___x_464_; 
v___x_453_ = lean_unsigned_to_nat(4090u);
v___x_454_ = l_List_replicateTR___redArg(v___x_453_, v___x_447_);
v___x_455_ = lean_unsigned_to_nat(128u);
v___x_456_ = lean_unsigned_to_nat(255u);
v___x_457_ = lean_box(0);
lean_inc(v___x_446_);
v___x_458_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_458_, 0, v___x_446_);
lean_ctor_set(v___x_458_, 1, v___x_457_);
v___x_459_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_459_, 0, v___x_448_);
lean_ctor_set(v___x_459_, 1, v___x_458_);
v___x_460_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_460_, 0, v___x_449_);
lean_ctor_set(v___x_460_, 1, v___x_459_);
v___x_461_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_461_, 0, v___x_456_);
lean_ctor_set(v___x_461_, 1, v___x_460_);
v___x_462_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_462_, 0, v___x_455_);
lean_ctor_set(v___x_462_, 1, v___x_461_);
v___x_463_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_463_, 0, v___x_446_);
lean_ctor_set(v___x_463_, 1, v___x_462_);
v___x_464_ = l_List_appendTR___redArg(v___x_454_, v___x_463_);
return v___x_464_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__16___boxed(lean_object* v___x_465_, lean_object* v___x_466_, lean_object* v___x_467_, lean_object* v___x_468_, lean_object* v_n_469_){
_start:
{
lean_object* v_res_470_; 
v_res_470_ = l_main___lam__16(v___x_465_, v___x_466_, v___x_467_, v___x_468_, v_n_469_);
lean_dec(v_n_469_);
return v_res_470_;
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(lean_object* v_s_471_){
_start:
{
lean_object* v___x_473_; lean_object* v_putStr_474_; lean_object* v___x_475_; 
v___x_473_ = lean_get_stdout();
v_putStr_474_ = lean_ctor_get(v___x_473_, 4);
lean_inc_ref(v_putStr_474_);
lean_dec_ref(v___x_473_);
v___x_475_ = lean_apply_2(v_putStr_474_, v_s_471_, lean_box(0));
return v___x_475_;
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0___boxed(lean_object* v_s_476_, lean_object* v_a_477_){
_start:
{
lean_object* v_res_478_; 
v_res_478_ = l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(v_s_476_);
return v_res_478_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0(lean_object* v_s_479_){
_start:
{
uint32_t v___x_481_; lean_object* v___x_482_; lean_object* v___x_483_; 
v___x_481_ = 10;
v___x_482_ = lean_string_push(v_s_479_, v___x_481_);
v___x_483_ = l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(v___x_482_);
return v___x_483_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0___boxed(lean_object* v_s_484_, lean_object* v_a_485_){
_start:
{
lean_object* v_res_486_; 
v_res_486_ = l_IO_println___at___00main_spec__0(v_s_484_);
return v_res_486_;
}
}
static lean_object* _init_l_main___closed__12(void){
_start:
{
lean_object* v___x_506_; lean_object* v___f_507_; 
v___x_506_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___f_507_ = lean_alloc_closure((void*)(l_main___lam__12___boxed), 2, 1);
lean_closure_set(v___f_507_, 0, v___x_506_);
return v___f_507_;
}
}
static lean_object* _init_l_main___closed__13(void){
_start:
{
lean_object* v___x_508_; lean_object* v___x_509_; lean_object* v___x_510_; lean_object* v___x_511_; lean_object* v_s__0__0_512_; 
v___x_508_ = lean_box(0);
v___x_509_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_510_ = lean_unsigned_to_nat(0u);
v___x_511_ = ((lean_object*)(l_main___closed__9));
v_s__0__0_512_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_s__0__0_512_, 0, v___x_511_);
lean_ctor_set(v_s__0__0_512_, 1, v___x_510_);
lean_ctor_set(v_s__0__0_512_, 2, v___x_509_);
lean_ctor_set(v_s__0__0_512_, 3, v___x_508_);
return v_s__0__0_512_;
}
}
static lean_object* _init_l_main___closed__14(void){
_start:
{
lean_object* v___f_513_; lean_object* v___f_514_; lean_object* v___f_515_; lean_object* v___f_516_; lean_object* v___f_517_; lean_object* v___x_518_; 
v___f_513_ = ((lean_object*)(l_main___closed__11));
v___f_514_ = ((lean_object*)(l_main___closed__10));
v___f_515_ = ((lean_object*)(l_main___closed__6));
v___f_516_ = ((lean_object*)(l_main___closed__5));
v___f_517_ = lean_obj_once(&l_main___closed__12, &l_main___closed__12_once, _init_l_main___closed__12);
v___x_518_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_518_, 0, v___f_517_);
lean_ctor_set(v___x_518_, 1, v___f_516_);
lean_ctor_set(v___x_518_, 2, v___f_515_);
lean_ctor_set(v___x_518_, 3, v___f_514_);
lean_ctor_set(v___x_518_, 4, v___f_513_);
return v___x_518_;
}
}
static lean_object* _init_l_main___closed__15(void){
_start:
{
lean_object* v___x_519_; lean_object* v___x_520_; lean_object* v___x_521_; lean_object* v_s__0__0_522_; lean_object* v___x_523_; lean_object* v_r__0__0_524_; 
v___x_519_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_520_ = lean_obj_once(&l_main___closed__14, &l_main___closed__14_once, _init_l_main___closed__14);
v___x_521_ = lean_unsigned_to_nat(0u);
v_s__0__0_522_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_523_ = l_MachineRuntime_model;
v_r__0__0_524_ = l_FormalSpecAgent_TypedMachine_external(v___x_523_, v_s__0__0_522_, v___x_521_, v___x_520_, v___x_519_);
return v_r__0__0_524_;
}
}
static lean_object* _init_l_main___closed__16(void){
_start:
{
lean_object* v_r__0__0_525_; lean_object* v_s__0__0_526_; lean_object* v___x_527_; lean_object* v___x_528_; 
v_r__0__0_525_ = lean_obj_once(&l_main___closed__15, &l_main___closed__15_once, _init_l_main___closed__15);
v_s__0__0_526_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_527_ = l_MachineRuntime_schema;
v___x_528_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_527_, v_s__0__0_526_, v_r__0__0_525_);
return v___x_528_;
}
}
static lean_object* _init_l_main___closed__17(void){
_start:
{
lean_object* v___x_529_; lean_object* v___x_530_; 
v___x_529_ = lean_obj_once(&l_main___closed__16, &l_main___closed__16_once, _init_l_main___closed__16);
v___x_530_ = l_outcomeText(v___x_529_);
return v___x_530_;
}
}
static lean_object* _init_l_main___closed__18(void){
_start:
{
lean_object* v_r__0__0_531_; lean_object* v_s__0__0_532_; lean_object* v___x_533_; 
v_r__0__0_531_ = lean_obj_once(&l_main___closed__15, &l_main___closed__15_once, _init_l_main___closed__15);
v_s__0__0_532_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_533_ = l_FormalSpecAgent_TypedMachine_rollback(v_s__0__0_532_, v_r__0__0_531_);
return v___x_533_;
}
}
static lean_object* _init_l_main___closed__20(void){
_start:
{
lean_object* v___f_537_; lean_object* v___f_538_; lean_object* v___f_539_; lean_object* v___f_540_; lean_object* v___f_541_; lean_object* v___x_542_; 
v___f_537_ = ((lean_object*)(l_main___closed__11));
v___f_538_ = ((lean_object*)(l_main___closed__3));
v___f_539_ = ((lean_object*)(l_main___closed__6));
v___f_540_ = ((lean_object*)(l_main___closed__5));
v___f_541_ = lean_obj_once(&l_main___closed__12, &l_main___closed__12_once, _init_l_main___closed__12);
v___x_542_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_542_, 0, v___f_541_);
lean_ctor_set(v___x_542_, 1, v___f_540_);
lean_ctor_set(v___x_542_, 2, v___f_539_);
lean_ctor_set(v___x_542_, 3, v___f_538_);
lean_ctor_set(v___x_542_, 4, v___f_537_);
return v___x_542_;
}
}
static lean_object* _init_l_main___closed__21(void){
_start:
{
lean_object* v___x_543_; lean_object* v___x_544_; 
v___x_543_ = lean_unsigned_to_nat(5u);
v___x_544_ = lean_nat_to_int(v___x_543_);
return v___x_544_;
}
}
static lean_object* _init_l_main___closed__22(void){
_start:
{
lean_object* v___x_545_; lean_object* v___x_546_; lean_object* v___x_547_; lean_object* v___f_548_; 
v___x_545_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_546_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_547_ = lean_unsigned_to_nat(0u);
v___f_548_ = lean_alloc_closure((void*)(l_main___lam__13___boxed), 4, 3);
lean_closure_set(v___f_548_, 0, v___x_547_);
lean_closure_set(v___f_548_, 1, v___x_546_);
lean_closure_set(v___f_548_, 2, v___x_545_);
return v___f_548_;
}
}
static lean_object* _init_l_main___closed__23(void){
_start:
{
lean_object* v___x_549_; lean_object* v___x_550_; lean_object* v___x_551_; lean_object* v___x_552_; lean_object* v___x_553_; lean_object* v___x_554_; 
v___x_549_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_550_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_551_ = lean_unsigned_to_nat(3u);
v___x_552_ = lean_obj_once(&l_main___closed__18, &l_main___closed__18_once, _init_l_main___closed__18);
v___x_553_ = l_MachineRuntime_model;
v___x_554_ = l_FormalSpecAgent_TypedMachine_external(v___x_553_, v___x_552_, v___x_551_, v___x_550_, v___x_549_);
return v___x_554_;
}
}
static lean_object* _init_l_main___closed__24(void){
_start:
{
lean_object* v___x_555_; lean_object* v___x_556_; lean_object* v___x_557_; lean_object* v___x_558_; 
v___x_555_ = lean_obj_once(&l_main___closed__23, &l_main___closed__23_once, _init_l_main___closed__23);
v___x_556_ = lean_obj_once(&l_main___closed__18, &l_main___closed__18_once, _init_l_main___closed__18);
v___x_557_ = l_MachineRuntime_schema;
v___x_558_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_557_, v___x_556_, v___x_555_);
return v___x_558_;
}
}
static lean_object* _init_l_main___closed__25(void){
_start:
{
lean_object* v___x_559_; lean_object* v___x_560_; 
v___x_559_ = lean_obj_once(&l_main___closed__24, &l_main___closed__24_once, _init_l_main___closed__24);
v___x_560_ = l_outcomeText(v___x_559_);
return v___x_560_;
}
}
static lean_object* _init_l_main___closed__26(void){
_start:
{
lean_object* v___x_561_; lean_object* v___x_562_; lean_object* v___x_563_; 
v___x_561_ = lean_obj_once(&l_main___closed__23, &l_main___closed__23_once, _init_l_main___closed__23);
v___x_562_ = lean_obj_once(&l_main___closed__18, &l_main___closed__18_once, _init_l_main___closed__18);
v___x_563_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_562_, v___x_561_);
return v___x_563_;
}
}
static lean_object* _init_l_main___closed__27(void){
_start:
{
lean_object* v___x_564_; lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_567_; 
v___x_564_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_565_ = lean_obj_once(&l_main___closed__26, &l_main___closed__26_once, _init_l_main___closed__26);
v___x_566_ = l_MachineRuntime_model;
v___x_567_ = l_FormalSpecAgent_TypedMachine_stepTimer(v___x_566_, v___x_565_, v___x_564_);
return v___x_567_;
}
}
static lean_object* _init_l_main___closed__28(void){
_start:
{
lean_object* v___x_568_; lean_object* v___x_569_; lean_object* v___x_570_; lean_object* v___x_571_; 
v___x_568_ = lean_obj_once(&l_main___closed__27, &l_main___closed__27_once, _init_l_main___closed__27);
v___x_569_ = lean_obj_once(&l_main___closed__26, &l_main___closed__26_once, _init_l_main___closed__26);
v___x_570_ = l_MachineRuntime_schema;
v___x_571_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_570_, v___x_569_, v___x_568_);
return v___x_571_;
}
}
static lean_object* _init_l_main___closed__29(void){
_start:
{
lean_object* v___x_572_; lean_object* v___x_573_; 
v___x_572_ = lean_obj_once(&l_main___closed__28, &l_main___closed__28_once, _init_l_main___closed__28);
v___x_573_ = l_outcomeText(v___x_572_);
return v___x_573_;
}
}
static lean_object* _init_l_main___closed__30(void){
_start:
{
lean_object* v___x_574_; lean_object* v___x_575_; lean_object* v___x_576_; 
v___x_574_ = lean_obj_once(&l_main___closed__27, &l_main___closed__27_once, _init_l_main___closed__27);
v___x_575_ = lean_obj_once(&l_main___closed__26, &l_main___closed__26_once, _init_l_main___closed__26);
v___x_576_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_575_, v___x_574_);
return v___x_576_;
}
}
static lean_object* _init_l_main___closed__31(void){
_start:
{
lean_object* v___x_577_; lean_object* v___x_578_; lean_object* v___x_579_; lean_object* v___x_580_; 
v___x_577_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_578_ = lean_obj_once(&l_main___closed__30, &l_main___closed__30_once, _init_l_main___closed__30);
v___x_579_ = l_MachineRuntime_model;
v___x_580_ = l_FormalSpecAgent_TypedMachine_stepTimer(v___x_579_, v___x_578_, v___x_577_);
return v___x_580_;
}
}
static lean_object* _init_l_main___closed__32(void){
_start:
{
lean_object* v___x_581_; lean_object* v___x_582_; lean_object* v___x_583_; lean_object* v___x_584_; 
v___x_581_ = lean_obj_once(&l_main___closed__31, &l_main___closed__31_once, _init_l_main___closed__31);
v___x_582_ = lean_obj_once(&l_main___closed__30, &l_main___closed__30_once, _init_l_main___closed__30);
v___x_583_ = l_MachineRuntime_schema;
v___x_584_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_583_, v___x_582_, v___x_581_);
return v___x_584_;
}
}
static lean_object* _init_l_main___closed__33(void){
_start:
{
lean_object* v___x_585_; lean_object* v___x_586_; 
v___x_585_ = lean_obj_once(&l_main___closed__32, &l_main___closed__32_once, _init_l_main___closed__32);
v___x_586_ = l_outcomeText(v___x_585_);
return v___x_586_;
}
}
static lean_object* _init_l_main___closed__34(void){
_start:
{
lean_object* v___f_587_; lean_object* v___f_588_; lean_object* v___f_589_; lean_object* v___f_590_; lean_object* v___f_591_; lean_object* v___x_592_; 
v___f_587_ = ((lean_object*)(l_main___closed__11));
v___f_588_ = ((lean_object*)(l_main___closed__19));
v___f_589_ = ((lean_object*)(l_main___closed__8));
v___f_590_ = ((lean_object*)(l_main___closed__7));
v___f_591_ = lean_obj_once(&l_main___closed__22, &l_main___closed__22_once, _init_l_main___closed__22);
v___x_592_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_592_, 0, v___f_591_);
lean_ctor_set(v___x_592_, 1, v___f_590_);
lean_ctor_set(v___x_592_, 2, v___f_589_);
lean_ctor_set(v___x_592_, 3, v___f_588_);
lean_ctor_set(v___x_592_, 4, v___f_587_);
return v___x_592_;
}
}
static lean_object* _init_l_main___closed__35(void){
_start:
{
lean_object* v___x_593_; lean_object* v___x_594_; lean_object* v___x_595_; lean_object* v___f_596_; 
v___x_593_ = lean_unsigned_to_nat(1u);
v___x_594_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_595_ = lean_unsigned_to_nat(0u);
v___f_596_ = lean_alloc_closure((void*)(l_main___lam__14___boxed), 4, 3);
lean_closure_set(v___f_596_, 0, v___x_595_);
lean_closure_set(v___f_596_, 1, v___x_594_);
lean_closure_set(v___f_596_, 2, v___x_593_);
return v___f_596_;
}
}
static lean_object* _init_l_main___closed__36(void){
_start:
{
lean_object* v___x_597_; lean_object* v___x_598_; lean_object* v___x_599_; 
v___x_597_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_598_ = lean_unsigned_to_nat(0u);
v___x_599_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_599_, 0, v___x_598_);
lean_ctor_set(v___x_599_, 1, v___x_597_);
return v___x_599_;
}
}
static lean_object* _init_l_main___closed__37(void){
_start:
{
lean_object* v___x_600_; lean_object* v___x_601_; lean_object* v___x_602_; 
v___x_600_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_601_ = lean_unsigned_to_nat(1u);
v___x_602_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_602_, 0, v___x_601_);
lean_ctor_set(v___x_602_, 1, v___x_600_);
return v___x_602_;
}
}
static lean_object* _init_l_main___closed__38(void){
_start:
{
lean_object* v___x_603_; lean_object* v___x_604_; lean_object* v___x_605_; 
v___x_603_ = lean_box(0);
v___x_604_ = lean_obj_once(&l_main___closed__37, &l_main___closed__37_once, _init_l_main___closed__37);
v___x_605_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_605_, 0, v___x_604_);
lean_ctor_set(v___x_605_, 1, v___x_603_);
return v___x_605_;
}
}
static lean_object* _init_l_main___closed__39(void){
_start:
{
lean_object* v___x_606_; lean_object* v___x_607_; lean_object* v___x_608_; 
v___x_606_ = lean_obj_once(&l_main___closed__38, &l_main___closed__38_once, _init_l_main___closed__38);
v___x_607_ = lean_obj_once(&l_main___closed__36, &l_main___closed__36_once, _init_l_main___closed__36);
v___x_608_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_608_, 0, v___x_607_);
lean_ctor_set(v___x_608_, 1, v___x_606_);
return v___x_608_;
}
}
static lean_object* _init_l_main___closed__40(void){
_start:
{
lean_object* v___x_609_; lean_object* v___x_610_; lean_object* v___x_611_; lean_object* v___x_612_; lean_object* v___x_613_; 
v___x_609_ = lean_obj_once(&l_main___closed__39, &l_main___closed__39_once, _init_l_main___closed__39);
v___x_610_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_611_ = lean_unsigned_to_nat(1u);
v___x_612_ = lean_obj_once(&l_main___closed__34, &l_main___closed__34_once, _init_l_main___closed__34);
v___x_613_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_613_, 0, v___x_612_);
lean_ctor_set(v___x_613_, 1, v___x_611_);
lean_ctor_set(v___x_613_, 2, v___x_610_);
lean_ctor_set(v___x_613_, 3, v___x_609_);
return v___x_613_;
}
}
static lean_object* _init_l_main___closed__41(void){
_start:
{
lean_object* v___x_614_; lean_object* v___x_615_; lean_object* v___x_616_; lean_object* v___x_617_; lean_object* v___x_618_; lean_object* v___x_619_; 
v___x_614_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_615_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_616_ = lean_unsigned_to_nat(3u);
v___x_617_ = lean_obj_once(&l_main___closed__40, &l_main___closed__40_once, _init_l_main___closed__40);
v___x_618_ = l_MachineRuntime_model;
v___x_619_ = l_FormalSpecAgent_TypedMachine_external(v___x_618_, v___x_617_, v___x_616_, v___x_615_, v___x_614_);
return v___x_619_;
}
}
static lean_object* _init_l_main___closed__42(void){
_start:
{
lean_object* v___x_620_; lean_object* v___x_621_; lean_object* v___x_622_; lean_object* v___x_623_; 
v___x_620_ = lean_obj_once(&l_main___closed__41, &l_main___closed__41_once, _init_l_main___closed__41);
v___x_621_ = lean_obj_once(&l_main___closed__40, &l_main___closed__40_once, _init_l_main___closed__40);
v___x_622_ = l_MachineRuntime_schema;
v___x_623_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_622_, v___x_621_, v___x_620_);
return v___x_623_;
}
}
static lean_object* _init_l_main___closed__43(void){
_start:
{
lean_object* v___x_624_; lean_object* v___x_625_; 
v___x_624_ = lean_obj_once(&l_main___closed__42, &l_main___closed__42_once, _init_l_main___closed__42);
v___x_625_ = l_outcomeText(v___x_624_);
return v___x_625_;
}
}
static lean_object* _init_l_main___closed__44(void){
_start:
{
lean_object* v___x_626_; lean_object* v___x_627_; lean_object* v___x_628_; 
v___x_626_ = lean_obj_once(&l_main___closed__41, &l_main___closed__41_once, _init_l_main___closed__41);
v___x_627_ = lean_obj_once(&l_main___closed__40, &l_main___closed__40_once, _init_l_main___closed__40);
v___x_628_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_627_, v___x_626_);
return v___x_628_;
}
}
static lean_object* _init_l_main___closed__45(void){
_start:
{
lean_object* v___x_629_; lean_object* v___x_630_; lean_object* v___x_631_; lean_object* v___x_632_; 
v___x_629_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_630_ = lean_obj_once(&l_main___closed__44, &l_main___closed__44_once, _init_l_main___closed__44);
v___x_631_ = l_MachineRuntime_model;
v___x_632_ = l_FormalSpecAgent_TypedMachine_stepTimer(v___x_631_, v___x_630_, v___x_629_);
return v___x_632_;
}
}
static lean_object* _init_l_main___closed__46(void){
_start:
{
lean_object* v___x_633_; lean_object* v___x_634_; lean_object* v___x_635_; lean_object* v___x_636_; 
v___x_633_ = lean_obj_once(&l_main___closed__45, &l_main___closed__45_once, _init_l_main___closed__45);
v___x_634_ = lean_obj_once(&l_main___closed__44, &l_main___closed__44_once, _init_l_main___closed__44);
v___x_635_ = l_MachineRuntime_schema;
v___x_636_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_635_, v___x_634_, v___x_633_);
return v___x_636_;
}
}
static lean_object* _init_l_main___closed__47(void){
_start:
{
lean_object* v___x_637_; lean_object* v___x_638_; 
v___x_637_ = lean_obj_once(&l_main___closed__46, &l_main___closed__46_once, _init_l_main___closed__46);
v___x_638_ = l_outcomeText(v___x_637_);
return v___x_638_;
}
}
static lean_object* _init_l_main___closed__48(void){
_start:
{
lean_object* v___x_639_; lean_object* v___x_640_; lean_object* v___x_641_; 
v___x_639_ = lean_obj_once(&l_main___closed__45, &l_main___closed__45_once, _init_l_main___closed__45);
v___x_640_ = lean_obj_once(&l_main___closed__44, &l_main___closed__44_once, _init_l_main___closed__44);
v___x_641_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_640_, v___x_639_);
return v___x_641_;
}
}
static lean_object* _init_l_main___closed__49(void){
_start:
{
lean_object* v___x_642_; lean_object* v___x_643_; 
v___x_642_ = lean_unsigned_to_nat(7u);
v___x_643_ = lean_nat_to_int(v___x_642_);
return v___x_643_;
}
}
static lean_object* _init_l_main___closed__50(void){
_start:
{
lean_object* v___x_644_; lean_object* v___x_645_; lean_object* v___x_646_; lean_object* v___x_647_; 
v___x_644_ = lean_obj_once(&l_main___closed__49, &l_main___closed__49_once, _init_l_main___closed__49);
v___x_645_ = lean_obj_once(&l_main___closed__48, &l_main___closed__48_once, _init_l_main___closed__48);
v___x_646_ = l_MachineRuntime_model;
v___x_647_ = l_FormalSpecAgent_TypedMachine_stepTimer(v___x_646_, v___x_645_, v___x_644_);
return v___x_647_;
}
}
static lean_object* _init_l_main___closed__51(void){
_start:
{
lean_object* v___x_648_; lean_object* v___x_649_; lean_object* v___x_650_; lean_object* v___x_651_; 
v___x_648_ = lean_obj_once(&l_main___closed__50, &l_main___closed__50_once, _init_l_main___closed__50);
v___x_649_ = lean_obj_once(&l_main___closed__48, &l_main___closed__48_once, _init_l_main___closed__48);
v___x_650_ = l_MachineRuntime_schema;
v___x_651_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_650_, v___x_649_, v___x_648_);
return v___x_651_;
}
}
static lean_object* _init_l_main___closed__52(void){
_start:
{
lean_object* v___x_652_; lean_object* v___x_653_; 
v___x_652_ = lean_obj_once(&l_main___closed__51, &l_main___closed__51_once, _init_l_main___closed__51);
v___x_653_ = l_outcomeText(v___x_652_);
return v___x_653_;
}
}
static lean_object* _init_l_main___closed__53(void){
_start:
{
lean_object* v___x_654_; lean_object* v___x_655_; lean_object* v___x_656_; 
v___x_654_ = lean_obj_once(&l_main___closed__50, &l_main___closed__50_once, _init_l_main___closed__50);
v___x_655_ = lean_obj_once(&l_main___closed__48, &l_main___closed__48_once, _init_l_main___closed__48);
v___x_656_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_655_, v___x_654_);
return v___x_656_;
}
}
static lean_object* _init_l_main___closed__54(void){
_start:
{
lean_object* v___x_657_; lean_object* v___x_658_; lean_object* v___x_659_; lean_object* v___x_660_; 
v___x_657_ = lean_obj_once(&l_main___closed__49, &l_main___closed__49_once, _init_l_main___closed__49);
v___x_658_ = lean_obj_once(&l_main___closed__53, &l_main___closed__53_once, _init_l_main___closed__53);
v___x_659_ = l_MachineRuntime_model;
v___x_660_ = l_FormalSpecAgent_TypedMachine_stepTimer(v___x_659_, v___x_658_, v___x_657_);
return v___x_660_;
}
}
static lean_object* _init_l_main___closed__55(void){
_start:
{
lean_object* v___x_661_; lean_object* v___x_662_; lean_object* v___x_663_; lean_object* v___x_664_; 
v___x_661_ = lean_obj_once(&l_main___closed__54, &l_main___closed__54_once, _init_l_main___closed__54);
v___x_662_ = lean_obj_once(&l_main___closed__53, &l_main___closed__53_once, _init_l_main___closed__53);
v___x_663_ = l_MachineRuntime_schema;
v___x_664_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_663_, v___x_662_, v___x_661_);
return v___x_664_;
}
}
static lean_object* _init_l_main___closed__56(void){
_start:
{
lean_object* v___x_665_; lean_object* v___x_666_; 
v___x_665_ = lean_obj_once(&l_main___closed__55, &l_main___closed__55_once, _init_l_main___closed__55);
v___x_666_ = l_outcomeText(v___x_665_);
return v___x_666_;
}
}
static lean_object* _init_l_main___closed__58(void){
_start:
{
lean_object* v___x_673_; lean_object* v___x_674_; lean_object* v___x_675_; lean_object* v_s__0__0_676_; lean_object* v___x_677_; lean_object* v___x_678_; 
v___x_673_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_674_ = ((lean_object*)(l_main___closed__57));
v___x_675_ = lean_unsigned_to_nat(1u);
v_s__0__0_676_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_677_ = l_MachineRuntime_model;
v___x_678_ = l_FormalSpecAgent_TypedMachine_external(v___x_677_, v_s__0__0_676_, v___x_675_, v___x_674_, v___x_673_);
return v___x_678_;
}
}
static lean_object* _init_l_main___closed__59(void){
_start:
{
lean_object* v___x_679_; lean_object* v_s__0__0_680_; lean_object* v___x_681_; lean_object* v___x_682_; 
v___x_679_ = lean_obj_once(&l_main___closed__58, &l_main___closed__58_once, _init_l_main___closed__58);
v_s__0__0_680_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_681_ = l_MachineRuntime_schema;
v___x_682_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_681_, v_s__0__0_680_, v___x_679_);
return v___x_682_;
}
}
static lean_object* _init_l_main___closed__60(void){
_start:
{
lean_object* v___x_683_; lean_object* v___x_684_; 
v___x_683_ = lean_obj_once(&l_main___closed__59, &l_main___closed__59_once, _init_l_main___closed__59);
v___x_684_ = l_outcomeText(v___x_683_);
return v___x_684_;
}
}
static lean_object* _init_l_main___closed__61(void){
_start:
{
lean_object* v___x_685_; lean_object* v_s__0__0_686_; lean_object* v___x_687_; 
v___x_685_ = lean_obj_once(&l_main___closed__58, &l_main___closed__58_once, _init_l_main___closed__58);
v_s__0__0_686_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_687_ = l_FormalSpecAgent_TypedMachine_rollback(v_s__0__0_686_, v___x_685_);
return v___x_687_;
}
}
static lean_object* _init_l_main___closed__62(void){
_start:
{
lean_object* v___f_688_; lean_object* v___f_689_; lean_object* v___f_690_; lean_object* v___f_691_; lean_object* v___f_692_; lean_object* v___x_693_; 
v___f_688_ = ((lean_object*)(l_main___closed__11));
v___f_689_ = ((lean_object*)(l_main___closed__3));
v___f_690_ = ((lean_object*)(l_main___closed__6));
v___f_691_ = ((lean_object*)(l_main___closed__5));
v___f_692_ = lean_obj_once(&l_main___closed__35, &l_main___closed__35_once, _init_l_main___closed__35);
v___x_693_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_693_, 0, v___f_692_);
lean_ctor_set(v___x_693_, 1, v___f_691_);
lean_ctor_set(v___x_693_, 2, v___f_690_);
lean_ctor_set(v___x_693_, 3, v___f_689_);
lean_ctor_set(v___x_693_, 4, v___f_688_);
return v___x_693_;
}
}
static lean_object* _init_l_main___closed__63(void){
_start:
{
lean_object* v___x_694_; lean_object* v___x_695_; 
v___x_694_ = lean_unsigned_to_nat(3u);
v___x_695_ = lean_nat_to_int(v___x_694_);
return v___x_695_;
}
}
static lean_object* _init_l_main___closed__64(void){
_start:
{
lean_object* v___x_696_; lean_object* v___x_697_; lean_object* v___x_698_; lean_object* v___x_699_; lean_object* v___x_700_; lean_object* v___x_701_; 
v___x_696_ = lean_obj_once(&l_main___closed__63, &l_main___closed__63_once, _init_l_main___closed__63);
v___x_697_ = lean_obj_once(&l_main___closed__62, &l_main___closed__62_once, _init_l_main___closed__62);
v___x_698_ = lean_unsigned_to_nat(1u);
v___x_699_ = lean_obj_once(&l_main___closed__61, &l_main___closed__61_once, _init_l_main___closed__61);
v___x_700_ = l_MachineRuntime_model;
v___x_701_ = l_FormalSpecAgent_TypedMachine_external(v___x_700_, v___x_699_, v___x_698_, v___x_697_, v___x_696_);
return v___x_701_;
}
}
static lean_object* _init_l_main___closed__65(void){
_start:
{
lean_object* v___x_702_; lean_object* v___x_703_; lean_object* v___x_704_; lean_object* v___x_705_; 
v___x_702_ = lean_obj_once(&l_main___closed__64, &l_main___closed__64_once, _init_l_main___closed__64);
v___x_703_ = lean_obj_once(&l_main___closed__61, &l_main___closed__61_once, _init_l_main___closed__61);
v___x_704_ = l_MachineRuntime_schema;
v___x_705_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_704_, v___x_703_, v___x_702_);
return v___x_705_;
}
}
static lean_object* _init_l_main___closed__66(void){
_start:
{
lean_object* v___x_706_; lean_object* v___x_707_; 
v___x_706_ = lean_obj_once(&l_main___closed__65, &l_main___closed__65_once, _init_l_main___closed__65);
v___x_707_ = l_outcomeText(v___x_706_);
return v___x_707_;
}
}
static lean_object* _init_l_main___closed__67(void){
_start:
{
lean_object* v___x_708_; lean_object* v___x_709_; lean_object* v___x_710_; lean_object* v_s__0__0_711_; lean_object* v___x_712_; lean_object* v___x_713_; 
v___x_708_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_709_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_710_ = lean_unsigned_to_nat(2u);
v_s__0__0_711_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_712_ = l_MachineRuntime_model;
v___x_713_ = l_FormalSpecAgent_TypedMachine_external(v___x_712_, v_s__0__0_711_, v___x_710_, v___x_709_, v___x_708_);
return v___x_713_;
}
}
static lean_object* _init_l_main___closed__68(void){
_start:
{
lean_object* v___x_714_; lean_object* v_s__0__0_715_; lean_object* v___x_716_; lean_object* v___x_717_; 
v___x_714_ = lean_obj_once(&l_main___closed__67, &l_main___closed__67_once, _init_l_main___closed__67);
v_s__0__0_715_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_716_ = l_MachineRuntime_schema;
v___x_717_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_716_, v_s__0__0_715_, v___x_714_);
return v___x_717_;
}
}
static lean_object* _init_l_main___closed__69(void){
_start:
{
lean_object* v___x_718_; lean_object* v___x_719_; 
v___x_718_ = lean_obj_once(&l_main___closed__68, &l_main___closed__68_once, _init_l_main___closed__68);
v___x_719_ = l_outcomeText(v___x_718_);
return v___x_719_;
}
}
static lean_object* _init_l_main___closed__70(void){
_start:
{
lean_object* v___x_720_; lean_object* v___x_721_; lean_object* v___x_722_; lean_object* v_s__0__0_723_; lean_object* v___x_724_; lean_object* v___x_725_; 
v___x_720_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_721_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_722_ = lean_unsigned_to_nat(4u);
v_s__0__0_723_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_724_ = l_MachineRuntime_model;
v___x_725_ = l_FormalSpecAgent_TypedMachine_external(v___x_724_, v_s__0__0_723_, v___x_722_, v___x_721_, v___x_720_);
return v___x_725_;
}
}
static lean_object* _init_l_main___closed__71(void){
_start:
{
lean_object* v___x_726_; lean_object* v_s__0__0_727_; lean_object* v___x_728_; lean_object* v___x_729_; 
v___x_726_ = lean_obj_once(&l_main___closed__70, &l_main___closed__70_once, _init_l_main___closed__70);
v_s__0__0_727_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_728_ = l_MachineRuntime_schema;
v___x_729_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_728_, v_s__0__0_727_, v___x_726_);
return v___x_729_;
}
}
static lean_object* _init_l_main___closed__72(void){
_start:
{
lean_object* v___x_730_; lean_object* v___x_731_; 
v___x_730_ = lean_obj_once(&l_main___closed__71, &l_main___closed__71_once, _init_l_main___closed__71);
v___x_731_ = l_outcomeText(v___x_730_);
return v___x_731_;
}
}
static lean_object* _init_l_main___closed__73(void){
_start:
{
lean_object* v___x_732_; lean_object* v_s__0__0_733_; lean_object* v___x_734_; 
v___x_732_ = lean_obj_once(&l_main___closed__70, &l_main___closed__70_once, _init_l_main___closed__70);
v_s__0__0_733_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_734_ = l_FormalSpecAgent_TypedMachine_rollback(v_s__0__0_733_, v___x_732_);
return v___x_734_;
}
}
static lean_object* _init_l_main___closed__74(void){
_start:
{
lean_object* v___x_735_; lean_object* v___x_736_; lean_object* v___x_737_; lean_object* v___x_738_; lean_object* v___x_739_; lean_object* v___x_740_; 
v___x_735_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_736_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_737_ = lean_unsigned_to_nat(5u);
v___x_738_ = lean_obj_once(&l_main___closed__73, &l_main___closed__73_once, _init_l_main___closed__73);
v___x_739_ = l_MachineRuntime_model;
v___x_740_ = l_FormalSpecAgent_TypedMachine_external(v___x_739_, v___x_738_, v___x_737_, v___x_736_, v___x_735_);
return v___x_740_;
}
}
static lean_object* _init_l_main___closed__75(void){
_start:
{
lean_object* v___x_741_; lean_object* v___x_742_; lean_object* v___x_743_; lean_object* v___x_744_; 
v___x_741_ = lean_obj_once(&l_main___closed__74, &l_main___closed__74_once, _init_l_main___closed__74);
v___x_742_ = lean_obj_once(&l_main___closed__73, &l_main___closed__73_once, _init_l_main___closed__73);
v___x_743_ = l_MachineRuntime_schema;
v___x_744_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_743_, v___x_742_, v___x_741_);
return v___x_744_;
}
}
static lean_object* _init_l_main___closed__76(void){
_start:
{
lean_object* v___x_745_; lean_object* v___x_746_; 
v___x_745_ = lean_obj_once(&l_main___closed__75, &l_main___closed__75_once, _init_l_main___closed__75);
v___x_746_ = l_outcomeText(v___x_745_);
return v___x_746_;
}
}
static lean_object* _init_l_main___closed__77(void){
_start:
{
lean_object* v___x_747_; lean_object* v___x_748_; lean_object* v___x_749_; 
v___x_747_ = lean_obj_once(&l_main___closed__74, &l_main___closed__74_once, _init_l_main___closed__74);
v___x_748_ = lean_obj_once(&l_main___closed__73, &l_main___closed__73_once, _init_l_main___closed__73);
v___x_749_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_748_, v___x_747_);
return v___x_749_;
}
}
static lean_object* _init_l_main___closed__78(void){
_start:
{
lean_object* v___x_750_; lean_object* v___x_751_; lean_object* v___x_752_; lean_object* v___f_753_; 
v___x_750_ = lean_unsigned_to_nat(6u);
v___x_751_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_752_ = lean_unsigned_to_nat(0u);
v___f_753_ = lean_alloc_closure((void*)(l_main___lam__15___boxed), 4, 3);
lean_closure_set(v___f_753_, 0, v___x_752_);
lean_closure_set(v___f_753_, 1, v___x_751_);
lean_closure_set(v___f_753_, 2, v___x_750_);
return v___f_753_;
}
}
static lean_object* _init_l_main___closed__80(void){
_start:
{
lean_object* v___x_759_; lean_object* v___x_760_; lean_object* v___x_761_; lean_object* v___x_762_; lean_object* v___x_763_; lean_object* v___x_764_; 
v___x_759_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_760_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_761_ = lean_unsigned_to_nat(6u);
v___x_762_ = lean_obj_once(&l_main___closed__77, &l_main___closed__77_once, _init_l_main___closed__77);
v___x_763_ = l_MachineRuntime_model;
v___x_764_ = l_FormalSpecAgent_TypedMachine_external(v___x_763_, v___x_762_, v___x_761_, v___x_760_, v___x_759_);
return v___x_764_;
}
}
static lean_object* _init_l_main___closed__81(void){
_start:
{
lean_object* v___x_765_; lean_object* v___x_766_; lean_object* v___x_767_; lean_object* v___x_768_; 
v___x_765_ = lean_obj_once(&l_main___closed__80, &l_main___closed__80_once, _init_l_main___closed__80);
v___x_766_ = lean_obj_once(&l_main___closed__77, &l_main___closed__77_once, _init_l_main___closed__77);
v___x_767_ = l_MachineRuntime_schema;
v___x_768_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_767_, v___x_766_, v___x_765_);
return v___x_768_;
}
}
static lean_object* _init_l_main___closed__82(void){
_start:
{
lean_object* v___x_769_; lean_object* v___x_770_; 
v___x_769_ = lean_obj_once(&l_main___closed__81, &l_main___closed__81_once, _init_l_main___closed__81);
v___x_770_ = l_outcomeText(v___x_769_);
return v___x_770_;
}
}
static lean_object* _init_l_main___closed__83(void){
_start:
{
lean_object* v___f_771_; lean_object* v___f_772_; lean_object* v___f_773_; lean_object* v___f_774_; lean_object* v___f_775_; lean_object* v___x_776_; 
v___f_771_ = ((lean_object*)(l_main___closed__11));
v___f_772_ = ((lean_object*)(l_main___closed__19));
v___f_773_ = ((lean_object*)(l_main___closed__8));
v___f_774_ = ((lean_object*)(l_main___closed__7));
v___f_775_ = lean_obj_once(&l_main___closed__78, &l_main___closed__78_once, _init_l_main___closed__78);
v___x_776_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_776_, 0, v___f_775_);
lean_ctor_set(v___x_776_, 1, v___f_774_);
lean_ctor_set(v___x_776_, 2, v___f_773_);
lean_ctor_set(v___x_776_, 3, v___f_772_);
lean_ctor_set(v___x_776_, 4, v___f_771_);
return v___x_776_;
}
}
static lean_object* _init_l_main___closed__84(void){
_start:
{
lean_object* v___x_777_; lean_object* v___x_778_; lean_object* v___x_779_; lean_object* v___x_780_; lean_object* v___x_781_; 
v___x_777_ = lean_obj_once(&l_main___closed__38, &l_main___closed__38_once, _init_l_main___closed__38);
v___x_778_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_779_ = lean_unsigned_to_nat(1u);
v___x_780_ = lean_obj_once(&l_main___closed__83, &l_main___closed__83_once, _init_l_main___closed__83);
v___x_781_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_781_, 0, v___x_780_);
lean_ctor_set(v___x_781_, 1, v___x_779_);
lean_ctor_set(v___x_781_, 2, v___x_778_);
lean_ctor_set(v___x_781_, 3, v___x_777_);
return v___x_781_;
}
}
static lean_object* _init_l_main___closed__85(void){
_start:
{
lean_object* v___x_782_; lean_object* v___x_783_; 
v___x_782_ = lean_unsigned_to_nat(4u);
v___x_783_ = lean_nat_to_int(v___x_782_);
return v___x_783_;
}
}
static lean_object* _init_l_main___closed__86(void){
_start:
{
lean_object* v___x_784_; lean_object* v___x_785_; lean_object* v___x_786_; lean_object* v___x_787_; lean_object* v___x_788_; lean_object* v___x_789_; 
v___x_784_ = lean_obj_once(&l_main___closed__85, &l_main___closed__85_once, _init_l_main___closed__85);
v___x_785_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_786_ = lean_unsigned_to_nat(5u);
v___x_787_ = lean_obj_once(&l_main___closed__84, &l_main___closed__84_once, _init_l_main___closed__84);
v___x_788_ = l_MachineRuntime_model;
v___x_789_ = l_FormalSpecAgent_TypedMachine_external(v___x_788_, v___x_787_, v___x_786_, v___x_785_, v___x_784_);
return v___x_789_;
}
}
static lean_object* _init_l_main___closed__87(void){
_start:
{
lean_object* v___x_790_; lean_object* v___x_791_; lean_object* v___x_792_; lean_object* v___x_793_; 
v___x_790_ = lean_obj_once(&l_main___closed__86, &l_main___closed__86_once, _init_l_main___closed__86);
v___x_791_ = lean_obj_once(&l_main___closed__84, &l_main___closed__84_once, _init_l_main___closed__84);
v___x_792_ = l_MachineRuntime_schema;
v___x_793_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_792_, v___x_791_, v___x_790_);
return v___x_793_;
}
}
static lean_object* _init_l_main___closed__88(void){
_start:
{
lean_object* v___x_794_; lean_object* v___x_795_; 
v___x_794_ = lean_obj_once(&l_main___closed__87, &l_main___closed__87_once, _init_l_main___closed__87);
v___x_795_ = l_outcomeText(v___x_794_);
return v___x_795_;
}
}
static lean_object* _init_l_main___closed__89(void){
_start:
{
lean_object* v___x_796_; lean_object* v___x_797_; lean_object* v___x_798_; 
v___x_796_ = lean_obj_once(&l_main___closed__86, &l_main___closed__86_once, _init_l_main___closed__86);
v___x_797_ = lean_obj_once(&l_main___closed__84, &l_main___closed__84_once, _init_l_main___closed__84);
v___x_798_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_797_, v___x_796_);
return v___x_798_;
}
}
static lean_object* _init_l_main___closed__90(void){
_start:
{
lean_object* v___x_799_; lean_object* v___x_800_; lean_object* v___x_801_; lean_object* v___x_802_; 
v___x_799_ = lean_obj_once(&l_main___closed__85, &l_main___closed__85_once, _init_l_main___closed__85);
v___x_800_ = lean_obj_once(&l_main___closed__89, &l_main___closed__89_once, _init_l_main___closed__89);
v___x_801_ = l_MachineRuntime_model;
v___x_802_ = l_FormalSpecAgent_TypedMachine_stepTimer(v___x_801_, v___x_800_, v___x_799_);
return v___x_802_;
}
}
static lean_object* _init_l_main___closed__91(void){
_start:
{
lean_object* v___x_803_; lean_object* v___x_804_; lean_object* v___x_805_; lean_object* v___x_806_; 
v___x_803_ = lean_obj_once(&l_main___closed__90, &l_main___closed__90_once, _init_l_main___closed__90);
v___x_804_ = lean_obj_once(&l_main___closed__89, &l_main___closed__89_once, _init_l_main___closed__89);
v___x_805_ = l_MachineRuntime_schema;
v___x_806_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_805_, v___x_804_, v___x_803_);
return v___x_806_;
}
}
static lean_object* _init_l_main___closed__92(void){
_start:
{
lean_object* v___x_807_; lean_object* v___x_808_; 
v___x_807_ = lean_obj_once(&l_main___closed__91, &l_main___closed__91_once, _init_l_main___closed__91);
v___x_808_ = l_outcomeText(v___x_807_);
return v___x_808_;
}
}
static lean_object* _init_l_main___closed__93(void){
_start:
{
lean_object* v___x_809_; lean_object* v___x_810_; lean_object* v___x_811_; 
v___x_809_ = lean_obj_once(&l_main___closed__90, &l_main___closed__90_once, _init_l_main___closed__90);
v___x_810_ = lean_obj_once(&l_main___closed__89, &l_main___closed__89_once, _init_l_main___closed__89);
v___x_811_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_810_, v___x_809_);
return v___x_811_;
}
}
static lean_object* _init_l_main___closed__94(void){
_start:
{
lean_object* v___x_812_; lean_object* v___x_813_; 
v___x_812_ = lean_unsigned_to_nat(6u);
v___x_813_ = lean_nat_to_int(v___x_812_);
return v___x_813_;
}
}
static lean_object* _init_l_main___closed__95(void){
_start:
{
lean_object* v___x_814_; lean_object* v___x_815_; lean_object* v___x_816_; lean_object* v___x_817_; 
v___x_814_ = lean_obj_once(&l_main___closed__94, &l_main___closed__94_once, _init_l_main___closed__94);
v___x_815_ = lean_obj_once(&l_main___closed__93, &l_main___closed__93_once, _init_l_main___closed__93);
v___x_816_ = l_MachineRuntime_model;
v___x_817_ = l_FormalSpecAgent_TypedMachine_stepTimer(v___x_816_, v___x_815_, v___x_814_);
return v___x_817_;
}
}
static lean_object* _init_l_main___closed__96(void){
_start:
{
lean_object* v___x_818_; lean_object* v___x_819_; lean_object* v___x_820_; lean_object* v___x_821_; 
v___x_818_ = lean_obj_once(&l_main___closed__95, &l_main___closed__95_once, _init_l_main___closed__95);
v___x_819_ = lean_obj_once(&l_main___closed__93, &l_main___closed__93_once, _init_l_main___closed__93);
v___x_820_ = l_MachineRuntime_schema;
v___x_821_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_820_, v___x_819_, v___x_818_);
return v___x_821_;
}
}
static lean_object* _init_l_main___closed__97(void){
_start:
{
lean_object* v___x_822_; lean_object* v___x_823_; 
v___x_822_ = lean_obj_once(&l_main___closed__96, &l_main___closed__96_once, _init_l_main___closed__96);
v___x_823_ = l_outcomeText(v___x_822_);
return v___x_823_;
}
}
static lean_object* _init_l_main___closed__98(void){
_start:
{
lean_object* v___f_824_; lean_object* v___f_825_; lean_object* v___f_826_; lean_object* v___f_827_; lean_object* v___f_828_; lean_object* v___x_829_; 
v___f_824_ = ((lean_object*)(l_main___closed__11));
v___f_825_ = ((lean_object*)(l_main___closed__79));
v___f_826_ = ((lean_object*)(l_main___closed__6));
v___f_827_ = ((lean_object*)(l_main___closed__5));
v___f_828_ = lean_obj_once(&l_main___closed__12, &l_main___closed__12_once, _init_l_main___closed__12);
v___x_829_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_829_, 0, v___f_828_);
lean_ctor_set(v___x_829_, 1, v___f_827_);
lean_ctor_set(v___x_829_, 2, v___f_826_);
lean_ctor_set(v___x_829_, 3, v___f_825_);
lean_ctor_set(v___x_829_, 4, v___f_824_);
return v___x_829_;
}
}
static lean_object* _init_l_main___closed__99(void){
_start:
{
lean_object* v___x_830_; lean_object* v___x_831_; lean_object* v___x_832_; lean_object* v_s__0__0_833_; lean_object* v___x_834_; lean_object* v___x_835_; 
v___x_830_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_831_ = lean_obj_once(&l_main___closed__98, &l_main___closed__98_once, _init_l_main___closed__98);
v___x_832_ = lean_unsigned_to_nat(0u);
v_s__0__0_833_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_834_ = l_MachineRuntime_model;
v___x_835_ = l_FormalSpecAgent_TypedMachine_external(v___x_834_, v_s__0__0_833_, v___x_832_, v___x_831_, v___x_830_);
return v___x_835_;
}
}
static lean_object* _init_l_main___closed__100(void){
_start:
{
lean_object* v___x_836_; lean_object* v_s__0__0_837_; lean_object* v___x_838_; lean_object* v___x_839_; 
v___x_836_ = lean_obj_once(&l_main___closed__99, &l_main___closed__99_once, _init_l_main___closed__99);
v_s__0__0_837_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_838_ = l_MachineRuntime_schema;
v___x_839_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_838_, v_s__0__0_837_, v___x_836_);
return v___x_839_;
}
}
static lean_object* _init_l_main___closed__101(void){
_start:
{
lean_object* v___x_840_; lean_object* v___x_841_; 
v___x_840_ = lean_obj_once(&l_main___closed__100, &l_main___closed__100_once, _init_l_main___closed__100);
v___x_841_ = l_outcomeText(v___x_840_);
return v___x_841_;
}
}
LEAN_EXPORT lean_object* _lean_main(){
_start:
{
lean_object* v___x_843_; lean_object* v___x_844_; 
v___x_843_ = lean_obj_once(&l_main___closed__17, &l_main___closed__17_once, _init_l_main___closed__17);
v___x_844_ = l_IO_println___at___00main_spec__0(v___x_843_);
if (lean_obj_tag(v___x_844_) == 0)
{
lean_object* v___x_845_; lean_object* v___x_846_; 
lean_dec_ref_known(v___x_844_, 1);
v___x_845_ = lean_obj_once(&l_main___closed__25, &l_main___closed__25_once, _init_l_main___closed__25);
v___x_846_ = l_IO_println___at___00main_spec__0(v___x_845_);
if (lean_obj_tag(v___x_846_) == 0)
{
lean_object* v___x_847_; lean_object* v___x_848_; 
lean_dec_ref_known(v___x_846_, 1);
v___x_847_ = lean_obj_once(&l_main___closed__29, &l_main___closed__29_once, _init_l_main___closed__29);
v___x_848_ = l_IO_println___at___00main_spec__0(v___x_847_);
if (lean_obj_tag(v___x_848_) == 0)
{
lean_object* v___x_849_; lean_object* v___x_850_; 
lean_dec_ref_known(v___x_848_, 1);
v___x_849_ = lean_obj_once(&l_main___closed__33, &l_main___closed__33_once, _init_l_main___closed__33);
v___x_850_ = l_IO_println___at___00main_spec__0(v___x_849_);
if (lean_obj_tag(v___x_850_) == 0)
{
lean_object* v___x_851_; lean_object* v___x_852_; 
lean_dec_ref_known(v___x_850_, 1);
v___x_851_ = lean_obj_once(&l_main___closed__43, &l_main___closed__43_once, _init_l_main___closed__43);
v___x_852_ = l_IO_println___at___00main_spec__0(v___x_851_);
if (lean_obj_tag(v___x_852_) == 0)
{
lean_object* v___x_853_; lean_object* v___x_854_; 
lean_dec_ref_known(v___x_852_, 1);
v___x_853_ = lean_obj_once(&l_main___closed__47, &l_main___closed__47_once, _init_l_main___closed__47);
v___x_854_ = l_IO_println___at___00main_spec__0(v___x_853_);
if (lean_obj_tag(v___x_854_) == 0)
{
lean_object* v___x_855_; lean_object* v___x_856_; 
lean_dec_ref_known(v___x_854_, 1);
v___x_855_ = lean_obj_once(&l_main___closed__52, &l_main___closed__52_once, _init_l_main___closed__52);
v___x_856_ = l_IO_println___at___00main_spec__0(v___x_855_);
if (lean_obj_tag(v___x_856_) == 0)
{
lean_object* v___x_857_; lean_object* v___x_858_; 
lean_dec_ref_known(v___x_856_, 1);
v___x_857_ = lean_obj_once(&l_main___closed__56, &l_main___closed__56_once, _init_l_main___closed__56);
v___x_858_ = l_IO_println___at___00main_spec__0(v___x_857_);
if (lean_obj_tag(v___x_858_) == 0)
{
lean_object* v___x_859_; lean_object* v___x_860_; 
lean_dec_ref_known(v___x_858_, 1);
v___x_859_ = lean_obj_once(&l_main___closed__60, &l_main___closed__60_once, _init_l_main___closed__60);
v___x_860_ = l_IO_println___at___00main_spec__0(v___x_859_);
if (lean_obj_tag(v___x_860_) == 0)
{
lean_object* v___x_861_; lean_object* v___x_862_; 
lean_dec_ref_known(v___x_860_, 1);
v___x_861_ = lean_obj_once(&l_main___closed__66, &l_main___closed__66_once, _init_l_main___closed__66);
v___x_862_ = l_IO_println___at___00main_spec__0(v___x_861_);
if (lean_obj_tag(v___x_862_) == 0)
{
lean_object* v___x_863_; lean_object* v___x_864_; 
lean_dec_ref_known(v___x_862_, 1);
v___x_863_ = lean_obj_once(&l_main___closed__69, &l_main___closed__69_once, _init_l_main___closed__69);
v___x_864_ = l_IO_println___at___00main_spec__0(v___x_863_);
if (lean_obj_tag(v___x_864_) == 0)
{
lean_object* v___x_865_; lean_object* v___x_866_; 
lean_dec_ref_known(v___x_864_, 1);
v___x_865_ = lean_obj_once(&l_main___closed__72, &l_main___closed__72_once, _init_l_main___closed__72);
v___x_866_ = l_IO_println___at___00main_spec__0(v___x_865_);
if (lean_obj_tag(v___x_866_) == 0)
{
lean_object* v___x_867_; lean_object* v___x_868_; 
lean_dec_ref_known(v___x_866_, 1);
v___x_867_ = lean_obj_once(&l_main___closed__76, &l_main___closed__76_once, _init_l_main___closed__76);
v___x_868_ = l_IO_println___at___00main_spec__0(v___x_867_);
if (lean_obj_tag(v___x_868_) == 0)
{
lean_object* v___x_869_; lean_object* v___x_870_; 
lean_dec_ref_known(v___x_868_, 1);
v___x_869_ = lean_obj_once(&l_main___closed__82, &l_main___closed__82_once, _init_l_main___closed__82);
v___x_870_ = l_IO_println___at___00main_spec__0(v___x_869_);
if (lean_obj_tag(v___x_870_) == 0)
{
lean_object* v___x_871_; lean_object* v___x_872_; 
lean_dec_ref_known(v___x_870_, 1);
v___x_871_ = lean_obj_once(&l_main___closed__88, &l_main___closed__88_once, _init_l_main___closed__88);
v___x_872_ = l_IO_println___at___00main_spec__0(v___x_871_);
if (lean_obj_tag(v___x_872_) == 0)
{
lean_object* v___x_873_; lean_object* v___x_874_; 
lean_dec_ref_known(v___x_872_, 1);
v___x_873_ = lean_obj_once(&l_main___closed__92, &l_main___closed__92_once, _init_l_main___closed__92);
v___x_874_ = l_IO_println___at___00main_spec__0(v___x_873_);
if (lean_obj_tag(v___x_874_) == 0)
{
lean_object* v___x_875_; lean_object* v___x_876_; 
lean_dec_ref_known(v___x_874_, 1);
v___x_875_ = lean_obj_once(&l_main___closed__97, &l_main___closed__97_once, _init_l_main___closed__97);
v___x_876_ = l_IO_println___at___00main_spec__0(v___x_875_);
if (lean_obj_tag(v___x_876_) == 0)
{
lean_object* v___x_877_; lean_object* v___x_878_; 
lean_dec_ref_known(v___x_876_, 1);
v___x_877_ = lean_obj_once(&l_main___closed__101, &l_main___closed__101_once, _init_l_main___closed__101);
v___x_878_ = l_IO_println___at___00main_spec__0(v___x_877_);
if (lean_obj_tag(v___x_878_) == 0)
{
lean_object* v___x_880_; uint8_t v_isShared_881_; uint8_t v_isSharedCheck_886_; 
v_isSharedCheck_886_ = !lean_is_exclusive(v___x_878_);
if (v_isSharedCheck_886_ == 0)
{
lean_object* v_unused_887_; 
v_unused_887_ = lean_ctor_get(v___x_878_, 0);
lean_dec(v_unused_887_);
v___x_880_ = v___x_878_;
v_isShared_881_ = v_isSharedCheck_886_;
goto v_resetjp_879_;
}
else
{
lean_dec(v___x_878_);
v___x_880_ = lean_box(0);
v_isShared_881_ = v_isSharedCheck_886_;
goto v_resetjp_879_;
}
v_resetjp_879_:
{
lean_object* v___x_882_; lean_object* v___x_884_; 
v___x_882_ = lean_box(0);
if (v_isShared_881_ == 0)
{
lean_ctor_set(v___x_880_, 0, v___x_882_);
v___x_884_ = v___x_880_;
goto v_reusejp_883_;
}
else
{
lean_object* v_reuseFailAlloc_885_; 
v_reuseFailAlloc_885_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_885_, 0, v___x_882_);
v___x_884_ = v_reuseFailAlloc_885_;
goto v_reusejp_883_;
}
v_reusejp_883_:
{
return v___x_884_;
}
}
}
else
{
return v___x_878_;
}
}
else
{
return v___x_876_;
}
}
else
{
return v___x_874_;
}
}
else
{
return v___x_872_;
}
}
else
{
return v___x_870_;
}
}
else
{
return v___x_868_;
}
}
else
{
return v___x_866_;
}
}
else
{
return v___x_864_;
}
}
else
{
return v___x_862_;
}
}
else
{
return v___x_860_;
}
}
else
{
return v___x_858_;
}
}
else
{
return v___x_856_;
}
}
else
{
return v___x_854_;
}
}
else
{
return v___x_852_;
}
}
else
{
return v___x_850_;
}
}
else
{
return v___x_848_;
}
}
else
{
return v___x_846_;
}
}
else
{
return v___x_844_;
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_a_888_){
_start:
{
lean_object* v_res_889_; 
v_res_889_ = _lean_main();
return v_res_889_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ModelMachine(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Runner(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ModelMachine(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_main___lam__2___closed__1___boxed__const__1 = _init_l_main___lam__2___closed__1___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__1___boxed__const__1);
l_main___lam__2___closed__2___boxed__const__1 = _init_l_main___lam__2___closed__2___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__2___boxed__const__1);
l_main___lam__2___closed__3___boxed__const__1 = _init_l_main___lam__2___closed__3___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__3___boxed__const__1);
l_main___lam__2___closed__5___boxed__const__1 = _init_l_main___lam__2___closed__5___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__5___boxed__const__1);
l_main___lam__7___closed__0___boxed__const__1 = _init_l_main___lam__7___closed__0___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__0___boxed__const__1);
l_main___lam__7___closed__1___boxed__const__1 = _init_l_main___lam__7___closed__1___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__1___boxed__const__1);
l_main___lam__7___closed__2___boxed__const__1 = _init_l_main___lam__7___closed__2___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__2___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    return _lean_main();
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_Runner(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
