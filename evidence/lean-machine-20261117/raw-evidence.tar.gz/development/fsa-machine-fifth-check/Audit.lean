import Proofs

example : Approved.get_set_same := Proofs.get_set_same
#print axioms Proofs.get_set_same
example : Approved.rollback_error := Proofs.rollback_error
#print axioms Proofs.rollback_error
example : Approved.cancel_membership := Proofs.cancel_membership
#print axioms Proofs.cancel_membership
example : Approved.fire_invariant := Proofs.fire_invariant
#print axioms Proofs.fire_invariant
example : Approved.initial_valid_0 := Proofs.initial_valid_0
#print axioms Proofs.initial_valid_0
example : Approved.witness_0_0 := Proofs.witness_0_0
#print axioms Proofs.witness_0_0
example : Approved.witness_0_1 := Proofs.witness_0_1
#print axioms Proofs.witness_0_1
example : Approved.witness_0_2 := Proofs.witness_0_2
#print axioms Proofs.witness_0_2
example : Approved.witness_0_3 := Proofs.witness_0_3
#print axioms Proofs.witness_0_3
example : Approved.initial_valid_1 := Proofs.initial_valid_1
#print axioms Proofs.initial_valid_1
example : Approved.witness_1_0 := Proofs.witness_1_0
#print axioms Proofs.witness_1_0
example : Approved.witness_1_1 := Proofs.witness_1_1
#print axioms Proofs.witness_1_1
example : Approved.witness_1_2 := Proofs.witness_1_2
#print axioms Proofs.witness_1_2
example : Approved.witness_1_3 := Proofs.witness_1_3
#print axioms Proofs.witness_1_3
example : Approved.initial_valid_2 := Proofs.initial_valid_2
#print axioms Proofs.initial_valid_2
example : Approved.witness_2_0 := Proofs.witness_2_0
#print axioms Proofs.witness_2_0
example : Approved.witness_2_1 := Proofs.witness_2_1
#print axioms Proofs.witness_2_1
example : Approved.initial_valid_3 := Proofs.initial_valid_3
#print axioms Proofs.initial_valid_3
example : Approved.witness_3_0 := Proofs.witness_3_0
#print axioms Proofs.witness_3_0
example : Approved.initial_valid_4 := Proofs.initial_valid_4
#print axioms Proofs.initial_valid_4
example : Approved.witness_4_0 := Proofs.witness_4_0
#print axioms Proofs.witness_4_0
example : Approved.witness_4_1 := Proofs.witness_4_1
#print axioms Proofs.witness_4_1
example : Approved.witness_4_2 := Proofs.witness_4_2
#print axioms Proofs.witness_4_2
example : Approved.initial_valid_5 := Proofs.initial_valid_5
#print axioms Proofs.initial_valid_5
example : Approved.witness_5_0 := Proofs.witness_5_0
#print axioms Proofs.witness_5_0
example : Approved.witness_5_1 := Proofs.witness_5_1
#print axioms Proofs.witness_5_1
example : Approved.witness_5_2 := Proofs.witness_5_2
#print axioms Proofs.witness_5_2
example : Approved.initial_valid_6 := Proofs.initial_valid_6
#print axioms Proofs.initial_valid_6
example : Approved.witness_6_0 := Proofs.witness_6_0
#print axioms Proofs.witness_6_0
