import MachineObserve

set_option maxRecDepth 16384

namespace Approved

def e0 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (0)

def e1 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean false

def e2 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e3 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([] : FormalSpecAgent.Bytes)

def e4 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116])

def e5 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean true

def e6 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.field .octets 0

def e7 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (4)

def e8 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 0

def e9 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (1)

def e10 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.add e8 e9

def e11 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.variable .sequence 2

def e12 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.seqAdd e11 e9

def e13 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])

def e14 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 1

def e15 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 3

def e16 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.variable .text 4

def e17 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.stateIs 0

def e18 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.timerActive 0

def e19 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.timerActive 1

def e20 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (5)

def e21 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (10)

def e22 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 0

def e23 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (-1)

def e24 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (3)

def e25 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (7)

def e26 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e8 e0

def e27 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e15

def e28 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (4096)

def e29 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e27 e28

def rule_0 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 0, source := 0, target := 1, event := 0, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .octets 3 e6, FormalSpecAgent.TypedMachine.Action.assign .integer 0 e7, FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.assign .boolean 1 e5, FormalSpecAgent.TypedMachine.Action.assign .sequence 2 e12, FormalSpecAgent.TypedMachine.Action.assign .text 4 e13, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 1 e20, FormalSpecAgent.TypedMachine.Action.arm 0 e20] }

def rule_1 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 1, source := 0, target := 1, event := 1, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e21, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 0 e22] }

def rule_2 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 2, source := 0, target := 2, event := 2, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e23, FormalSpecAgent.TypedMachine.Action.arm 0 e20, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_3 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 3, source := 1, target := 1, event := 6, guard := e18, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_4 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 4, source := 1, target := 2, event := 7, guard := e19, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.cancel 0] }

def rule_5 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 5, source := 1, target := 1, event := 3, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.arm 0 e24, FormalSpecAgent.TypedMachine.Action.arm 0 e25, FormalSpecAgent.TypedMachine.Action.cancel 1, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_6 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 6, source := 0, target := 0, event := 4, guard := e5, actions := [] }

def rule_7 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 7, source := 0, target := 1, event := 4, guard := e5, actions := [] }

def schema : List (FormalSpecAgent.TypedIR.Kind × Nat) := [(.integer, 0), (.boolean, 1), (.sequence, 2), (.octets, 3), (.text, 4)]

def model : FormalSpecAgent.TypedMachine.Model :=
  { rules := [rule_0, rule_1, rule_2, rule_3, rule_4, rule_5, rule_6, rule_7], invariants := [e26, e29], timerEvents := fun n => if n = 0 then 6 else if n = 1 then 7 else 0, externalEvents := [0, 1, 2, 3, 4, 5] }

def initial_0 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_0_0 := FormalSpecAgent.TypedMachine.external model initial_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_0_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_0 result_0_0

def result_0_1 := FormalSpecAgent.TypedMachine.external model after_0_0 3 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)

def after_0_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_0 result_0_1

def result_0_2 := FormalSpecAgent.TypedMachine.stepTimer model after_0_1 (5)

def after_0_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_1 result_0_2

def result_0_3 := FormalSpecAgent.TypedMachine.stepTimer model after_0_2 (5)

def after_0_3 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_2 result_0_3

def initial_1 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨1, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_1_0 := FormalSpecAgent.TypedMachine.external model initial_1 3 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_1_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_1 result_1_0

def result_1_1 := FormalSpecAgent.TypedMachine.stepTimer model after_1_0 (5)

def after_1_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_1_0 result_1_1

def result_1_2 := FormalSpecAgent.TypedMachine.stepTimer model after_1_1 (7)

def after_1_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_1_1 result_1_2

def result_1_3 := FormalSpecAgent.TypedMachine.stepTimer model after_1_2 (7)

def after_1_3 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_1_2 result_1_3

def initial_2 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_2_0 := FormalSpecAgent.TypedMachine.external model initial_2 1 ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_2_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_2 result_2_0

def result_2_1 := FormalSpecAgent.TypedMachine.external model after_2_0 1 ({ integers := fun n => if n = 0 then (-1) else (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (3)

def after_2_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_2_0 result_2_1

def initial_3 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_3_0 := FormalSpecAgent.TypedMachine.external model initial_3 2 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_3_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_3 result_3_0

def initial_4 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_4_0 := FormalSpecAgent.TypedMachine.external model initial_4 4 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_4_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_4 result_4_0

def result_4_1 := FormalSpecAgent.TypedMachine.external model after_4_0 5 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_4_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_4_0 result_4_1

def result_4_2 := FormalSpecAgent.TypedMachine.external model after_4_1 6 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_4_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_4_1 result_4_2

def initial_5 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨1, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_5_0 := FormalSpecAgent.TypedMachine.external model initial_5 5 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (4)

def after_5_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_5 result_5_0

def result_5_1 := FormalSpecAgent.TypedMachine.stepTimer model after_5_0 (4)

def after_5_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_5_0 result_5_1

def result_5_2 := FormalSpecAgent.TypedMachine.stepTimer model after_5_1 (6)

def after_5_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_5_1 result_5_2

def initial_6 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_6_0 := FormalSpecAgent.TypedMachine.external model initial_6 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_6_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_6 result_6_0
def get_set_same : Prop :=
  ∀ (k : FormalSpecAgent.TypedIR.Kind) (n : Nat) (v : FormalSpecAgent.TypedIR.Value k) (s : FormalSpecAgent.TypedIR.Values), FormalSpecAgent.TypedIR.getValue k (FormalSpecAgent.TypedMachine.setValue k n v s) n = v

def rollback_error : Prop :=
  ∀ (s : FormalSpecAgent.TypedMachine.Snapshot) (f : FormalSpecAgent.TypedMachine.Fault), FormalSpecAgent.TypedMachine.rollback s (.error f) = s

def cancel_membership : Prop :=
  ∀ (s : FormalSpecAgent.TypedMachine.Snapshot) (n : Nat), ∀ e ∈ (FormalSpecAgent.TypedMachine.cancelTimer s n).timers, e.timer ≠ n

def fire_invariant : Prop :=
  ∀ (m : FormalSpecAgent.TypedMachine.Model) (s : FormalSpecAgent.TypedMachine.Snapshot) (e : Nat) (f : FormalSpecAgent.TypedIR.Values) (timer : Option Nat) (t : FormalSpecAgent.TypedMachine.Transition), FormalSpecAgent.TypedMachine.fire m s e f timer = .ok t → FormalSpecAgent.TypedMachine.invariantsHold m t.after = true

def initial_valid_0 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_0 = true

def witness_0_0 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema initial_0 result_0_0 = FormalSpecAgent.MachineObserve.Outcome.success 0 0 (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨1, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (5))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])]

def witness_0_1 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_0_0 result_0_1 = FormalSpecAgent.MachineObserve.Outcome.error .pendingTimer (FormalSpecAgent.MachineObserve.snapshot schema after_0_0)

def witness_0_2 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_0_1 result_0_2 = FormalSpecAgent.MachineObserve.Outcome.success 3 6 (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨1, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (6))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean true))])]

def witness_0_3 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_0_2 result_0_3 = FormalSpecAgent.MachineObserve.Outcome.success 4 7 (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (7))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])]

def initial_valid_1 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_1 = true

def witness_1_0 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema initial_1 result_1_0 = FormalSpecAgent.MachineObserve.Outcome.success 5 3 (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (7)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (5))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])]

def witness_1_1 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_1_0 result_1_1 = FormalSpecAgent.MachineObserve.Outcome.error .time (FormalSpecAgent.MachineObserve.snapshot schema after_1_0)

def witness_1_2 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_1_1 result_1_2 = FormalSpecAgent.MachineObserve.Outcome.success 3 6 (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (7), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (6))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])]

def witness_1_3 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_1_2 result_1_3 = FormalSpecAgent.MachineObserve.Outcome.error .noTimer (FormalSpecAgent.MachineObserve.snapshot schema after_1_2)

def initial_valid_2 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_2 = true

def witness_2_0 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema initial_2 result_2_0 = FormalSpecAgent.MachineObserve.Outcome.error .badDelay (FormalSpecAgent.MachineObserve.snapshot schema initial_2)

def witness_2_1 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_2_0 result_2_1 = FormalSpecAgent.MachineObserve.Outcome.error .badDelay (FormalSpecAgent.MachineObserve.snapshot schema after_2_0)

def initial_valid_3 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_3 = true

def witness_3_0 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema initial_3 result_3_0 = FormalSpecAgent.MachineObserve.Outcome.error .invariant (FormalSpecAgent.MachineObserve.snapshot schema initial_3)

def initial_valid_4 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_4 = true

def witness_4_0 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema initial_4 result_4_0 = FormalSpecAgent.MachineObserve.Outcome.error .conflict (FormalSpecAgent.MachineObserve.snapshot schema initial_4)

def witness_4_1 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_4_0 result_4_1 = FormalSpecAgent.MachineObserve.Outcome.error .uncovered (FormalSpecAgent.MachineObserve.snapshot schema after_4_0)

def witness_4_2 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_4_1 result_4_2 = FormalSpecAgent.MachineObserve.Outcome.error .timerInjection (FormalSpecAgent.MachineObserve.snapshot schema after_4_1)

def initial_valid_5 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_5 = true

def witness_5_0 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema initial_5 result_5_0 = FormalSpecAgent.MachineObserve.Outcome.error .time (FormalSpecAgent.MachineObserve.snapshot schema initial_5)

def witness_5_1 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_5_0 result_5_1 = FormalSpecAgent.MachineObserve.Outcome.error .time (FormalSpecAgent.MachineObserve.snapshot schema after_5_0)

def witness_5_2 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema after_5_1 result_5_2 = FormalSpecAgent.MachineObserve.Outcome.error .time (FormalSpecAgent.MachineObserve.snapshot schema after_5_1)

def initial_valid_6 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_6 = true

def witness_6_0 : Prop :=
  FormalSpecAgent.MachineObserve.outcome schema initial_6 result_6_0 = FormalSpecAgent.MachineObserve.Outcome.success 0 0 (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨1, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (5))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])]

end Approved
