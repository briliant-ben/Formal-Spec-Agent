// Lean compiler output
// Module: Runner
// Imports: public import Init public meta import Init public import ModelMachine
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_string_mk(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_replicateTR___redArg(lean_object*, lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
extern lean_object* l_MachineRuntime_model;
lean_object* l_FormalSpecAgent_TypedMachine_external(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_rollback(lean_object*, lean_object*);
extern lean_object* l_MachineRuntime_schema;
lean_object* l_FormalSpecAgent_MachineObserve_outcome(lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Int_repr(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_string_data(lean_object*);
lean_object* lean_uint32_to_nat(uint32_t);
lean_object* l_String_intercalate(lean_object*, lean_object*);
lean_object* lean_string_push(lean_object*, uint32_t);
lean_object* lean_get_stdout();
static const lean_string_object l_array___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "["};
static const lean_object* l_array___closed__0 = (const lean_object*)&l_array___closed__0_value;
static const lean_string_object l_array___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* l_array___closed__1 = (const lean_object*)&l_array___closed__1_value;
static const lean_string_object l_array___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "]"};
static const lean_object* l_array___closed__2 = (const lean_object*)&l_array___closed__2_value;
LEAN_EXPORT lean_object* l_array(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__1(lean_object*, lean_object*);
static const lean_string_object l_pvalue___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "{\"kind\":\"int\",\"value\":"};
static const lean_object* l_pvalue___closed__0 = (const lean_object*)&l_pvalue___closed__0_value;
static const lean_string_object l_pvalue___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "}"};
static const lean_object* l_pvalue___closed__1 = (const lean_object*)&l_pvalue___closed__1_value;
static const lean_string_object l_pvalue___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "{\"kind\":\"bool\",\"value\":"};
static const lean_object* l_pvalue___closed__2 = (const lean_object*)&l_pvalue___closed__2_value;
static const lean_string_object l_pvalue___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "false"};
static const lean_object* l_pvalue___closed__3 = (const lean_object*)&l_pvalue___closed__3_value;
static const lean_string_object l_pvalue___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "true"};
static const lean_object* l_pvalue___closed__4 = (const lean_object*)&l_pvalue___closed__4_value;
static const lean_string_object l_pvalue___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "{\"kind\":\"string\",\"value\":"};
static const lean_object* l_pvalue___closed__5 = (const lean_object*)&l_pvalue___closed__5_value;
static const lean_string_object l_pvalue___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "{\"kind\":\"bytes\",\"value\":"};
static const lean_object* l_pvalue___closed__6 = (const lean_object*)&l_pvalue___closed__6_value;
static const lean_string_object l_pvalue___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "{\"kind\":\"seq32\",\"value\":"};
static const lean_object* l_pvalue___closed__7 = (const lean_object*)&l_pvalue___closed__7_value;
LEAN_EXPORT lean_object* l_pvalue(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__0(lean_object*, lean_object*);
static const lean_string_object l_ss___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "{\"state\":"};
static const lean_object* l_ss___closed__0 = (const lean_object*)&l_ss___closed__0_value;
static const lean_string_object l_ss___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"now_ms\":"};
static const lean_object* l_ss___closed__1 = (const lean_object*)&l_ss___closed__1_value;
static const lean_string_object l_ss___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = ",\"variables\":"};
static const lean_object* l_ss___closed__2 = (const lean_object*)&l_ss___closed__2_value;
static const lean_string_object l_ss___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"timers\":"};
static const lean_object* l_ss___closed__3 = (const lean_object*)&l_ss___closed__3_value;
LEAN_EXPORT lean_object* l_ss(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00msg_spec__0(lean_object*, lean_object*);
static const lean_string_object l_msg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "{\"message\":"};
static const lean_object* l_msg___closed__0 = (const lean_object*)&l_msg___closed__0_value;
static const lean_string_object l_msg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"fields\":"};
static const lean_object* l_msg___closed__1 = (const lean_object*)&l_msg___closed__1_value;
LEAN_EXPORT lean_object* l_msg(lean_object*);
static const lean_string_object l_faultName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "uncovered"};
static const lean_object* l_faultName___closed__0 = (const lean_object*)&l_faultName___closed__0_value;
static const lean_string_object l_faultName___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "conflict"};
static const lean_object* l_faultName___closed__1 = (const lean_object*)&l_faultName___closed__1_value;
static const lean_string_object l_faultName___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "badDelay"};
static const lean_object* l_faultName___closed__2 = (const lean_object*)&l_faultName___closed__2_value;
static const lean_string_object l_faultName___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "invariant"};
static const lean_object* l_faultName___closed__3 = (const lean_object*)&l_faultName___closed__3_value;
static const lean_string_object l_faultName___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "time"};
static const lean_object* l_faultName___closed__4 = (const lean_object*)&l_faultName___closed__4_value;
static const lean_string_object l_faultName___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "timerInjection"};
static const lean_object* l_faultName___closed__5 = (const lean_object*)&l_faultName___closed__5_value;
static const lean_string_object l_faultName___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "pendingTimer"};
static const lean_object* l_faultName___closed__6 = (const lean_object*)&l_faultName___closed__6_value;
static const lean_string_object l_faultName___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "noTimer"};
static const lean_object* l_faultName___closed__7 = (const lean_object*)&l_faultName___closed__7_value;
LEAN_EXPORT lean_object* l_faultName(uint8_t);
LEAN_EXPORT lean_object* l_faultName___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00outcomeText_spec__0(lean_object*, lean_object*);
static const lean_string_object l_outcomeText___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "{\"status\":\"ok\",\"rule\":"};
static const lean_object* l_outcomeText___closed__0 = (const lean_object*)&l_outcomeText___closed__0_value;
static const lean_string_object l_outcomeText___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = ",\"event\":"};
static const lean_object* l_outcomeText___closed__1 = (const lean_object*)&l_outcomeText___closed__1_value;
static const lean_string_object l_outcomeText___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = ",\"after\":"};
static const lean_object* l_outcomeText___closed__2 = (const lean_object*)&l_outcomeText___closed__2_value;
static const lean_string_object l_outcomeText___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = ",\"emitted\":"};
static const lean_object* l_outcomeText___closed__3 = (const lean_object*)&l_outcomeText___closed__3_value;
static const lean_string_object l_outcomeText___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "{\"status\":\"error\",\"fault\":\""};
static const lean_object* l_outcomeText___closed__4 = (const lean_object*)&l_outcomeText___closed__4_value;
static const lean_string_object l_outcomeText___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "\",\"after\":"};
static const lean_object* l_outcomeText___closed__5 = (const lean_object*)&l_outcomeText___closed__5_value;
static const lean_string_object l_outcomeText___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = ",\"emitted\":[]}"};
static const lean_object* l_outcomeText___closed__6 = (const lean_object*)&l_outcomeText___closed__6_value;
LEAN_EXPORT lean_object* l_outcomeText(lean_object*);
static lean_once_cell_t l_main___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__0;
static lean_once_cell_t l_main___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__1;
static lean_once_cell_t l_main___lam__0___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__2;
static lean_once_cell_t l_main___lam__0___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__3;
static lean_once_cell_t l_main___lam__0___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__4;
static lean_once_cell_t l_main___lam__0___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__5;
LEAN_EXPORT lean_object* l_main___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__0___boxed(lean_object*);
LEAN_EXPORT uint8_t l_main___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__1___boxed(lean_object*);
static lean_once_cell_t l_main___lam__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__0;
LEAN_EXPORT lean_object* l_main___lam__2___closed__1___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__1;
LEAN_EXPORT lean_object* l_main___lam__2___closed__2___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__2;
LEAN_EXPORT lean_object* l_main___lam__2___closed__3___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__3;
static lean_once_cell_t l_main___lam__2___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__4;
static lean_once_cell_t l_main___lam__2___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__5;
LEAN_EXPORT lean_object* l_main___lam__2___closed__6___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__6;
LEAN_EXPORT lean_object* l_main___lam__2___closed__7___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__7;
LEAN_EXPORT lean_object* l_main___lam__2___closed__8___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__8;
LEAN_EXPORT lean_object* l_main___lam__2___closed__9___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__9;
LEAN_EXPORT lean_object* l_main___lam__2___closed__10___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__10;
LEAN_EXPORT lean_object* l_main___lam__2___closed__11___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__11;
static lean_once_cell_t l_main___lam__2___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__12;
static lean_once_cell_t l_main___lam__2___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__13;
static lean_once_cell_t l_main___lam__2___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__14;
LEAN_EXPORT lean_object* l_main___lam__2___closed__15___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__15;
LEAN_EXPORT lean_object* l_main___lam__2___closed__16___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__16;
LEAN_EXPORT lean_object* l_main___lam__2___closed__17___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__17;
LEAN_EXPORT lean_object* l_main___lam__2___closed__18___boxed__const__1;
static lean_once_cell_t l_main___lam__2___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__18;
static lean_once_cell_t l_main___lam__2___closed__19_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__19;
static lean_once_cell_t l_main___lam__2___closed__20_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__20;
LEAN_EXPORT lean_object* l_main___lam__2(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__2___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__3(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__3___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__4(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__4___boxed(lean_object*);
LEAN_EXPORT uint8_t l_main___lam__5(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__5___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__6(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__6___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__8(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__8___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__7(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__7___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__9(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__9___boxed(lean_object*, lean_object*);
static lean_once_cell_t l_main___lam__10___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__10___closed__0;
LEAN_EXPORT lean_object* l_main___lam__10(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__10___boxed(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_main___lam__11___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(221) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___lam__11___closed__0 = (const lean_object*)&l_main___lam__11___closed__0_value;
static const lean_ctor_object l_main___lam__11___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(72) << 1) | 1)),((lean_object*)&l_main___lam__11___closed__0_value)}};
static const lean_object* l_main___lam__11___closed__1 = (const lean_object*)&l_main___lam__11___closed__1_value;
static const lean_ctor_object l_main___lam__11___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(16) << 1) | 1)),((lean_object*)&l_main___lam__11___closed__1_value)}};
static const lean_object* l_main___lam__11___closed__2 = (const lean_object*)&l_main___lam__11___closed__2_value;
LEAN_EXPORT lean_object* l_main___lam__11(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_main___lam__12___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(217) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___lam__12___closed__0 = (const lean_object*)&l_main___lam__12___closed__0_value;
static const lean_ctor_object l_main___lam__12___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(72) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__0_value)}};
static const lean_object* l_main___lam__12___closed__1 = (const lean_object*)&l_main___lam__12___closed__1_value;
static const lean_ctor_object l_main___lam__12___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(16) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__1_value)}};
static const lean_object* l_main___lam__12___closed__2 = (const lean_object*)&l_main___lam__12___closed__2_value;
LEAN_EXPORT lean_object* l_main___lam__12(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__13(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_closure_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_closure_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__2___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_closure_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__3___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_closure_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__4___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_closure_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__5___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_closure_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__6___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_ctor_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&l_main___closed__0_value),((lean_object*)&l_main___closed__1_value),((lean_object*)&l_main___closed__2_value),((lean_object*)&l_main___closed__3_value),((lean_object*)&l_main___closed__4_value)}};
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_closure_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__8___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_closure_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__7___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static lean_once_cell_t l_main___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__10;
static lean_once_cell_t l_main___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__11;
static lean_once_cell_t l_main___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__12;
static lean_once_cell_t l_main___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__13;
static lean_once_cell_t l_main___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__14;
static lean_once_cell_t l_main___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__15;
static lean_once_cell_t l_main___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__16;
static lean_once_cell_t l_main___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__17;
static const lean_closure_object l_main___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__11___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(8) << 1) | 1))} };
static const lean_object* l_main___closed__18 = (const lean_object*)&l_main___closed__18_value;
static const lean_closure_object l_main___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__12___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(8) << 1) | 1))} };
static const lean_object* l_main___closed__19 = (const lean_object*)&l_main___closed__19_value;
static const lean_closure_object l_main___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*3, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__13___boxed, .m_arity = 4, .m_num_fixed = 3, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(8) << 1) | 1))} };
static const lean_object* l_main___closed__20 = (const lean_object*)&l_main___closed__20_value;
static lean_once_cell_t l_main___closed__21_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__21;
static lean_once_cell_t l_main___closed__22_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__22;
static lean_once_cell_t l_main___closed__23_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__23;
static lean_once_cell_t l_main___closed__24_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__24;
static lean_once_cell_t l_main___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__25;
static lean_once_cell_t l_main___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__26;
static lean_once_cell_t l_main___closed__27_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__27;
static lean_once_cell_t l_main___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__28;
static lean_once_cell_t l_main___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__29;
static lean_once_cell_t l_main___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__30;
static lean_once_cell_t l_main___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__31;
static lean_once_cell_t l_main___closed__32_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__32;
static lean_once_cell_t l_main___closed__33_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__33;
static lean_once_cell_t l_main___closed__34_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__34;
static lean_once_cell_t l_main___closed__35_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__35;
static lean_once_cell_t l_main___closed__36_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__36;
static lean_once_cell_t l_main___closed__37_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__37;
static lean_once_cell_t l_main___closed__38_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__38;
static lean_once_cell_t l_main___closed__39_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__39;
static lean_once_cell_t l_main___closed__40_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__40;
static lean_once_cell_t l_main___closed__41_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__41;
static lean_once_cell_t l_main___closed__42_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__42;
static lean_once_cell_t l_main___closed__43_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__43;
static lean_once_cell_t l_main___closed__44_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__44;
static lean_once_cell_t l_main___closed__45_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__45;
static lean_once_cell_t l_main___closed__46_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__46;
static lean_once_cell_t l_main___closed__47_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__47;
static lean_once_cell_t l_main___closed__48_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__48;
static lean_once_cell_t l_main___closed__49_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__49;
static lean_once_cell_t l_main___closed__50_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__50;
static lean_once_cell_t l_main___closed__51_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__51;
static lean_once_cell_t l_main___closed__52_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__52;
static lean_once_cell_t l_main___closed__53_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__53;
static lean_once_cell_t l_main___closed__54_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__54;
static lean_once_cell_t l_main___closed__55_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__55;
static lean_once_cell_t l_main___closed__56_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__56;
static lean_once_cell_t l_main___closed__57_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__57;
static lean_once_cell_t l_main___closed__58_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__58;
static lean_once_cell_t l_main___closed__59_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__59;
static lean_once_cell_t l_main___closed__60_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__60;
static lean_once_cell_t l_main___closed__61_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__61;
static lean_once_cell_t l_main___closed__62_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__62;
static lean_once_cell_t l_main___closed__63_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__63;
static lean_once_cell_t l_main___closed__64_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__64;
LEAN_EXPORT lean_object* _lean_main();
LEAN_EXPORT lean_object* l_main___boxed(lean_object*);
LEAN_EXPORT lean_object* l_array(lean_object* v_xs_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; 
v___x_5_ = ((lean_object*)(l_array___closed__0));
v___x_6_ = ((lean_object*)(l_array___closed__1));
v___x_7_ = l_String_intercalate(v___x_6_, v_xs_4_);
v___x_8_ = lean_string_append(v___x_5_, v___x_7_);
lean_dec_ref(v___x_7_);
v___x_9_ = ((lean_object*)(l_array___closed__2));
v___x_10_ = lean_string_append(v___x_8_, v___x_9_);
return v___x_10_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__0(lean_object* v_a_11_, lean_object* v_a_12_){
_start:
{
if (lean_obj_tag(v_a_11_) == 0)
{
lean_object* v___x_13_; 
v___x_13_ = l_List_reverse___redArg(v_a_12_);
return v___x_13_;
}
else
{
lean_object* v_head_14_; lean_object* v_tail_15_; lean_object* v___x_17_; uint8_t v_isShared_18_; uint8_t v_isSharedCheck_26_; 
v_head_14_ = lean_ctor_get(v_a_11_, 0);
v_tail_15_ = lean_ctor_get(v_a_11_, 1);
v_isSharedCheck_26_ = !lean_is_exclusive(v_a_11_);
if (v_isSharedCheck_26_ == 0)
{
v___x_17_ = v_a_11_;
v_isShared_18_ = v_isSharedCheck_26_;
goto v_resetjp_16_;
}
else
{
lean_inc(v_tail_15_);
lean_inc(v_head_14_);
lean_dec(v_a_11_);
v___x_17_ = lean_box(0);
v_isShared_18_ = v_isSharedCheck_26_;
goto v_resetjp_16_;
}
v_resetjp_16_:
{
uint32_t v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_23_; 
v___x_19_ = lean_unbox_uint32(v_head_14_);
lean_dec(v_head_14_);
v___x_20_ = lean_uint32_to_nat(v___x_19_);
v___x_21_ = l_Nat_reprFast(v___x_20_);
if (v_isShared_18_ == 0)
{
lean_ctor_set(v___x_17_, 1, v_a_12_);
lean_ctor_set(v___x_17_, 0, v___x_21_);
v___x_23_ = v___x_17_;
goto v_reusejp_22_;
}
else
{
lean_object* v_reuseFailAlloc_25_; 
v_reuseFailAlloc_25_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_25_, 0, v___x_21_);
lean_ctor_set(v_reuseFailAlloc_25_, 1, v_a_12_);
v___x_23_ = v_reuseFailAlloc_25_;
goto v_reusejp_22_;
}
v_reusejp_22_:
{
v_a_11_ = v_tail_15_;
v_a_12_ = v___x_23_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__1(lean_object* v_a_27_, lean_object* v_a_28_){
_start:
{
if (lean_obj_tag(v_a_27_) == 0)
{
lean_object* v___x_29_; 
v___x_29_ = l_List_reverse___redArg(v_a_28_);
return v___x_29_;
}
else
{
lean_object* v_head_30_; lean_object* v_tail_31_; lean_object* v___x_33_; uint8_t v_isShared_34_; uint8_t v_isSharedCheck_40_; 
v_head_30_ = lean_ctor_get(v_a_27_, 0);
v_tail_31_ = lean_ctor_get(v_a_27_, 1);
v_isSharedCheck_40_ = !lean_is_exclusive(v_a_27_);
if (v_isSharedCheck_40_ == 0)
{
v___x_33_ = v_a_27_;
v_isShared_34_ = v_isSharedCheck_40_;
goto v_resetjp_32_;
}
else
{
lean_inc(v_tail_31_);
lean_inc(v_head_30_);
lean_dec(v_a_27_);
v___x_33_ = lean_box(0);
v_isShared_34_ = v_isSharedCheck_40_;
goto v_resetjp_32_;
}
v_resetjp_32_:
{
lean_object* v___x_35_; lean_object* v___x_37_; 
v___x_35_ = l_Nat_reprFast(v_head_30_);
if (v_isShared_34_ == 0)
{
lean_ctor_set(v___x_33_, 1, v_a_28_);
lean_ctor_set(v___x_33_, 0, v___x_35_);
v___x_37_ = v___x_33_;
goto v_reusejp_36_;
}
else
{
lean_object* v_reuseFailAlloc_39_; 
v_reuseFailAlloc_39_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_39_, 0, v___x_35_);
lean_ctor_set(v_reuseFailAlloc_39_, 1, v_a_28_);
v___x_37_ = v_reuseFailAlloc_39_;
goto v_reusejp_36_;
}
v_reusejp_36_:
{
v_a_27_ = v_tail_31_;
v_a_28_ = v___x_37_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_pvalue(lean_object* v_x_49_){
_start:
{
switch(lean_obj_tag(v_x_49_))
{
case 0:
{
lean_object* v_a_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; 
v_a_50_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_50_);
lean_dec_ref_known(v_x_49_, 1);
v___x_51_ = ((lean_object*)(l_pvalue___closed__0));
v___x_52_ = l_Int_repr(v_a_50_);
lean_dec(v_a_50_);
v___x_53_ = lean_string_append(v___x_51_, v___x_52_);
lean_dec_ref(v___x_52_);
v___x_54_ = ((lean_object*)(l_pvalue___closed__1));
v___x_55_ = lean_string_append(v___x_53_, v___x_54_);
return v___x_55_;
}
case 1:
{
uint8_t v_a_56_; lean_object* v___x_57_; lean_object* v___y_59_; 
v_a_56_ = lean_ctor_get_uint8(v_x_49_, 0);
lean_dec_ref_known(v_x_49_, 0);
v___x_57_ = ((lean_object*)(l_pvalue___closed__2));
if (v_a_56_ == 0)
{
lean_object* v___x_63_; 
v___x_63_ = ((lean_object*)(l_pvalue___closed__3));
v___y_59_ = v___x_63_;
goto v___jp_58_;
}
else
{
lean_object* v___x_64_; 
v___x_64_ = ((lean_object*)(l_pvalue___closed__4));
v___y_59_ = v___x_64_;
goto v___jp_58_;
}
v___jp_58_:
{
lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; 
v___x_60_ = lean_string_append(v___x_57_, v___y_59_);
v___x_61_ = ((lean_object*)(l_pvalue___closed__1));
v___x_62_ = lean_string_append(v___x_60_, v___x_61_);
return v___x_62_;
}
}
case 2:
{
lean_object* v_a_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; lean_object* v___x_72_; lean_object* v___x_73_; 
v_a_65_ = lean_ctor_get(v_x_49_, 0);
lean_inc_ref(v_a_65_);
lean_dec_ref_known(v_x_49_, 1);
v___x_66_ = ((lean_object*)(l_pvalue___closed__5));
v___x_67_ = lean_string_data(v_a_65_);
v___x_68_ = lean_box(0);
v___x_69_ = l_List_mapTR_loop___at___00pvalue_spec__0(v___x_67_, v___x_68_);
v___x_70_ = l_array(v___x_69_);
v___x_71_ = lean_string_append(v___x_66_, v___x_70_);
lean_dec_ref(v___x_70_);
v___x_72_ = ((lean_object*)(l_pvalue___closed__1));
v___x_73_ = lean_string_append(v___x_71_, v___x_72_);
return v___x_73_;
}
case 3:
{
lean_object* v_a_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; 
v_a_74_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_74_);
lean_dec_ref_known(v_x_49_, 1);
v___x_75_ = ((lean_object*)(l_pvalue___closed__6));
v___x_76_ = lean_box(0);
v___x_77_ = l_List_mapTR_loop___at___00pvalue_spec__1(v_a_74_, v___x_76_);
v___x_78_ = l_array(v___x_77_);
v___x_79_ = lean_string_append(v___x_75_, v___x_78_);
lean_dec_ref(v___x_78_);
v___x_80_ = ((lean_object*)(l_pvalue___closed__1));
v___x_81_ = lean_string_append(v___x_79_, v___x_80_);
return v___x_81_;
}
default: 
{
lean_object* v_a_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; 
v_a_82_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_82_);
lean_dec_ref_known(v_x_49_, 1);
v___x_83_ = ((lean_object*)(l_pvalue___closed__7));
v___x_84_ = l_Nat_reprFast(v_a_82_);
v___x_85_ = lean_string_append(v___x_83_, v___x_84_);
lean_dec_ref(v___x_84_);
v___x_86_ = ((lean_object*)(l_pvalue___closed__1));
v___x_87_ = lean_string_append(v___x_85_, v___x_86_);
return v___x_87_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__1(lean_object* v_a_88_, lean_object* v_a_89_){
_start:
{
if (lean_obj_tag(v_a_88_) == 0)
{
lean_object* v___x_90_; 
v___x_90_ = l_List_reverse___redArg(v_a_89_);
return v___x_90_;
}
else
{
lean_object* v_head_91_; lean_object* v_tail_92_; lean_object* v___x_94_; uint8_t v_isShared_95_; uint8_t v_isSharedCheck_114_; 
v_head_91_ = lean_ctor_get(v_a_88_, 0);
v_tail_92_ = lean_ctor_get(v_a_88_, 1);
v_isSharedCheck_114_ = !lean_is_exclusive(v_a_88_);
if (v_isSharedCheck_114_ == 0)
{
v___x_94_ = v_a_88_;
v_isShared_95_ = v_isSharedCheck_114_;
goto v_resetjp_93_;
}
else
{
lean_inc(v_tail_92_);
lean_inc(v_head_91_);
lean_dec(v_a_88_);
v___x_94_ = lean_box(0);
v_isShared_95_ = v_isSharedCheck_114_;
goto v_resetjp_93_;
}
v_resetjp_93_:
{
lean_object* v_fst_96_; lean_object* v_snd_97_; lean_object* v___x_99_; uint8_t v_isShared_100_; uint8_t v_isSharedCheck_113_; 
v_fst_96_ = lean_ctor_get(v_head_91_, 0);
v_snd_97_ = lean_ctor_get(v_head_91_, 1);
v_isSharedCheck_113_ = !lean_is_exclusive(v_head_91_);
if (v_isSharedCheck_113_ == 0)
{
v___x_99_ = v_head_91_;
v_isShared_100_ = v_isSharedCheck_113_;
goto v_resetjp_98_;
}
else
{
lean_inc(v_snd_97_);
lean_inc(v_fst_96_);
lean_dec(v_head_91_);
v___x_99_ = lean_box(0);
v_isShared_100_ = v_isSharedCheck_113_;
goto v_resetjp_98_;
}
v_resetjp_98_:
{
lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; lean_object* v___x_105_; 
v___x_101_ = l_Nat_reprFast(v_fst_96_);
v___x_102_ = l_Int_repr(v_snd_97_);
lean_dec(v_snd_97_);
v___x_103_ = lean_box(0);
if (v_isShared_95_ == 0)
{
lean_ctor_set(v___x_94_, 1, v___x_103_);
lean_ctor_set(v___x_94_, 0, v___x_102_);
v___x_105_ = v___x_94_;
goto v_reusejp_104_;
}
else
{
lean_object* v_reuseFailAlloc_112_; 
v_reuseFailAlloc_112_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_112_, 0, v___x_102_);
lean_ctor_set(v_reuseFailAlloc_112_, 1, v___x_103_);
v___x_105_ = v_reuseFailAlloc_112_;
goto v_reusejp_104_;
}
v_reusejp_104_:
{
lean_object* v___x_107_; 
if (v_isShared_100_ == 0)
{
lean_ctor_set_tag(v___x_99_, 1);
lean_ctor_set(v___x_99_, 1, v___x_105_);
lean_ctor_set(v___x_99_, 0, v___x_101_);
v___x_107_ = v___x_99_;
goto v_reusejp_106_;
}
else
{
lean_object* v_reuseFailAlloc_111_; 
v_reuseFailAlloc_111_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_111_, 0, v___x_101_);
lean_ctor_set(v_reuseFailAlloc_111_, 1, v___x_105_);
v___x_107_ = v_reuseFailAlloc_111_;
goto v_reusejp_106_;
}
v_reusejp_106_:
{
lean_object* v___x_108_; lean_object* v___x_109_; 
v___x_108_ = l_array(v___x_107_);
v___x_109_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_109_, 0, v___x_108_);
lean_ctor_set(v___x_109_, 1, v_a_89_);
v_a_88_ = v_tail_92_;
v_a_89_ = v___x_109_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__0(lean_object* v_a_115_, lean_object* v_a_116_){
_start:
{
if (lean_obj_tag(v_a_115_) == 0)
{
lean_object* v___x_117_; 
v___x_117_ = l_List_reverse___redArg(v_a_116_);
return v___x_117_;
}
else
{
lean_object* v_head_118_; lean_object* v_tail_119_; lean_object* v___x_121_; uint8_t v_isShared_122_; uint8_t v_isSharedCheck_128_; 
v_head_118_ = lean_ctor_get(v_a_115_, 0);
v_tail_119_ = lean_ctor_get(v_a_115_, 1);
v_isSharedCheck_128_ = !lean_is_exclusive(v_a_115_);
if (v_isSharedCheck_128_ == 0)
{
v___x_121_ = v_a_115_;
v_isShared_122_ = v_isSharedCheck_128_;
goto v_resetjp_120_;
}
else
{
lean_inc(v_tail_119_);
lean_inc(v_head_118_);
lean_dec(v_a_115_);
v___x_121_ = lean_box(0);
v_isShared_122_ = v_isSharedCheck_128_;
goto v_resetjp_120_;
}
v_resetjp_120_:
{
lean_object* v___x_123_; lean_object* v___x_125_; 
v___x_123_ = l_pvalue(v_head_118_);
if (v_isShared_122_ == 0)
{
lean_ctor_set(v___x_121_, 1, v_a_116_);
lean_ctor_set(v___x_121_, 0, v___x_123_);
v___x_125_ = v___x_121_;
goto v_reusejp_124_;
}
else
{
lean_object* v_reuseFailAlloc_127_; 
v_reuseFailAlloc_127_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_127_, 0, v___x_123_);
lean_ctor_set(v_reuseFailAlloc_127_, 1, v_a_116_);
v___x_125_ = v_reuseFailAlloc_127_;
goto v_reusejp_124_;
}
v_reusejp_124_:
{
v_a_115_ = v_tail_119_;
v_a_116_ = v___x_125_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ss(lean_object* v_s_133_){
_start:
{
lean_object* v_state_134_; lean_object* v_now_135_; lean_object* v_values_136_; lean_object* v_timers_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; lean_object* v___x_157_; 
v_state_134_ = lean_ctor_get(v_s_133_, 0);
lean_inc(v_state_134_);
v_now_135_ = lean_ctor_get(v_s_133_, 1);
lean_inc(v_now_135_);
v_values_136_ = lean_ctor_get(v_s_133_, 2);
lean_inc(v_values_136_);
v_timers_137_ = lean_ctor_get(v_s_133_, 3);
lean_inc(v_timers_137_);
lean_dec_ref(v_s_133_);
v___x_138_ = ((lean_object*)(l_ss___closed__0));
v___x_139_ = l_Nat_reprFast(v_state_134_);
v___x_140_ = lean_string_append(v___x_138_, v___x_139_);
lean_dec_ref(v___x_139_);
v___x_141_ = ((lean_object*)(l_ss___closed__1));
v___x_142_ = lean_string_append(v___x_140_, v___x_141_);
v___x_143_ = l_Int_repr(v_now_135_);
lean_dec(v_now_135_);
v___x_144_ = lean_string_append(v___x_142_, v___x_143_);
lean_dec_ref(v___x_143_);
v___x_145_ = ((lean_object*)(l_ss___closed__2));
v___x_146_ = lean_string_append(v___x_144_, v___x_145_);
v___x_147_ = lean_box(0);
v___x_148_ = l_List_mapTR_loop___at___00ss_spec__0(v_values_136_, v___x_147_);
v___x_149_ = l_array(v___x_148_);
v___x_150_ = lean_string_append(v___x_146_, v___x_149_);
lean_dec_ref(v___x_149_);
v___x_151_ = ((lean_object*)(l_ss___closed__3));
v___x_152_ = lean_string_append(v___x_150_, v___x_151_);
v___x_153_ = l_List_mapTR_loop___at___00ss_spec__1(v_timers_137_, v___x_147_);
v___x_154_ = l_array(v___x_153_);
v___x_155_ = lean_string_append(v___x_152_, v___x_154_);
lean_dec_ref(v___x_154_);
v___x_156_ = ((lean_object*)(l_pvalue___closed__1));
v___x_157_ = lean_string_append(v___x_155_, v___x_156_);
return v___x_157_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00msg_spec__0(lean_object* v_a_158_, lean_object* v_a_159_){
_start:
{
if (lean_obj_tag(v_a_158_) == 0)
{
lean_object* v___x_160_; 
v___x_160_ = l_List_reverse___redArg(v_a_159_);
return v___x_160_;
}
else
{
lean_object* v_head_161_; lean_object* v_tail_162_; lean_object* v___x_164_; uint8_t v_isShared_165_; uint8_t v_isSharedCheck_184_; 
v_head_161_ = lean_ctor_get(v_a_158_, 0);
v_tail_162_ = lean_ctor_get(v_a_158_, 1);
v_isSharedCheck_184_ = !lean_is_exclusive(v_a_158_);
if (v_isSharedCheck_184_ == 0)
{
v___x_164_ = v_a_158_;
v_isShared_165_ = v_isSharedCheck_184_;
goto v_resetjp_163_;
}
else
{
lean_inc(v_tail_162_);
lean_inc(v_head_161_);
lean_dec(v_a_158_);
v___x_164_ = lean_box(0);
v_isShared_165_ = v_isSharedCheck_184_;
goto v_resetjp_163_;
}
v_resetjp_163_:
{
lean_object* v_fst_166_; lean_object* v_snd_167_; lean_object* v___x_169_; uint8_t v_isShared_170_; uint8_t v_isSharedCheck_183_; 
v_fst_166_ = lean_ctor_get(v_head_161_, 0);
v_snd_167_ = lean_ctor_get(v_head_161_, 1);
v_isSharedCheck_183_ = !lean_is_exclusive(v_head_161_);
if (v_isSharedCheck_183_ == 0)
{
v___x_169_ = v_head_161_;
v_isShared_170_ = v_isSharedCheck_183_;
goto v_resetjp_168_;
}
else
{
lean_inc(v_snd_167_);
lean_inc(v_fst_166_);
lean_dec(v_head_161_);
v___x_169_ = lean_box(0);
v_isShared_170_ = v_isSharedCheck_183_;
goto v_resetjp_168_;
}
v_resetjp_168_:
{
lean_object* v___x_171_; lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_175_; 
v___x_171_ = l_Nat_reprFast(v_fst_166_);
v___x_172_ = l_pvalue(v_snd_167_);
v___x_173_ = lean_box(0);
if (v_isShared_165_ == 0)
{
lean_ctor_set(v___x_164_, 1, v___x_173_);
lean_ctor_set(v___x_164_, 0, v___x_172_);
v___x_175_ = v___x_164_;
goto v_reusejp_174_;
}
else
{
lean_object* v_reuseFailAlloc_182_; 
v_reuseFailAlloc_182_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_182_, 0, v___x_172_);
lean_ctor_set(v_reuseFailAlloc_182_, 1, v___x_173_);
v___x_175_ = v_reuseFailAlloc_182_;
goto v_reusejp_174_;
}
v_reusejp_174_:
{
lean_object* v___x_177_; 
if (v_isShared_170_ == 0)
{
lean_ctor_set_tag(v___x_169_, 1);
lean_ctor_set(v___x_169_, 1, v___x_175_);
lean_ctor_set(v___x_169_, 0, v___x_171_);
v___x_177_ = v___x_169_;
goto v_reusejp_176_;
}
else
{
lean_object* v_reuseFailAlloc_181_; 
v_reuseFailAlloc_181_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_181_, 0, v___x_171_);
lean_ctor_set(v_reuseFailAlloc_181_, 1, v___x_175_);
v___x_177_ = v_reuseFailAlloc_181_;
goto v_reusejp_176_;
}
v_reusejp_176_:
{
lean_object* v___x_178_; lean_object* v___x_179_; 
v___x_178_ = l_array(v___x_177_);
v___x_179_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_179_, 0, v___x_178_);
lean_ctor_set(v___x_179_, 1, v_a_159_);
v_a_158_ = v_tail_162_;
v_a_159_ = v___x_179_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_msg(lean_object* v_m_187_){
_start:
{
lean_object* v_fst_188_; lean_object* v_snd_189_; lean_object* v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; lean_object* v___x_200_; 
v_fst_188_ = lean_ctor_get(v_m_187_, 0);
lean_inc(v_fst_188_);
v_snd_189_ = lean_ctor_get(v_m_187_, 1);
lean_inc(v_snd_189_);
lean_dec_ref(v_m_187_);
v___x_190_ = ((lean_object*)(l_msg___closed__0));
v___x_191_ = l_Nat_reprFast(v_fst_188_);
v___x_192_ = lean_string_append(v___x_190_, v___x_191_);
lean_dec_ref(v___x_191_);
v___x_193_ = ((lean_object*)(l_msg___closed__1));
v___x_194_ = lean_string_append(v___x_192_, v___x_193_);
v___x_195_ = lean_box(0);
v___x_196_ = l_List_mapTR_loop___at___00msg_spec__0(v_snd_189_, v___x_195_);
v___x_197_ = l_array(v___x_196_);
v___x_198_ = lean_string_append(v___x_194_, v___x_197_);
lean_dec_ref(v___x_197_);
v___x_199_ = ((lean_object*)(l_pvalue___closed__1));
v___x_200_ = lean_string_append(v___x_198_, v___x_199_);
return v___x_200_;
}
}
LEAN_EXPORT lean_object* l_faultName(uint8_t v_x_209_){
_start:
{
switch(v_x_209_)
{
case 0:
{
lean_object* v___x_210_; 
v___x_210_ = ((lean_object*)(l_faultName___closed__0));
return v___x_210_;
}
case 1:
{
lean_object* v___x_211_; 
v___x_211_ = ((lean_object*)(l_faultName___closed__1));
return v___x_211_;
}
case 2:
{
lean_object* v___x_212_; 
v___x_212_ = ((lean_object*)(l_faultName___closed__2));
return v___x_212_;
}
case 3:
{
lean_object* v___x_213_; 
v___x_213_ = ((lean_object*)(l_faultName___closed__3));
return v___x_213_;
}
case 4:
{
lean_object* v___x_214_; 
v___x_214_ = ((lean_object*)(l_faultName___closed__4));
return v___x_214_;
}
case 5:
{
lean_object* v___x_215_; 
v___x_215_ = ((lean_object*)(l_faultName___closed__5));
return v___x_215_;
}
case 6:
{
lean_object* v___x_216_; 
v___x_216_ = ((lean_object*)(l_faultName___closed__6));
return v___x_216_;
}
default: 
{
lean_object* v___x_217_; 
v___x_217_ = ((lean_object*)(l_faultName___closed__7));
return v___x_217_;
}
}
}
}
LEAN_EXPORT lean_object* l_faultName___boxed(lean_object* v_x_218_){
_start:
{
uint8_t v_x_76__boxed_219_; lean_object* v_res_220_; 
v_x_76__boxed_219_ = lean_unbox(v_x_218_);
v_res_220_ = l_faultName(v_x_76__boxed_219_);
return v_res_220_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00outcomeText_spec__0(lean_object* v_a_221_, lean_object* v_a_222_){
_start:
{
if (lean_obj_tag(v_a_221_) == 0)
{
lean_object* v___x_223_; 
v___x_223_ = l_List_reverse___redArg(v_a_222_);
return v___x_223_;
}
else
{
lean_object* v_head_224_; lean_object* v_tail_225_; lean_object* v___x_227_; uint8_t v_isShared_228_; uint8_t v_isSharedCheck_234_; 
v_head_224_ = lean_ctor_get(v_a_221_, 0);
v_tail_225_ = lean_ctor_get(v_a_221_, 1);
v_isSharedCheck_234_ = !lean_is_exclusive(v_a_221_);
if (v_isSharedCheck_234_ == 0)
{
v___x_227_ = v_a_221_;
v_isShared_228_ = v_isSharedCheck_234_;
goto v_resetjp_226_;
}
else
{
lean_inc(v_tail_225_);
lean_inc(v_head_224_);
lean_dec(v_a_221_);
v___x_227_ = lean_box(0);
v_isShared_228_ = v_isSharedCheck_234_;
goto v_resetjp_226_;
}
v_resetjp_226_:
{
lean_object* v___x_229_; lean_object* v___x_231_; 
v___x_229_ = l_msg(v_head_224_);
if (v_isShared_228_ == 0)
{
lean_ctor_set(v___x_227_, 1, v_a_222_);
lean_ctor_set(v___x_227_, 0, v___x_229_);
v___x_231_ = v___x_227_;
goto v_reusejp_230_;
}
else
{
lean_object* v_reuseFailAlloc_233_; 
v_reuseFailAlloc_233_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_233_, 0, v___x_229_);
lean_ctor_set(v_reuseFailAlloc_233_, 1, v_a_222_);
v___x_231_ = v_reuseFailAlloc_233_;
goto v_reusejp_230_;
}
v_reusejp_230_:
{
v_a_221_ = v_tail_225_;
v_a_222_ = v___x_231_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_outcomeText(lean_object* v_x_242_){
_start:
{
if (lean_obj_tag(v_x_242_) == 0)
{
lean_object* v_a_243_; lean_object* v_a_244_; lean_object* v_a_245_; lean_object* v_a_246_; lean_object* v___x_247_; lean_object* v___x_248_; lean_object* v___x_249_; lean_object* v___x_250_; lean_object* v___x_251_; lean_object* v___x_252_; lean_object* v___x_253_; lean_object* v___x_254_; lean_object* v___x_255_; lean_object* v___x_256_; lean_object* v___x_257_; lean_object* v___x_258_; lean_object* v___x_259_; lean_object* v___x_260_; lean_object* v___x_261_; lean_object* v___x_262_; lean_object* v___x_263_; lean_object* v___x_264_; lean_object* v___x_265_; 
v_a_243_ = lean_ctor_get(v_x_242_, 0);
lean_inc(v_a_243_);
v_a_244_ = lean_ctor_get(v_x_242_, 1);
lean_inc(v_a_244_);
v_a_245_ = lean_ctor_get(v_x_242_, 2);
lean_inc_ref(v_a_245_);
v_a_246_ = lean_ctor_get(v_x_242_, 3);
lean_inc(v_a_246_);
lean_dec_ref_known(v_x_242_, 4);
v___x_247_ = ((lean_object*)(l_outcomeText___closed__0));
v___x_248_ = l_Nat_reprFast(v_a_243_);
v___x_249_ = lean_string_append(v___x_247_, v___x_248_);
lean_dec_ref(v___x_248_);
v___x_250_ = ((lean_object*)(l_outcomeText___closed__1));
v___x_251_ = lean_string_append(v___x_249_, v___x_250_);
v___x_252_ = l_Nat_reprFast(v_a_244_);
v___x_253_ = lean_string_append(v___x_251_, v___x_252_);
lean_dec_ref(v___x_252_);
v___x_254_ = ((lean_object*)(l_outcomeText___closed__2));
v___x_255_ = lean_string_append(v___x_253_, v___x_254_);
v___x_256_ = l_ss(v_a_245_);
v___x_257_ = lean_string_append(v___x_255_, v___x_256_);
lean_dec_ref(v___x_256_);
v___x_258_ = ((lean_object*)(l_outcomeText___closed__3));
v___x_259_ = lean_string_append(v___x_257_, v___x_258_);
v___x_260_ = lean_box(0);
v___x_261_ = l_List_mapTR_loop___at___00outcomeText_spec__0(v_a_246_, v___x_260_);
v___x_262_ = l_array(v___x_261_);
v___x_263_ = lean_string_append(v___x_259_, v___x_262_);
lean_dec_ref(v___x_262_);
v___x_264_ = ((lean_object*)(l_pvalue___closed__1));
v___x_265_ = lean_string_append(v___x_263_, v___x_264_);
return v___x_265_;
}
else
{
uint8_t v_a_266_; lean_object* v_a_267_; lean_object* v___x_268_; lean_object* v___x_269_; lean_object* v___x_270_; lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_275_; lean_object* v___x_276_; 
v_a_266_ = lean_ctor_get_uint8(v_x_242_, sizeof(void*)*1);
v_a_267_ = lean_ctor_get(v_x_242_, 0);
lean_inc_ref(v_a_267_);
lean_dec_ref_known(v_x_242_, 1);
v___x_268_ = ((lean_object*)(l_outcomeText___closed__4));
v___x_269_ = l_faultName(v_a_266_);
v___x_270_ = lean_string_append(v___x_268_, v___x_269_);
lean_dec_ref(v___x_269_);
v___x_271_ = ((lean_object*)(l_outcomeText___closed__5));
v___x_272_ = lean_string_append(v___x_270_, v___x_271_);
v___x_273_ = l_ss(v_a_267_);
v___x_274_ = lean_string_append(v___x_272_, v___x_273_);
lean_dec_ref(v___x_273_);
v___x_275_ = ((lean_object*)(l_outcomeText___closed__6));
v___x_276_ = lean_string_append(v___x_274_, v___x_275_);
return v___x_276_;
}
}
}
static lean_object* _init_l_main___lam__0___closed__0(void){
_start:
{
lean_object* v___x_277_; lean_object* v___x_278_; 
v___x_277_ = lean_unsigned_to_nat(0u);
v___x_278_ = lean_nat_to_int(v___x_277_);
return v___x_278_;
}
}
static lean_object* _init_l_main___lam__0___closed__1(void){
_start:
{
lean_object* v___x_279_; lean_object* v___x_280_; 
v___x_279_ = lean_unsigned_to_nat(8u);
v___x_280_ = lean_nat_to_int(v___x_279_);
return v___x_280_;
}
}
static lean_object* _init_l_main___lam__0___closed__2(void){
_start:
{
lean_object* v___x_281_; lean_object* v___x_282_; 
v___x_281_ = lean_unsigned_to_nat(16u);
v___x_282_ = lean_nat_to_int(v___x_281_);
return v___x_282_;
}
}
static lean_object* _init_l_main___lam__0___closed__3(void){
_start:
{
lean_object* v___x_283_; lean_object* v___x_284_; 
v___x_283_ = lean_unsigned_to_nat(60000u);
v___x_284_ = lean_nat_to_int(v___x_283_);
return v___x_284_;
}
}
static lean_object* _init_l_main___lam__0___closed__4(void){
_start:
{
lean_object* v___x_285_; lean_object* v___x_286_; 
v___x_285_ = lean_unsigned_to_nat(30000u);
v___x_286_ = lean_nat_to_int(v___x_285_);
return v___x_286_;
}
}
static lean_object* _init_l_main___lam__0___closed__5(void){
_start:
{
lean_object* v___x_287_; lean_object* v___x_288_; 
v___x_287_ = lean_unsigned_to_nat(1000u);
v___x_288_ = lean_nat_to_int(v___x_287_);
return v___x_288_;
}
}
LEAN_EXPORT lean_object* l_main___lam__0(lean_object* v_n_289_){
_start:
{
lean_object* v___x_290_; uint8_t v___x_291_; 
v___x_290_ = lean_unsigned_to_nat(1u);
v___x_291_ = lean_nat_dec_eq(v_n_289_, v___x_290_);
if (v___x_291_ == 0)
{
lean_object* v___x_292_; uint8_t v___x_293_; 
v___x_292_ = lean_unsigned_to_nat(2u);
v___x_293_ = lean_nat_dec_eq(v_n_289_, v___x_292_);
if (v___x_293_ == 0)
{
lean_object* v___x_294_; uint8_t v___x_295_; 
v___x_294_ = lean_unsigned_to_nat(11u);
v___x_295_ = lean_nat_dec_eq(v_n_289_, v___x_294_);
if (v___x_295_ == 0)
{
lean_object* v___x_296_; uint8_t v___x_297_; 
v___x_296_ = lean_unsigned_to_nat(12u);
v___x_297_ = lean_nat_dec_eq(v_n_289_, v___x_296_);
if (v___x_297_ == 0)
{
lean_object* v___x_298_; uint8_t v___x_299_; 
v___x_298_ = lean_unsigned_to_nat(13u);
v___x_299_ = lean_nat_dec_eq(v_n_289_, v___x_298_);
if (v___x_299_ == 0)
{
lean_object* v___x_300_; uint8_t v___x_301_; 
v___x_300_ = lean_unsigned_to_nat(14u);
v___x_301_ = lean_nat_dec_eq(v_n_289_, v___x_300_);
if (v___x_301_ == 0)
{
lean_object* v___x_302_; uint8_t v___x_303_; 
v___x_302_ = lean_unsigned_to_nat(15u);
v___x_303_ = lean_nat_dec_eq(v_n_289_, v___x_302_);
if (v___x_303_ == 0)
{
lean_object* v___x_304_; uint8_t v___x_305_; 
v___x_304_ = lean_unsigned_to_nat(34u);
v___x_305_ = lean_nat_dec_eq(v_n_289_, v___x_304_);
if (v___x_305_ == 0)
{
lean_object* v___x_306_; uint8_t v___x_307_; 
v___x_306_ = lean_unsigned_to_nat(35u);
v___x_307_ = lean_nat_dec_eq(v_n_289_, v___x_306_);
if (v___x_307_ == 0)
{
lean_object* v___x_308_; uint8_t v___x_309_; 
v___x_308_ = lean_unsigned_to_nat(37u);
v___x_309_ = lean_nat_dec_eq(v_n_289_, v___x_308_);
if (v___x_309_ == 0)
{
lean_object* v___x_310_; uint8_t v___x_311_; 
v___x_310_ = lean_unsigned_to_nat(38u);
v___x_311_ = lean_nat_dec_eq(v_n_289_, v___x_310_);
if (v___x_311_ == 0)
{
lean_object* v___x_312_; uint8_t v___x_313_; 
v___x_312_ = lean_unsigned_to_nat(39u);
v___x_313_ = lean_nat_dec_eq(v_n_289_, v___x_312_);
if (v___x_313_ == 0)
{
lean_object* v___x_314_; uint8_t v___x_315_; 
v___x_314_ = lean_unsigned_to_nat(43u);
v___x_315_ = lean_nat_dec_eq(v_n_289_, v___x_314_);
if (v___x_315_ == 0)
{
lean_object* v___x_316_; 
v___x_316_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_316_;
}
else
{
lean_object* v___x_317_; 
v___x_317_ = lean_obj_once(&l_main___lam__0___closed__1, &l_main___lam__0___closed__1_once, _init_l_main___lam__0___closed__1);
return v___x_317_;
}
}
else
{
lean_object* v___x_318_; 
v___x_318_ = lean_obj_once(&l_main___lam__0___closed__2, &l_main___lam__0___closed__2_once, _init_l_main___lam__0___closed__2);
return v___x_318_;
}
}
else
{
lean_object* v___x_319_; 
v___x_319_ = lean_obj_once(&l_main___lam__0___closed__3, &l_main___lam__0___closed__3_once, _init_l_main___lam__0___closed__3);
return v___x_319_;
}
}
else
{
lean_object* v___x_320_; 
v___x_320_ = lean_obj_once(&l_main___lam__0___closed__4, &l_main___lam__0___closed__4_once, _init_l_main___lam__0___closed__4);
return v___x_320_;
}
}
else
{
lean_object* v___x_321_; 
v___x_321_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_321_;
}
}
else
{
lean_object* v___x_322_; 
v___x_322_ = lean_obj_once(&l_main___lam__0___closed__5, &l_main___lam__0___closed__5_once, _init_l_main___lam__0___closed__5);
return v___x_322_;
}
}
else
{
lean_object* v___x_323_; 
v___x_323_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_323_;
}
}
else
{
lean_object* v___x_324_; 
v___x_324_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_324_;
}
}
else
{
lean_object* v___x_325_; 
v___x_325_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_325_;
}
}
else
{
lean_object* v___x_326_; 
v___x_326_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_326_;
}
}
else
{
lean_object* v___x_327_; 
v___x_327_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_327_;
}
}
else
{
lean_object* v___x_328_; 
v___x_328_ = lean_obj_once(&l_main___lam__0___closed__3, &l_main___lam__0___closed__3_once, _init_l_main___lam__0___closed__3);
return v___x_328_;
}
}
else
{
lean_object* v___x_329_; 
v___x_329_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_329_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__0___boxed(lean_object* v_n_330_){
_start:
{
lean_object* v_res_331_; 
v_res_331_ = l_main___lam__0(v_n_330_);
lean_dec(v_n_330_);
return v_res_331_;
}
}
LEAN_EXPORT uint8_t l_main___lam__1(lean_object* v_n_332_){
_start:
{
lean_object* v___x_333_; uint8_t v___x_334_; 
v___x_333_ = lean_unsigned_to_nat(3u);
v___x_334_ = lean_nat_dec_eq(v_n_332_, v___x_333_);
if (v___x_334_ == 0)
{
lean_object* v___x_335_; uint8_t v___x_336_; 
v___x_335_ = lean_unsigned_to_nat(17u);
v___x_336_ = lean_nat_dec_eq(v_n_332_, v___x_335_);
if (v___x_336_ == 0)
{
lean_object* v___x_337_; uint8_t v___x_338_; 
v___x_337_ = lean_unsigned_to_nat(36u);
v___x_338_ = lean_nat_dec_eq(v_n_332_, v___x_337_);
return v___x_338_;
}
else
{
return v___x_334_;
}
}
else
{
return v___x_334_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__1___boxed(lean_object* v_n_339_){
_start:
{
uint8_t v_res_340_; lean_object* v_r_341_; 
v_res_340_ = l_main___lam__1(v_n_339_);
lean_dec(v_n_339_);
v_r_341_ = lean_box(v_res_340_);
return v_r_341_;
}
}
static lean_object* _init_l_main___lam__2___closed__0(void){
_start:
{
lean_object* v___x_342_; lean_object* v___x_343_; 
v___x_342_ = lean_box(0);
v___x_343_ = lean_string_mk(v___x_342_);
return v___x_343_;
}
}
static lean_object* _init_l_main___lam__2___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_344_; lean_object* v___x_345_; 
v___x_344_ = 101;
v___x_345_ = lean_box_uint32(v___x_344_);
return v___x_345_;
}
}
static lean_object* _init_l_main___lam__2___closed__1(void){
_start:
{
lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v___x_348_; 
v___x_346_ = lean_box(0);
v___x_347_ = l_main___lam__2___closed__1___boxed__const__1;
v___x_348_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_348_, 0, v___x_347_);
lean_ctor_set(v___x_348_, 1, v___x_346_);
return v___x_348_;
}
}
static lean_object* _init_l_main___lam__2___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_349_; lean_object* v___x_350_; 
v___x_349_ = 110;
v___x_350_ = lean_box_uint32(v___x_349_);
return v___x_350_;
}
}
static lean_object* _init_l_main___lam__2___closed__2(void){
_start:
{
lean_object* v___x_351_; lean_object* v___x_352_; lean_object* v___x_353_; 
v___x_351_ = lean_obj_once(&l_main___lam__2___closed__1, &l_main___lam__2___closed__1_once, _init_l_main___lam__2___closed__1);
v___x_352_ = l_main___lam__2___closed__2___boxed__const__1;
v___x_353_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_353_, 0, v___x_352_);
lean_ctor_set(v___x_353_, 1, v___x_351_);
return v___x_353_;
}
}
static lean_object* _init_l_main___lam__2___closed__3___boxed__const__1(void){
_start:
{
uint32_t v___x_354_; lean_object* v___x_355_; 
v___x_354_ = 111;
v___x_355_ = lean_box_uint32(v___x_354_);
return v___x_355_;
}
}
static lean_object* _init_l_main___lam__2___closed__3(void){
_start:
{
lean_object* v___x_356_; lean_object* v___x_357_; lean_object* v___x_358_; 
v___x_356_ = lean_obj_once(&l_main___lam__2___closed__2, &l_main___lam__2___closed__2_once, _init_l_main___lam__2___closed__2);
v___x_357_ = l_main___lam__2___closed__3___boxed__const__1;
v___x_358_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_358_, 0, v___x_357_);
lean_ctor_set(v___x_358_, 1, v___x_356_);
return v___x_358_;
}
}
static lean_object* _init_l_main___lam__2___closed__4(void){
_start:
{
lean_object* v___x_359_; lean_object* v___x_360_; lean_object* v___x_361_; 
v___x_359_ = lean_obj_once(&l_main___lam__2___closed__3, &l_main___lam__2___closed__3_once, _init_l_main___lam__2___closed__3);
v___x_360_ = l_main___lam__2___closed__2___boxed__const__1;
v___x_361_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_361_, 0, v___x_360_);
lean_ctor_set(v___x_361_, 1, v___x_359_);
return v___x_361_;
}
}
static lean_object* _init_l_main___lam__2___closed__5(void){
_start:
{
lean_object* v___x_362_; lean_object* v___x_363_; 
v___x_362_ = lean_obj_once(&l_main___lam__2___closed__4, &l_main___lam__2___closed__4_once, _init_l_main___lam__2___closed__4);
v___x_363_ = lean_string_mk(v___x_362_);
return v___x_363_;
}
}
static lean_object* _init_l_main___lam__2___closed__6___boxed__const__1(void){
_start:
{
uint32_t v___x_364_; lean_object* v___x_365_; 
v___x_364_ = 68;
v___x_365_ = lean_box_uint32(v___x_364_);
return v___x_365_;
}
}
static lean_object* _init_l_main___lam__2___closed__6(void){
_start:
{
lean_object* v___x_366_; lean_object* v___x_367_; lean_object* v___x_368_; 
v___x_366_ = lean_box(0);
v___x_367_ = l_main___lam__2___closed__6___boxed__const__1;
v___x_368_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_368_, 0, v___x_367_);
lean_ctor_set(v___x_368_, 1, v___x_366_);
return v___x_368_;
}
}
static lean_object* _init_l_main___lam__2___closed__7___boxed__const__1(void){
_start:
{
uint32_t v___x_369_; lean_object* v___x_370_; 
v___x_369_ = 69;
v___x_370_ = lean_box_uint32(v___x_369_);
return v___x_370_;
}
}
static lean_object* _init_l_main___lam__2___closed__7(void){
_start:
{
lean_object* v___x_371_; lean_object* v___x_372_; lean_object* v___x_373_; 
v___x_371_ = lean_obj_once(&l_main___lam__2___closed__6, &l_main___lam__2___closed__6_once, _init_l_main___lam__2___closed__6);
v___x_372_ = l_main___lam__2___closed__7___boxed__const__1;
v___x_373_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_373_, 0, v___x_372_);
lean_ctor_set(v___x_373_, 1, v___x_371_);
return v___x_373_;
}
}
static lean_object* _init_l_main___lam__2___closed__8___boxed__const__1(void){
_start:
{
uint32_t v___x_374_; lean_object* v___x_375_; 
v___x_374_ = 83;
v___x_375_ = lean_box_uint32(v___x_374_);
return v___x_375_;
}
}
static lean_object* _init_l_main___lam__2___closed__8(void){
_start:
{
lean_object* v___x_376_; lean_object* v___x_377_; lean_object* v___x_378_; 
v___x_376_ = lean_obj_once(&l_main___lam__2___closed__7, &l_main___lam__2___closed__7_once, _init_l_main___lam__2___closed__7);
v___x_377_ = l_main___lam__2___closed__8___boxed__const__1;
v___x_378_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_378_, 0, v___x_377_);
lean_ctor_set(v___x_378_, 1, v___x_376_);
return v___x_378_;
}
}
static lean_object* _init_l_main___lam__2___closed__9___boxed__const__1(void){
_start:
{
uint32_t v___x_379_; lean_object* v___x_380_; 
v___x_379_ = 79;
v___x_380_ = lean_box_uint32(v___x_379_);
return v___x_380_;
}
}
static lean_object* _init_l_main___lam__2___closed__9(void){
_start:
{
lean_object* v___x_381_; lean_object* v___x_382_; lean_object* v___x_383_; 
v___x_381_ = lean_obj_once(&l_main___lam__2___closed__8, &l_main___lam__2___closed__8_once, _init_l_main___lam__2___closed__8);
v___x_382_ = l_main___lam__2___closed__9___boxed__const__1;
v___x_383_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_383_, 0, v___x_382_);
lean_ctor_set(v___x_383_, 1, v___x_381_);
return v___x_383_;
}
}
static lean_object* _init_l_main___lam__2___closed__10___boxed__const__1(void){
_start:
{
uint32_t v___x_384_; lean_object* v___x_385_; 
v___x_384_ = 76;
v___x_385_ = lean_box_uint32(v___x_384_);
return v___x_385_;
}
}
static lean_object* _init_l_main___lam__2___closed__10(void){
_start:
{
lean_object* v___x_386_; lean_object* v___x_387_; lean_object* v___x_388_; 
v___x_386_ = lean_obj_once(&l_main___lam__2___closed__9, &l_main___lam__2___closed__9_once, _init_l_main___lam__2___closed__9);
v___x_387_ = l_main___lam__2___closed__10___boxed__const__1;
v___x_388_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_388_, 0, v___x_387_);
lean_ctor_set(v___x_388_, 1, v___x_386_);
return v___x_388_;
}
}
static lean_object* _init_l_main___lam__2___closed__11___boxed__const__1(void){
_start:
{
uint32_t v___x_389_; lean_object* v___x_390_; 
v___x_389_ = 67;
v___x_390_ = lean_box_uint32(v___x_389_);
return v___x_390_;
}
}
static lean_object* _init_l_main___lam__2___closed__11(void){
_start:
{
lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_393_; 
v___x_391_ = lean_obj_once(&l_main___lam__2___closed__10, &l_main___lam__2___closed__10_once, _init_l_main___lam__2___closed__10);
v___x_392_ = l_main___lam__2___closed__11___boxed__const__1;
v___x_393_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_393_, 0, v___x_392_);
lean_ctor_set(v___x_393_, 1, v___x_391_);
return v___x_393_;
}
}
static lean_object* _init_l_main___lam__2___closed__12(void){
_start:
{
lean_object* v___x_394_; lean_object* v___x_395_; 
v___x_394_ = lean_obj_once(&l_main___lam__2___closed__11, &l_main___lam__2___closed__11_once, _init_l_main___lam__2___closed__11);
v___x_395_ = lean_string_mk(v___x_394_);
return v___x_395_;
}
}
static lean_object* _init_l_main___lam__2___closed__13(void){
_start:
{
lean_object* v___x_396_; lean_object* v___x_397_; lean_object* v___x_398_; 
v___x_396_ = lean_box(0);
v___x_397_ = l_main___lam__2___closed__8___boxed__const__1;
v___x_398_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_398_, 0, v___x_397_);
lean_ctor_set(v___x_398_, 1, v___x_396_);
return v___x_398_;
}
}
static lean_object* _init_l_main___lam__2___closed__14(void){
_start:
{
lean_object* v___x_399_; lean_object* v___x_400_; 
v___x_399_ = lean_obj_once(&l_main___lam__2___closed__13, &l_main___lam__2___closed__13_once, _init_l_main___lam__2___closed__13);
v___x_400_ = lean_string_mk(v___x_399_);
return v___x_400_;
}
}
static lean_object* _init_l_main___lam__2___closed__15___boxed__const__1(void){
_start:
{
uint32_t v___x_401_; lean_object* v___x_402_; 
v___x_401_ = 89;
v___x_402_ = lean_box_uint32(v___x_401_);
return v___x_402_;
}
}
static lean_object* _init_l_main___lam__2___closed__15(void){
_start:
{
lean_object* v___x_403_; lean_object* v___x_404_; lean_object* v___x_405_; 
v___x_403_ = lean_box(0);
v___x_404_ = l_main___lam__2___closed__15___boxed__const__1;
v___x_405_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_405_, 0, v___x_404_);
lean_ctor_set(v___x_405_, 1, v___x_403_);
return v___x_405_;
}
}
static lean_object* _init_l_main___lam__2___closed__16___boxed__const__1(void){
_start:
{
uint32_t v___x_406_; lean_object* v___x_407_; 
v___x_406_ = 84;
v___x_407_ = lean_box_uint32(v___x_406_);
return v___x_407_;
}
}
static lean_object* _init_l_main___lam__2___closed__16(void){
_start:
{
lean_object* v___x_408_; lean_object* v___x_409_; lean_object* v___x_410_; 
v___x_408_ = lean_obj_once(&l_main___lam__2___closed__15, &l_main___lam__2___closed__15_once, _init_l_main___lam__2___closed__15);
v___x_409_ = l_main___lam__2___closed__16___boxed__const__1;
v___x_410_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_410_, 0, v___x_409_);
lean_ctor_set(v___x_410_, 1, v___x_408_);
return v___x_410_;
}
}
static lean_object* _init_l_main___lam__2___closed__17___boxed__const__1(void){
_start:
{
uint32_t v___x_411_; lean_object* v___x_412_; 
v___x_411_ = 80;
v___x_412_ = lean_box_uint32(v___x_411_);
return v___x_412_;
}
}
static lean_object* _init_l_main___lam__2___closed__17(void){
_start:
{
lean_object* v___x_413_; lean_object* v___x_414_; lean_object* v___x_415_; 
v___x_413_ = lean_obj_once(&l_main___lam__2___closed__16, &l_main___lam__2___closed__16_once, _init_l_main___lam__2___closed__16);
v___x_414_ = l_main___lam__2___closed__17___boxed__const__1;
v___x_415_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_415_, 0, v___x_414_);
lean_ctor_set(v___x_415_, 1, v___x_413_);
return v___x_415_;
}
}
static lean_object* _init_l_main___lam__2___closed__18___boxed__const__1(void){
_start:
{
uint32_t v___x_416_; lean_object* v___x_417_; 
v___x_416_ = 77;
v___x_417_ = lean_box_uint32(v___x_416_);
return v___x_417_;
}
}
static lean_object* _init_l_main___lam__2___closed__18(void){
_start:
{
lean_object* v___x_418_; lean_object* v___x_419_; lean_object* v___x_420_; 
v___x_418_ = lean_obj_once(&l_main___lam__2___closed__17, &l_main___lam__2___closed__17_once, _init_l_main___lam__2___closed__17);
v___x_419_ = l_main___lam__2___closed__18___boxed__const__1;
v___x_420_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_420_, 0, v___x_419_);
lean_ctor_set(v___x_420_, 1, v___x_418_);
return v___x_420_;
}
}
static lean_object* _init_l_main___lam__2___closed__19(void){
_start:
{
lean_object* v___x_421_; lean_object* v___x_422_; lean_object* v___x_423_; 
v___x_421_ = lean_obj_once(&l_main___lam__2___closed__18, &l_main___lam__2___closed__18_once, _init_l_main___lam__2___closed__18);
v___x_422_ = l_main___lam__2___closed__7___boxed__const__1;
v___x_423_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_423_, 0, v___x_422_);
lean_ctor_set(v___x_423_, 1, v___x_421_);
return v___x_423_;
}
}
static lean_object* _init_l_main___lam__2___closed__20(void){
_start:
{
lean_object* v___x_424_; lean_object* v___x_425_; 
v___x_424_ = lean_obj_once(&l_main___lam__2___closed__19, &l_main___lam__2___closed__19_once, _init_l_main___lam__2___closed__19);
v___x_425_ = lean_string_mk(v___x_424_);
return v___x_425_;
}
}
LEAN_EXPORT lean_object* l_main___lam__2(lean_object* v_n_426_){
_start:
{
lean_object* v___x_427_; uint8_t v___x_428_; 
v___x_427_ = lean_unsigned_to_nat(19u);
v___x_428_ = lean_nat_dec_eq(v_n_426_, v___x_427_);
if (v___x_428_ == 0)
{
lean_object* v___x_429_; uint8_t v___x_430_; 
v___x_429_ = lean_unsigned_to_nat(24u);
v___x_430_ = lean_nat_dec_eq(v_n_426_, v___x_429_);
if (v___x_430_ == 0)
{
lean_object* v___x_431_; uint8_t v___x_432_; 
v___x_431_ = lean_unsigned_to_nat(25u);
v___x_432_ = lean_nat_dec_eq(v_n_426_, v___x_431_);
if (v___x_432_ == 0)
{
lean_object* v___x_433_; uint8_t v___x_434_; 
v___x_433_ = lean_unsigned_to_nat(33u);
v___x_434_ = lean_nat_dec_eq(v_n_426_, v___x_433_);
if (v___x_434_ == 0)
{
lean_object* v___x_435_; uint8_t v___x_436_; 
v___x_435_ = lean_unsigned_to_nat(55u);
v___x_436_ = lean_nat_dec_eq(v_n_426_, v___x_435_);
if (v___x_436_ == 0)
{
lean_object* v___x_437_; uint8_t v___x_438_; 
v___x_437_ = lean_unsigned_to_nat(56u);
v___x_438_ = lean_nat_dec_eq(v_n_426_, v___x_437_);
if (v___x_438_ == 0)
{
lean_object* v___x_439_; uint8_t v___x_440_; 
v___x_439_ = lean_unsigned_to_nat(57u);
v___x_440_ = lean_nat_dec_eq(v_n_426_, v___x_439_);
if (v___x_440_ == 0)
{
lean_object* v___x_441_; 
v___x_441_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_441_;
}
else
{
lean_object* v___x_442_; 
v___x_442_ = lean_obj_once(&l_main___lam__2___closed__5, &l_main___lam__2___closed__5_once, _init_l_main___lam__2___closed__5);
return v___x_442_;
}
}
else
{
lean_object* v___x_443_; 
v___x_443_ = lean_obj_once(&l_main___lam__2___closed__12, &l_main___lam__2___closed__12_once, _init_l_main___lam__2___closed__12);
return v___x_443_;
}
}
else
{
lean_object* v___x_444_; 
v___x_444_ = lean_obj_once(&l_main___lam__2___closed__5, &l_main___lam__2___closed__5_once, _init_l_main___lam__2___closed__5);
return v___x_444_;
}
}
else
{
lean_object* v___x_445_; 
v___x_445_ = lean_obj_once(&l_main___lam__2___closed__14, &l_main___lam__2___closed__14_once, _init_l_main___lam__2___closed__14);
return v___x_445_;
}
}
else
{
lean_object* v___x_446_; 
v___x_446_ = lean_obj_once(&l_main___lam__2___closed__20, &l_main___lam__2___closed__20_once, _init_l_main___lam__2___closed__20);
return v___x_446_;
}
}
else
{
lean_object* v___x_447_; 
v___x_447_ = lean_obj_once(&l_main___lam__2___closed__5, &l_main___lam__2___closed__5_once, _init_l_main___lam__2___closed__5);
return v___x_447_;
}
}
else
{
lean_object* v___x_448_; 
v___x_448_ = lean_obj_once(&l_main___lam__2___closed__5, &l_main___lam__2___closed__5_once, _init_l_main___lam__2___closed__5);
return v___x_448_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__2___boxed(lean_object* v_n_449_){
_start:
{
lean_object* v_res_450_; 
v_res_450_ = l_main___lam__2(v_n_449_);
lean_dec(v_n_449_);
return v_res_450_;
}
}
LEAN_EXPORT lean_object* l_main___lam__3(lean_object* v_n_451_){
_start:
{
lean_object* v___x_452_; 
v___x_452_ = lean_box(0);
return v___x_452_;
}
}
LEAN_EXPORT lean_object* l_main___lam__3___boxed(lean_object* v_n_453_){
_start:
{
lean_object* v_res_454_; 
v_res_454_ = l_main___lam__3(v_n_453_);
lean_dec(v_n_453_);
return v_res_454_;
}
}
LEAN_EXPORT lean_object* l_main___lam__4(lean_object* v_n_455_){
_start:
{
lean_object* v___x_456_; uint8_t v___x_457_; 
v___x_456_ = lean_unsigned_to_nat(26u);
v___x_457_ = lean_nat_dec_eq(v_n_455_, v___x_456_);
if (v___x_457_ == 0)
{
lean_object* v___x_458_; uint8_t v___x_459_; 
v___x_458_ = lean_unsigned_to_nat(27u);
v___x_459_ = lean_nat_dec_eq(v_n_455_, v___x_458_);
if (v___x_459_ == 0)
{
lean_object* v___x_460_; uint8_t v___x_461_; 
v___x_460_ = lean_unsigned_to_nat(28u);
v___x_461_ = lean_nat_dec_eq(v_n_455_, v___x_460_);
if (v___x_461_ == 0)
{
lean_object* v___x_462_; uint8_t v___x_463_; 
v___x_462_ = lean_unsigned_to_nat(29u);
v___x_463_ = lean_nat_dec_eq(v_n_455_, v___x_462_);
if (v___x_463_ == 0)
{
lean_object* v___x_464_; uint8_t v___x_465_; 
v___x_464_ = lean_unsigned_to_nat(30u);
v___x_465_ = lean_nat_dec_eq(v_n_455_, v___x_464_);
if (v___x_465_ == 0)
{
lean_object* v___x_466_; uint8_t v___x_467_; 
v___x_466_ = lean_unsigned_to_nat(31u);
v___x_467_ = lean_nat_dec_eq(v_n_455_, v___x_466_);
if (v___x_467_ == 0)
{
lean_object* v___x_468_; 
v___x_468_ = lean_unsigned_to_nat(0u);
return v___x_468_;
}
else
{
lean_object* v___x_469_; 
v___x_469_ = lean_unsigned_to_nat(1000u);
return v___x_469_;
}
}
else
{
lean_object* v___x_470_; 
v___x_470_ = lean_unsigned_to_nat(0u);
return v___x_470_;
}
}
else
{
lean_object* v___x_471_; 
v___x_471_ = lean_unsigned_to_nat(1000u);
return v___x_471_;
}
}
else
{
lean_object* v___x_472_; 
v___x_472_ = lean_unsigned_to_nat(1000u);
return v___x_472_;
}
}
else
{
lean_object* v___x_473_; 
v___x_473_ = lean_unsigned_to_nat(0u);
return v___x_473_;
}
}
else
{
lean_object* v___x_474_; 
v___x_474_ = lean_unsigned_to_nat(1000u);
return v___x_474_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__4___boxed(lean_object* v_n_475_){
_start:
{
lean_object* v_res_476_; 
v_res_476_ = l_main___lam__4(v_n_475_);
lean_dec(v_n_475_);
return v_res_476_;
}
}
LEAN_EXPORT uint8_t l_main___lam__5(lean_object* v_n_477_){
_start:
{
uint8_t v___x_478_; 
v___x_478_ = 0;
return v___x_478_;
}
}
LEAN_EXPORT lean_object* l_main___lam__5___boxed(lean_object* v_n_479_){
_start:
{
uint8_t v_res_480_; lean_object* v_r_481_; 
v_res_480_ = l_main___lam__5(v_n_479_);
lean_dec(v_n_479_);
v_r_481_ = lean_box(v_res_480_);
return v_r_481_;
}
}
LEAN_EXPORT lean_object* l_main___lam__6(lean_object* v_n_482_){
_start:
{
lean_object* v___x_483_; 
v___x_483_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_483_;
}
}
LEAN_EXPORT lean_object* l_main___lam__6___boxed(lean_object* v_n_484_){
_start:
{
lean_object* v_res_485_; 
v_res_485_ = l_main___lam__6(v_n_484_);
lean_dec(v_n_484_);
return v_res_485_;
}
}
LEAN_EXPORT lean_object* l_main___lam__8(lean_object* v___x_486_, lean_object* v_n_487_){
_start:
{
lean_inc(v___x_486_);
return v___x_486_;
}
}
LEAN_EXPORT lean_object* l_main___lam__8___boxed(lean_object* v___x_488_, lean_object* v_n_489_){
_start:
{
lean_object* v_res_490_; 
v_res_490_ = l_main___lam__8(v___x_488_, v_n_489_);
lean_dec(v_n_489_);
lean_dec(v___x_488_);
return v_res_490_;
}
}
LEAN_EXPORT lean_object* l_main___lam__7(lean_object* v___x_491_, lean_object* v_n_492_){
_start:
{
uint8_t v___x_493_; 
v___x_493_ = lean_nat_dec_eq(v_n_492_, v___x_491_);
if (v___x_493_ == 0)
{
lean_object* v___x_494_; 
lean_dec(v___x_491_);
v___x_494_ = lean_box(0);
return v___x_494_;
}
else
{
lean_object* v___x_495_; lean_object* v___x_496_; lean_object* v___x_497_; lean_object* v___x_498_; lean_object* v___x_499_; lean_object* v___x_500_; lean_object* v___x_501_; lean_object* v___x_502_; lean_object* v___x_503_; 
v___x_495_ = lean_unsigned_to_nat(128u);
v___x_496_ = lean_unsigned_to_nat(255u);
v___x_497_ = lean_unsigned_to_nat(7u);
v___x_498_ = lean_box(0);
lean_inc(v___x_491_);
v___x_499_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_499_, 0, v___x_491_);
lean_ctor_set(v___x_499_, 1, v___x_498_);
v___x_500_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_500_, 0, v___x_497_);
lean_ctor_set(v___x_500_, 1, v___x_499_);
v___x_501_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_501_, 0, v___x_496_);
lean_ctor_set(v___x_501_, 1, v___x_500_);
v___x_502_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_502_, 0, v___x_495_);
lean_ctor_set(v___x_502_, 1, v___x_501_);
v___x_503_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_503_, 0, v___x_491_);
lean_ctor_set(v___x_503_, 1, v___x_502_);
return v___x_503_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__7___boxed(lean_object* v___x_504_, lean_object* v_n_505_){
_start:
{
lean_object* v_res_506_; 
v_res_506_ = l_main___lam__7(v___x_504_, v_n_505_);
lean_dec(v_n_505_);
return v_res_506_;
}
}
LEAN_EXPORT lean_object* l_main___lam__9(lean_object* v___x_507_, lean_object* v_n_508_){
_start:
{
lean_inc(v___x_507_);
return v___x_507_;
}
}
LEAN_EXPORT lean_object* l_main___lam__9___boxed(lean_object* v___x_509_, lean_object* v_n_510_){
_start:
{
lean_object* v_res_511_; 
v_res_511_ = l_main___lam__9(v___x_509_, v_n_510_);
lean_dec(v_n_510_);
lean_dec(v___x_509_);
return v_res_511_;
}
}
static lean_object* _init_l_main___lam__10___closed__0(void){
_start:
{
lean_object* v___x_512_; lean_object* v___x_513_; 
v___x_512_ = lean_unsigned_to_nat(3u);
v___x_513_ = lean_nat_to_int(v___x_512_);
return v___x_513_;
}
}
LEAN_EXPORT lean_object* l_main___lam__10(lean_object* v___x_514_, lean_object* v___x_515_, lean_object* v_n_516_){
_start:
{
uint8_t v___x_517_; 
v___x_517_ = lean_nat_dec_eq(v_n_516_, v___x_514_);
if (v___x_517_ == 0)
{
lean_inc(v___x_515_);
return v___x_515_;
}
else
{
lean_object* v___x_518_; 
v___x_518_ = lean_obj_once(&l_main___lam__10___closed__0, &l_main___lam__10___closed__0_once, _init_l_main___lam__10___closed__0);
return v___x_518_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__10___boxed(lean_object* v___x_519_, lean_object* v___x_520_, lean_object* v_n_521_){
_start:
{
lean_object* v_res_522_; 
v_res_522_ = l_main___lam__10(v___x_519_, v___x_520_, v_n_521_);
lean_dec(v_n_521_);
lean_dec(v___x_520_);
lean_dec(v___x_519_);
return v_res_522_;
}
}
LEAN_EXPORT lean_object* l_main___lam__11(lean_object* v___x_532_, lean_object* v___x_533_, lean_object* v___x_534_, lean_object* v_n_535_){
_start:
{
uint8_t v___x_536_; 
v___x_536_ = lean_nat_dec_eq(v_n_535_, v___x_532_);
if (v___x_536_ == 0)
{
lean_object* v___x_537_; 
lean_dec(v___x_534_);
lean_dec(v___x_533_);
lean_dec(v___x_532_);
v___x_537_ = lean_box(0);
return v___x_537_;
}
else
{
lean_object* v___x_538_; lean_object* v___x_539_; lean_object* v___x_540_; lean_object* v___x_541_; lean_object* v___x_542_; lean_object* v___x_543_; lean_object* v___x_544_; lean_object* v___x_545_; lean_object* v___x_546_; lean_object* v___x_547_; lean_object* v___x_548_; lean_object* v___x_549_; lean_object* v___x_550_; lean_object* v___x_551_; lean_object* v___x_552_; lean_object* v___x_553_; lean_object* v___x_554_; lean_object* v___x_555_; lean_object* v___x_556_; lean_object* v___x_557_; lean_object* v___x_558_; lean_object* v___x_559_; lean_object* v___x_560_; lean_object* v___x_561_; lean_object* v___x_562_; lean_object* v___x_563_; lean_object* v___x_564_; lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_567_; lean_object* v___x_568_; lean_object* v___x_569_; lean_object* v___x_570_; lean_object* v___x_571_; lean_object* v___x_572_; lean_object* v___x_573_; lean_object* v___x_574_; lean_object* v___x_575_; lean_object* v___x_576_; lean_object* v___x_577_; lean_object* v___x_578_; lean_object* v___x_579_; lean_object* v___x_580_; lean_object* v___x_581_; lean_object* v___x_582_; lean_object* v___x_583_; lean_object* v___x_584_; lean_object* v___x_585_; lean_object* v___x_586_; lean_object* v___x_587_; lean_object* v___x_588_; lean_object* v___x_589_; lean_object* v___x_590_; lean_object* v___x_591_; lean_object* v___x_592_; lean_object* v___x_593_; lean_object* v___x_594_; lean_object* v___x_595_; lean_object* v___x_596_; lean_object* v___x_597_; lean_object* v___x_598_; lean_object* v___x_599_; lean_object* v___x_600_; lean_object* v___x_601_; lean_object* v___x_602_; lean_object* v___x_603_; 
v___x_538_ = lean_box(0);
lean_inc_n(v___x_533_, 4);
v___x_539_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_539_, 0, v___x_533_);
lean_ctor_set(v___x_539_, 1, v___x_538_);
v___x_540_ = lean_unsigned_to_nat(4u);
lean_inc_n(v___x_532_, 14);
v___x_541_ = l_List_replicateTR___redArg(v___x_540_, v___x_532_);
lean_inc(v___x_541_);
lean_inc_ref(v___x_539_);
v___x_542_ = l_List_appendTR___redArg(v___x_539_, v___x_541_);
v___x_543_ = lean_unsigned_to_nat(1u);
v___x_544_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_544_, 0, v___x_543_);
lean_ctor_set(v___x_544_, 1, v___x_539_);
v___x_545_ = l_List_appendTR___redArg(v___x_542_, v___x_544_);
v___x_546_ = l_List_appendTR___redArg(v___x_545_, v___x_541_);
v___x_547_ = lean_unsigned_to_nat(80u);
v___x_548_ = lean_unsigned_to_nat(18u);
v___x_549_ = ((lean_object*)(l_main___lam__11___closed__2));
v___x_550_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_550_, 0, v___x_532_);
lean_ctor_set(v___x_550_, 1, v___x_549_);
v___x_551_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_551_, 0, v___x_548_);
lean_ctor_set(v___x_551_, 1, v___x_550_);
v___x_552_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_552_, 0, v___x_547_);
lean_ctor_set(v___x_552_, 1, v___x_551_);
v___x_553_ = lean_unsigned_to_nat(40u);
v___x_554_ = lean_unsigned_to_nat(3u);
v___x_555_ = lean_unsigned_to_nat(233u);
v___x_556_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_556_, 0, v___x_555_);
lean_ctor_set(v___x_556_, 1, v___x_552_);
v___x_557_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_557_, 0, v___x_554_);
lean_ctor_set(v___x_557_, 1, v___x_556_);
v___x_558_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_558_, 0, v___x_532_);
lean_ctor_set(v___x_558_, 1, v___x_557_);
v___x_559_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_559_, 0, v___x_532_);
lean_ctor_set(v___x_559_, 1, v___x_558_);
v___x_560_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_560_, 0, v___x_553_);
lean_ctor_set(v___x_560_, 1, v___x_559_);
v___x_561_ = lean_unsigned_to_nat(156u);
v___x_562_ = lean_unsigned_to_nat(64u);
v___x_563_ = lean_unsigned_to_nat(35u);
v___x_564_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_564_, 0, v___x_563_);
lean_ctor_set(v___x_564_, 1, v___x_560_);
v___x_565_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_565_, 0, v___x_532_);
lean_ctor_set(v___x_565_, 1, v___x_564_);
v___x_566_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_566_, 0, v___x_532_);
lean_ctor_set(v___x_566_, 1, v___x_565_);
v___x_567_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_567_, 0, v___x_562_);
lean_ctor_set(v___x_567_, 1, v___x_566_);
v___x_568_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_568_, 0, v___x_561_);
lean_ctor_set(v___x_568_, 1, v___x_567_);
v___x_569_ = lean_unsigned_to_nat(31u);
v___x_570_ = lean_unsigned_to_nat(144u);
v___x_571_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_571_, 0, v___x_570_);
lean_ctor_set(v___x_571_, 1, v___x_568_);
v___x_572_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_572_, 0, v___x_569_);
lean_ctor_set(v___x_572_, 1, v___x_571_);
v___x_573_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_573_, 0, v___x_543_);
lean_ctor_set(v___x_573_, 1, v___x_572_);
v___x_574_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_574_, 0, v___x_533_);
lean_ctor_set(v___x_574_, 1, v___x_573_);
v___x_575_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_575_, 0, v___x_532_);
lean_ctor_set(v___x_575_, 1, v___x_574_);
v___x_576_ = lean_unsigned_to_nat(192u);
v___x_577_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_577_, 0, v___x_576_);
lean_ctor_set(v___x_577_, 1, v___x_575_);
v___x_578_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_578_, 0, v___x_533_);
lean_ctor_set(v___x_578_, 1, v___x_577_);
v___x_579_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_579_, 0, v___x_533_);
lean_ctor_set(v___x_579_, 1, v___x_578_);
v___x_580_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_580_, 0, v___x_532_);
lean_ctor_set(v___x_580_, 1, v___x_579_);
v___x_581_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_581_, 0, v___x_576_);
lean_ctor_set(v___x_581_, 1, v___x_580_);
v___x_582_ = lean_unsigned_to_nat(6u);
v___x_583_ = lean_unsigned_to_nat(182u);
v___x_584_ = lean_unsigned_to_nat(204u);
v___x_585_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_585_, 0, v___x_584_);
lean_ctor_set(v___x_585_, 1, v___x_581_);
v___x_586_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_586_, 0, v___x_583_);
lean_ctor_set(v___x_586_, 1, v___x_585_);
v___x_587_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_587_, 0, v___x_582_);
lean_ctor_set(v___x_587_, 1, v___x_586_);
v___x_588_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_588_, 0, v___x_562_);
lean_ctor_set(v___x_588_, 1, v___x_587_);
v___x_589_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_589_, 0, v___x_532_);
lean_ctor_set(v___x_589_, 1, v___x_588_);
v___x_590_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_590_, 0, v___x_562_);
lean_ctor_set(v___x_590_, 1, v___x_589_);
v___x_591_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_591_, 0, v___x_532_);
lean_ctor_set(v___x_591_, 1, v___x_590_);
v___x_592_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_592_, 0, v___x_532_);
lean_ctor_set(v___x_592_, 1, v___x_591_);
v___x_593_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_593_, 0, v___x_553_);
lean_ctor_set(v___x_593_, 1, v___x_592_);
v___x_594_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_594_, 0, v___x_532_);
lean_ctor_set(v___x_594_, 1, v___x_593_);
v___x_595_ = lean_unsigned_to_nat(69u);
v___x_596_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_596_, 0, v___x_532_);
lean_ctor_set(v___x_596_, 1, v___x_594_);
v___x_597_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_597_, 0, v___x_595_);
lean_ctor_set(v___x_597_, 1, v___x_596_);
v___x_598_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_598_, 0, v___x_532_);
lean_ctor_set(v___x_598_, 1, v___x_597_);
lean_inc(v___x_534_);
v___x_599_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_599_, 0, v___x_534_);
lean_ctor_set(v___x_599_, 1, v___x_598_);
v___x_600_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_600_, 0, v___x_533_);
lean_ctor_set(v___x_600_, 1, v___x_599_);
v___x_601_ = l_List_appendTR___redArg(v___x_546_, v___x_600_);
v___x_602_ = l_List_replicateTR___redArg(v___x_534_, v___x_532_);
v___x_603_ = l_List_appendTR___redArg(v___x_601_, v___x_602_);
return v___x_603_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__11___boxed(lean_object* v___x_604_, lean_object* v___x_605_, lean_object* v___x_606_, lean_object* v_n_607_){
_start:
{
lean_object* v_res_608_; 
v_res_608_ = l_main___lam__11(v___x_604_, v___x_605_, v___x_606_, v_n_607_);
lean_dec(v_n_607_);
return v_res_608_;
}
}
LEAN_EXPORT lean_object* l_main___lam__12(lean_object* v___x_618_, lean_object* v___x_619_, lean_object* v___x_620_, lean_object* v_n_621_){
_start:
{
uint8_t v___x_622_; 
v___x_622_ = lean_nat_dec_eq(v_n_621_, v___x_618_);
if (v___x_622_ == 0)
{
lean_object* v___x_623_; 
lean_dec(v___x_620_);
lean_dec(v___x_619_);
lean_dec(v___x_618_);
v___x_623_ = lean_box(0);
return v___x_623_;
}
else
{
lean_object* v___x_624_; lean_object* v___x_625_; lean_object* v___x_626_; lean_object* v___x_627_; lean_object* v___x_628_; lean_object* v___x_629_; lean_object* v___x_630_; lean_object* v___x_631_; lean_object* v___x_632_; lean_object* v___x_633_; lean_object* v___x_634_; lean_object* v___x_635_; lean_object* v___x_636_; lean_object* v___x_637_; lean_object* v___x_638_; lean_object* v___x_639_; lean_object* v___x_640_; lean_object* v___x_641_; lean_object* v___x_642_; lean_object* v___x_643_; lean_object* v___x_644_; lean_object* v___x_645_; lean_object* v___x_646_; lean_object* v___x_647_; lean_object* v___x_648_; lean_object* v___x_649_; lean_object* v___x_650_; lean_object* v___x_651_; lean_object* v___x_652_; lean_object* v___x_653_; lean_object* v___x_654_; lean_object* v___x_655_; lean_object* v___x_656_; lean_object* v___x_657_; lean_object* v___x_658_; lean_object* v___x_659_; lean_object* v___x_660_; lean_object* v___x_661_; lean_object* v___x_662_; lean_object* v___x_663_; lean_object* v___x_664_; lean_object* v___x_665_; lean_object* v___x_666_; lean_object* v___x_667_; lean_object* v___x_668_; lean_object* v___x_669_; lean_object* v___x_670_; lean_object* v___x_671_; lean_object* v___x_672_; lean_object* v___x_673_; lean_object* v___x_674_; lean_object* v___x_675_; lean_object* v___x_676_; lean_object* v___x_677_; lean_object* v___x_678_; lean_object* v___x_679_; lean_object* v___x_680_; lean_object* v___x_681_; lean_object* v___x_682_; lean_object* v___x_683_; lean_object* v___x_684_; lean_object* v___x_685_; lean_object* v___x_686_; lean_object* v___x_687_; lean_object* v___x_688_; lean_object* v___x_689_; lean_object* v___x_690_; 
v___x_624_ = lean_box(0);
lean_inc_n(v___x_619_, 4);
v___x_625_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_625_, 0, v___x_619_);
lean_ctor_set(v___x_625_, 1, v___x_624_);
v___x_626_ = lean_unsigned_to_nat(4u);
lean_inc_n(v___x_618_, 14);
v___x_627_ = l_List_replicateTR___redArg(v___x_626_, v___x_618_);
lean_inc(v___x_627_);
lean_inc_ref(v___x_625_);
v___x_628_ = l_List_appendTR___redArg(v___x_625_, v___x_627_);
v___x_629_ = lean_unsigned_to_nat(1u);
v___x_630_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_630_, 0, v___x_629_);
lean_ctor_set(v___x_630_, 1, v___x_625_);
v___x_631_ = l_List_appendTR___redArg(v___x_628_, v___x_630_);
v___x_632_ = l_List_appendTR___redArg(v___x_631_, v___x_627_);
v___x_633_ = lean_unsigned_to_nat(80u);
v___x_634_ = lean_unsigned_to_nat(16u);
v___x_635_ = ((lean_object*)(l_main___lam__12___closed__2));
v___x_636_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_636_, 0, v___x_618_);
lean_ctor_set(v___x_636_, 1, v___x_635_);
v___x_637_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_637_, 0, v___x_634_);
lean_ctor_set(v___x_637_, 1, v___x_636_);
v___x_638_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_638_, 0, v___x_633_);
lean_ctor_set(v___x_638_, 1, v___x_637_);
v___x_639_ = lean_unsigned_to_nat(41u);
v___x_640_ = lean_unsigned_to_nat(3u);
v___x_641_ = lean_unsigned_to_nat(238u);
v___x_642_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_642_, 0, v___x_641_);
lean_ctor_set(v___x_642_, 1, v___x_638_);
v___x_643_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_643_, 0, v___x_640_);
lean_ctor_set(v___x_643_, 1, v___x_642_);
v___x_644_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_644_, 0, v___x_618_);
lean_ctor_set(v___x_644_, 1, v___x_643_);
v___x_645_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_645_, 0, v___x_618_);
lean_ctor_set(v___x_645_, 1, v___x_644_);
v___x_646_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_646_, 0, v___x_639_);
lean_ctor_set(v___x_646_, 1, v___x_645_);
v___x_647_ = lean_unsigned_to_nat(156u);
v___x_648_ = lean_unsigned_to_nat(64u);
v___x_649_ = lean_unsigned_to_nat(35u);
v___x_650_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_650_, 0, v___x_649_);
lean_ctor_set(v___x_650_, 1, v___x_646_);
v___x_651_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_651_, 0, v___x_618_);
lean_ctor_set(v___x_651_, 1, v___x_650_);
v___x_652_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_652_, 0, v___x_618_);
lean_ctor_set(v___x_652_, 1, v___x_651_);
v___x_653_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_653_, 0, v___x_648_);
lean_ctor_set(v___x_653_, 1, v___x_652_);
v___x_654_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_654_, 0, v___x_647_);
lean_ctor_set(v___x_654_, 1, v___x_653_);
v___x_655_ = lean_unsigned_to_nat(31u);
v___x_656_ = lean_unsigned_to_nat(144u);
v___x_657_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_657_, 0, v___x_656_);
lean_ctor_set(v___x_657_, 1, v___x_654_);
v___x_658_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_658_, 0, v___x_655_);
lean_ctor_set(v___x_658_, 1, v___x_657_);
v___x_659_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_659_, 0, v___x_629_);
lean_ctor_set(v___x_659_, 1, v___x_658_);
v___x_660_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_660_, 0, v___x_619_);
lean_ctor_set(v___x_660_, 1, v___x_659_);
v___x_661_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_661_, 0, v___x_618_);
lean_ctor_set(v___x_661_, 1, v___x_660_);
v___x_662_ = lean_unsigned_to_nat(192u);
v___x_663_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_663_, 0, v___x_662_);
lean_ctor_set(v___x_663_, 1, v___x_661_);
v___x_664_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_664_, 0, v___x_619_);
lean_ctor_set(v___x_664_, 1, v___x_663_);
v___x_665_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_665_, 0, v___x_619_);
lean_ctor_set(v___x_665_, 1, v___x_664_);
v___x_666_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_666_, 0, v___x_618_);
lean_ctor_set(v___x_666_, 1, v___x_665_);
v___x_667_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_667_, 0, v___x_662_);
lean_ctor_set(v___x_667_, 1, v___x_666_);
v___x_668_ = lean_unsigned_to_nat(6u);
v___x_669_ = lean_unsigned_to_nat(182u);
v___x_670_ = lean_unsigned_to_nat(204u);
v___x_671_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_671_, 0, v___x_670_);
lean_ctor_set(v___x_671_, 1, v___x_667_);
v___x_672_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_672_, 0, v___x_669_);
lean_ctor_set(v___x_672_, 1, v___x_671_);
v___x_673_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_673_, 0, v___x_668_);
lean_ctor_set(v___x_673_, 1, v___x_672_);
v___x_674_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_674_, 0, v___x_648_);
lean_ctor_set(v___x_674_, 1, v___x_673_);
v___x_675_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_675_, 0, v___x_618_);
lean_ctor_set(v___x_675_, 1, v___x_674_);
v___x_676_ = lean_unsigned_to_nat(40u);
v___x_677_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_677_, 0, v___x_648_);
lean_ctor_set(v___x_677_, 1, v___x_675_);
v___x_678_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_678_, 0, v___x_618_);
lean_ctor_set(v___x_678_, 1, v___x_677_);
v___x_679_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_679_, 0, v___x_618_);
lean_ctor_set(v___x_679_, 1, v___x_678_);
v___x_680_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_680_, 0, v___x_676_);
lean_ctor_set(v___x_680_, 1, v___x_679_);
v___x_681_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_681_, 0, v___x_618_);
lean_ctor_set(v___x_681_, 1, v___x_680_);
v___x_682_ = lean_unsigned_to_nat(69u);
v___x_683_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_683_, 0, v___x_618_);
lean_ctor_set(v___x_683_, 1, v___x_681_);
v___x_684_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_684_, 0, v___x_682_);
lean_ctor_set(v___x_684_, 1, v___x_683_);
v___x_685_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_685_, 0, v___x_618_);
lean_ctor_set(v___x_685_, 1, v___x_684_);
lean_inc(v___x_620_);
v___x_686_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_686_, 0, v___x_620_);
lean_ctor_set(v___x_686_, 1, v___x_685_);
v___x_687_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_687_, 0, v___x_619_);
lean_ctor_set(v___x_687_, 1, v___x_686_);
v___x_688_ = l_List_appendTR___redArg(v___x_632_, v___x_687_);
v___x_689_ = l_List_replicateTR___redArg(v___x_620_, v___x_618_);
v___x_690_ = l_List_appendTR___redArg(v___x_688_, v___x_689_);
return v___x_690_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__12___boxed(lean_object* v___x_691_, lean_object* v___x_692_, lean_object* v___x_693_, lean_object* v_n_694_){
_start:
{
lean_object* v_res_695_; 
v_res_695_ = l_main___lam__12(v___x_691_, v___x_692_, v___x_693_, v_n_694_);
lean_dec(v_n_694_);
return v_res_695_;
}
}
LEAN_EXPORT lean_object* l_main___lam__13(lean_object* v___x_696_, lean_object* v___x_697_, lean_object* v___x_698_, lean_object* v_n_699_){
_start:
{
uint8_t v___x_700_; 
v___x_700_ = lean_nat_dec_eq(v_n_699_, v___x_696_);
if (v___x_700_ == 0)
{
lean_object* v___x_701_; 
lean_dec(v___x_698_);
lean_dec(v___x_697_);
lean_dec(v___x_696_);
v___x_701_ = lean_box(0);
return v___x_701_;
}
else
{
lean_object* v___x_702_; lean_object* v___x_703_; lean_object* v___x_704_; lean_object* v___x_705_; lean_object* v___x_706_; lean_object* v___x_707_; lean_object* v___x_708_; lean_object* v___x_709_; lean_object* v___x_710_; lean_object* v___x_711_; lean_object* v___x_712_; lean_object* v___x_713_; lean_object* v___x_714_; lean_object* v___x_715_; lean_object* v___x_716_; lean_object* v___x_717_; lean_object* v___x_718_; lean_object* v___x_719_; lean_object* v___x_720_; lean_object* v___x_721_; lean_object* v___x_722_; lean_object* v___x_723_; lean_object* v___x_724_; lean_object* v___x_725_; lean_object* v___x_726_; lean_object* v___x_727_; lean_object* v___x_728_; lean_object* v___x_729_; lean_object* v___x_730_; lean_object* v___x_731_; lean_object* v___x_732_; lean_object* v___x_733_; lean_object* v___x_734_; lean_object* v___x_735_; lean_object* v___x_736_; lean_object* v___x_737_; lean_object* v___x_738_; lean_object* v___x_739_; lean_object* v___x_740_; lean_object* v___x_741_; lean_object* v___x_742_; lean_object* v___x_743_; lean_object* v___x_744_; lean_object* v___x_745_; lean_object* v___x_746_; lean_object* v___x_747_; lean_object* v___x_748_; lean_object* v___x_749_; lean_object* v___x_750_; lean_object* v___x_751_; lean_object* v___x_752_; lean_object* v___x_753_; lean_object* v___x_754_; lean_object* v___x_755_; lean_object* v___x_756_; lean_object* v___x_757_; lean_object* v___x_758_; lean_object* v___x_759_; lean_object* v___x_760_; lean_object* v___x_761_; lean_object* v___x_762_; lean_object* v___x_763_; lean_object* v___x_764_; lean_object* v___x_765_; lean_object* v___x_766_; lean_object* v___x_767_; lean_object* v___x_768_; lean_object* v___x_769_; lean_object* v___x_770_; lean_object* v___x_771_; lean_object* v___x_772_; lean_object* v___x_773_; lean_object* v___x_774_; lean_object* v___x_775_; lean_object* v___x_776_; lean_object* v___x_777_; lean_object* v___x_778_; lean_object* v___x_779_; lean_object* v___x_780_; lean_object* v___x_781_; 
v___x_702_ = lean_box(0);
lean_inc_n(v___x_697_, 4);
v___x_703_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_703_, 0, v___x_697_);
lean_ctor_set(v___x_703_, 1, v___x_702_);
v___x_704_ = lean_unsigned_to_nat(4u);
lean_inc_n(v___x_696_, 19);
v___x_705_ = l_List_replicateTR___redArg(v___x_704_, v___x_696_);
lean_inc(v___x_705_);
lean_inc_ref(v___x_703_);
v___x_706_ = l_List_appendTR___redArg(v___x_703_, v___x_705_);
v___x_707_ = lean_unsigned_to_nat(1u);
v___x_708_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_708_, 0, v___x_707_);
lean_ctor_set(v___x_708_, 1, v___x_703_);
v___x_709_ = l_List_appendTR___redArg(v___x_706_, v___x_708_);
v___x_710_ = l_List_appendTR___redArg(v___x_709_, v___x_705_);
v___x_711_ = lean_unsigned_to_nat(9u);
v___x_712_ = lean_unsigned_to_nat(254u);
v___x_713_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_713_, 0, v___x_696_);
lean_ctor_set(v___x_713_, 1, v___x_702_);
v___x_714_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_714_, 0, v___x_696_);
lean_ctor_set(v___x_714_, 1, v___x_713_);
v___x_715_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_715_, 0, v___x_696_);
lean_ctor_set(v___x_715_, 1, v___x_714_);
v___x_716_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_716_, 0, v___x_712_);
lean_ctor_set(v___x_716_, 1, v___x_715_);
v___x_717_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_717_, 0, v___x_696_);
lean_ctor_set(v___x_717_, 1, v___x_716_);
v___x_718_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_718_, 0, v___x_711_);
lean_ctor_set(v___x_718_, 1, v___x_717_);
v___x_719_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_719_, 0, v___x_696_);
lean_ctor_set(v___x_719_, 1, v___x_718_);
v___x_720_ = lean_unsigned_to_nat(24u);
v___x_721_ = lean_unsigned_to_nat(16u);
v___x_722_ = lean_unsigned_to_nat(65u);
v___x_723_ = lean_unsigned_to_nat(205u);
v___x_724_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_724_, 0, v___x_696_);
lean_ctor_set(v___x_724_, 1, v___x_719_);
v___x_725_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_725_, 0, v___x_723_);
lean_ctor_set(v___x_725_, 1, v___x_724_);
v___x_726_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_726_, 0, v___x_722_);
lean_ctor_set(v___x_726_, 1, v___x_725_);
v___x_727_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_727_, 0, v___x_721_);
lean_ctor_set(v___x_727_, 1, v___x_726_);
v___x_728_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_728_, 0, v___x_696_);
lean_ctor_set(v___x_728_, 1, v___x_727_);
v___x_729_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_729_, 0, v___x_720_);
lean_ctor_set(v___x_729_, 1, v___x_728_);
v___x_730_ = lean_unsigned_to_nat(41u);
v___x_731_ = lean_unsigned_to_nat(3u);
v___x_732_ = lean_unsigned_to_nat(238u);
v___x_733_ = lean_unsigned_to_nat(80u);
v___x_734_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_734_, 0, v___x_733_);
lean_ctor_set(v___x_734_, 1, v___x_729_);
v___x_735_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_735_, 0, v___x_732_);
lean_ctor_set(v___x_735_, 1, v___x_734_);
v___x_736_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_736_, 0, v___x_731_);
lean_ctor_set(v___x_736_, 1, v___x_735_);
v___x_737_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_737_, 0, v___x_696_);
lean_ctor_set(v___x_737_, 1, v___x_736_);
v___x_738_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_738_, 0, v___x_696_);
lean_ctor_set(v___x_738_, 1, v___x_737_);
v___x_739_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_739_, 0, v___x_730_);
lean_ctor_set(v___x_739_, 1, v___x_738_);
v___x_740_ = lean_unsigned_to_nat(144u);
v___x_741_ = lean_unsigned_to_nat(156u);
v___x_742_ = lean_unsigned_to_nat(64u);
v___x_743_ = lean_unsigned_to_nat(35u);
v___x_744_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_744_, 0, v___x_743_);
lean_ctor_set(v___x_744_, 1, v___x_739_);
v___x_745_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_745_, 0, v___x_696_);
lean_ctor_set(v___x_745_, 1, v___x_744_);
v___x_746_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_746_, 0, v___x_696_);
lean_ctor_set(v___x_746_, 1, v___x_745_);
v___x_747_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_747_, 0, v___x_742_);
lean_ctor_set(v___x_747_, 1, v___x_746_);
v___x_748_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_748_, 0, v___x_741_);
lean_ctor_set(v___x_748_, 1, v___x_747_);
v___x_749_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_749_, 0, v___x_740_);
lean_ctor_set(v___x_749_, 1, v___x_748_);
v___x_750_ = lean_unsigned_to_nat(192u);
v___x_751_ = lean_unsigned_to_nat(31u);
v___x_752_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_752_, 0, v___x_751_);
lean_ctor_set(v___x_752_, 1, v___x_749_);
v___x_753_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_753_, 0, v___x_707_);
lean_ctor_set(v___x_753_, 1, v___x_752_);
v___x_754_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_754_, 0, v___x_697_);
lean_ctor_set(v___x_754_, 1, v___x_753_);
v___x_755_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_755_, 0, v___x_696_);
lean_ctor_set(v___x_755_, 1, v___x_754_);
v___x_756_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_756_, 0, v___x_750_);
lean_ctor_set(v___x_756_, 1, v___x_755_);
v___x_757_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_757_, 0, v___x_697_);
lean_ctor_set(v___x_757_, 1, v___x_756_);
v___x_758_ = lean_unsigned_to_nat(6u);
v___x_759_ = lean_unsigned_to_nat(182u);
v___x_760_ = lean_unsigned_to_nat(201u);
v___x_761_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_761_, 0, v___x_697_);
lean_ctor_set(v___x_761_, 1, v___x_757_);
v___x_762_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_762_, 0, v___x_696_);
lean_ctor_set(v___x_762_, 1, v___x_761_);
v___x_763_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_763_, 0, v___x_750_);
lean_ctor_set(v___x_763_, 1, v___x_762_);
v___x_764_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_764_, 0, v___x_760_);
lean_ctor_set(v___x_764_, 1, v___x_763_);
v___x_765_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_765_, 0, v___x_759_);
lean_ctor_set(v___x_765_, 1, v___x_764_);
v___x_766_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_766_, 0, v___x_758_);
lean_ctor_set(v___x_766_, 1, v___x_765_);
v___x_767_ = lean_unsigned_to_nat(43u);
v___x_768_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_768_, 0, v___x_742_);
lean_ctor_set(v___x_768_, 1, v___x_766_);
v___x_769_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_769_, 0, v___x_696_);
lean_ctor_set(v___x_769_, 1, v___x_768_);
v___x_770_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_770_, 0, v___x_742_);
lean_ctor_set(v___x_770_, 1, v___x_769_);
v___x_771_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_771_, 0, v___x_696_);
lean_ctor_set(v___x_771_, 1, v___x_770_);
v___x_772_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_772_, 0, v___x_696_);
lean_ctor_set(v___x_772_, 1, v___x_771_);
v___x_773_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_773_, 0, v___x_767_);
lean_ctor_set(v___x_773_, 1, v___x_772_);
v___x_774_ = lean_unsigned_to_nat(69u);
v___x_775_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_775_, 0, v___x_696_);
lean_ctor_set(v___x_775_, 1, v___x_773_);
v___x_776_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_776_, 0, v___x_696_);
lean_ctor_set(v___x_776_, 1, v___x_775_);
v___x_777_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_777_, 0, v___x_774_);
lean_ctor_set(v___x_777_, 1, v___x_776_);
v___x_778_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_778_, 0, v___x_696_);
lean_ctor_set(v___x_778_, 1, v___x_777_);
v___x_779_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_779_, 0, v___x_698_);
lean_ctor_set(v___x_779_, 1, v___x_778_);
v___x_780_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_780_, 0, v___x_697_);
lean_ctor_set(v___x_780_, 1, v___x_779_);
v___x_781_ = l_List_appendTR___redArg(v___x_710_, v___x_780_);
return v___x_781_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__13___boxed(lean_object* v___x_782_, lean_object* v___x_783_, lean_object* v___x_784_, lean_object* v_n_785_){
_start:
{
lean_object* v_res_786_; 
v_res_786_ = l_main___lam__13(v___x_782_, v___x_783_, v___x_784_, v_n_785_);
lean_dec(v_n_785_);
return v_res_786_;
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(lean_object* v_s_787_){
_start:
{
lean_object* v___x_789_; lean_object* v_putStr_790_; lean_object* v___x_791_; 
v___x_789_ = lean_get_stdout();
v_putStr_790_ = lean_ctor_get(v___x_789_, 4);
lean_inc_ref(v_putStr_790_);
lean_dec_ref(v___x_789_);
v___x_791_ = lean_apply_2(v_putStr_790_, v_s_787_, lean_box(0));
return v___x_791_;
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0___boxed(lean_object* v_s_792_, lean_object* v_a_793_){
_start:
{
lean_object* v_res_794_; 
v_res_794_ = l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(v_s_792_);
return v_res_794_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0(lean_object* v_s_795_){
_start:
{
uint32_t v___x_797_; lean_object* v___x_798_; lean_object* v___x_799_; 
v___x_797_ = 10;
v___x_798_ = lean_string_push(v_s_795_, v___x_797_);
v___x_799_ = l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(v___x_798_);
return v___x_799_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0___boxed(lean_object* v_s_800_, lean_object* v_a_801_){
_start:
{
lean_object* v_res_802_; 
v_res_802_ = l_IO_println___at___00main_spec__0(v_s_800_);
return v_res_802_;
}
}
static lean_object* _init_l_main___closed__10(void){
_start:
{
lean_object* v___x_820_; lean_object* v___f_821_; 
v___x_820_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___f_821_ = lean_alloc_closure((void*)(l_main___lam__9___boxed), 2, 1);
lean_closure_set(v___f_821_, 0, v___x_820_);
return v___f_821_;
}
}
static lean_object* _init_l_main___closed__11(void){
_start:
{
lean_object* v___x_822_; lean_object* v___x_823_; lean_object* v___f_824_; 
v___x_822_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_823_ = lean_unsigned_to_nat(0u);
v___f_824_ = lean_alloc_closure((void*)(l_main___lam__10___boxed), 3, 2);
lean_closure_set(v___f_824_, 0, v___x_823_);
lean_closure_set(v___f_824_, 1, v___x_822_);
return v___f_824_;
}
}
static lean_object* _init_l_main___closed__12(void){
_start:
{
lean_object* v___x_825_; lean_object* v___x_826_; lean_object* v___x_827_; lean_object* v___x_828_; lean_object* v_s__0__0_829_; 
v___x_825_ = lean_box(0);
v___x_826_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_827_ = lean_unsigned_to_nat(0u);
v___x_828_ = ((lean_object*)(l_main___closed__7));
v_s__0__0_829_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_s__0__0_829_, 0, v___x_828_);
lean_ctor_set(v_s__0__0_829_, 1, v___x_827_);
lean_ctor_set(v_s__0__0_829_, 2, v___x_826_);
lean_ctor_set(v_s__0__0_829_, 3, v___x_825_);
return v_s__0__0_829_;
}
}
static lean_object* _init_l_main___closed__13(void){
_start:
{
lean_object* v___f_830_; lean_object* v___f_831_; lean_object* v___f_832_; lean_object* v___f_833_; lean_object* v___f_834_; lean_object* v___x_835_; 
v___f_830_ = ((lean_object*)(l_main___closed__8));
v___f_831_ = ((lean_object*)(l_main___closed__3));
v___f_832_ = ((lean_object*)(l_main___closed__6));
v___f_833_ = ((lean_object*)(l_main___closed__5));
v___f_834_ = lean_obj_once(&l_main___closed__10, &l_main___closed__10_once, _init_l_main___closed__10);
v___x_835_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_835_, 0, v___f_834_);
lean_ctor_set(v___x_835_, 1, v___f_833_);
lean_ctor_set(v___x_835_, 2, v___f_832_);
lean_ctor_set(v___x_835_, 3, v___f_831_);
lean_ctor_set(v___x_835_, 4, v___f_830_);
return v___x_835_;
}
}
static lean_object* _init_l_main___closed__14(void){
_start:
{
lean_object* v___x_836_; lean_object* v___x_837_; lean_object* v___x_838_; lean_object* v_s__0__0_839_; lean_object* v___x_840_; lean_object* v_r__0__0_841_; 
v___x_836_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_837_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_838_ = lean_unsigned_to_nat(8u);
v_s__0__0_839_ = lean_obj_once(&l_main___closed__12, &l_main___closed__12_once, _init_l_main___closed__12);
v___x_840_ = l_MachineRuntime_model;
v_r__0__0_841_ = l_FormalSpecAgent_TypedMachine_external(v___x_840_, v_s__0__0_839_, v___x_838_, v___x_837_, v___x_836_);
return v_r__0__0_841_;
}
}
static lean_object* _init_l_main___closed__15(void){
_start:
{
lean_object* v_r__0__0_842_; lean_object* v_s__0__0_843_; lean_object* v___x_844_; lean_object* v___x_845_; 
v_r__0__0_842_ = lean_obj_once(&l_main___closed__14, &l_main___closed__14_once, _init_l_main___closed__14);
v_s__0__0_843_ = lean_obj_once(&l_main___closed__12, &l_main___closed__12_once, _init_l_main___closed__12);
v___x_844_ = l_MachineRuntime_schema;
v___x_845_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_844_, v_s__0__0_843_, v_r__0__0_842_);
return v___x_845_;
}
}
static lean_object* _init_l_main___closed__16(void){
_start:
{
lean_object* v___x_846_; lean_object* v___x_847_; 
v___x_846_ = lean_obj_once(&l_main___closed__15, &l_main___closed__15_once, _init_l_main___closed__15);
v___x_847_ = l_outcomeText(v___x_846_);
return v___x_847_;
}
}
static lean_object* _init_l_main___closed__17(void){
_start:
{
lean_object* v_r__0__0_848_; lean_object* v_s__0__0_849_; lean_object* v___x_850_; 
v_r__0__0_848_ = lean_obj_once(&l_main___closed__14, &l_main___closed__14_once, _init_l_main___closed__14);
v_s__0__0_849_ = lean_obj_once(&l_main___closed__12, &l_main___closed__12_once, _init_l_main___closed__12);
v___x_850_ = l_FormalSpecAgent_TypedMachine_rollback(v_s__0__0_849_, v_r__0__0_848_);
return v___x_850_;
}
}
static lean_object* _init_l_main___closed__21(void){
_start:
{
lean_object* v___f_863_; lean_object* v___f_864_; lean_object* v___f_865_; lean_object* v___f_866_; lean_object* v___f_867_; lean_object* v___x_868_; 
v___f_863_ = ((lean_object*)(l_main___closed__8));
v___f_864_ = ((lean_object*)(l_main___closed__18));
v___f_865_ = ((lean_object*)(l_main___closed__6));
v___f_866_ = ((lean_object*)(l_main___closed__5));
v___f_867_ = lean_obj_once(&l_main___closed__10, &l_main___closed__10_once, _init_l_main___closed__10);
v___x_868_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_868_, 0, v___f_867_);
lean_ctor_set(v___x_868_, 1, v___f_866_);
lean_ctor_set(v___x_868_, 2, v___f_865_);
lean_ctor_set(v___x_868_, 3, v___f_864_);
lean_ctor_set(v___x_868_, 4, v___f_863_);
return v___x_868_;
}
}
static lean_object* _init_l_main___closed__22(void){
_start:
{
lean_object* v___x_869_; lean_object* v___x_870_; 
v___x_869_ = lean_unsigned_to_nat(10u);
v___x_870_ = lean_nat_to_int(v___x_869_);
return v___x_870_;
}
}
static lean_object* _init_l_main___closed__23(void){
_start:
{
lean_object* v___x_871_; lean_object* v___x_872_; lean_object* v___x_873_; lean_object* v___x_874_; lean_object* v___x_875_; lean_object* v___x_876_; 
v___x_871_ = lean_obj_once(&l_main___closed__22, &l_main___closed__22_once, _init_l_main___closed__22);
v___x_872_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v___x_873_ = lean_unsigned_to_nat(2u);
v___x_874_ = lean_obj_once(&l_main___closed__17, &l_main___closed__17_once, _init_l_main___closed__17);
v___x_875_ = l_MachineRuntime_model;
v___x_876_ = l_FormalSpecAgent_TypedMachine_external(v___x_875_, v___x_874_, v___x_873_, v___x_872_, v___x_871_);
return v___x_876_;
}
}
static lean_object* _init_l_main___closed__24(void){
_start:
{
lean_object* v___x_877_; lean_object* v___x_878_; lean_object* v___x_879_; lean_object* v___x_880_; 
v___x_877_ = lean_obj_once(&l_main___closed__23, &l_main___closed__23_once, _init_l_main___closed__23);
v___x_878_ = lean_obj_once(&l_main___closed__17, &l_main___closed__17_once, _init_l_main___closed__17);
v___x_879_ = l_MachineRuntime_schema;
v___x_880_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_879_, v___x_878_, v___x_877_);
return v___x_880_;
}
}
static lean_object* _init_l_main___closed__25(void){
_start:
{
lean_object* v___x_881_; lean_object* v___x_882_; 
v___x_881_ = lean_obj_once(&l_main___closed__24, &l_main___closed__24_once, _init_l_main___closed__24);
v___x_882_ = l_outcomeText(v___x_881_);
return v___x_882_;
}
}
static lean_object* _init_l_main___closed__26(void){
_start:
{
lean_object* v___x_883_; lean_object* v___x_884_; lean_object* v___x_885_; 
v___x_883_ = lean_obj_once(&l_main___closed__23, &l_main___closed__23_once, _init_l_main___closed__23);
v___x_884_ = lean_obj_once(&l_main___closed__17, &l_main___closed__17_once, _init_l_main___closed__17);
v___x_885_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_884_, v___x_883_);
return v___x_885_;
}
}
static lean_object* _init_l_main___closed__27(void){
_start:
{
lean_object* v___f_886_; lean_object* v___f_887_; lean_object* v___f_888_; lean_object* v___f_889_; lean_object* v___f_890_; lean_object* v___x_891_; 
v___f_886_ = ((lean_object*)(l_main___closed__8));
v___f_887_ = ((lean_object*)(l_main___closed__9));
v___f_888_ = ((lean_object*)(l_main___closed__6));
v___f_889_ = ((lean_object*)(l_main___closed__5));
v___f_890_ = lean_obj_once(&l_main___closed__10, &l_main___closed__10_once, _init_l_main___closed__10);
v___x_891_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_891_, 0, v___f_890_);
lean_ctor_set(v___x_891_, 1, v___f_889_);
lean_ctor_set(v___x_891_, 2, v___f_888_);
lean_ctor_set(v___x_891_, 3, v___f_887_);
lean_ctor_set(v___x_891_, 4, v___f_886_);
return v___x_891_;
}
}
static lean_object* _init_l_main___closed__28(void){
_start:
{
lean_object* v___x_892_; lean_object* v___x_893_; 
v___x_892_ = lean_unsigned_to_nat(20u);
v___x_893_ = lean_nat_to_int(v___x_892_);
return v___x_893_;
}
}
static lean_object* _init_l_main___closed__29(void){
_start:
{
lean_object* v___x_894_; lean_object* v___x_895_; lean_object* v___x_896_; lean_object* v___x_897_; lean_object* v___x_898_; lean_object* v___x_899_; 
v___x_894_ = lean_obj_once(&l_main___closed__28, &l_main___closed__28_once, _init_l_main___closed__28);
v___x_895_ = lean_obj_once(&l_main___closed__27, &l_main___closed__27_once, _init_l_main___closed__27);
v___x_896_ = lean_unsigned_to_nat(21u);
v___x_897_ = lean_obj_once(&l_main___closed__26, &l_main___closed__26_once, _init_l_main___closed__26);
v___x_898_ = l_MachineRuntime_model;
v___x_899_ = l_FormalSpecAgent_TypedMachine_external(v___x_898_, v___x_897_, v___x_896_, v___x_895_, v___x_894_);
return v___x_899_;
}
}
static lean_object* _init_l_main___closed__30(void){
_start:
{
lean_object* v___x_900_; lean_object* v___x_901_; lean_object* v___x_902_; lean_object* v___x_903_; 
v___x_900_ = lean_obj_once(&l_main___closed__29, &l_main___closed__29_once, _init_l_main___closed__29);
v___x_901_ = lean_obj_once(&l_main___closed__26, &l_main___closed__26_once, _init_l_main___closed__26);
v___x_902_ = l_MachineRuntime_schema;
v___x_903_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_902_, v___x_901_, v___x_900_);
return v___x_903_;
}
}
static lean_object* _init_l_main___closed__31(void){
_start:
{
lean_object* v___x_904_; lean_object* v___x_905_; 
v___x_904_ = lean_obj_once(&l_main___closed__30, &l_main___closed__30_once, _init_l_main___closed__30);
v___x_905_ = l_outcomeText(v___x_904_);
return v___x_905_;
}
}
static lean_object* _init_l_main___closed__32(void){
_start:
{
lean_object* v___x_906_; lean_object* v___x_907_; lean_object* v___x_908_; 
v___x_906_ = lean_obj_once(&l_main___closed__29, &l_main___closed__29_once, _init_l_main___closed__29);
v___x_907_ = lean_obj_once(&l_main___closed__26, &l_main___closed__26_once, _init_l_main___closed__26);
v___x_908_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_907_, v___x_906_);
return v___x_908_;
}
}
static lean_object* _init_l_main___closed__33(void){
_start:
{
lean_object* v___x_909_; lean_object* v___x_910_; 
v___x_909_ = lean_unsigned_to_nat(21u);
v___x_910_ = lean_nat_to_int(v___x_909_);
return v___x_910_;
}
}
static lean_object* _init_l_main___closed__34(void){
_start:
{
lean_object* v___x_911_; lean_object* v___x_912_; lean_object* v___x_913_; lean_object* v___x_914_; lean_object* v___x_915_; lean_object* v___x_916_; 
v___x_911_ = lean_obj_once(&l_main___closed__33, &l_main___closed__33_once, _init_l_main___closed__33);
v___x_912_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_913_ = lean_unsigned_to_nat(22u);
v___x_914_ = lean_obj_once(&l_main___closed__32, &l_main___closed__32_once, _init_l_main___closed__32);
v___x_915_ = l_MachineRuntime_model;
v___x_916_ = l_FormalSpecAgent_TypedMachine_external(v___x_915_, v___x_914_, v___x_913_, v___x_912_, v___x_911_);
return v___x_916_;
}
}
static lean_object* _init_l_main___closed__35(void){
_start:
{
lean_object* v___x_917_; lean_object* v___x_918_; lean_object* v___x_919_; lean_object* v___x_920_; 
v___x_917_ = lean_obj_once(&l_main___closed__34, &l_main___closed__34_once, _init_l_main___closed__34);
v___x_918_ = lean_obj_once(&l_main___closed__32, &l_main___closed__32_once, _init_l_main___closed__32);
v___x_919_ = l_MachineRuntime_schema;
v___x_920_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_919_, v___x_918_, v___x_917_);
return v___x_920_;
}
}
static lean_object* _init_l_main___closed__36(void){
_start:
{
lean_object* v___x_921_; lean_object* v___x_922_; 
v___x_921_ = lean_obj_once(&l_main___closed__35, &l_main___closed__35_once, _init_l_main___closed__35);
v___x_922_ = l_outcomeText(v___x_921_);
return v___x_922_;
}
}
static lean_object* _init_l_main___closed__37(void){
_start:
{
lean_object* v___x_923_; lean_object* v___x_924_; lean_object* v___x_925_; 
v___x_923_ = lean_obj_once(&l_main___closed__34, &l_main___closed__34_once, _init_l_main___closed__34);
v___x_924_ = lean_obj_once(&l_main___closed__32, &l_main___closed__32_once, _init_l_main___closed__32);
v___x_925_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_924_, v___x_923_);
return v___x_925_;
}
}
static lean_object* _init_l_main___closed__38(void){
_start:
{
lean_object* v___x_926_; lean_object* v___x_927_; 
v___x_926_ = lean_unsigned_to_nat(22u);
v___x_927_ = lean_nat_to_int(v___x_926_);
return v___x_927_;
}
}
static lean_object* _init_l_main___closed__39(void){
_start:
{
lean_object* v___x_928_; lean_object* v___x_929_; lean_object* v___x_930_; lean_object* v___x_931_; lean_object* v___x_932_; lean_object* v___x_933_; 
v___x_928_ = lean_obj_once(&l_main___closed__38, &l_main___closed__38_once, _init_l_main___closed__38);
v___x_929_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_930_ = lean_unsigned_to_nat(22u);
v___x_931_ = lean_obj_once(&l_main___closed__37, &l_main___closed__37_once, _init_l_main___closed__37);
v___x_932_ = l_MachineRuntime_model;
v___x_933_ = l_FormalSpecAgent_TypedMachine_external(v___x_932_, v___x_931_, v___x_930_, v___x_929_, v___x_928_);
return v___x_933_;
}
}
static lean_object* _init_l_main___closed__40(void){
_start:
{
lean_object* v___x_934_; lean_object* v___x_935_; lean_object* v___x_936_; lean_object* v___x_937_; 
v___x_934_ = lean_obj_once(&l_main___closed__39, &l_main___closed__39_once, _init_l_main___closed__39);
v___x_935_ = lean_obj_once(&l_main___closed__37, &l_main___closed__37_once, _init_l_main___closed__37);
v___x_936_ = l_MachineRuntime_schema;
v___x_937_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_936_, v___x_935_, v___x_934_);
return v___x_937_;
}
}
static lean_object* _init_l_main___closed__41(void){
_start:
{
lean_object* v___x_938_; lean_object* v___x_939_; 
v___x_938_ = lean_obj_once(&l_main___closed__40, &l_main___closed__40_once, _init_l_main___closed__40);
v___x_939_ = l_outcomeText(v___x_938_);
return v___x_939_;
}
}
static lean_object* _init_l_main___closed__42(void){
_start:
{
lean_object* v___x_940_; lean_object* v___x_941_; lean_object* v___x_942_; 
v___x_940_ = lean_obj_once(&l_main___closed__39, &l_main___closed__39_once, _init_l_main___closed__39);
v___x_941_ = lean_obj_once(&l_main___closed__37, &l_main___closed__37_once, _init_l_main___closed__37);
v___x_942_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_941_, v___x_940_);
return v___x_942_;
}
}
static lean_object* _init_l_main___closed__43(void){
_start:
{
lean_object* v___f_943_; lean_object* v___f_944_; lean_object* v___f_945_; lean_object* v___f_946_; lean_object* v___f_947_; lean_object* v___x_948_; 
v___f_943_ = ((lean_object*)(l_main___closed__8));
v___f_944_ = ((lean_object*)(l_main___closed__19));
v___f_945_ = ((lean_object*)(l_main___closed__6));
v___f_946_ = ((lean_object*)(l_main___closed__5));
v___f_947_ = lean_obj_once(&l_main___closed__10, &l_main___closed__10_once, _init_l_main___closed__10);
v___x_948_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_948_, 0, v___f_947_);
lean_ctor_set(v___x_948_, 1, v___f_946_);
lean_ctor_set(v___x_948_, 2, v___f_945_);
lean_ctor_set(v___x_948_, 3, v___f_944_);
lean_ctor_set(v___x_948_, 4, v___f_943_);
return v___x_948_;
}
}
static lean_object* _init_l_main___closed__44(void){
_start:
{
lean_object* v___x_949_; lean_object* v___x_950_; 
v___x_949_ = lean_unsigned_to_nat(30u);
v___x_950_ = lean_nat_to_int(v___x_949_);
return v___x_950_;
}
}
static lean_object* _init_l_main___closed__45(void){
_start:
{
lean_object* v___x_951_; lean_object* v___x_952_; lean_object* v___x_953_; lean_object* v___x_954_; lean_object* v___x_955_; lean_object* v___x_956_; 
v___x_951_ = lean_obj_once(&l_main___closed__44, &l_main___closed__44_once, _init_l_main___closed__44);
v___x_952_ = lean_obj_once(&l_main___closed__43, &l_main___closed__43_once, _init_l_main___closed__43);
v___x_953_ = lean_unsigned_to_nat(2u);
v___x_954_ = lean_obj_once(&l_main___closed__42, &l_main___closed__42_once, _init_l_main___closed__42);
v___x_955_ = l_MachineRuntime_model;
v___x_956_ = l_FormalSpecAgent_TypedMachine_external(v___x_955_, v___x_954_, v___x_953_, v___x_952_, v___x_951_);
return v___x_956_;
}
}
static lean_object* _init_l_main___closed__46(void){
_start:
{
lean_object* v___x_957_; lean_object* v___x_958_; lean_object* v___x_959_; lean_object* v___x_960_; 
v___x_957_ = lean_obj_once(&l_main___closed__45, &l_main___closed__45_once, _init_l_main___closed__45);
v___x_958_ = lean_obj_once(&l_main___closed__42, &l_main___closed__42_once, _init_l_main___closed__42);
v___x_959_ = l_MachineRuntime_schema;
v___x_960_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_959_, v___x_958_, v___x_957_);
return v___x_960_;
}
}
static lean_object* _init_l_main___closed__47(void){
_start:
{
lean_object* v___x_961_; lean_object* v___x_962_; 
v___x_961_ = lean_obj_once(&l_main___closed__46, &l_main___closed__46_once, _init_l_main___closed__46);
v___x_962_ = l_outcomeText(v___x_961_);
return v___x_962_;
}
}
static lean_object* _init_l_main___closed__48(void){
_start:
{
lean_object* v___x_963_; lean_object* v___x_964_; lean_object* v___x_965_; 
v___x_963_ = lean_obj_once(&l_main___closed__45, &l_main___closed__45_once, _init_l_main___closed__45);
v___x_964_ = lean_obj_once(&l_main___closed__42, &l_main___closed__42_once, _init_l_main___closed__42);
v___x_965_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_964_, v___x_963_);
return v___x_965_;
}
}
static lean_object* _init_l_main___closed__49(void){
_start:
{
lean_object* v___f_966_; lean_object* v___f_967_; lean_object* v___f_968_; lean_object* v___f_969_; lean_object* v___f_970_; lean_object* v___x_971_; 
v___f_966_ = ((lean_object*)(l_main___closed__8));
v___f_967_ = ((lean_object*)(l_main___closed__20));
v___f_968_ = ((lean_object*)(l_main___closed__6));
v___f_969_ = ((lean_object*)(l_main___closed__5));
v___f_970_ = lean_obj_once(&l_main___closed__10, &l_main___closed__10_once, _init_l_main___closed__10);
v___x_971_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_971_, 0, v___f_970_);
lean_ctor_set(v___x_971_, 1, v___f_969_);
lean_ctor_set(v___x_971_, 2, v___f_968_);
lean_ctor_set(v___x_971_, 3, v___f_967_);
lean_ctor_set(v___x_971_, 4, v___f_966_);
return v___x_971_;
}
}
static lean_object* _init_l_main___closed__50(void){
_start:
{
lean_object* v___x_972_; lean_object* v___x_973_; 
v___x_972_ = lean_unsigned_to_nat(40u);
v___x_973_ = lean_nat_to_int(v___x_972_);
return v___x_973_;
}
}
static lean_object* _init_l_main___closed__51(void){
_start:
{
lean_object* v___x_974_; lean_object* v___x_975_; lean_object* v___x_976_; lean_object* v___x_977_; lean_object* v___x_978_; lean_object* v___x_979_; 
v___x_974_ = lean_obj_once(&l_main___closed__50, &l_main___closed__50_once, _init_l_main___closed__50);
v___x_975_ = lean_obj_once(&l_main___closed__49, &l_main___closed__49_once, _init_l_main___closed__49);
v___x_976_ = lean_unsigned_to_nat(2u);
v___x_977_ = lean_obj_once(&l_main___closed__48, &l_main___closed__48_once, _init_l_main___closed__48);
v___x_978_ = l_MachineRuntime_model;
v___x_979_ = l_FormalSpecAgent_TypedMachine_external(v___x_978_, v___x_977_, v___x_976_, v___x_975_, v___x_974_);
return v___x_979_;
}
}
static lean_object* _init_l_main___closed__52(void){
_start:
{
lean_object* v___x_980_; lean_object* v___x_981_; lean_object* v___x_982_; lean_object* v___x_983_; 
v___x_980_ = lean_obj_once(&l_main___closed__51, &l_main___closed__51_once, _init_l_main___closed__51);
v___x_981_ = lean_obj_once(&l_main___closed__48, &l_main___closed__48_once, _init_l_main___closed__48);
v___x_982_ = l_MachineRuntime_schema;
v___x_983_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_982_, v___x_981_, v___x_980_);
return v___x_983_;
}
}
static lean_object* _init_l_main___closed__53(void){
_start:
{
lean_object* v___x_984_; lean_object* v___x_985_; 
v___x_984_ = lean_obj_once(&l_main___closed__52, &l_main___closed__52_once, _init_l_main___closed__52);
v___x_985_ = l_outcomeText(v___x_984_);
return v___x_985_;
}
}
static lean_object* _init_l_main___closed__54(void){
_start:
{
lean_object* v___x_986_; lean_object* v___x_987_; lean_object* v___x_988_; 
v___x_986_ = lean_obj_once(&l_main___closed__51, &l_main___closed__51_once, _init_l_main___closed__51);
v___x_987_ = lean_obj_once(&l_main___closed__48, &l_main___closed__48_once, _init_l_main___closed__48);
v___x_988_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_987_, v___x_986_);
return v___x_988_;
}
}
static lean_object* _init_l_main___closed__55(void){
_start:
{
lean_object* v___f_989_; lean_object* v___f_990_; lean_object* v___f_991_; lean_object* v___f_992_; lean_object* v___f_993_; lean_object* v___x_994_; 
v___f_989_ = ((lean_object*)(l_main___closed__8));
v___f_990_ = ((lean_object*)(l_main___closed__3));
v___f_991_ = ((lean_object*)(l_main___closed__6));
v___f_992_ = ((lean_object*)(l_main___closed__5));
v___f_993_ = lean_obj_once(&l_main___closed__11, &l_main___closed__11_once, _init_l_main___closed__11);
v___x_994_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_994_, 0, v___f_993_);
lean_ctor_set(v___x_994_, 1, v___f_992_);
lean_ctor_set(v___x_994_, 2, v___f_991_);
lean_ctor_set(v___x_994_, 3, v___f_990_);
lean_ctor_set(v___x_994_, 4, v___f_989_);
return v___x_994_;
}
}
static lean_object* _init_l_main___closed__56(void){
_start:
{
lean_object* v___x_995_; lean_object* v___x_996_; 
v___x_995_ = lean_unsigned_to_nat(41u);
v___x_996_ = lean_nat_to_int(v___x_995_);
return v___x_996_;
}
}
static lean_object* _init_l_main___closed__57(void){
_start:
{
lean_object* v___x_997_; lean_object* v___x_998_; lean_object* v___x_999_; lean_object* v___x_1000_; lean_object* v___x_1001_; lean_object* v___x_1002_; 
v___x_997_ = lean_obj_once(&l_main___closed__56, &l_main___closed__56_once, _init_l_main___closed__56);
v___x_998_ = lean_obj_once(&l_main___closed__55, &l_main___closed__55_once, _init_l_main___closed__55);
v___x_999_ = lean_unsigned_to_nat(23u);
v___x_1000_ = lean_obj_once(&l_main___closed__54, &l_main___closed__54_once, _init_l_main___closed__54);
v___x_1001_ = l_MachineRuntime_model;
v___x_1002_ = l_FormalSpecAgent_TypedMachine_external(v___x_1001_, v___x_1000_, v___x_999_, v___x_998_, v___x_997_);
return v___x_1002_;
}
}
static lean_object* _init_l_main___closed__58(void){
_start:
{
lean_object* v___x_1003_; lean_object* v___x_1004_; lean_object* v___x_1005_; lean_object* v___x_1006_; 
v___x_1003_ = lean_obj_once(&l_main___closed__57, &l_main___closed__57_once, _init_l_main___closed__57);
v___x_1004_ = lean_obj_once(&l_main___closed__54, &l_main___closed__54_once, _init_l_main___closed__54);
v___x_1005_ = l_MachineRuntime_schema;
v___x_1006_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_1005_, v___x_1004_, v___x_1003_);
return v___x_1006_;
}
}
static lean_object* _init_l_main___closed__59(void){
_start:
{
lean_object* v___x_1007_; lean_object* v___x_1008_; 
v___x_1007_ = lean_obj_once(&l_main___closed__58, &l_main___closed__58_once, _init_l_main___closed__58);
v___x_1008_ = l_outcomeText(v___x_1007_);
return v___x_1008_;
}
}
static lean_object* _init_l_main___closed__60(void){
_start:
{
lean_object* v___x_1009_; lean_object* v___x_1010_; lean_object* v___x_1011_; 
v___x_1009_ = lean_obj_once(&l_main___closed__57, &l_main___closed__57_once, _init_l_main___closed__57);
v___x_1010_ = lean_obj_once(&l_main___closed__54, &l_main___closed__54_once, _init_l_main___closed__54);
v___x_1011_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_1010_, v___x_1009_);
return v___x_1011_;
}
}
static lean_object* _init_l_main___closed__61(void){
_start:
{
lean_object* v___x_1012_; lean_object* v___x_1013_; 
v___x_1012_ = lean_unsigned_to_nat(50u);
v___x_1013_ = lean_nat_to_int(v___x_1012_);
return v___x_1013_;
}
}
static lean_object* _init_l_main___closed__62(void){
_start:
{
lean_object* v___x_1014_; lean_object* v___x_1015_; lean_object* v___x_1016_; lean_object* v___x_1017_; lean_object* v___x_1018_; lean_object* v___x_1019_; 
v___x_1014_ = lean_obj_once(&l_main___closed__61, &l_main___closed__61_once, _init_l_main___closed__61);
v___x_1015_ = lean_obj_once(&l_main___closed__13, &l_main___closed__13_once, _init_l_main___closed__13);
v___x_1016_ = lean_unsigned_to_nat(10u);
v___x_1017_ = lean_obj_once(&l_main___closed__60, &l_main___closed__60_once, _init_l_main___closed__60);
v___x_1018_ = l_MachineRuntime_model;
v___x_1019_ = l_FormalSpecAgent_TypedMachine_external(v___x_1018_, v___x_1017_, v___x_1016_, v___x_1015_, v___x_1014_);
return v___x_1019_;
}
}
static lean_object* _init_l_main___closed__63(void){
_start:
{
lean_object* v___x_1020_; lean_object* v___x_1021_; lean_object* v___x_1022_; lean_object* v___x_1023_; 
v___x_1020_ = lean_obj_once(&l_main___closed__62, &l_main___closed__62_once, _init_l_main___closed__62);
v___x_1021_ = lean_obj_once(&l_main___closed__60, &l_main___closed__60_once, _init_l_main___closed__60);
v___x_1022_ = l_MachineRuntime_schema;
v___x_1023_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_1022_, v___x_1021_, v___x_1020_);
return v___x_1023_;
}
}
static lean_object* _init_l_main___closed__64(void){
_start:
{
lean_object* v___x_1024_; lean_object* v___x_1025_; 
v___x_1024_ = lean_obj_once(&l_main___closed__63, &l_main___closed__63_once, _init_l_main___closed__63);
v___x_1025_ = l_outcomeText(v___x_1024_);
return v___x_1025_;
}
}
LEAN_EXPORT lean_object* _lean_main(){
_start:
{
lean_object* v___x_1027_; lean_object* v___x_1028_; 
v___x_1027_ = lean_obj_once(&l_main___closed__16, &l_main___closed__16_once, _init_l_main___closed__16);
v___x_1028_ = l_IO_println___at___00main_spec__0(v___x_1027_);
if (lean_obj_tag(v___x_1028_) == 0)
{
lean_object* v___x_1029_; lean_object* v___x_1030_; 
lean_dec_ref_known(v___x_1028_, 1);
v___x_1029_ = lean_obj_once(&l_main___closed__25, &l_main___closed__25_once, _init_l_main___closed__25);
v___x_1030_ = l_IO_println___at___00main_spec__0(v___x_1029_);
if (lean_obj_tag(v___x_1030_) == 0)
{
lean_object* v___x_1031_; lean_object* v___x_1032_; 
lean_dec_ref_known(v___x_1030_, 1);
v___x_1031_ = lean_obj_once(&l_main___closed__31, &l_main___closed__31_once, _init_l_main___closed__31);
v___x_1032_ = l_IO_println___at___00main_spec__0(v___x_1031_);
if (lean_obj_tag(v___x_1032_) == 0)
{
lean_object* v___x_1033_; lean_object* v___x_1034_; 
lean_dec_ref_known(v___x_1032_, 1);
v___x_1033_ = lean_obj_once(&l_main___closed__36, &l_main___closed__36_once, _init_l_main___closed__36);
v___x_1034_ = l_IO_println___at___00main_spec__0(v___x_1033_);
if (lean_obj_tag(v___x_1034_) == 0)
{
lean_object* v___x_1035_; lean_object* v___x_1036_; 
lean_dec_ref_known(v___x_1034_, 1);
v___x_1035_ = lean_obj_once(&l_main___closed__41, &l_main___closed__41_once, _init_l_main___closed__41);
v___x_1036_ = l_IO_println___at___00main_spec__0(v___x_1035_);
if (lean_obj_tag(v___x_1036_) == 0)
{
lean_object* v___x_1037_; lean_object* v___x_1038_; 
lean_dec_ref_known(v___x_1036_, 1);
v___x_1037_ = lean_obj_once(&l_main___closed__47, &l_main___closed__47_once, _init_l_main___closed__47);
v___x_1038_ = l_IO_println___at___00main_spec__0(v___x_1037_);
if (lean_obj_tag(v___x_1038_) == 0)
{
lean_object* v___x_1039_; lean_object* v___x_1040_; 
lean_dec_ref_known(v___x_1038_, 1);
v___x_1039_ = lean_obj_once(&l_main___closed__53, &l_main___closed__53_once, _init_l_main___closed__53);
v___x_1040_ = l_IO_println___at___00main_spec__0(v___x_1039_);
if (lean_obj_tag(v___x_1040_) == 0)
{
lean_object* v___x_1041_; lean_object* v___x_1042_; 
lean_dec_ref_known(v___x_1040_, 1);
v___x_1041_ = lean_obj_once(&l_main___closed__59, &l_main___closed__59_once, _init_l_main___closed__59);
v___x_1042_ = l_IO_println___at___00main_spec__0(v___x_1041_);
if (lean_obj_tag(v___x_1042_) == 0)
{
lean_object* v___x_1043_; lean_object* v___x_1044_; 
lean_dec_ref_known(v___x_1042_, 1);
v___x_1043_ = lean_obj_once(&l_main___closed__64, &l_main___closed__64_once, _init_l_main___closed__64);
v___x_1044_ = l_IO_println___at___00main_spec__0(v___x_1043_);
if (lean_obj_tag(v___x_1044_) == 0)
{
lean_object* v___x_1046_; uint8_t v_isShared_1047_; uint8_t v_isSharedCheck_1052_; 
v_isSharedCheck_1052_ = !lean_is_exclusive(v___x_1044_);
if (v_isSharedCheck_1052_ == 0)
{
lean_object* v_unused_1053_; 
v_unused_1053_ = lean_ctor_get(v___x_1044_, 0);
lean_dec(v_unused_1053_);
v___x_1046_ = v___x_1044_;
v_isShared_1047_ = v_isSharedCheck_1052_;
goto v_resetjp_1045_;
}
else
{
lean_dec(v___x_1044_);
v___x_1046_ = lean_box(0);
v_isShared_1047_ = v_isSharedCheck_1052_;
goto v_resetjp_1045_;
}
v_resetjp_1045_:
{
lean_object* v___x_1048_; lean_object* v___x_1050_; 
v___x_1048_ = lean_box(0);
if (v_isShared_1047_ == 0)
{
lean_ctor_set(v___x_1046_, 0, v___x_1048_);
v___x_1050_ = v___x_1046_;
goto v_reusejp_1049_;
}
else
{
lean_object* v_reuseFailAlloc_1051_; 
v_reuseFailAlloc_1051_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1051_, 0, v___x_1048_);
v___x_1050_ = v_reuseFailAlloc_1051_;
goto v_reusejp_1049_;
}
v_reusejp_1049_:
{
return v___x_1050_;
}
}
}
else
{
return v___x_1044_;
}
}
else
{
return v___x_1042_;
}
}
else
{
return v___x_1040_;
}
}
else
{
return v___x_1038_;
}
}
else
{
return v___x_1036_;
}
}
else
{
return v___x_1034_;
}
}
else
{
return v___x_1032_;
}
}
else
{
return v___x_1030_;
}
}
else
{
return v___x_1028_;
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_a_1054_){
_start:
{
lean_object* v_res_1055_; 
v_res_1055_ = _lean_main();
return v_res_1055_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ModelMachine(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Runner(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ModelMachine(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_main___lam__2___closed__1___boxed__const__1 = _init_l_main___lam__2___closed__1___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__1___boxed__const__1);
l_main___lam__2___closed__2___boxed__const__1 = _init_l_main___lam__2___closed__2___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__2___boxed__const__1);
l_main___lam__2___closed__3___boxed__const__1 = _init_l_main___lam__2___closed__3___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__3___boxed__const__1);
l_main___lam__2___closed__6___boxed__const__1 = _init_l_main___lam__2___closed__6___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__6___boxed__const__1);
l_main___lam__2___closed__7___boxed__const__1 = _init_l_main___lam__2___closed__7___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__7___boxed__const__1);
l_main___lam__2___closed__8___boxed__const__1 = _init_l_main___lam__2___closed__8___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__8___boxed__const__1);
l_main___lam__2___closed__9___boxed__const__1 = _init_l_main___lam__2___closed__9___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__9___boxed__const__1);
l_main___lam__2___closed__10___boxed__const__1 = _init_l_main___lam__2___closed__10___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__10___boxed__const__1);
l_main___lam__2___closed__11___boxed__const__1 = _init_l_main___lam__2___closed__11___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__11___boxed__const__1);
l_main___lam__2___closed__15___boxed__const__1 = _init_l_main___lam__2___closed__15___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__15___boxed__const__1);
l_main___lam__2___closed__16___boxed__const__1 = _init_l_main___lam__2___closed__16___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__16___boxed__const__1);
l_main___lam__2___closed__17___boxed__const__1 = _init_l_main___lam__2___closed__17___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__17___boxed__const__1);
l_main___lam__2___closed__18___boxed__const__1 = _init_l_main___lam__2___closed__18___boxed__const__1();
lean_mark_persistent(l_main___lam__2___closed__18___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    return _lean_main();
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_Runner(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
