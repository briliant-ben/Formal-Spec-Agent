import ModelValues

open FormalSpecAgent.TypedIR

def numbers (xs : List Nat) : String :=
  "[" ++ String.intercalate "," (xs.map toString) ++ "]"

def valueText (k : Kind) (v : Value k) : String :=
  match k with
  | .integer => toString v
  | .boolean => toString v
  | .sequence => toString v.val
  | .octets => numbers (v.map Fin.val)
  | .text => numbers (v.toList.map Char.toNat)

def main : IO Unit := do
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e12 ValuesRuntime.context_0)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e14 ValuesRuntime.context_1)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e15 ValuesRuntime.context_2)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e16 ValuesRuntime.context_3)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e17 ValuesRuntime.context_4)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e18 ValuesRuntime.context_5)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e20 ValuesRuntime.context_6)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e23 ValuesRuntime.context_7)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e26 ValuesRuntime.context_8)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e27 ValuesRuntime.context_9)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e28 ValuesRuntime.context_10)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e29 ValuesRuntime.context_11)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e33 ValuesRuntime.context_12)) ++ "}")
  IO.println ("{\"kind\":\"seq32\",\"value\":" ++ (valueText .sequence (eval ValuesRuntime.e35 ValuesRuntime.context_13)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e36 ValuesRuntime.context_14)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e37 ValuesRuntime.context_15)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e38 ValuesRuntime.context_16)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e39 ValuesRuntime.context_17)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e40 ValuesRuntime.context_18)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e32 ValuesRuntime.context_19)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e43 ValuesRuntime.context_20)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e44 ValuesRuntime.context_21)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e45 ValuesRuntime.context_22)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e46 ValuesRuntime.context_23)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e47 ValuesRuntime.context_24)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e48 ValuesRuntime.context_25)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e49 ValuesRuntime.context_26)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e50 ValuesRuntime.context_27)) ++ "}")
  IO.println ("{\"kind\":\"string\",\"value\":" ++ (valueText .text (eval ValuesRuntime.e52 ValuesRuntime.context_28)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e43 ValuesRuntime.context_29)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e43 ValuesRuntime.context_30)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e44 ValuesRuntime.context_31)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e44 ValuesRuntime.context_32)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e33 ValuesRuntime.context_33)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e27 ValuesRuntime.context_34)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e29 ValuesRuntime.context_35)) ++ "}")
  IO.println ("{\"kind\":\"seq32\",\"value\":" ++ (valueText .sequence (eval ValuesRuntime.e35 ValuesRuntime.context_36)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e36 ValuesRuntime.context_37)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e37 ValuesRuntime.context_38)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e38 ValuesRuntime.context_39)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e39 ValuesRuntime.context_40)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e37 ValuesRuntime.context_41)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e38 ValuesRuntime.context_42)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e39 ValuesRuntime.context_43)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e48 ValuesRuntime.context_44)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e48 ValuesRuntime.context_45)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e48 ValuesRuntime.context_46)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e48 ValuesRuntime.context_47)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e48 ValuesRuntime.context_48)) ++ "}")
  IO.println ("{\"kind\":\"string\",\"value\":" ++ (valueText .text (eval ValuesRuntime.e52 ValuesRuntime.context_49)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e50 ValuesRuntime.context_50)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e49 ValuesRuntime.context_51)) ++ "}")
  IO.println ("{\"kind\":\"bool\",\"value\":" ++ (valueText .boolean (eval ValuesRuntime.e20 ValuesRuntime.context_52)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e48 ValuesRuntime.context_53)) ++ "}")
  IO.println ("{\"kind\":\"int\",\"value\":" ++ (valueText .integer (eval ValuesRuntime.e40 ValuesRuntime.context_54)) ++ "}")
  IO.println ("{\"kind\":\"bytes\",\"value\":" ++ (valueText .octets (eval ValuesRuntime.e32 ValuesRuntime.context_55)) ++ "}")
