import Approved

set_option maxRecDepth 16384

namespace Proofs

theorem checksum_range : Approved.checksum_range := by
  unfold Approved.checksum_range
  intro data
  exact FormalSpecAgent.ValueOps.checksum_range data

theorem sequence_distance_range : Approved.sequence_distance_range := by
  unfold Approved.sequence_distance_range
  intro a b
  unfold FormalSpecAgent.ValueOps.seqDistance
  omega

theorem half_space_unordered : Approved.half_space_unordered := by
  unfold Approved.half_space_unordered
  intro a b h
  simp_all [FormalSpecAgent.ValueOps.seqComparable, FormalSpecAgent.ValueOps.seqLt, FormalSpecAgent.ValueOps.seqLe]

theorem witness_0 : Approved.witness_0 := by
  unfold Approved.witness_0
  decide

theorem witness_1 : Approved.witness_1 := by
  unfold Approved.witness_1
  decide

theorem witness_2 : Approved.witness_2 := by
  unfold Approved.witness_2
  decide

theorem witness_3 : Approved.witness_3 := by
  unfold Approved.witness_3
  decide

theorem witness_4 : Approved.witness_4 := by
  unfold Approved.witness_4
  decide

theorem witness_5 : Approved.witness_5 := by
  unfold Approved.witness_5
  decide

theorem witness_6 : Approved.witness_6 := by
  unfold Approved.witness_6
  decide

theorem witness_7 : Approved.witness_7 := by
  unfold Approved.witness_7
  decide

theorem witness_8 : Approved.witness_8 := by
  unfold Approved.witness_8
  decide

theorem witness_9 : Approved.witness_9 := by
  unfold Approved.witness_9
  decide

theorem witness_10 : Approved.witness_10 := by
  unfold Approved.witness_10
  decide

theorem witness_11 : Approved.witness_11 := by
  unfold Approved.witness_11
  decide

theorem witness_12 : Approved.witness_12 := by
  unfold Approved.witness_12
  decide

theorem witness_13 : Approved.witness_13 := by
  unfold Approved.witness_13
  decide

theorem witness_14 : Approved.witness_14 := by
  unfold Approved.witness_14
  decide

theorem witness_15 : Approved.witness_15 := by
  unfold Approved.witness_15
  decide

theorem witness_16 : Approved.witness_16 := by
  unfold Approved.witness_16
  decide

theorem witness_17 : Approved.witness_17 := by
  unfold Approved.witness_17
  decide

theorem witness_18 : Approved.witness_18 := by
  unfold Approved.witness_18
  decide

theorem witness_19 : Approved.witness_19 := by
  unfold Approved.witness_19
  decide

theorem witness_20 : Approved.witness_20 := by
  unfold Approved.witness_20
  decide

theorem witness_21 : Approved.witness_21 := by
  unfold Approved.witness_21
  decide

theorem witness_22 : Approved.witness_22 := by
  unfold Approved.witness_22
  decide

theorem witness_23 : Approved.witness_23 := by
  unfold Approved.witness_23
  decide

theorem witness_24 : Approved.witness_24 := by
  unfold Approved.witness_24
  decide

theorem witness_25 : Approved.witness_25 := by
  unfold Approved.witness_25
  dsimp [Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, Approved.e40, Approved.e41, Approved.e42, Approved.e43, Approved.e44, Approved.e45, Approved.e46, Approved.e47, Approved.e48, Approved.e49, Approved.e50, Approved.e51, Approved.e52, Approved.e53, Approved.e54, Approved.e55, Approved.e56, Approved.e57, Approved.e58, Approved.e59, Approved.e60, Approved.e61, Approved.e62, Approved.e63, Approved.e64, Approved.e65, Approved.e66, Approved.e67, Approved.e68, Approved.e69, Approved.e70, Approved.e71, Approved.e72, Approved.e73, Approved.e74, Approved.e75, Approved.e76, Approved.e77, Approved.e78, Approved.e79, Approved.e80, Approved.e81, Approved.context_0, Approved.context_1, Approved.context_2, Approved.context_3, Approved.context_4, Approved.context_5, Approved.context_6, Approved.context_7, Approved.context_8, Approved.context_9, Approved.context_10, Approved.context_11, Approved.context_12, Approved.context_13, Approved.context_14, Approved.context_15, Approved.context_16, Approved.context_17, Approved.context_18, Approved.context_19, Approved.context_20, Approved.context_21, Approved.context_22, Approved.context_23, Approved.context_24, Approved.context_25, Approved.context_26, Approved.context_27, Approved.context_28, Approved.context_29, Approved.context_30, Approved.context_31, Approved.context_32, Approved.context_33, Approved.context_34, Approved.context_35, Approved.context_36, Approved.context_37, Approved.context_38, Approved.context_39, Approved.context_40, Approved.context_41, Approved.context_42, Approved.context_43, Approved.context_44, Approved.context_45, Approved.context_46, Approved.context_47, Approved.context_48, Approved.context_49, Approved.context_50, Approved.context_51, Approved.context_52, Approved.context_53, Approved.context_54, Approved.context_55, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.checksum, FormalSpecAgent.ValueOps.wordSum]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  all_goals
    decide

theorem witness_26 : Approved.witness_26 := by
  unfold Approved.witness_26
  decide

theorem witness_27 : Approved.witness_27 := by
  unfold Approved.witness_27
  decide

theorem witness_28 : Approved.witness_28 := by
  unfold Approved.witness_28
  decide

theorem witness_29 : Approved.witness_29 := by
  unfold Approved.witness_29
  decide

theorem witness_30 : Approved.witness_30 := by
  unfold Approved.witness_30
  decide

theorem witness_31 : Approved.witness_31 := by
  unfold Approved.witness_31
  decide

theorem witness_32 : Approved.witness_32 := by
  unfold Approved.witness_32
  decide

theorem witness_33 : Approved.witness_33 := by
  unfold Approved.witness_33
  decide

theorem witness_34 : Approved.witness_34 := by
  unfold Approved.witness_34
  decide

theorem witness_35 : Approved.witness_35 := by
  unfold Approved.witness_35
  decide

theorem witness_36 : Approved.witness_36 := by
  unfold Approved.witness_36
  decide

theorem witness_37 : Approved.witness_37 := by
  unfold Approved.witness_37
  decide

theorem witness_38 : Approved.witness_38 := by
  unfold Approved.witness_38
  decide

theorem witness_39 : Approved.witness_39 := by
  unfold Approved.witness_39
  decide

theorem witness_40 : Approved.witness_40 := by
  unfold Approved.witness_40
  decide

theorem witness_41 : Approved.witness_41 := by
  unfold Approved.witness_41
  decide

theorem witness_42 : Approved.witness_42 := by
  unfold Approved.witness_42
  decide

theorem witness_43 : Approved.witness_43 := by
  unfold Approved.witness_43
  decide

theorem witness_44 : Approved.witness_44 := by
  unfold Approved.witness_44
  dsimp [Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, Approved.e40, Approved.e41, Approved.e42, Approved.e43, Approved.e44, Approved.e45, Approved.e46, Approved.e47, Approved.e48, Approved.e49, Approved.e50, Approved.e51, Approved.e52, Approved.e53, Approved.e54, Approved.e55, Approved.e56, Approved.e57, Approved.e58, Approved.e59, Approved.e60, Approved.e61, Approved.e62, Approved.e63, Approved.e64, Approved.e65, Approved.e66, Approved.e67, Approved.e68, Approved.e69, Approved.e70, Approved.e71, Approved.e72, Approved.e73, Approved.e74, Approved.e75, Approved.e76, Approved.e77, Approved.e78, Approved.e79, Approved.e80, Approved.e81, Approved.context_0, Approved.context_1, Approved.context_2, Approved.context_3, Approved.context_4, Approved.context_5, Approved.context_6, Approved.context_7, Approved.context_8, Approved.context_9, Approved.context_10, Approved.context_11, Approved.context_12, Approved.context_13, Approved.context_14, Approved.context_15, Approved.context_16, Approved.context_17, Approved.context_18, Approved.context_19, Approved.context_20, Approved.context_21, Approved.context_22, Approved.context_23, Approved.context_24, Approved.context_25, Approved.context_26, Approved.context_27, Approved.context_28, Approved.context_29, Approved.context_30, Approved.context_31, Approved.context_32, Approved.context_33, Approved.context_34, Approved.context_35, Approved.context_36, Approved.context_37, Approved.context_38, Approved.context_39, Approved.context_40, Approved.context_41, Approved.context_42, Approved.context_43, Approved.context_44, Approved.context_45, Approved.context_46, Approved.context_47, Approved.context_48, Approved.context_49, Approved.context_50, Approved.context_51, Approved.context_52, Approved.context_53, Approved.context_54, Approved.context_55, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.checksum, FormalSpecAgent.ValueOps.wordSum]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  all_goals
    decide

theorem witness_45 : Approved.witness_45 := by
  unfold Approved.witness_45
  dsimp [Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, Approved.e40, Approved.e41, Approved.e42, Approved.e43, Approved.e44, Approved.e45, Approved.e46, Approved.e47, Approved.e48, Approved.e49, Approved.e50, Approved.e51, Approved.e52, Approved.e53, Approved.e54, Approved.e55, Approved.e56, Approved.e57, Approved.e58, Approved.e59, Approved.e60, Approved.e61, Approved.e62, Approved.e63, Approved.e64, Approved.e65, Approved.e66, Approved.e67, Approved.e68, Approved.e69, Approved.e70, Approved.e71, Approved.e72, Approved.e73, Approved.e74, Approved.e75, Approved.e76, Approved.e77, Approved.e78, Approved.e79, Approved.e80, Approved.e81, Approved.context_0, Approved.context_1, Approved.context_2, Approved.context_3, Approved.context_4, Approved.context_5, Approved.context_6, Approved.context_7, Approved.context_8, Approved.context_9, Approved.context_10, Approved.context_11, Approved.context_12, Approved.context_13, Approved.context_14, Approved.context_15, Approved.context_16, Approved.context_17, Approved.context_18, Approved.context_19, Approved.context_20, Approved.context_21, Approved.context_22, Approved.context_23, Approved.context_24, Approved.context_25, Approved.context_26, Approved.context_27, Approved.context_28, Approved.context_29, Approved.context_30, Approved.context_31, Approved.context_32, Approved.context_33, Approved.context_34, Approved.context_35, Approved.context_36, Approved.context_37, Approved.context_38, Approved.context_39, Approved.context_40, Approved.context_41, Approved.context_42, Approved.context_43, Approved.context_44, Approved.context_45, Approved.context_46, Approved.context_47, Approved.context_48, Approved.context_49, Approved.context_50, Approved.context_51, Approved.context_52, Approved.context_53, Approved.context_54, Approved.context_55, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.checksum, FormalSpecAgent.ValueOps.wordSum]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  all_goals
    decide

theorem witness_46 : Approved.witness_46 := by
  unfold Approved.witness_46
  dsimp [Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, Approved.e40, Approved.e41, Approved.e42, Approved.e43, Approved.e44, Approved.e45, Approved.e46, Approved.e47, Approved.e48, Approved.e49, Approved.e50, Approved.e51, Approved.e52, Approved.e53, Approved.e54, Approved.e55, Approved.e56, Approved.e57, Approved.e58, Approved.e59, Approved.e60, Approved.e61, Approved.e62, Approved.e63, Approved.e64, Approved.e65, Approved.e66, Approved.e67, Approved.e68, Approved.e69, Approved.e70, Approved.e71, Approved.e72, Approved.e73, Approved.e74, Approved.e75, Approved.e76, Approved.e77, Approved.e78, Approved.e79, Approved.e80, Approved.e81, Approved.context_0, Approved.context_1, Approved.context_2, Approved.context_3, Approved.context_4, Approved.context_5, Approved.context_6, Approved.context_7, Approved.context_8, Approved.context_9, Approved.context_10, Approved.context_11, Approved.context_12, Approved.context_13, Approved.context_14, Approved.context_15, Approved.context_16, Approved.context_17, Approved.context_18, Approved.context_19, Approved.context_20, Approved.context_21, Approved.context_22, Approved.context_23, Approved.context_24, Approved.context_25, Approved.context_26, Approved.context_27, Approved.context_28, Approved.context_29, Approved.context_30, Approved.context_31, Approved.context_32, Approved.context_33, Approved.context_34, Approved.context_35, Approved.context_36, Approved.context_37, Approved.context_38, Approved.context_39, Approved.context_40, Approved.context_41, Approved.context_42, Approved.context_43, Approved.context_44, Approved.context_45, Approved.context_46, Approved.context_47, Approved.context_48, Approved.context_49, Approved.context_50, Approved.context_51, Approved.context_52, Approved.context_53, Approved.context_54, Approved.context_55, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.checksum, FormalSpecAgent.ValueOps.wordSum]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  all_goals
    decide

theorem witness_47 : Approved.witness_47 := by
  unfold Approved.witness_47
  dsimp [Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, Approved.e40, Approved.e41, Approved.e42, Approved.e43, Approved.e44, Approved.e45, Approved.e46, Approved.e47, Approved.e48, Approved.e49, Approved.e50, Approved.e51, Approved.e52, Approved.e53, Approved.e54, Approved.e55, Approved.e56, Approved.e57, Approved.e58, Approved.e59, Approved.e60, Approved.e61, Approved.e62, Approved.e63, Approved.e64, Approved.e65, Approved.e66, Approved.e67, Approved.e68, Approved.e69, Approved.e70, Approved.e71, Approved.e72, Approved.e73, Approved.e74, Approved.e75, Approved.e76, Approved.e77, Approved.e78, Approved.e79, Approved.e80, Approved.e81, Approved.context_0, Approved.context_1, Approved.context_2, Approved.context_3, Approved.context_4, Approved.context_5, Approved.context_6, Approved.context_7, Approved.context_8, Approved.context_9, Approved.context_10, Approved.context_11, Approved.context_12, Approved.context_13, Approved.context_14, Approved.context_15, Approved.context_16, Approved.context_17, Approved.context_18, Approved.context_19, Approved.context_20, Approved.context_21, Approved.context_22, Approved.context_23, Approved.context_24, Approved.context_25, Approved.context_26, Approved.context_27, Approved.context_28, Approved.context_29, Approved.context_30, Approved.context_31, Approved.context_32, Approved.context_33, Approved.context_34, Approved.context_35, Approved.context_36, Approved.context_37, Approved.context_38, Approved.context_39, Approved.context_40, Approved.context_41, Approved.context_42, Approved.context_43, Approved.context_44, Approved.context_45, Approved.context_46, Approved.context_47, Approved.context_48, Approved.context_49, Approved.context_50, Approved.context_51, Approved.context_52, Approved.context_53, Approved.context_54, Approved.context_55, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.checksum, FormalSpecAgent.ValueOps.wordSum]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  all_goals
    decide

theorem witness_48 : Approved.witness_48 := by
  unfold Approved.witness_48
  dsimp [Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, Approved.e40, Approved.e41, Approved.e42, Approved.e43, Approved.e44, Approved.e45, Approved.e46, Approved.e47, Approved.e48, Approved.e49, Approved.e50, Approved.e51, Approved.e52, Approved.e53, Approved.e54, Approved.e55, Approved.e56, Approved.e57, Approved.e58, Approved.e59, Approved.e60, Approved.e61, Approved.e62, Approved.e63, Approved.e64, Approved.e65, Approved.e66, Approved.e67, Approved.e68, Approved.e69, Approved.e70, Approved.e71, Approved.e72, Approved.e73, Approved.e74, Approved.e75, Approved.e76, Approved.e77, Approved.e78, Approved.e79, Approved.e80, Approved.e81, Approved.context_0, Approved.context_1, Approved.context_2, Approved.context_3, Approved.context_4, Approved.context_5, Approved.context_6, Approved.context_7, Approved.context_8, Approved.context_9, Approved.context_10, Approved.context_11, Approved.context_12, Approved.context_13, Approved.context_14, Approved.context_15, Approved.context_16, Approved.context_17, Approved.context_18, Approved.context_19, Approved.context_20, Approved.context_21, Approved.context_22, Approved.context_23, Approved.context_24, Approved.context_25, Approved.context_26, Approved.context_27, Approved.context_28, Approved.context_29, Approved.context_30, Approved.context_31, Approved.context_32, Approved.context_33, Approved.context_34, Approved.context_35, Approved.context_36, Approved.context_37, Approved.context_38, Approved.context_39, Approved.context_40, Approved.context_41, Approved.context_42, Approved.context_43, Approved.context_44, Approved.context_45, Approved.context_46, Approved.context_47, Approved.context_48, Approved.context_49, Approved.context_50, Approved.context_51, Approved.context_52, Approved.context_53, Approved.context_54, Approved.context_55, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.checksum, FormalSpecAgent.ValueOps.wordSum]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  all_goals
    decide

theorem witness_49 : Approved.witness_49 := by
  unfold Approved.witness_49
  decide

theorem witness_50 : Approved.witness_50 := by
  unfold Approved.witness_50
  decide

theorem witness_51 : Approved.witness_51 := by
  unfold Approved.witness_51
  decide

theorem witness_52 : Approved.witness_52 := by
  unfold Approved.witness_52
  decide

theorem witness_53 : Approved.witness_53 := by
  unfold Approved.witness_53
  dsimp [Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.e27, Approved.e28, Approved.e29, Approved.e30, Approved.e31, Approved.e32, Approved.e33, Approved.e34, Approved.e35, Approved.e36, Approved.e37, Approved.e38, Approved.e39, Approved.e40, Approved.e41, Approved.e42, Approved.e43, Approved.e44, Approved.e45, Approved.e46, Approved.e47, Approved.e48, Approved.e49, Approved.e50, Approved.e51, Approved.e52, Approved.e53, Approved.e54, Approved.e55, Approved.e56, Approved.e57, Approved.e58, Approved.e59, Approved.e60, Approved.e61, Approved.e62, Approved.e63, Approved.e64, Approved.e65, Approved.e66, Approved.e67, Approved.e68, Approved.e69, Approved.e70, Approved.e71, Approved.e72, Approved.e73, Approved.e74, Approved.e75, Approved.e76, Approved.e77, Approved.e78, Approved.e79, Approved.e80, Approved.e81, Approved.context_0, Approved.context_1, Approved.context_2, Approved.context_3, Approved.context_4, Approved.context_5, Approved.context_6, Approved.context_7, Approved.context_8, Approved.context_9, Approved.context_10, Approved.context_11, Approved.context_12, Approved.context_13, Approved.context_14, Approved.context_15, Approved.context_16, Approved.context_17, Approved.context_18, Approved.context_19, Approved.context_20, Approved.context_21, Approved.context_22, Approved.context_23, Approved.context_24, Approved.context_25, Approved.context_26, Approved.context_27, Approved.context_28, Approved.context_29, Approved.context_30, Approved.context_31, Approved.context_32, Approved.context_33, Approved.context_34, Approved.context_35, Approved.context_36, Approved.context_37, Approved.context_38, Approved.context_39, Approved.context_40, Approved.context_41, Approved.context_42, Approved.context_43, Approved.context_44, Approved.context_45, Approved.context_46, Approved.context_47, Approved.context_48, Approved.context_49, Approved.context_50, Approved.context_51, Approved.context_52, Approved.context_53, Approved.context_54, Approved.context_55, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.ValueOps.checksum, FormalSpecAgent.ValueOps.wordSum]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  try
    rw [FormalSpecAgent.ValueOps.fold16]
  all_goals
    decide

theorem witness_54 : Approved.witness_54 := by
  unfold Approved.witness_54
  decide

theorem witness_55 : Approved.witness_55 := by
  unfold Approved.witness_55
  decide

end Proofs
