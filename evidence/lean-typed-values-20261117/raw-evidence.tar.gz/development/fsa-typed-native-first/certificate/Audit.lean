import Proofs

example : Approved.checksum_range := Proofs.checksum_range
#print axioms Proofs.checksum_range
example : Approved.sequence_distance_range := Proofs.sequence_distance_range
#print axioms Proofs.sequence_distance_range
example : Approved.half_space_unordered := Proofs.half_space_unordered
#print axioms Proofs.half_space_unordered
example : Approved.witness_0 := Proofs.witness_0
#print axioms Proofs.witness_0
example : Approved.witness_1 := Proofs.witness_1
#print axioms Proofs.witness_1
example : Approved.witness_2 := Proofs.witness_2
#print axioms Proofs.witness_2
example : Approved.witness_3 := Proofs.witness_3
#print axioms Proofs.witness_3
example : Approved.witness_4 := Proofs.witness_4
#print axioms Proofs.witness_4
example : Approved.witness_5 := Proofs.witness_5
#print axioms Proofs.witness_5
example : Approved.witness_6 := Proofs.witness_6
#print axioms Proofs.witness_6
example : Approved.witness_7 := Proofs.witness_7
#print axioms Proofs.witness_7
example : Approved.witness_8 := Proofs.witness_8
#print axioms Proofs.witness_8
example : Approved.witness_9 := Proofs.witness_9
#print axioms Proofs.witness_9
example : Approved.witness_10 := Proofs.witness_10
#print axioms Proofs.witness_10
example : Approved.witness_11 := Proofs.witness_11
#print axioms Proofs.witness_11
example : Approved.witness_12 := Proofs.witness_12
#print axioms Proofs.witness_12
example : Approved.witness_13 := Proofs.witness_13
#print axioms Proofs.witness_13
example : Approved.witness_14 := Proofs.witness_14
#print axioms Proofs.witness_14
example : Approved.witness_15 := Proofs.witness_15
#print axioms Proofs.witness_15
example : Approved.witness_16 := Proofs.witness_16
#print axioms Proofs.witness_16
example : Approved.witness_17 := Proofs.witness_17
#print axioms Proofs.witness_17
example : Approved.witness_18 := Proofs.witness_18
#print axioms Proofs.witness_18
example : Approved.witness_19 := Proofs.witness_19
#print axioms Proofs.witness_19
example : Approved.witness_20 := Proofs.witness_20
#print axioms Proofs.witness_20
example : Approved.witness_21 := Proofs.witness_21
#print axioms Proofs.witness_21
example : Approved.witness_22 := Proofs.witness_22
#print axioms Proofs.witness_22
example : Approved.witness_23 := Proofs.witness_23
#print axioms Proofs.witness_23
example : Approved.witness_24 := Proofs.witness_24
#print axioms Proofs.witness_24
example : Approved.witness_25 := Proofs.witness_25
#print axioms Proofs.witness_25
example : Approved.witness_26 := Proofs.witness_26
#print axioms Proofs.witness_26
example : Approved.witness_27 := Proofs.witness_27
#print axioms Proofs.witness_27
example : Approved.witness_28 := Proofs.witness_28
#print axioms Proofs.witness_28
example : Approved.witness_29 := Proofs.witness_29
#print axioms Proofs.witness_29
example : Approved.witness_30 := Proofs.witness_30
#print axioms Proofs.witness_30
example : Approved.witness_31 := Proofs.witness_31
#print axioms Proofs.witness_31
example : Approved.witness_32 := Proofs.witness_32
#print axioms Proofs.witness_32
example : Approved.witness_33 := Proofs.witness_33
#print axioms Proofs.witness_33
example : Approved.witness_34 := Proofs.witness_34
#print axioms Proofs.witness_34
example : Approved.witness_35 := Proofs.witness_35
#print axioms Proofs.witness_35
example : Approved.witness_36 := Proofs.witness_36
#print axioms Proofs.witness_36
example : Approved.witness_37 := Proofs.witness_37
#print axioms Proofs.witness_37
example : Approved.witness_38 := Proofs.witness_38
#print axioms Proofs.witness_38
example : Approved.witness_39 := Proofs.witness_39
#print axioms Proofs.witness_39
example : Approved.witness_40 := Proofs.witness_40
#print axioms Proofs.witness_40
example : Approved.witness_41 := Proofs.witness_41
#print axioms Proofs.witness_41
example : Approved.witness_42 := Proofs.witness_42
#print axioms Proofs.witness_42
example : Approved.witness_43 := Proofs.witness_43
#print axioms Proofs.witness_43
example : Approved.witness_44 := Proofs.witness_44
#print axioms Proofs.witness_44
example : Approved.witness_45 := Proofs.witness_45
#print axioms Proofs.witness_45
example : Approved.witness_46 := Proofs.witness_46
#print axioms Proofs.witness_46
example : Approved.witness_47 := Proofs.witness_47
#print axioms Proofs.witness_47
example : Approved.witness_48 := Proofs.witness_48
#print axioms Proofs.witness_48
example : Approved.witness_49 := Proofs.witness_49
#print axioms Proofs.witness_49
example : Approved.witness_50 := Proofs.witness_50
#print axioms Proofs.witness_50
example : Approved.witness_51 := Proofs.witness_51
#print axioms Proofs.witness_51
example : Approved.witness_52 := Proofs.witness_52
#print axioms Proofs.witness_52
