import TypedIR

set_option maxRecDepth 16384

namespace Approved

def e0 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (-257)

def e1 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean true

def e2 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68])

def e3 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes)

def e4 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e5 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (0)

def e6 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean false

def e7 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([] : FormalSpecAgent.Bytes)

def e8 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e9 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [])

def e10 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 0

def e11 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (5)

def e12 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.add e10 e11

def e13 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (-3)

def e14 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.mul e10 e13

def e15 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.sub e10 e11

def e16 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.minimum e10 e11

def e17 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e10 e11

def e18 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e10 e11

def e19 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.variable .text 2

def e20 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.equal .text e19 e2

def e21 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.variable .sequence 4

def e22 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.field .sequence 4

def e23 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.notEqual .sequence e21 e22

def e24 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 1

def e25 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.field .boolean 5

def e26 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolAnd e24 e25

def e27 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolOr e24 e25

def e28 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolNot e24

def e29 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.implies e24 e25

def e30 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 3

def e31 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.field .octets 3

def e32 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.concat e30 e31

def e33 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.choose .octets e25 e32 e7

def e34 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 2

def e35 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.seqAdd e21 e34

def e36 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.seqDistance e21 e22

def e37 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.seqComparable e21 e22

def e38 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.seqLt e21 e22

def e39 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.seqLe e21 e22

def e40 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e30

def e41 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 0

def e42 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 1

def e43 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.slice e30 e41 e42

def e44 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.byteAt e30 e41

def e45 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.pack8 e10

def e46 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.pack16 e10

def e47 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.pack32 e10

def e48 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.checksum e31

def e49 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.stateIs 0

def e50 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.timerActive 0

def e51 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 79, Char.ofNat 84, Char.ofNat 72, Char.ofNat 69, Char.ofNat 82])

def e52 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.choose .text e25 e19 e51

def e53 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 5

def e54 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 6

def e55 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 7

def e56 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 8

def e57 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 9

def e58 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 10

def e59 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 11

def e60 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 12

def e61 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 13

def e62 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 14

def e63 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 15

def e64 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 16

def e65 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 17

def e66 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.variable .sequence 18

def e67 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 19

def e68 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 20

def e69 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 21

def e70 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 22

def e71 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 23

def e72 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 24

def e73 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 25

def e74 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 26

def e75 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 27

def e76 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 28

def e77 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 29

def e78 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 30

def e79 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 31

def e80 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 32

def e81 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.variable .text 33

def context_0 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_1 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_2 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_3 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_4 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_5 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_6 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_7 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_8 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_9 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_10 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_11 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_12 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_13 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_14 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_15 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_16 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_17 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_18 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_19 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_20 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_21 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_22 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_23 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_24 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_25 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_26 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_27 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_28 : FormalSpecAgent.TypedIR.Context :=
  context_0

def context_29 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (-1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_30 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (-1) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_31 : FormalSpecAgent.TypedIR.Context :=
  context_29

def context_32 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (4) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_33 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then false else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_34 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then false else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_35 : FormalSpecAgent.TypedIR.Context :=
  context_33

def context_36 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (-4294967297) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_37 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_38 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨2147483648, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_39 : FormalSpecAgent.TypedIR.Context :=
  context_38

def context_40 : FormalSpecAgent.TypedIR.Context :=
  context_38

def context_41 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_42 : FormalSpecAgent.TypedIR.Context :=
  context_41

def context_43 : FormalSpecAgent.TypedIR.Context :=
  context_41

def context_44 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_45 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨255, by decide⟩, ⟨255, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_46 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨128, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_47 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨255, by decide⟩, ⟨255, by decide⟩, ⟨0, by decide⟩, ⟨1, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_48 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨1, by decide⟩, ⟨242, by decide⟩, ⟨3, by decide⟩, ⟨244, by decide⟩, ⟨245, by decide⟩, ⟨246, by decide⟩, ⟨247, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_49 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_50 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, activeTimers := [0] } : FormalSpecAgent.TypedIR.Context)

def context_51 : FormalSpecAgent.TypedIR.Context :=
  ({ store := ({ integers := fun n => if n = 0 then (-257) else if n = 5 then (0) else if n = 6 then (0) else if n = 7 then (0) else if n = 8 then (0) else if n = 19 then (0) else if n = 23 then (0) else if n = 26 then (0) else if n = 30 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 9 then false else if n = 10 then false else if n = 11 then false else if n = 12 then false else if n = 13 then false else if n = 14 then false else if n = 15 then false else if n = 16 then false else if n = 20 then false else if n = 21 then false else if n = 22 then false else if n = 31 then false else if n = 32 then false else false, texts := fun n => if n = 2 then (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68]) else if n = 33 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩] : FormalSpecAgent.Bytes) else if n = 17 then ([] : FormalSpecAgent.Bytes) else if n = 24 then ([] : FormalSpecAgent.Bytes) else if n = 25 then ([] : FormalSpecAgent.Bytes) else if n = 27 then ([] : FormalSpecAgent.Bytes) else if n = 28 then ([] : FormalSpecAgent.Bytes) else if n = 29 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else if n = 18 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), fields := ({ integers := fun n => if n = 0 then (1) else if n = 1 then (2) else if n = 2 then (1) else (0), booleans := fun n => if n = 5 then true else false, texts := fun n => (String.ofList []), buffers := fun n => if n = 3 then ([⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 4 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, activeTimers := [] } : FormalSpecAgent.TypedIR.Context)

def context_52 : FormalSpecAgent.TypedIR.Context :=
  context_49

def checksum_range : Prop :=
  ∀ (data : FormalSpecAgent.Bytes), 0 ≤ FormalSpecAgent.ValueOps.checksum data ∧ FormalSpecAgent.ValueOps.checksum data ≤ 65535

def sequence_distance_range : Prop :=
  ∀ (a b : FormalSpecAgent.ValueOps.Seq32), 0 ≤ FormalSpecAgent.ValueOps.seqDistance a b ∧ FormalSpecAgent.ValueOps.seqDistance a b < 4294967296

def half_space_unordered : Prop :=
  ∀ (a b : FormalSpecAgent.ValueOps.Seq32), FormalSpecAgent.ValueOps.seqDistance a b = 2147483648 → FormalSpecAgent.ValueOps.seqComparable a b = false ∧ FormalSpecAgent.ValueOps.seqLt a b = false ∧ FormalSpecAgent.ValueOps.seqLe a b = false

def witness_0 : Prop :=
  FormalSpecAgent.TypedIR.eval e12 context_0 = (-252)

def witness_1 : Prop :=
  FormalSpecAgent.TypedIR.eval e14 context_1 = (771)

def witness_2 : Prop :=
  FormalSpecAgent.TypedIR.eval e15 context_2 = (-262)

def witness_3 : Prop :=
  FormalSpecAgent.TypedIR.eval e16 context_3 = (-257)

def witness_4 : Prop :=
  FormalSpecAgent.TypedIR.eval e17 context_4 = true

def witness_5 : Prop :=
  FormalSpecAgent.TypedIR.eval e18 context_5 = false

def witness_6 : Prop :=
  FormalSpecAgent.TypedIR.eval e20 context_6 = true

def witness_7 : Prop :=
  FormalSpecAgent.TypedIR.eval e23 context_7 = true

def witness_8 : Prop :=
  FormalSpecAgent.TypedIR.eval e26 context_8 = true

def witness_9 : Prop :=
  FormalSpecAgent.TypedIR.eval e27 context_9 = true

def witness_10 : Prop :=
  FormalSpecAgent.TypedIR.eval e28 context_10 = false

def witness_11 : Prop :=
  FormalSpecAgent.TypedIR.eval e29 context_11 = true

def witness_12 : Prop :=
  FormalSpecAgent.TypedIR.eval e33 context_12 = ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩, ⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes)

def witness_13 : Prop :=
  FormalSpecAgent.TypedIR.eval e35 context_13 = (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def witness_14 : Prop :=
  FormalSpecAgent.TypedIR.eval e36 context_14 = (1)

def witness_15 : Prop :=
  FormalSpecAgent.TypedIR.eval e37 context_15 = true

def witness_16 : Prop :=
  FormalSpecAgent.TypedIR.eval e38 context_16 = true

def witness_17 : Prop :=
  FormalSpecAgent.TypedIR.eval e39 context_17 = true

def witness_18 : Prop :=
  FormalSpecAgent.TypedIR.eval e40 context_18 = (4)

def witness_19 : Prop :=
  FormalSpecAgent.TypedIR.eval e32 context_19 = ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨4, by decide⟩, ⟨1, by decide⟩, ⟨2, by decide⟩] : FormalSpecAgent.Bytes)

def witness_20 : Prop :=
  FormalSpecAgent.TypedIR.eval e43 context_20 = ([⟨128, by decide⟩, ⟨255, by decide⟩] : FormalSpecAgent.Bytes)

def witness_21 : Prop :=
  FormalSpecAgent.TypedIR.eval e44 context_21 = (128)

def witness_22 : Prop :=
  FormalSpecAgent.TypedIR.eval e45 context_22 = ([⟨255, by decide⟩] : FormalSpecAgent.Bytes)

def witness_23 : Prop :=
  FormalSpecAgent.TypedIR.eval e46 context_23 = ([⟨254, by decide⟩, ⟨255, by decide⟩] : FormalSpecAgent.Bytes)

def witness_24 : Prop :=
  FormalSpecAgent.TypedIR.eval e47 context_24 = ([⟨255, by decide⟩, ⟨255, by decide⟩, ⟨254, by decide⟩, ⟨255, by decide⟩] : FormalSpecAgent.Bytes)

def witness_25 : Prop :=
  FormalSpecAgent.TypedIR.eval e48 context_25 = (65277)

def witness_26 : Prop :=
  FormalSpecAgent.TypedIR.eval e49 context_26 = true

def witness_27 : Prop :=
  FormalSpecAgent.TypedIR.eval e50 context_27 = false

def witness_28 : Prop :=
  FormalSpecAgent.TypedIR.eval e52 context_28 = (String.ofList [Char.ofNat 67, Char.ofNat 76, Char.ofNat 79, Char.ofNat 83, Char.ofNat 69, Char.ofNat 68])

def witness_29 : Prop :=
  FormalSpecAgent.TypedIR.eval e43 context_29 = ([⟨0, by decide⟩, ⟨128, by decide⟩] : FormalSpecAgent.Bytes)

def witness_30 : Prop :=
  FormalSpecAgent.TypedIR.eval e43 context_30 = ([] : FormalSpecAgent.Bytes)

def witness_31 : Prop :=
  FormalSpecAgent.TypedIR.eval e44 context_31 = (0)

def witness_32 : Prop :=
  FormalSpecAgent.TypedIR.eval e44 context_32 = (0)

def witness_33 : Prop :=
  FormalSpecAgent.TypedIR.eval e33 context_33 = ([] : FormalSpecAgent.Bytes)

def witness_34 : Prop :=
  FormalSpecAgent.TypedIR.eval e27 context_34 = false

def witness_35 : Prop :=
  FormalSpecAgent.TypedIR.eval e29 context_35 = false

def witness_36 : Prop :=
  FormalSpecAgent.TypedIR.eval e35 context_36 = (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def witness_37 : Prop :=
  FormalSpecAgent.TypedIR.eval e36 context_37 = (4294967295)

def witness_38 : Prop :=
  FormalSpecAgent.TypedIR.eval e37 context_38 = false

def witness_39 : Prop :=
  FormalSpecAgent.TypedIR.eval e38 context_39 = false

def witness_40 : Prop :=
  FormalSpecAgent.TypedIR.eval e39 context_40 = false

def witness_41 : Prop :=
  FormalSpecAgent.TypedIR.eval e37 context_41 = true

def witness_42 : Prop :=
  FormalSpecAgent.TypedIR.eval e38 context_42 = false

def witness_43 : Prop :=
  FormalSpecAgent.TypedIR.eval e39 context_43 = true

def witness_44 : Prop :=
  FormalSpecAgent.TypedIR.eval e48 context_44 = (65535)

def witness_45 : Prop :=
  FormalSpecAgent.TypedIR.eval e48 context_45 = (0)

def witness_46 : Prop :=
  FormalSpecAgent.TypedIR.eval e48 context_46 = (32767)

def witness_47 : Prop :=
  FormalSpecAgent.TypedIR.eval e48 context_47 = (65534)

def witness_48 : Prop :=
  FormalSpecAgent.TypedIR.eval e48 context_48 = (8717)

def witness_49 : Prop :=
  FormalSpecAgent.TypedIR.eval e52 context_49 = (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])

def witness_50 : Prop :=
  FormalSpecAgent.TypedIR.eval e50 context_50 = true

def witness_51 : Prop :=
  FormalSpecAgent.TypedIR.eval e49 context_51 = false

def witness_52 : Prop :=
  FormalSpecAgent.TypedIR.eval e20 context_52 = false

end Approved
