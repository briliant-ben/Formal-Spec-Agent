from pathlib import Path
import json,sys,os,time,hashlib,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/lean-typed-cell-oracle-20261118-0253';O.mkdir(exist_ok=False)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def st(s,**kw):save('status.json',dict(status=s,pid=os.getpid(),updated_at=time.time(),**kw))
(O/'controller.py').write_bytes(Path(__file__).read_bytes())
try:
 data=(P/'incoming/fsa-batch-0253-input.json').read_bytes();(O/'input.json').write_bytes(data);save('input-hash.json',dict(sha256=hashlib.sha256(data).hexdigest()))
 messages=[dict(role='system',content='You are an independent literal test-oracle author. Follow only the supplied normative benchmark and exact stimuli; return strict JSON. No code generation, execution, model implementation or self approval.'),dict(role='user',content=data.decode())]
 st('running',stage='independent_literal_oracle_proposal');sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 a=request(messages,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=12000,thinking='disabled',reasoning_effort=None,timeout=900)
 response=json.loads((P/'private/api-ledger'/a['response_file']).read_text())['response'];save('response.json',response);save('usage.json',{k:a.get(k)for k in ['usage','cached','request_sha256']})
 assert set(response)=={'cases','findings','limitations'} and type(response['cases'])is list and len(response['cases'])==1 and all(type(response[k])is list for k in ['findings','limitations'])
 st('literal_proposal_received_requires_controller_review')
except Exception as e:
 (O/'traceback.txt').write_text(traceback.format_exc());st('failed_or_rejected_no_retry',error_type=type(e).__name__)
