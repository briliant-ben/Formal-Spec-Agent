// Lean compiler output
// Module: Runner
// Imports: public import Init public meta import Init public import ModelMachine
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_string_mk(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
extern lean_object* l_MachineRuntime_model;
lean_object* l_FormalSpecAgent_TypedMachine_external(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_MachineRuntime_schema;
lean_object* l_FormalSpecAgent_MachineObserve_outcome(lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Int_repr(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_string_data(lean_object*);
lean_object* lean_uint32_to_nat(uint32_t);
lean_object* l_String_intercalate(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_rollback(lean_object*, lean_object*);
lean_object* lean_int_neg(lean_object*);
lean_object* lean_string_push(lean_object*, uint32_t);
lean_object* lean_get_stdout();
static const lean_string_object l_array___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "["};
static const lean_object* l_array___closed__0 = (const lean_object*)&l_array___closed__0_value;
static const lean_string_object l_array___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* l_array___closed__1 = (const lean_object*)&l_array___closed__1_value;
static const lean_string_object l_array___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "]"};
static const lean_object* l_array___closed__2 = (const lean_object*)&l_array___closed__2_value;
LEAN_EXPORT lean_object* l_array(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__1(lean_object*, lean_object*);
static const lean_string_object l_pvalue___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "{\"kind\":\"int\",\"value\":"};
static const lean_object* l_pvalue___closed__0 = (const lean_object*)&l_pvalue___closed__0_value;
static const lean_string_object l_pvalue___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "}"};
static const lean_object* l_pvalue___closed__1 = (const lean_object*)&l_pvalue___closed__1_value;
static const lean_string_object l_pvalue___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "{\"kind\":\"bool\",\"value\":"};
static const lean_object* l_pvalue___closed__2 = (const lean_object*)&l_pvalue___closed__2_value;
static const lean_string_object l_pvalue___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "false"};
static const lean_object* l_pvalue___closed__3 = (const lean_object*)&l_pvalue___closed__3_value;
static const lean_string_object l_pvalue___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "true"};
static const lean_object* l_pvalue___closed__4 = (const lean_object*)&l_pvalue___closed__4_value;
static const lean_string_object l_pvalue___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "{\"kind\":\"string\",\"value\":"};
static const lean_object* l_pvalue___closed__5 = (const lean_object*)&l_pvalue___closed__5_value;
static const lean_string_object l_pvalue___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "{\"kind\":\"bytes\",\"value\":"};
static const lean_object* l_pvalue___closed__6 = (const lean_object*)&l_pvalue___closed__6_value;
static const lean_string_object l_pvalue___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "{\"kind\":\"seq32\",\"value\":"};
static const lean_object* l_pvalue___closed__7 = (const lean_object*)&l_pvalue___closed__7_value;
LEAN_EXPORT lean_object* l_pvalue(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__0(lean_object*, lean_object*);
static const lean_string_object l_ss___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "{\"state\":"};
static const lean_object* l_ss___closed__0 = (const lean_object*)&l_ss___closed__0_value;
static const lean_string_object l_ss___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"now_ms\":"};
static const lean_object* l_ss___closed__1 = (const lean_object*)&l_ss___closed__1_value;
static const lean_string_object l_ss___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = ",\"variables\":"};
static const lean_object* l_ss___closed__2 = (const lean_object*)&l_ss___closed__2_value;
static const lean_string_object l_ss___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"timers\":"};
static const lean_object* l_ss___closed__3 = (const lean_object*)&l_ss___closed__3_value;
LEAN_EXPORT lean_object* l_ss(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00msg_spec__0(lean_object*, lean_object*);
static const lean_string_object l_msg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "{\"message\":"};
static const lean_object* l_msg___closed__0 = (const lean_object*)&l_msg___closed__0_value;
static const lean_string_object l_msg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = ",\"fields\":"};
static const lean_object* l_msg___closed__1 = (const lean_object*)&l_msg___closed__1_value;
LEAN_EXPORT lean_object* l_msg(lean_object*);
static const lean_string_object l_faultName___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "uncovered"};
static const lean_object* l_faultName___closed__0 = (const lean_object*)&l_faultName___closed__0_value;
static const lean_string_object l_faultName___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "conflict"};
static const lean_object* l_faultName___closed__1 = (const lean_object*)&l_faultName___closed__1_value;
static const lean_string_object l_faultName___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "badDelay"};
static const lean_object* l_faultName___closed__2 = (const lean_object*)&l_faultName___closed__2_value;
static const lean_string_object l_faultName___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "invariant"};
static const lean_object* l_faultName___closed__3 = (const lean_object*)&l_faultName___closed__3_value;
static const lean_string_object l_faultName___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "time"};
static const lean_object* l_faultName___closed__4 = (const lean_object*)&l_faultName___closed__4_value;
static const lean_string_object l_faultName___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "timerInjection"};
static const lean_object* l_faultName___closed__5 = (const lean_object*)&l_faultName___closed__5_value;
static const lean_string_object l_faultName___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "pendingTimer"};
static const lean_object* l_faultName___closed__6 = (const lean_object*)&l_faultName___closed__6_value;
static const lean_string_object l_faultName___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "noTimer"};
static const lean_object* l_faultName___closed__7 = (const lean_object*)&l_faultName___closed__7_value;
LEAN_EXPORT lean_object* l_faultName(uint8_t);
LEAN_EXPORT lean_object* l_faultName___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00outcomeText_spec__0(lean_object*, lean_object*);
static const lean_string_object l_outcomeText___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "{\"status\":\"ok\",\"rule\":"};
static const lean_object* l_outcomeText___closed__0 = (const lean_object*)&l_outcomeText___closed__0_value;
static const lean_string_object l_outcomeText___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = ",\"event\":"};
static const lean_object* l_outcomeText___closed__1 = (const lean_object*)&l_outcomeText___closed__1_value;
static const lean_string_object l_outcomeText___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = ",\"after\":"};
static const lean_object* l_outcomeText___closed__2 = (const lean_object*)&l_outcomeText___closed__2_value;
static const lean_string_object l_outcomeText___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = ",\"emitted\":"};
static const lean_object* l_outcomeText___closed__3 = (const lean_object*)&l_outcomeText___closed__3_value;
static const lean_string_object l_outcomeText___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "{\"status\":\"error\",\"fault\":\""};
static const lean_object* l_outcomeText___closed__4 = (const lean_object*)&l_outcomeText___closed__4_value;
static const lean_string_object l_outcomeText___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "\",\"after\":"};
static const lean_object* l_outcomeText___closed__5 = (const lean_object*)&l_outcomeText___closed__5_value;
static const lean_string_object l_outcomeText___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = ",\"emitted\":[]}"};
static const lean_object* l_outcomeText___closed__6 = (const lean_object*)&l_outcomeText___closed__6_value;
LEAN_EXPORT lean_object* l_outcomeText(lean_object*);
static lean_once_cell_t l_main___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__0___closed__0;
LEAN_EXPORT lean_object* l_main___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__0___boxed(lean_object*);
LEAN_EXPORT uint8_t l_main___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__1___boxed(lean_object*);
static lean_once_cell_t l_main___lam__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__2___closed__0;
LEAN_EXPORT lean_object* l_main___lam__2(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__2___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__3(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__3___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__4(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__4___boxed(lean_object*);
LEAN_EXPORT uint8_t l_main___lam__5(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__5___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__6___closed__0___boxed__const__1;
static lean_once_cell_t l_main___lam__6___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__6___closed__0;
LEAN_EXPORT lean_object* l_main___lam__6___closed__1___boxed__const__1;
static lean_once_cell_t l_main___lam__6___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__6___closed__1;
LEAN_EXPORT lean_object* l_main___lam__6___closed__2___boxed__const__1;
static lean_once_cell_t l_main___lam__6___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__6___closed__2;
static lean_once_cell_t l_main___lam__6___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__6___closed__3;
LEAN_EXPORT lean_object* l_main___lam__6(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__6___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__7___closed__0___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__0;
LEAN_EXPORT lean_object* l_main___lam__7___closed__1___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__1;
LEAN_EXPORT lean_object* l_main___lam__7___closed__2___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__2;
LEAN_EXPORT lean_object* l_main___lam__7___closed__3___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__3;
LEAN_EXPORT lean_object* l_main___lam__7___closed__4___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__4;
LEAN_EXPORT lean_object* l_main___lam__7___closed__5___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__5;
static lean_once_cell_t l_main___lam__7___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__6;
static lean_once_cell_t l_main___lam__7___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__7;
static lean_once_cell_t l_main___lam__7___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__8;
LEAN_EXPORT lean_object* l_main___lam__7___closed__9___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__9;
LEAN_EXPORT lean_object* l_main___lam__7___closed__10___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__10;
LEAN_EXPORT lean_object* l_main___lam__7___closed__11___boxed__const__1;
static lean_once_cell_t l_main___lam__7___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__11;
static lean_once_cell_t l_main___lam__7___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__7___closed__12;
LEAN_EXPORT lean_object* l_main___lam__7(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__7___boxed(lean_object*);
static lean_once_cell_t l_main___lam__8___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__0;
static lean_once_cell_t l_main___lam__8___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__1;
LEAN_EXPORT lean_object* l_main___lam__8___closed__2___boxed__const__1;
static lean_once_cell_t l_main___lam__8___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__2;
LEAN_EXPORT lean_object* l_main___lam__8___closed__3___boxed__const__1;
static lean_once_cell_t l_main___lam__8___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__3;
LEAN_EXPORT lean_object* l_main___lam__8___closed__4___boxed__const__1;
static lean_once_cell_t l_main___lam__8___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__4;
LEAN_EXPORT lean_object* l_main___lam__8___closed__5___boxed__const__1;
static lean_once_cell_t l_main___lam__8___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__5;
static lean_once_cell_t l_main___lam__8___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__6;
static lean_once_cell_t l_main___lam__8___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__7;
static lean_once_cell_t l_main___lam__8___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__8;
static lean_once_cell_t l_main___lam__8___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__9;
static lean_once_cell_t l_main___lam__8___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__10;
static lean_once_cell_t l_main___lam__8___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__11;
static lean_once_cell_t l_main___lam__8___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__12;
static lean_once_cell_t l_main___lam__8___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__13;
static lean_once_cell_t l_main___lam__8___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__14;
static lean_once_cell_t l_main___lam__8___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__15;
static lean_once_cell_t l_main___lam__8___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__8___closed__16;
LEAN_EXPORT lean_object* l_main___lam__8(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__8___boxed(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__9___closed__0___boxed__const__1;
static lean_once_cell_t l_main___lam__9___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__9___closed__0;
LEAN_EXPORT lean_object* l_main___lam__9___closed__1___boxed__const__1;
static lean_once_cell_t l_main___lam__9___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__9___closed__1;
LEAN_EXPORT lean_object* l_main___lam__9___closed__2___boxed__const__1;
static lean_once_cell_t l_main___lam__9___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__9___closed__2;
LEAN_EXPORT lean_object* l_main___lam__9___closed__3___boxed__const__1;
static lean_once_cell_t l_main___lam__9___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__9___closed__3;
static lean_once_cell_t l_main___lam__9___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__9___closed__4;
static lean_once_cell_t l_main___lam__9___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__9___closed__5;
LEAN_EXPORT lean_object* l_main___lam__9(lean_object*);
LEAN_EXPORT lean_object* l_main___lam__9___boxed(lean_object*);
static const lean_ctor_object l_main___lam__10___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___lam__10___closed__0 = (const lean_object*)&l_main___lam__10___closed__0_value;
static const lean_ctor_object l_main___lam__10___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(255) << 1) | 1)),((lean_object*)&l_main___lam__10___closed__0_value)}};
static const lean_object* l_main___lam__10___closed__1 = (const lean_object*)&l_main___lam__10___closed__1_value;
static const lean_ctor_object l_main___lam__10___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(128) << 1) | 1)),((lean_object*)&l_main___lam__10___closed__1_value)}};
static const lean_object* l_main___lam__10___closed__2 = (const lean_object*)&l_main___lam__10___closed__2_value;
LEAN_EXPORT lean_object* l_main___lam__10(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__10___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__11(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__11___boxed(lean_object*, lean_object*);
static const lean_ctor_object l_main___lam__12___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(16) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___lam__12___closed__0 = (const lean_object*)&l_main___lam__12___closed__0_value;
static const lean_ctor_object l_main___lam__12___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(15) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__0_value)}};
static const lean_object* l_main___lam__12___closed__1 = (const lean_object*)&l_main___lam__12___closed__1_value;
static const lean_ctor_object l_main___lam__12___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(14) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__1_value)}};
static const lean_object* l_main___lam__12___closed__2 = (const lean_object*)&l_main___lam__12___closed__2_value;
static const lean_ctor_object l_main___lam__12___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(13) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__2_value)}};
static const lean_object* l_main___lam__12___closed__3 = (const lean_object*)&l_main___lam__12___closed__3_value;
static const lean_ctor_object l_main___lam__12___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(12) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__3_value)}};
static const lean_object* l_main___lam__12___closed__4 = (const lean_object*)&l_main___lam__12___closed__4_value;
static const lean_ctor_object l_main___lam__12___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(11) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__4_value)}};
static const lean_object* l_main___lam__12___closed__5 = (const lean_object*)&l_main___lam__12___closed__5_value;
static const lean_ctor_object l_main___lam__12___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(10) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__5_value)}};
static const lean_object* l_main___lam__12___closed__6 = (const lean_object*)&l_main___lam__12___closed__6_value;
static const lean_ctor_object l_main___lam__12___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(9) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__6_value)}};
static const lean_object* l_main___lam__12___closed__7 = (const lean_object*)&l_main___lam__12___closed__7_value;
static const lean_ctor_object l_main___lam__12___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(8) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__7_value)}};
static const lean_object* l_main___lam__12___closed__8 = (const lean_object*)&l_main___lam__12___closed__8_value;
static const lean_ctor_object l_main___lam__12___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__8_value)}};
static const lean_object* l_main___lam__12___closed__9 = (const lean_object*)&l_main___lam__12___closed__9_value;
static const lean_ctor_object l_main___lam__12___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(6) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__9_value)}};
static const lean_object* l_main___lam__12___closed__10 = (const lean_object*)&l_main___lam__12___closed__10_value;
static const lean_ctor_object l_main___lam__12___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__10_value)}};
static const lean_object* l_main___lam__12___closed__11 = (const lean_object*)&l_main___lam__12___closed__11_value;
static const lean_ctor_object l_main___lam__12___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__11_value)}};
static const lean_object* l_main___lam__12___closed__12 = (const lean_object*)&l_main___lam__12___closed__12_value;
static const lean_ctor_object l_main___lam__12___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__12_value)}};
static const lean_object* l_main___lam__12___closed__13 = (const lean_object*)&l_main___lam__12___closed__13_value;
static const lean_ctor_object l_main___lam__12___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__13_value)}};
static const lean_object* l_main___lam__12___closed__14 = (const lean_object*)&l_main___lam__12___closed__14_value;
static const lean_ctor_object l_main___lam__12___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_main___lam__12___closed__14_value)}};
static const lean_object* l_main___lam__12___closed__15 = (const lean_object*)&l_main___lam__12___closed__15_value;
LEAN_EXPORT lean_object* l_main___lam__12(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__12___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__13(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__13___boxed(lean_object*, lean_object*);
static const lean_ctor_object l_main___lam__14___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(9) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___lam__14___closed__0 = (const lean_object*)&l_main___lam__14___closed__0_value;
LEAN_EXPORT lean_object* l_main___lam__14(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__14___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__15(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__15___boxed(lean_object*, lean_object*);
static lean_once_cell_t l_main___lam__16___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__16___closed__0;
LEAN_EXPORT lean_object* l_main___lam__16(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__16___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__17(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__17___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__18(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__18___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__19(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__19___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__20(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__20___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_main___lam__21___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__21___closed__0;
LEAN_EXPORT lean_object* l_main___lam__21(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__21___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__23___closed__0___boxed__const__1;
static lean_once_cell_t l_main___lam__23___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__23___closed__0;
static lean_once_cell_t l_main___lam__23___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__23___closed__1;
static lean_once_cell_t l_main___lam__23___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__23___closed__2;
static lean_once_cell_t l_main___lam__23___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__23___closed__3;
LEAN_EXPORT lean_object* l_main___lam__23(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__23___boxed(lean_object*, lean_object*);
static const lean_ctor_object l_main___lam__22___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(248) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___lam__22___closed__0 = (const lean_object*)&l_main___lam__22___closed__0_value;
static const lean_ctor_object l_main___lam__22___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(7) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__0_value)}};
static const lean_object* l_main___lam__22___closed__1 = (const lean_object*)&l_main___lam__22___closed__1_value;
static const lean_ctor_object l_main___lam__22___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(249) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__1_value)}};
static const lean_object* l_main___lam__22___closed__2 = (const lean_object*)&l_main___lam__22___closed__2_value;
static const lean_ctor_object l_main___lam__22___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(6) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__2_value)}};
static const lean_object* l_main___lam__22___closed__3 = (const lean_object*)&l_main___lam__22___closed__3_value;
static const lean_ctor_object l_main___lam__22___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(250) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__3_value)}};
static const lean_object* l_main___lam__22___closed__4 = (const lean_object*)&l_main___lam__22___closed__4_value;
static const lean_ctor_object l_main___lam__22___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__4_value)}};
static const lean_object* l_main___lam__22___closed__5 = (const lean_object*)&l_main___lam__22___closed__5_value;
static const lean_ctor_object l_main___lam__22___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(251) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__5_value)}};
static const lean_object* l_main___lam__22___closed__6 = (const lean_object*)&l_main___lam__22___closed__6_value;
static const lean_ctor_object l_main___lam__22___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__6_value)}};
static const lean_object* l_main___lam__22___closed__7 = (const lean_object*)&l_main___lam__22___closed__7_value;
static const lean_ctor_object l_main___lam__22___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(252) << 1) | 1)),((lean_object*)&l_main___lam__22___closed__7_value)}};
static const lean_object* l_main___lam__22___closed__8 = (const lean_object*)&l_main___lam__22___closed__8_value;
LEAN_EXPORT lean_object* l_main___lam__22(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__22___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_main___lam__24___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__24___closed__0;
static lean_once_cell_t l_main___lam__24___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__24___closed__1;
static lean_once_cell_t l_main___lam__24___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__24___closed__2;
LEAN_EXPORT lean_object* l_main___lam__24___closed__3___boxed__const__1;
static lean_once_cell_t l_main___lam__24___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__24___closed__3;
static lean_once_cell_t l_main___lam__24___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___lam__24___closed__4;
LEAN_EXPORT lean_object* l_main___lam__24(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_main___lam__24___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_closure_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_closure_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__2___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_closure_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__3___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_closure_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__4___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_closure_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__5___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_closure_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__6___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_closure_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__7___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_closure_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__8___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_closure_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__9___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static const lean_ctor_object l_main___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&l_main___closed__0_value),((lean_object*)&l_main___closed__1_value),((lean_object*)&l_main___closed__2_value),((lean_object*)&l_main___closed__3_value),((lean_object*)&l_main___closed__4_value)}};
static const lean_object* l_main___closed__10 = (const lean_object*)&l_main___closed__10_value;
static const lean_closure_object l_main___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__10___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__11 = (const lean_object*)&l_main___closed__11_value;
static const lean_closure_object l_main___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__11___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__12 = (const lean_object*)&l_main___closed__12_value;
static const lean_closure_object l_main___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__12___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__13 = (const lean_object*)&l_main___closed__13_value;
static const lean_closure_object l_main___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__13___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__14 = (const lean_object*)&l_main___closed__14_value;
static const lean_closure_object l_main___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__14___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__15 = (const lean_object*)&l_main___closed__15_value;
static const lean_closure_object l_main___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__15___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__16 = (const lean_object*)&l_main___closed__16_value;
static lean_once_cell_t l_main___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__17;
static lean_once_cell_t l_main___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__18;
static lean_once_cell_t l_main___closed__19_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__19;
static lean_once_cell_t l_main___closed__20_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__20;
static lean_once_cell_t l_main___closed__21_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__21;
static lean_once_cell_t l_main___closed__22_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__22;
static lean_once_cell_t l_main___closed__23_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__23;
static lean_once_cell_t l_main___closed__24_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__24;
static lean_once_cell_t l_main___closed__25_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__25;
static const lean_closure_object l_main___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__18___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__26 = (const lean_object*)&l_main___closed__26_value;
static const lean_closure_object l_main___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*2, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__19___boxed, .m_arity = 3, .m_num_fixed = 2, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l_main___closed__27 = (const lean_object*)&l_main___closed__27_value;
static lean_once_cell_t l_main___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__28;
static lean_once_cell_t l_main___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__29;
static lean_once_cell_t l_main___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__30;
static lean_once_cell_t l_main___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__31;
static lean_once_cell_t l_main___closed__32_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__32;
static lean_once_cell_t l_main___closed__33_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__33;
static lean_once_cell_t l_main___closed__34_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__34;
static lean_once_cell_t l_main___closed__35_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__35;
static lean_once_cell_t l_main___closed__36_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__36;
static lean_once_cell_t l_main___closed__37_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__37;
static lean_once_cell_t l_main___closed__38_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__38;
static lean_once_cell_t l_main___closed__39_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__39;
static lean_once_cell_t l_main___closed__40_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__40;
static lean_once_cell_t l_main___closed__41_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__41;
static const lean_closure_object l_main___closed__42_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__23___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))} };
static const lean_object* l_main___closed__42 = (const lean_object*)&l_main___closed__42_value;
static const lean_closure_object l_main___closed__43_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*4, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__22___boxed, .m_arity = 5, .m_num_fixed = 4, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))} };
static const lean_object* l_main___closed__43 = (const lean_object*)&l_main___closed__43_value;
static const lean_closure_object l_main___closed__44_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_main___lam__24___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))} };
static const lean_object* l_main___closed__44 = (const lean_object*)&l_main___closed__44_value;
static lean_once_cell_t l_main___closed__45_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__45;
static lean_once_cell_t l_main___closed__46_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__46;
static lean_once_cell_t l_main___closed__47_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__47;
static lean_once_cell_t l_main___closed__48_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__48;
static lean_once_cell_t l_main___closed__49_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__49;
static lean_once_cell_t l_main___closed__50_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__50;
static lean_once_cell_t l_main___closed__51_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__51;
static lean_once_cell_t l_main___closed__52_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__52;
static lean_once_cell_t l_main___closed__53_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__53;
static lean_once_cell_t l_main___closed__54_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__54;
static lean_once_cell_t l_main___closed__55_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__55;
static lean_once_cell_t l_main___closed__56_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__56;
static lean_once_cell_t l_main___closed__57_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__57;
static lean_once_cell_t l_main___closed__58_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__58;
static lean_once_cell_t l_main___closed__59_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__59;
static lean_once_cell_t l_main___closed__60_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_main___closed__60;
LEAN_EXPORT lean_object* _lean_main();
LEAN_EXPORT lean_object* l_main___boxed(lean_object*);
LEAN_EXPORT lean_object* l_array(lean_object* v_xs_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; 
v___x_5_ = ((lean_object*)(l_array___closed__0));
v___x_6_ = ((lean_object*)(l_array___closed__1));
v___x_7_ = l_String_intercalate(v___x_6_, v_xs_4_);
v___x_8_ = lean_string_append(v___x_5_, v___x_7_);
lean_dec_ref(v___x_7_);
v___x_9_ = ((lean_object*)(l_array___closed__2));
v___x_10_ = lean_string_append(v___x_8_, v___x_9_);
return v___x_10_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__0(lean_object* v_a_11_, lean_object* v_a_12_){
_start:
{
if (lean_obj_tag(v_a_11_) == 0)
{
lean_object* v___x_13_; 
v___x_13_ = l_List_reverse___redArg(v_a_12_);
return v___x_13_;
}
else
{
lean_object* v_head_14_; lean_object* v_tail_15_; lean_object* v___x_17_; uint8_t v_isShared_18_; uint8_t v_isSharedCheck_26_; 
v_head_14_ = lean_ctor_get(v_a_11_, 0);
v_tail_15_ = lean_ctor_get(v_a_11_, 1);
v_isSharedCheck_26_ = !lean_is_exclusive(v_a_11_);
if (v_isSharedCheck_26_ == 0)
{
v___x_17_ = v_a_11_;
v_isShared_18_ = v_isSharedCheck_26_;
goto v_resetjp_16_;
}
else
{
lean_inc(v_tail_15_);
lean_inc(v_head_14_);
lean_dec(v_a_11_);
v___x_17_ = lean_box(0);
v_isShared_18_ = v_isSharedCheck_26_;
goto v_resetjp_16_;
}
v_resetjp_16_:
{
uint32_t v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_23_; 
v___x_19_ = lean_unbox_uint32(v_head_14_);
lean_dec(v_head_14_);
v___x_20_ = lean_uint32_to_nat(v___x_19_);
v___x_21_ = l_Nat_reprFast(v___x_20_);
if (v_isShared_18_ == 0)
{
lean_ctor_set(v___x_17_, 1, v_a_12_);
lean_ctor_set(v___x_17_, 0, v___x_21_);
v___x_23_ = v___x_17_;
goto v_reusejp_22_;
}
else
{
lean_object* v_reuseFailAlloc_25_; 
v_reuseFailAlloc_25_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_25_, 0, v___x_21_);
lean_ctor_set(v_reuseFailAlloc_25_, 1, v_a_12_);
v___x_23_ = v_reuseFailAlloc_25_;
goto v_reusejp_22_;
}
v_reusejp_22_:
{
v_a_11_ = v_tail_15_;
v_a_12_ = v___x_23_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00pvalue_spec__1(lean_object* v_a_27_, lean_object* v_a_28_){
_start:
{
if (lean_obj_tag(v_a_27_) == 0)
{
lean_object* v___x_29_; 
v___x_29_ = l_List_reverse___redArg(v_a_28_);
return v___x_29_;
}
else
{
lean_object* v_head_30_; lean_object* v_tail_31_; lean_object* v___x_33_; uint8_t v_isShared_34_; uint8_t v_isSharedCheck_40_; 
v_head_30_ = lean_ctor_get(v_a_27_, 0);
v_tail_31_ = lean_ctor_get(v_a_27_, 1);
v_isSharedCheck_40_ = !lean_is_exclusive(v_a_27_);
if (v_isSharedCheck_40_ == 0)
{
v___x_33_ = v_a_27_;
v_isShared_34_ = v_isSharedCheck_40_;
goto v_resetjp_32_;
}
else
{
lean_inc(v_tail_31_);
lean_inc(v_head_30_);
lean_dec(v_a_27_);
v___x_33_ = lean_box(0);
v_isShared_34_ = v_isSharedCheck_40_;
goto v_resetjp_32_;
}
v_resetjp_32_:
{
lean_object* v___x_35_; lean_object* v___x_37_; 
v___x_35_ = l_Nat_reprFast(v_head_30_);
if (v_isShared_34_ == 0)
{
lean_ctor_set(v___x_33_, 1, v_a_28_);
lean_ctor_set(v___x_33_, 0, v___x_35_);
v___x_37_ = v___x_33_;
goto v_reusejp_36_;
}
else
{
lean_object* v_reuseFailAlloc_39_; 
v_reuseFailAlloc_39_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_39_, 0, v___x_35_);
lean_ctor_set(v_reuseFailAlloc_39_, 1, v_a_28_);
v___x_37_ = v_reuseFailAlloc_39_;
goto v_reusejp_36_;
}
v_reusejp_36_:
{
v_a_27_ = v_tail_31_;
v_a_28_ = v___x_37_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_pvalue(lean_object* v_x_49_){
_start:
{
switch(lean_obj_tag(v_x_49_))
{
case 0:
{
lean_object* v_a_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; 
v_a_50_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_50_);
lean_dec_ref_known(v_x_49_, 1);
v___x_51_ = ((lean_object*)(l_pvalue___closed__0));
v___x_52_ = l_Int_repr(v_a_50_);
lean_dec(v_a_50_);
v___x_53_ = lean_string_append(v___x_51_, v___x_52_);
lean_dec_ref(v___x_52_);
v___x_54_ = ((lean_object*)(l_pvalue___closed__1));
v___x_55_ = lean_string_append(v___x_53_, v___x_54_);
return v___x_55_;
}
case 1:
{
uint8_t v_a_56_; lean_object* v___x_57_; lean_object* v___y_59_; 
v_a_56_ = lean_ctor_get_uint8(v_x_49_, 0);
lean_dec_ref_known(v_x_49_, 0);
v___x_57_ = ((lean_object*)(l_pvalue___closed__2));
if (v_a_56_ == 0)
{
lean_object* v___x_63_; 
v___x_63_ = ((lean_object*)(l_pvalue___closed__3));
v___y_59_ = v___x_63_;
goto v___jp_58_;
}
else
{
lean_object* v___x_64_; 
v___x_64_ = ((lean_object*)(l_pvalue___closed__4));
v___y_59_ = v___x_64_;
goto v___jp_58_;
}
v___jp_58_:
{
lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; 
v___x_60_ = lean_string_append(v___x_57_, v___y_59_);
v___x_61_ = ((lean_object*)(l_pvalue___closed__1));
v___x_62_ = lean_string_append(v___x_60_, v___x_61_);
return v___x_62_;
}
}
case 2:
{
lean_object* v_a_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; lean_object* v___x_72_; lean_object* v___x_73_; 
v_a_65_ = lean_ctor_get(v_x_49_, 0);
lean_inc_ref(v_a_65_);
lean_dec_ref_known(v_x_49_, 1);
v___x_66_ = ((lean_object*)(l_pvalue___closed__5));
v___x_67_ = lean_string_data(v_a_65_);
v___x_68_ = lean_box(0);
v___x_69_ = l_List_mapTR_loop___at___00pvalue_spec__0(v___x_67_, v___x_68_);
v___x_70_ = l_array(v___x_69_);
v___x_71_ = lean_string_append(v___x_66_, v___x_70_);
lean_dec_ref(v___x_70_);
v___x_72_ = ((lean_object*)(l_pvalue___closed__1));
v___x_73_ = lean_string_append(v___x_71_, v___x_72_);
return v___x_73_;
}
case 3:
{
lean_object* v_a_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; 
v_a_74_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_74_);
lean_dec_ref_known(v_x_49_, 1);
v___x_75_ = ((lean_object*)(l_pvalue___closed__6));
v___x_76_ = lean_box(0);
v___x_77_ = l_List_mapTR_loop___at___00pvalue_spec__1(v_a_74_, v___x_76_);
v___x_78_ = l_array(v___x_77_);
v___x_79_ = lean_string_append(v___x_75_, v___x_78_);
lean_dec_ref(v___x_78_);
v___x_80_ = ((lean_object*)(l_pvalue___closed__1));
v___x_81_ = lean_string_append(v___x_79_, v___x_80_);
return v___x_81_;
}
default: 
{
lean_object* v_a_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; 
v_a_82_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_82_);
lean_dec_ref_known(v_x_49_, 1);
v___x_83_ = ((lean_object*)(l_pvalue___closed__7));
v___x_84_ = l_Nat_reprFast(v_a_82_);
v___x_85_ = lean_string_append(v___x_83_, v___x_84_);
lean_dec_ref(v___x_84_);
v___x_86_ = ((lean_object*)(l_pvalue___closed__1));
v___x_87_ = lean_string_append(v___x_85_, v___x_86_);
return v___x_87_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__1(lean_object* v_a_88_, lean_object* v_a_89_){
_start:
{
if (lean_obj_tag(v_a_88_) == 0)
{
lean_object* v___x_90_; 
v___x_90_ = l_List_reverse___redArg(v_a_89_);
return v___x_90_;
}
else
{
lean_object* v_head_91_; lean_object* v_tail_92_; lean_object* v___x_94_; uint8_t v_isShared_95_; uint8_t v_isSharedCheck_114_; 
v_head_91_ = lean_ctor_get(v_a_88_, 0);
v_tail_92_ = lean_ctor_get(v_a_88_, 1);
v_isSharedCheck_114_ = !lean_is_exclusive(v_a_88_);
if (v_isSharedCheck_114_ == 0)
{
v___x_94_ = v_a_88_;
v_isShared_95_ = v_isSharedCheck_114_;
goto v_resetjp_93_;
}
else
{
lean_inc(v_tail_92_);
lean_inc(v_head_91_);
lean_dec(v_a_88_);
v___x_94_ = lean_box(0);
v_isShared_95_ = v_isSharedCheck_114_;
goto v_resetjp_93_;
}
v_resetjp_93_:
{
lean_object* v_fst_96_; lean_object* v_snd_97_; lean_object* v___x_99_; uint8_t v_isShared_100_; uint8_t v_isSharedCheck_113_; 
v_fst_96_ = lean_ctor_get(v_head_91_, 0);
v_snd_97_ = lean_ctor_get(v_head_91_, 1);
v_isSharedCheck_113_ = !lean_is_exclusive(v_head_91_);
if (v_isSharedCheck_113_ == 0)
{
v___x_99_ = v_head_91_;
v_isShared_100_ = v_isSharedCheck_113_;
goto v_resetjp_98_;
}
else
{
lean_inc(v_snd_97_);
lean_inc(v_fst_96_);
lean_dec(v_head_91_);
v___x_99_ = lean_box(0);
v_isShared_100_ = v_isSharedCheck_113_;
goto v_resetjp_98_;
}
v_resetjp_98_:
{
lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; lean_object* v___x_105_; 
v___x_101_ = l_Nat_reprFast(v_fst_96_);
v___x_102_ = l_Int_repr(v_snd_97_);
lean_dec(v_snd_97_);
v___x_103_ = lean_box(0);
if (v_isShared_95_ == 0)
{
lean_ctor_set(v___x_94_, 1, v___x_103_);
lean_ctor_set(v___x_94_, 0, v___x_102_);
v___x_105_ = v___x_94_;
goto v_reusejp_104_;
}
else
{
lean_object* v_reuseFailAlloc_112_; 
v_reuseFailAlloc_112_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_112_, 0, v___x_102_);
lean_ctor_set(v_reuseFailAlloc_112_, 1, v___x_103_);
v___x_105_ = v_reuseFailAlloc_112_;
goto v_reusejp_104_;
}
v_reusejp_104_:
{
lean_object* v___x_107_; 
if (v_isShared_100_ == 0)
{
lean_ctor_set_tag(v___x_99_, 1);
lean_ctor_set(v___x_99_, 1, v___x_105_);
lean_ctor_set(v___x_99_, 0, v___x_101_);
v___x_107_ = v___x_99_;
goto v_reusejp_106_;
}
else
{
lean_object* v_reuseFailAlloc_111_; 
v_reuseFailAlloc_111_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_111_, 0, v___x_101_);
lean_ctor_set(v_reuseFailAlloc_111_, 1, v___x_105_);
v___x_107_ = v_reuseFailAlloc_111_;
goto v_reusejp_106_;
}
v_reusejp_106_:
{
lean_object* v___x_108_; lean_object* v___x_109_; 
v___x_108_ = l_array(v___x_107_);
v___x_109_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_109_, 0, v___x_108_);
lean_ctor_set(v___x_109_, 1, v_a_89_);
v_a_88_ = v_tail_92_;
v_a_89_ = v___x_109_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00ss_spec__0(lean_object* v_a_115_, lean_object* v_a_116_){
_start:
{
if (lean_obj_tag(v_a_115_) == 0)
{
lean_object* v___x_117_; 
v___x_117_ = l_List_reverse___redArg(v_a_116_);
return v___x_117_;
}
else
{
lean_object* v_head_118_; lean_object* v_tail_119_; lean_object* v___x_121_; uint8_t v_isShared_122_; uint8_t v_isSharedCheck_128_; 
v_head_118_ = lean_ctor_get(v_a_115_, 0);
v_tail_119_ = lean_ctor_get(v_a_115_, 1);
v_isSharedCheck_128_ = !lean_is_exclusive(v_a_115_);
if (v_isSharedCheck_128_ == 0)
{
v___x_121_ = v_a_115_;
v_isShared_122_ = v_isSharedCheck_128_;
goto v_resetjp_120_;
}
else
{
lean_inc(v_tail_119_);
lean_inc(v_head_118_);
lean_dec(v_a_115_);
v___x_121_ = lean_box(0);
v_isShared_122_ = v_isSharedCheck_128_;
goto v_resetjp_120_;
}
v_resetjp_120_:
{
lean_object* v___x_123_; lean_object* v___x_125_; 
v___x_123_ = l_pvalue(v_head_118_);
if (v_isShared_122_ == 0)
{
lean_ctor_set(v___x_121_, 1, v_a_116_);
lean_ctor_set(v___x_121_, 0, v___x_123_);
v___x_125_ = v___x_121_;
goto v_reusejp_124_;
}
else
{
lean_object* v_reuseFailAlloc_127_; 
v_reuseFailAlloc_127_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_127_, 0, v___x_123_);
lean_ctor_set(v_reuseFailAlloc_127_, 1, v_a_116_);
v___x_125_ = v_reuseFailAlloc_127_;
goto v_reusejp_124_;
}
v_reusejp_124_:
{
v_a_115_ = v_tail_119_;
v_a_116_ = v___x_125_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ss(lean_object* v_s_133_){
_start:
{
lean_object* v_state_134_; lean_object* v_now_135_; lean_object* v_values_136_; lean_object* v_timers_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; lean_object* v___x_157_; 
v_state_134_ = lean_ctor_get(v_s_133_, 0);
lean_inc(v_state_134_);
v_now_135_ = lean_ctor_get(v_s_133_, 1);
lean_inc(v_now_135_);
v_values_136_ = lean_ctor_get(v_s_133_, 2);
lean_inc(v_values_136_);
v_timers_137_ = lean_ctor_get(v_s_133_, 3);
lean_inc(v_timers_137_);
lean_dec_ref(v_s_133_);
v___x_138_ = ((lean_object*)(l_ss___closed__0));
v___x_139_ = l_Nat_reprFast(v_state_134_);
v___x_140_ = lean_string_append(v___x_138_, v___x_139_);
lean_dec_ref(v___x_139_);
v___x_141_ = ((lean_object*)(l_ss___closed__1));
v___x_142_ = lean_string_append(v___x_140_, v___x_141_);
v___x_143_ = l_Int_repr(v_now_135_);
lean_dec(v_now_135_);
v___x_144_ = lean_string_append(v___x_142_, v___x_143_);
lean_dec_ref(v___x_143_);
v___x_145_ = ((lean_object*)(l_ss___closed__2));
v___x_146_ = lean_string_append(v___x_144_, v___x_145_);
v___x_147_ = lean_box(0);
v___x_148_ = l_List_mapTR_loop___at___00ss_spec__0(v_values_136_, v___x_147_);
v___x_149_ = l_array(v___x_148_);
v___x_150_ = lean_string_append(v___x_146_, v___x_149_);
lean_dec_ref(v___x_149_);
v___x_151_ = ((lean_object*)(l_ss___closed__3));
v___x_152_ = lean_string_append(v___x_150_, v___x_151_);
v___x_153_ = l_List_mapTR_loop___at___00ss_spec__1(v_timers_137_, v___x_147_);
v___x_154_ = l_array(v___x_153_);
v___x_155_ = lean_string_append(v___x_152_, v___x_154_);
lean_dec_ref(v___x_154_);
v___x_156_ = ((lean_object*)(l_pvalue___closed__1));
v___x_157_ = lean_string_append(v___x_155_, v___x_156_);
return v___x_157_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00msg_spec__0(lean_object* v_a_158_, lean_object* v_a_159_){
_start:
{
if (lean_obj_tag(v_a_158_) == 0)
{
lean_object* v___x_160_; 
v___x_160_ = l_List_reverse___redArg(v_a_159_);
return v___x_160_;
}
else
{
lean_object* v_head_161_; lean_object* v_tail_162_; lean_object* v___x_164_; uint8_t v_isShared_165_; uint8_t v_isSharedCheck_184_; 
v_head_161_ = lean_ctor_get(v_a_158_, 0);
v_tail_162_ = lean_ctor_get(v_a_158_, 1);
v_isSharedCheck_184_ = !lean_is_exclusive(v_a_158_);
if (v_isSharedCheck_184_ == 0)
{
v___x_164_ = v_a_158_;
v_isShared_165_ = v_isSharedCheck_184_;
goto v_resetjp_163_;
}
else
{
lean_inc(v_tail_162_);
lean_inc(v_head_161_);
lean_dec(v_a_158_);
v___x_164_ = lean_box(0);
v_isShared_165_ = v_isSharedCheck_184_;
goto v_resetjp_163_;
}
v_resetjp_163_:
{
lean_object* v_fst_166_; lean_object* v_snd_167_; lean_object* v___x_169_; uint8_t v_isShared_170_; uint8_t v_isSharedCheck_183_; 
v_fst_166_ = lean_ctor_get(v_head_161_, 0);
v_snd_167_ = lean_ctor_get(v_head_161_, 1);
v_isSharedCheck_183_ = !lean_is_exclusive(v_head_161_);
if (v_isSharedCheck_183_ == 0)
{
v___x_169_ = v_head_161_;
v_isShared_170_ = v_isSharedCheck_183_;
goto v_resetjp_168_;
}
else
{
lean_inc(v_snd_167_);
lean_inc(v_fst_166_);
lean_dec(v_head_161_);
v___x_169_ = lean_box(0);
v_isShared_170_ = v_isSharedCheck_183_;
goto v_resetjp_168_;
}
v_resetjp_168_:
{
lean_object* v___x_171_; lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_175_; 
v___x_171_ = l_Nat_reprFast(v_fst_166_);
v___x_172_ = l_pvalue(v_snd_167_);
v___x_173_ = lean_box(0);
if (v_isShared_165_ == 0)
{
lean_ctor_set(v___x_164_, 1, v___x_173_);
lean_ctor_set(v___x_164_, 0, v___x_172_);
v___x_175_ = v___x_164_;
goto v_reusejp_174_;
}
else
{
lean_object* v_reuseFailAlloc_182_; 
v_reuseFailAlloc_182_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_182_, 0, v___x_172_);
lean_ctor_set(v_reuseFailAlloc_182_, 1, v___x_173_);
v___x_175_ = v_reuseFailAlloc_182_;
goto v_reusejp_174_;
}
v_reusejp_174_:
{
lean_object* v___x_177_; 
if (v_isShared_170_ == 0)
{
lean_ctor_set_tag(v___x_169_, 1);
lean_ctor_set(v___x_169_, 1, v___x_175_);
lean_ctor_set(v___x_169_, 0, v___x_171_);
v___x_177_ = v___x_169_;
goto v_reusejp_176_;
}
else
{
lean_object* v_reuseFailAlloc_181_; 
v_reuseFailAlloc_181_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_181_, 0, v___x_171_);
lean_ctor_set(v_reuseFailAlloc_181_, 1, v___x_175_);
v___x_177_ = v_reuseFailAlloc_181_;
goto v_reusejp_176_;
}
v_reusejp_176_:
{
lean_object* v___x_178_; lean_object* v___x_179_; 
v___x_178_ = l_array(v___x_177_);
v___x_179_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_179_, 0, v___x_178_);
lean_ctor_set(v___x_179_, 1, v_a_159_);
v_a_158_ = v_tail_162_;
v_a_159_ = v___x_179_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_msg(lean_object* v_m_187_){
_start:
{
lean_object* v_fst_188_; lean_object* v_snd_189_; lean_object* v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; lean_object* v___x_200_; 
v_fst_188_ = lean_ctor_get(v_m_187_, 0);
lean_inc(v_fst_188_);
v_snd_189_ = lean_ctor_get(v_m_187_, 1);
lean_inc(v_snd_189_);
lean_dec_ref(v_m_187_);
v___x_190_ = ((lean_object*)(l_msg___closed__0));
v___x_191_ = l_Nat_reprFast(v_fst_188_);
v___x_192_ = lean_string_append(v___x_190_, v___x_191_);
lean_dec_ref(v___x_191_);
v___x_193_ = ((lean_object*)(l_msg___closed__1));
v___x_194_ = lean_string_append(v___x_192_, v___x_193_);
v___x_195_ = lean_box(0);
v___x_196_ = l_List_mapTR_loop___at___00msg_spec__0(v_snd_189_, v___x_195_);
v___x_197_ = l_array(v___x_196_);
v___x_198_ = lean_string_append(v___x_194_, v___x_197_);
lean_dec_ref(v___x_197_);
v___x_199_ = ((lean_object*)(l_pvalue___closed__1));
v___x_200_ = lean_string_append(v___x_198_, v___x_199_);
return v___x_200_;
}
}
LEAN_EXPORT lean_object* l_faultName(uint8_t v_x_209_){
_start:
{
switch(v_x_209_)
{
case 0:
{
lean_object* v___x_210_; 
v___x_210_ = ((lean_object*)(l_faultName___closed__0));
return v___x_210_;
}
case 1:
{
lean_object* v___x_211_; 
v___x_211_ = ((lean_object*)(l_faultName___closed__1));
return v___x_211_;
}
case 2:
{
lean_object* v___x_212_; 
v___x_212_ = ((lean_object*)(l_faultName___closed__2));
return v___x_212_;
}
case 3:
{
lean_object* v___x_213_; 
v___x_213_ = ((lean_object*)(l_faultName___closed__3));
return v___x_213_;
}
case 4:
{
lean_object* v___x_214_; 
v___x_214_ = ((lean_object*)(l_faultName___closed__4));
return v___x_214_;
}
case 5:
{
lean_object* v___x_215_; 
v___x_215_ = ((lean_object*)(l_faultName___closed__5));
return v___x_215_;
}
case 6:
{
lean_object* v___x_216_; 
v___x_216_ = ((lean_object*)(l_faultName___closed__6));
return v___x_216_;
}
default: 
{
lean_object* v___x_217_; 
v___x_217_ = ((lean_object*)(l_faultName___closed__7));
return v___x_217_;
}
}
}
}
LEAN_EXPORT lean_object* l_faultName___boxed(lean_object* v_x_218_){
_start:
{
uint8_t v_x_76__boxed_219_; lean_object* v_res_220_; 
v_x_76__boxed_219_ = lean_unbox(v_x_218_);
v_res_220_ = l_faultName(v_x_76__boxed_219_);
return v_res_220_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00outcomeText_spec__0(lean_object* v_a_221_, lean_object* v_a_222_){
_start:
{
if (lean_obj_tag(v_a_221_) == 0)
{
lean_object* v___x_223_; 
v___x_223_ = l_List_reverse___redArg(v_a_222_);
return v___x_223_;
}
else
{
lean_object* v_head_224_; lean_object* v_tail_225_; lean_object* v___x_227_; uint8_t v_isShared_228_; uint8_t v_isSharedCheck_234_; 
v_head_224_ = lean_ctor_get(v_a_221_, 0);
v_tail_225_ = lean_ctor_get(v_a_221_, 1);
v_isSharedCheck_234_ = !lean_is_exclusive(v_a_221_);
if (v_isSharedCheck_234_ == 0)
{
v___x_227_ = v_a_221_;
v_isShared_228_ = v_isSharedCheck_234_;
goto v_resetjp_226_;
}
else
{
lean_inc(v_tail_225_);
lean_inc(v_head_224_);
lean_dec(v_a_221_);
v___x_227_ = lean_box(0);
v_isShared_228_ = v_isSharedCheck_234_;
goto v_resetjp_226_;
}
v_resetjp_226_:
{
lean_object* v___x_229_; lean_object* v___x_231_; 
v___x_229_ = l_msg(v_head_224_);
if (v_isShared_228_ == 0)
{
lean_ctor_set(v___x_227_, 1, v_a_222_);
lean_ctor_set(v___x_227_, 0, v___x_229_);
v___x_231_ = v___x_227_;
goto v_reusejp_230_;
}
else
{
lean_object* v_reuseFailAlloc_233_; 
v_reuseFailAlloc_233_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_233_, 0, v___x_229_);
lean_ctor_set(v_reuseFailAlloc_233_, 1, v_a_222_);
v___x_231_ = v_reuseFailAlloc_233_;
goto v_reusejp_230_;
}
v_reusejp_230_:
{
v_a_221_ = v_tail_225_;
v_a_222_ = v___x_231_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_outcomeText(lean_object* v_x_242_){
_start:
{
if (lean_obj_tag(v_x_242_) == 0)
{
lean_object* v_a_243_; lean_object* v_a_244_; lean_object* v_a_245_; lean_object* v_a_246_; lean_object* v___x_247_; lean_object* v___x_248_; lean_object* v___x_249_; lean_object* v___x_250_; lean_object* v___x_251_; lean_object* v___x_252_; lean_object* v___x_253_; lean_object* v___x_254_; lean_object* v___x_255_; lean_object* v___x_256_; lean_object* v___x_257_; lean_object* v___x_258_; lean_object* v___x_259_; lean_object* v___x_260_; lean_object* v___x_261_; lean_object* v___x_262_; lean_object* v___x_263_; lean_object* v___x_264_; lean_object* v___x_265_; 
v_a_243_ = lean_ctor_get(v_x_242_, 0);
lean_inc(v_a_243_);
v_a_244_ = lean_ctor_get(v_x_242_, 1);
lean_inc(v_a_244_);
v_a_245_ = lean_ctor_get(v_x_242_, 2);
lean_inc_ref(v_a_245_);
v_a_246_ = lean_ctor_get(v_x_242_, 3);
lean_inc(v_a_246_);
lean_dec_ref_known(v_x_242_, 4);
v___x_247_ = ((lean_object*)(l_outcomeText___closed__0));
v___x_248_ = l_Nat_reprFast(v_a_243_);
v___x_249_ = lean_string_append(v___x_247_, v___x_248_);
lean_dec_ref(v___x_248_);
v___x_250_ = ((lean_object*)(l_outcomeText___closed__1));
v___x_251_ = lean_string_append(v___x_249_, v___x_250_);
v___x_252_ = l_Nat_reprFast(v_a_244_);
v___x_253_ = lean_string_append(v___x_251_, v___x_252_);
lean_dec_ref(v___x_252_);
v___x_254_ = ((lean_object*)(l_outcomeText___closed__2));
v___x_255_ = lean_string_append(v___x_253_, v___x_254_);
v___x_256_ = l_ss(v_a_245_);
v___x_257_ = lean_string_append(v___x_255_, v___x_256_);
lean_dec_ref(v___x_256_);
v___x_258_ = ((lean_object*)(l_outcomeText___closed__3));
v___x_259_ = lean_string_append(v___x_257_, v___x_258_);
v___x_260_ = lean_box(0);
v___x_261_ = l_List_mapTR_loop___at___00outcomeText_spec__0(v_a_246_, v___x_260_);
v___x_262_ = l_array(v___x_261_);
v___x_263_ = lean_string_append(v___x_259_, v___x_262_);
lean_dec_ref(v___x_262_);
v___x_264_ = ((lean_object*)(l_pvalue___closed__1));
v___x_265_ = lean_string_append(v___x_263_, v___x_264_);
return v___x_265_;
}
else
{
uint8_t v_a_266_; lean_object* v_a_267_; lean_object* v___x_268_; lean_object* v___x_269_; lean_object* v___x_270_; lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_275_; lean_object* v___x_276_; 
v_a_266_ = lean_ctor_get_uint8(v_x_242_, sizeof(void*)*1);
v_a_267_ = lean_ctor_get(v_x_242_, 0);
lean_inc_ref(v_a_267_);
lean_dec_ref_known(v_x_242_, 1);
v___x_268_ = ((lean_object*)(l_outcomeText___closed__4));
v___x_269_ = l_faultName(v_a_266_);
v___x_270_ = lean_string_append(v___x_268_, v___x_269_);
lean_dec_ref(v___x_269_);
v___x_271_ = ((lean_object*)(l_outcomeText___closed__5));
v___x_272_ = lean_string_append(v___x_270_, v___x_271_);
v___x_273_ = l_ss(v_a_267_);
v___x_274_ = lean_string_append(v___x_272_, v___x_273_);
lean_dec_ref(v___x_273_);
v___x_275_ = ((lean_object*)(l_outcomeText___closed__6));
v___x_276_ = lean_string_append(v___x_274_, v___x_275_);
return v___x_276_;
}
}
}
static lean_object* _init_l_main___lam__0___closed__0(void){
_start:
{
lean_object* v___x_277_; lean_object* v___x_278_; 
v___x_277_ = lean_unsigned_to_nat(0u);
v___x_278_ = lean_nat_to_int(v___x_277_);
return v___x_278_;
}
}
LEAN_EXPORT lean_object* l_main___lam__0(lean_object* v_n_279_){
_start:
{
lean_object* v___x_280_; 
v___x_280_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
return v___x_280_;
}
}
LEAN_EXPORT lean_object* l_main___lam__0___boxed(lean_object* v_n_281_){
_start:
{
lean_object* v_res_282_; 
v_res_282_ = l_main___lam__0(v_n_281_);
lean_dec(v_n_281_);
return v_res_282_;
}
}
LEAN_EXPORT uint8_t l_main___lam__1(lean_object* v_n_283_){
_start:
{
lean_object* v___x_284_; uint8_t v___x_285_; 
v___x_284_ = lean_unsigned_to_nat(4u);
v___x_285_ = lean_nat_dec_eq(v_n_283_, v___x_284_);
if (v___x_285_ == 0)
{
return v___x_285_;
}
else
{
uint8_t v___x_286_; 
v___x_286_ = 0;
return v___x_286_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__1___boxed(lean_object* v_n_287_){
_start:
{
uint8_t v_res_288_; lean_object* v_r_289_; 
v_res_288_ = l_main___lam__1(v_n_287_);
lean_dec(v_n_287_);
v_r_289_ = lean_box(v_res_288_);
return v_r_289_;
}
}
static lean_object* _init_l_main___lam__2___closed__0(void){
_start:
{
lean_object* v___x_290_; lean_object* v___x_291_; 
v___x_290_ = lean_box(0);
v___x_291_ = lean_string_mk(v___x_290_);
return v___x_291_;
}
}
LEAN_EXPORT lean_object* l_main___lam__2(lean_object* v_n_292_){
_start:
{
lean_object* v___x_293_; 
v___x_293_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_293_;
}
}
LEAN_EXPORT lean_object* l_main___lam__2___boxed(lean_object* v_n_294_){
_start:
{
lean_object* v_res_295_; 
v_res_295_ = l_main___lam__2(v_n_294_);
lean_dec(v_n_294_);
return v_res_295_;
}
}
LEAN_EXPORT lean_object* l_main___lam__3(lean_object* v_n_296_){
_start:
{
lean_object* v___x_297_; 
v___x_297_ = lean_box(0);
return v___x_297_;
}
}
LEAN_EXPORT lean_object* l_main___lam__3___boxed(lean_object* v_n_298_){
_start:
{
lean_object* v_res_299_; 
v_res_299_ = l_main___lam__3(v_n_298_);
lean_dec(v_n_298_);
return v_res_299_;
}
}
LEAN_EXPORT lean_object* l_main___lam__4(lean_object* v_n_300_){
_start:
{
lean_object* v___x_301_; 
v___x_301_ = lean_unsigned_to_nat(0u);
return v___x_301_;
}
}
LEAN_EXPORT lean_object* l_main___lam__4___boxed(lean_object* v_n_302_){
_start:
{
lean_object* v_res_303_; 
v_res_303_ = l_main___lam__4(v_n_302_);
lean_dec(v_n_302_);
return v_res_303_;
}
}
LEAN_EXPORT uint8_t l_main___lam__5(lean_object* v_n_304_){
_start:
{
lean_object* v___x_305_; uint8_t v___x_306_; 
v___x_305_ = lean_unsigned_to_nat(4u);
v___x_306_ = lean_nat_dec_eq(v_n_304_, v___x_305_);
return v___x_306_;
}
}
LEAN_EXPORT lean_object* l_main___lam__5___boxed(lean_object* v_n_307_){
_start:
{
uint8_t v_res_308_; lean_object* v_r_309_; 
v_res_308_ = l_main___lam__5(v_n_307_);
lean_dec(v_n_307_);
v_r_309_ = lean_box(v_res_308_);
return v_r_309_;
}
}
static lean_object* _init_l_main___lam__6___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_310_; lean_object* v___x_311_; 
v___x_310_ = 0;
v___x_311_ = lean_box_uint32(v___x_310_);
return v___x_311_;
}
}
static lean_object* _init_l_main___lam__6___closed__0(void){
_start:
{
lean_object* v___x_312_; lean_object* v___x_313_; lean_object* v___x_314_; 
v___x_312_ = lean_box(0);
v___x_313_ = l_main___lam__6___closed__0___boxed__const__1;
v___x_314_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_314_, 0, v___x_313_);
lean_ctor_set(v___x_314_, 1, v___x_312_);
return v___x_314_;
}
}
static lean_object* _init_l_main___lam__6___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_315_; lean_object* v___x_316_; 
v___x_315_ = 10;
v___x_316_ = lean_box_uint32(v___x_315_);
return v___x_316_;
}
}
static lean_object* _init_l_main___lam__6___closed__1(void){
_start:
{
lean_object* v___x_317_; lean_object* v___x_318_; lean_object* v___x_319_; 
v___x_317_ = lean_obj_once(&l_main___lam__6___closed__0, &l_main___lam__6___closed__0_once, _init_l_main___lam__6___closed__0);
v___x_318_ = l_main___lam__6___closed__1___boxed__const__1;
v___x_319_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_319_, 0, v___x_318_);
lean_ctor_set(v___x_319_, 1, v___x_317_);
return v___x_319_;
}
}
static lean_object* _init_l_main___lam__6___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_320_; lean_object* v___x_321_; 
v___x_320_ = 24320;
v___x_321_ = lean_box_uint32(v___x_320_);
return v___x_321_;
}
}
static lean_object* _init_l_main___lam__6___closed__2(void){
_start:
{
lean_object* v___x_322_; lean_object* v___x_323_; lean_object* v___x_324_; 
v___x_322_ = lean_obj_once(&l_main___lam__6___closed__1, &l_main___lam__6___closed__1_once, _init_l_main___lam__6___closed__1);
v___x_323_ = l_main___lam__6___closed__2___boxed__const__1;
v___x_324_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_324_, 0, v___x_323_);
lean_ctor_set(v___x_324_, 1, v___x_322_);
return v___x_324_;
}
}
static lean_object* _init_l_main___lam__6___closed__3(void){
_start:
{
lean_object* v___x_325_; lean_object* v___x_326_; 
v___x_325_ = lean_obj_once(&l_main___lam__6___closed__2, &l_main___lam__6___closed__2_once, _init_l_main___lam__6___closed__2);
v___x_326_ = lean_string_mk(v___x_325_);
return v___x_326_;
}
}
LEAN_EXPORT lean_object* l_main___lam__6(lean_object* v_n_327_){
_start:
{
lean_object* v___x_328_; uint8_t v___x_329_; 
v___x_328_ = lean_unsigned_to_nat(3u);
v___x_329_ = lean_nat_dec_eq(v_n_327_, v___x_328_);
if (v___x_329_ == 0)
{
lean_object* v___x_330_; 
v___x_330_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_330_;
}
else
{
lean_object* v___x_331_; 
v___x_331_ = lean_obj_once(&l_main___lam__6___closed__3, &l_main___lam__6___closed__3_once, _init_l_main___lam__6___closed__3);
return v___x_331_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__6___boxed(lean_object* v_n_332_){
_start:
{
lean_object* v_res_333_; 
v_res_333_ = l_main___lam__6(v_n_332_);
lean_dec(v_n_332_);
return v_res_333_;
}
}
static lean_object* _init_l_main___lam__7___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_334_; lean_object* v___x_335_; 
v___x_334_ = 114;
v___x_335_ = lean_box_uint32(v___x_334_);
return v___x_335_;
}
}
static lean_object* _init_l_main___lam__7___closed__0(void){
_start:
{
lean_object* v___x_336_; lean_object* v___x_337_; lean_object* v___x_338_; 
v___x_336_ = lean_box(0);
v___x_337_ = l_main___lam__7___closed__0___boxed__const__1;
v___x_338_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_338_, 0, v___x_337_);
lean_ctor_set(v___x_338_, 1, v___x_336_);
return v___x_338_;
}
}
static lean_object* _init_l_main___lam__7___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_339_; lean_object* v___x_340_; 
v___x_339_ = 101;
v___x_340_ = lean_box_uint32(v___x_339_);
return v___x_340_;
}
}
static lean_object* _init_l_main___lam__7___closed__1(void){
_start:
{
lean_object* v___x_341_; lean_object* v___x_342_; lean_object* v___x_343_; 
v___x_341_ = lean_obj_once(&l_main___lam__7___closed__0, &l_main___lam__7___closed__0_once, _init_l_main___lam__7___closed__0);
v___x_342_ = l_main___lam__7___closed__1___boxed__const__1;
v___x_343_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_343_, 0, v___x_342_);
lean_ctor_set(v___x_343_, 1, v___x_341_);
return v___x_343_;
}
}
static lean_object* _init_l_main___lam__7___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_344_; lean_object* v___x_345_; 
v___x_344_ = 118;
v___x_345_ = lean_box_uint32(v___x_344_);
return v___x_345_;
}
}
static lean_object* _init_l_main___lam__7___closed__2(void){
_start:
{
lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v___x_348_; 
v___x_346_ = lean_obj_once(&l_main___lam__7___closed__1, &l_main___lam__7___closed__1_once, _init_l_main___lam__7___closed__1);
v___x_347_ = l_main___lam__7___closed__2___boxed__const__1;
v___x_348_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_348_, 0, v___x_347_);
lean_ctor_set(v___x_348_, 1, v___x_346_);
return v___x_348_;
}
}
static lean_object* _init_l_main___lam__7___closed__3___boxed__const__1(void){
_start:
{
uint32_t v___x_349_; lean_object* v___x_350_; 
v___x_349_ = 111;
v___x_350_ = lean_box_uint32(v___x_349_);
return v___x_350_;
}
}
static lean_object* _init_l_main___lam__7___closed__3(void){
_start:
{
lean_object* v___x_351_; lean_object* v___x_352_; lean_object* v___x_353_; 
v___x_351_ = lean_obj_once(&l_main___lam__7___closed__2, &l_main___lam__7___closed__2_once, _init_l_main___lam__7___closed__2);
v___x_352_ = l_main___lam__7___closed__3___boxed__const__1;
v___x_353_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_353_, 0, v___x_352_);
lean_ctor_set(v___x_353_, 1, v___x_351_);
return v___x_353_;
}
}
static lean_object* _init_l_main___lam__7___closed__4___boxed__const__1(void){
_start:
{
uint32_t v___x_354_; lean_object* v___x_355_; 
v___x_354_ = 45;
v___x_355_ = lean_box_uint32(v___x_354_);
return v___x_355_;
}
}
static lean_object* _init_l_main___lam__7___closed__4(void){
_start:
{
lean_object* v___x_356_; lean_object* v___x_357_; lean_object* v___x_358_; 
v___x_356_ = lean_obj_once(&l_main___lam__7___closed__3, &l_main___lam__7___closed__3_once, _init_l_main___lam__7___closed__3);
v___x_357_ = l_main___lam__7___closed__4___boxed__const__1;
v___x_358_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_358_, 0, v___x_357_);
lean_ctor_set(v___x_358_, 1, v___x_356_);
return v___x_358_;
}
}
static lean_object* _init_l_main___lam__7___closed__5___boxed__const__1(void){
_start:
{
uint32_t v___x_359_; lean_object* v___x_360_; 
v___x_359_ = 100;
v___x_360_ = lean_box_uint32(v___x_359_);
return v___x_360_;
}
}
static lean_object* _init_l_main___lam__7___closed__5(void){
_start:
{
lean_object* v___x_361_; lean_object* v___x_362_; lean_object* v___x_363_; 
v___x_361_ = lean_obj_once(&l_main___lam__7___closed__4, &l_main___lam__7___closed__4_once, _init_l_main___lam__7___closed__4);
v___x_362_ = l_main___lam__7___closed__5___boxed__const__1;
v___x_363_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_363_, 0, v___x_362_);
lean_ctor_set(v___x_363_, 1, v___x_361_);
return v___x_363_;
}
}
static lean_object* _init_l_main___lam__7___closed__6(void){
_start:
{
lean_object* v___x_364_; lean_object* v___x_365_; lean_object* v___x_366_; 
v___x_364_ = lean_obj_once(&l_main___lam__7___closed__5, &l_main___lam__7___closed__5_once, _init_l_main___lam__7___closed__5);
v___x_365_ = l_main___lam__7___closed__1___boxed__const__1;
v___x_366_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_366_, 0, v___x_365_);
lean_ctor_set(v___x_366_, 1, v___x_364_);
return v___x_366_;
}
}
static lean_object* _init_l_main___lam__7___closed__7(void){
_start:
{
lean_object* v___x_367_; lean_object* v___x_368_; lean_object* v___x_369_; 
v___x_367_ = lean_obj_once(&l_main___lam__7___closed__6, &l_main___lam__7___closed__6_once, _init_l_main___lam__7___closed__6);
v___x_368_ = l_main___lam__7___closed__0___boxed__const__1;
v___x_369_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_369_, 0, v___x_368_);
lean_ctor_set(v___x_369_, 1, v___x_367_);
return v___x_369_;
}
}
static lean_object* _init_l_main___lam__7___closed__8(void){
_start:
{
lean_object* v___x_370_; lean_object* v___x_371_; lean_object* v___x_372_; 
v___x_370_ = lean_obj_once(&l_main___lam__7___closed__7, &l_main___lam__7___closed__7_once, _init_l_main___lam__7___closed__7);
v___x_371_ = l_main___lam__7___closed__3___boxed__const__1;
v___x_372_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_372_, 0, v___x_371_);
lean_ctor_set(v___x_372_, 1, v___x_370_);
return v___x_372_;
}
}
static lean_object* _init_l_main___lam__7___closed__9___boxed__const__1(void){
_start:
{
uint32_t v___x_373_; lean_object* v___x_374_; 
v___x_373_ = 110;
v___x_374_ = lean_box_uint32(v___x_373_);
return v___x_374_;
}
}
static lean_object* _init_l_main___lam__7___closed__9(void){
_start:
{
lean_object* v___x_375_; lean_object* v___x_376_; lean_object* v___x_377_; 
v___x_375_ = lean_obj_once(&l_main___lam__7___closed__8, &l_main___lam__7___closed__8_once, _init_l_main___lam__7___closed__8);
v___x_376_ = l_main___lam__7___closed__9___boxed__const__1;
v___x_377_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_377_, 0, v___x_376_);
lean_ctor_set(v___x_377_, 1, v___x_375_);
return v___x_377_;
}
}
static lean_object* _init_l_main___lam__7___closed__10___boxed__const__1(void){
_start:
{
uint32_t v___x_378_; lean_object* v___x_379_; 
v___x_378_ = 103;
v___x_379_ = lean_box_uint32(v___x_378_);
return v___x_379_;
}
}
static lean_object* _init_l_main___lam__7___closed__10(void){
_start:
{
lean_object* v___x_380_; lean_object* v___x_381_; lean_object* v___x_382_; 
v___x_380_ = lean_obj_once(&l_main___lam__7___closed__9, &l_main___lam__7___closed__9_once, _init_l_main___lam__7___closed__9);
v___x_381_ = l_main___lam__7___closed__10___boxed__const__1;
v___x_382_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_382_, 0, v___x_381_);
lean_ctor_set(v___x_382_, 1, v___x_380_);
return v___x_382_;
}
}
static lean_object* _init_l_main___lam__7___closed__11___boxed__const__1(void){
_start:
{
uint32_t v___x_383_; lean_object* v___x_384_; 
v___x_383_ = 105;
v___x_384_ = lean_box_uint32(v___x_383_);
return v___x_384_;
}
}
static lean_object* _init_l_main___lam__7___closed__11(void){
_start:
{
lean_object* v___x_385_; lean_object* v___x_386_; lean_object* v___x_387_; 
v___x_385_ = lean_obj_once(&l_main___lam__7___closed__10, &l_main___lam__7___closed__10_once, _init_l_main___lam__7___closed__10);
v___x_386_ = l_main___lam__7___closed__11___boxed__const__1;
v___x_387_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_387_, 0, v___x_386_);
lean_ctor_set(v___x_387_, 1, v___x_385_);
return v___x_387_;
}
}
static lean_object* _init_l_main___lam__7___closed__12(void){
_start:
{
lean_object* v___x_388_; lean_object* v___x_389_; 
v___x_388_ = lean_obj_once(&l_main___lam__7___closed__11, &l_main___lam__7___closed__11_once, _init_l_main___lam__7___closed__11);
v___x_389_ = lean_string_mk(v___x_388_);
return v___x_389_;
}
}
LEAN_EXPORT lean_object* l_main___lam__7(lean_object* v_n_390_){
_start:
{
lean_object* v___x_391_; uint8_t v___x_392_; 
v___x_391_ = lean_unsigned_to_nat(3u);
v___x_392_ = lean_nat_dec_eq(v_n_390_, v___x_391_);
if (v___x_392_ == 0)
{
lean_object* v___x_393_; 
v___x_393_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_393_;
}
else
{
lean_object* v___x_394_; 
v___x_394_ = lean_obj_once(&l_main___lam__7___closed__12, &l_main___lam__7___closed__12_once, _init_l_main___lam__7___closed__12);
return v___x_394_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__7___boxed(lean_object* v_n_395_){
_start:
{
lean_object* v_res_396_; 
v_res_396_ = l_main___lam__7(v_n_395_);
lean_dec(v_n_395_);
return v_res_396_;
}
}
static lean_object* _init_l_main___lam__8___closed__0(void){
_start:
{
lean_object* v___x_397_; lean_object* v___x_398_; lean_object* v___x_399_; 
v___x_397_ = lean_box(0);
v___x_398_ = l_main___lam__7___closed__5___boxed__const__1;
v___x_399_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_399_, 0, v___x_398_);
lean_ctor_set(v___x_399_, 1, v___x_397_);
return v___x_399_;
}
}
static lean_object* _init_l_main___lam__8___closed__1(void){
_start:
{
lean_object* v___x_400_; lean_object* v___x_401_; lean_object* v___x_402_; 
v___x_400_ = lean_obj_once(&l_main___lam__8___closed__0, &l_main___lam__8___closed__0_once, _init_l_main___lam__8___closed__0);
v___x_401_ = l_main___lam__7___closed__1___boxed__const__1;
v___x_402_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_402_, 0, v___x_401_);
lean_ctor_set(v___x_402_, 1, v___x_400_);
return v___x_402_;
}
}
static lean_object* _init_l_main___lam__8___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_403_; lean_object* v___x_404_; 
v___x_403_ = 108;
v___x_404_ = lean_box_uint32(v___x_403_);
return v___x_404_;
}
}
static lean_object* _init_l_main___lam__8___closed__2(void){
_start:
{
lean_object* v___x_405_; lean_object* v___x_406_; lean_object* v___x_407_; 
v___x_405_ = lean_obj_once(&l_main___lam__8___closed__1, &l_main___lam__8___closed__1_once, _init_l_main___lam__8___closed__1);
v___x_406_ = l_main___lam__8___closed__2___boxed__const__1;
v___x_407_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_407_, 0, v___x_406_);
lean_ctor_set(v___x_407_, 1, v___x_405_);
return v___x_407_;
}
}
static lean_object* _init_l_main___lam__8___closed__3___boxed__const__1(void){
_start:
{
uint32_t v___x_408_; lean_object* v___x_409_; 
v___x_408_ = 98;
v___x_409_ = lean_box_uint32(v___x_408_);
return v___x_409_;
}
}
static lean_object* _init_l_main___lam__8___closed__3(void){
_start:
{
lean_object* v___x_410_; lean_object* v___x_411_; lean_object* v___x_412_; 
v___x_410_ = lean_obj_once(&l_main___lam__8___closed__2, &l_main___lam__8___closed__2_once, _init_l_main___lam__8___closed__2);
v___x_411_ = l_main___lam__8___closed__3___boxed__const__1;
v___x_412_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_412_, 0, v___x_411_);
lean_ctor_set(v___x_412_, 1, v___x_410_);
return v___x_412_;
}
}
static lean_object* _init_l_main___lam__8___closed__4___boxed__const__1(void){
_start:
{
uint32_t v___x_413_; lean_object* v___x_414_; 
v___x_413_ = 97;
v___x_414_ = lean_box_uint32(v___x_413_);
return v___x_414_;
}
}
static lean_object* _init_l_main___lam__8___closed__4(void){
_start:
{
lean_object* v___x_415_; lean_object* v___x_416_; lean_object* v___x_417_; 
v___x_415_ = lean_obj_once(&l_main___lam__8___closed__3, &l_main___lam__8___closed__3_once, _init_l_main___lam__8___closed__3);
v___x_416_ = l_main___lam__8___closed__4___boxed__const__1;
v___x_417_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_417_, 0, v___x_416_);
lean_ctor_set(v___x_417_, 1, v___x_415_);
return v___x_417_;
}
}
static lean_object* _init_l_main___lam__8___closed__5___boxed__const__1(void){
_start:
{
uint32_t v___x_418_; lean_object* v___x_419_; 
v___x_418_ = 115;
v___x_419_ = lean_box_uint32(v___x_418_);
return v___x_419_;
}
}
static lean_object* _init_l_main___lam__8___closed__5(void){
_start:
{
lean_object* v___x_420_; lean_object* v___x_421_; lean_object* v___x_422_; 
v___x_420_ = lean_obj_once(&l_main___lam__8___closed__4, &l_main___lam__8___closed__4_once, _init_l_main___lam__8___closed__4);
v___x_421_ = l_main___lam__8___closed__5___boxed__const__1;
v___x_422_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_422_, 0, v___x_421_);
lean_ctor_set(v___x_422_, 1, v___x_420_);
return v___x_422_;
}
}
static lean_object* _init_l_main___lam__8___closed__6(void){
_start:
{
lean_object* v___x_423_; lean_object* v___x_424_; lean_object* v___x_425_; 
v___x_423_ = lean_obj_once(&l_main___lam__8___closed__5, &l_main___lam__8___closed__5_once, _init_l_main___lam__8___closed__5);
v___x_424_ = l_main___lam__7___closed__11___boxed__const__1;
v___x_425_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_425_, 0, v___x_424_);
lean_ctor_set(v___x_425_, 1, v___x_423_);
return v___x_425_;
}
}
static lean_object* _init_l_main___lam__8___closed__7(void){
_start:
{
lean_object* v___x_426_; lean_object* v___x_427_; lean_object* v___x_428_; 
v___x_426_ = lean_obj_once(&l_main___lam__8___closed__6, &l_main___lam__8___closed__6_once, _init_l_main___lam__8___closed__6);
v___x_427_ = l_main___lam__7___closed__5___boxed__const__1;
v___x_428_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_428_, 0, v___x_427_);
lean_ctor_set(v___x_428_, 1, v___x_426_);
return v___x_428_;
}
}
static lean_object* _init_l_main___lam__8___closed__8(void){
_start:
{
lean_object* v___x_429_; lean_object* v___x_430_; lean_object* v___x_431_; 
v___x_429_ = lean_obj_once(&l_main___lam__8___closed__7, &l_main___lam__8___closed__7_once, _init_l_main___lam__8___closed__7);
v___x_430_ = l_main___lam__7___closed__4___boxed__const__1;
v___x_431_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_431_, 0, v___x_430_);
lean_ctor_set(v___x_431_, 1, v___x_429_);
return v___x_431_;
}
}
static lean_object* _init_l_main___lam__8___closed__9(void){
_start:
{
lean_object* v___x_432_; lean_object* v___x_433_; lean_object* v___x_434_; 
v___x_432_ = lean_obj_once(&l_main___lam__8___closed__8, &l_main___lam__8___closed__8_once, _init_l_main___lam__8___closed__8);
v___x_433_ = l_main___lam__7___closed__5___boxed__const__1;
v___x_434_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_434_, 0, v___x_433_);
lean_ctor_set(v___x_434_, 1, v___x_432_);
return v___x_434_;
}
}
static lean_object* _init_l_main___lam__8___closed__10(void){
_start:
{
lean_object* v___x_435_; lean_object* v___x_436_; lean_object* v___x_437_; 
v___x_435_ = lean_obj_once(&l_main___lam__8___closed__9, &l_main___lam__8___closed__9_once, _init_l_main___lam__8___closed__9);
v___x_436_ = l_main___lam__7___closed__1___boxed__const__1;
v___x_437_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_437_, 0, v___x_436_);
lean_ctor_set(v___x_437_, 1, v___x_435_);
return v___x_437_;
}
}
static lean_object* _init_l_main___lam__8___closed__11(void){
_start:
{
lean_object* v___x_438_; lean_object* v___x_439_; lean_object* v___x_440_; 
v___x_438_ = lean_obj_once(&l_main___lam__8___closed__10, &l_main___lam__8___closed__10_once, _init_l_main___lam__8___closed__10);
v___x_439_ = l_main___lam__7___closed__0___boxed__const__1;
v___x_440_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_440_, 0, v___x_439_);
lean_ctor_set(v___x_440_, 1, v___x_438_);
return v___x_440_;
}
}
static lean_object* _init_l_main___lam__8___closed__12(void){
_start:
{
lean_object* v___x_441_; lean_object* v___x_442_; lean_object* v___x_443_; 
v___x_441_ = lean_obj_once(&l_main___lam__8___closed__11, &l_main___lam__8___closed__11_once, _init_l_main___lam__8___closed__11);
v___x_442_ = l_main___lam__7___closed__3___boxed__const__1;
v___x_443_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_443_, 0, v___x_442_);
lean_ctor_set(v___x_443_, 1, v___x_441_);
return v___x_443_;
}
}
static lean_object* _init_l_main___lam__8___closed__13(void){
_start:
{
lean_object* v___x_444_; lean_object* v___x_445_; lean_object* v___x_446_; 
v___x_444_ = lean_obj_once(&l_main___lam__8___closed__12, &l_main___lam__8___closed__12_once, _init_l_main___lam__8___closed__12);
v___x_445_ = l_main___lam__7___closed__9___boxed__const__1;
v___x_446_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_446_, 0, v___x_445_);
lean_ctor_set(v___x_446_, 1, v___x_444_);
return v___x_446_;
}
}
static lean_object* _init_l_main___lam__8___closed__14(void){
_start:
{
lean_object* v___x_447_; lean_object* v___x_448_; lean_object* v___x_449_; 
v___x_447_ = lean_obj_once(&l_main___lam__8___closed__13, &l_main___lam__8___closed__13_once, _init_l_main___lam__8___closed__13);
v___x_448_ = l_main___lam__7___closed__10___boxed__const__1;
v___x_449_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_449_, 0, v___x_448_);
lean_ctor_set(v___x_449_, 1, v___x_447_);
return v___x_449_;
}
}
static lean_object* _init_l_main___lam__8___closed__15(void){
_start:
{
lean_object* v___x_450_; lean_object* v___x_451_; lean_object* v___x_452_; 
v___x_450_ = lean_obj_once(&l_main___lam__8___closed__14, &l_main___lam__8___closed__14_once, _init_l_main___lam__8___closed__14);
v___x_451_ = l_main___lam__7___closed__11___boxed__const__1;
v___x_452_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_452_, 0, v___x_451_);
lean_ctor_set(v___x_452_, 1, v___x_450_);
return v___x_452_;
}
}
static lean_object* _init_l_main___lam__8___closed__16(void){
_start:
{
lean_object* v___x_453_; lean_object* v___x_454_; 
v___x_453_ = lean_obj_once(&l_main___lam__8___closed__15, &l_main___lam__8___closed__15_once, _init_l_main___lam__8___closed__15);
v___x_454_ = lean_string_mk(v___x_453_);
return v___x_454_;
}
}
LEAN_EXPORT lean_object* l_main___lam__8(lean_object* v_n_455_){
_start:
{
lean_object* v___x_456_; uint8_t v___x_457_; 
v___x_456_ = lean_unsigned_to_nat(3u);
v___x_457_ = lean_nat_dec_eq(v_n_455_, v___x_456_);
if (v___x_457_ == 0)
{
lean_object* v___x_458_; 
v___x_458_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_458_;
}
else
{
lean_object* v___x_459_; 
v___x_459_ = lean_obj_once(&l_main___lam__8___closed__16, &l_main___lam__8___closed__16_once, _init_l_main___lam__8___closed__16);
return v___x_459_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__8___boxed(lean_object* v_n_460_){
_start:
{
lean_object* v_res_461_; 
v_res_461_ = l_main___lam__8(v_n_460_);
lean_dec(v_n_460_);
return v_res_461_;
}
}
static lean_object* _init_l_main___lam__9___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_462_; lean_object* v___x_463_; 
v___x_462_ = 121;
v___x_463_ = lean_box_uint32(v___x_462_);
return v___x_463_;
}
}
static lean_object* _init_l_main___lam__9___closed__0(void){
_start:
{
lean_object* v___x_464_; lean_object* v___x_465_; lean_object* v___x_466_; 
v___x_464_ = lean_box(0);
v___x_465_ = l_main___lam__9___closed__0___boxed__const__1;
v___x_466_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_466_, 0, v___x_465_);
lean_ctor_set(v___x_466_, 1, v___x_464_);
return v___x_466_;
}
}
static lean_object* _init_l_main___lam__9___closed__1___boxed__const__1(void){
_start:
{
uint32_t v___x_467_; lean_object* v___x_468_; 
v___x_467_ = 116;
v___x_468_ = lean_box_uint32(v___x_467_);
return v___x_468_;
}
}
static lean_object* _init_l_main___lam__9___closed__1(void){
_start:
{
lean_object* v___x_469_; lean_object* v___x_470_; lean_object* v___x_471_; 
v___x_469_ = lean_obj_once(&l_main___lam__9___closed__0, &l_main___lam__9___closed__0_once, _init_l_main___lam__9___closed__0);
v___x_470_ = l_main___lam__9___closed__1___boxed__const__1;
v___x_471_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_471_, 0, v___x_470_);
lean_ctor_set(v___x_471_, 1, v___x_469_);
return v___x_471_;
}
}
static lean_object* _init_l_main___lam__9___closed__2___boxed__const__1(void){
_start:
{
uint32_t v___x_472_; lean_object* v___x_473_; 
v___x_472_ = 112;
v___x_473_ = lean_box_uint32(v___x_472_);
return v___x_473_;
}
}
static lean_object* _init_l_main___lam__9___closed__2(void){
_start:
{
lean_object* v___x_474_; lean_object* v___x_475_; lean_object* v___x_476_; 
v___x_474_ = lean_obj_once(&l_main___lam__9___closed__1, &l_main___lam__9___closed__1_once, _init_l_main___lam__9___closed__1);
v___x_475_ = l_main___lam__9___closed__2___boxed__const__1;
v___x_476_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_476_, 0, v___x_475_);
lean_ctor_set(v___x_476_, 1, v___x_474_);
return v___x_476_;
}
}
static lean_object* _init_l_main___lam__9___closed__3___boxed__const__1(void){
_start:
{
uint32_t v___x_477_; lean_object* v___x_478_; 
v___x_477_ = 109;
v___x_478_ = lean_box_uint32(v___x_477_);
return v___x_478_;
}
}
static lean_object* _init_l_main___lam__9___closed__3(void){
_start:
{
lean_object* v___x_479_; lean_object* v___x_480_; lean_object* v___x_481_; 
v___x_479_ = lean_obj_once(&l_main___lam__9___closed__2, &l_main___lam__9___closed__2_once, _init_l_main___lam__9___closed__2);
v___x_480_ = l_main___lam__9___closed__3___boxed__const__1;
v___x_481_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_481_, 0, v___x_480_);
lean_ctor_set(v___x_481_, 1, v___x_479_);
return v___x_481_;
}
}
static lean_object* _init_l_main___lam__9___closed__4(void){
_start:
{
lean_object* v___x_482_; lean_object* v___x_483_; lean_object* v___x_484_; 
v___x_482_ = lean_obj_once(&l_main___lam__9___closed__3, &l_main___lam__9___closed__3_once, _init_l_main___lam__9___closed__3);
v___x_483_ = l_main___lam__7___closed__1___boxed__const__1;
v___x_484_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_484_, 0, v___x_483_);
lean_ctor_set(v___x_484_, 1, v___x_482_);
return v___x_484_;
}
}
static lean_object* _init_l_main___lam__9___closed__5(void){
_start:
{
lean_object* v___x_485_; lean_object* v___x_486_; 
v___x_485_ = lean_obj_once(&l_main___lam__9___closed__4, &l_main___lam__9___closed__4_once, _init_l_main___lam__9___closed__4);
v___x_486_ = lean_string_mk(v___x_485_);
return v___x_486_;
}
}
LEAN_EXPORT lean_object* l_main___lam__9(lean_object* v_n_487_){
_start:
{
lean_object* v___x_488_; uint8_t v___x_489_; 
v___x_488_ = lean_unsigned_to_nat(3u);
v___x_489_ = lean_nat_dec_eq(v_n_487_, v___x_488_);
if (v___x_489_ == 0)
{
lean_object* v___x_490_; 
v___x_490_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_490_;
}
else
{
lean_object* v___x_491_; 
v___x_491_ = lean_obj_once(&l_main___lam__9___closed__5, &l_main___lam__9___closed__5_once, _init_l_main___lam__9___closed__5);
return v___x_491_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__9___boxed(lean_object* v_n_492_){
_start:
{
lean_object* v_res_493_; 
v_res_493_ = l_main___lam__9(v_n_492_);
lean_dec(v_n_492_);
return v_res_493_;
}
}
LEAN_EXPORT lean_object* l_main___lam__10(lean_object* v___x_503_, lean_object* v_n_504_){
_start:
{
uint8_t v___x_505_; 
v___x_505_ = lean_nat_dec_eq(v_n_504_, v___x_503_);
if (v___x_505_ == 0)
{
lean_object* v___x_506_; 
lean_dec(v___x_503_);
v___x_506_ = lean_box(0);
return v___x_506_;
}
else
{
lean_object* v___x_507_; lean_object* v___x_508_; 
v___x_507_ = ((lean_object*)(l_main___lam__10___closed__2));
v___x_508_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_508_, 0, v___x_503_);
lean_ctor_set(v___x_508_, 1, v___x_507_);
return v___x_508_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__10___boxed(lean_object* v___x_509_, lean_object* v_n_510_){
_start:
{
lean_object* v_res_511_; 
v_res_511_ = l_main___lam__10(v___x_509_, v_n_510_);
lean_dec(v_n_510_);
return v_res_511_;
}
}
LEAN_EXPORT lean_object* l_main___lam__11(lean_object* v___x_512_, lean_object* v_n_513_){
_start:
{
lean_object* v___x_514_; uint8_t v___x_515_; 
v___x_514_ = lean_unsigned_to_nat(1u);
v___x_515_ = lean_nat_dec_eq(v_n_513_, v___x_514_);
if (v___x_515_ == 0)
{
lean_inc(v___x_512_);
return v___x_512_;
}
else
{
lean_object* v___x_516_; 
v___x_516_ = lean_unsigned_to_nat(4294967295u);
return v___x_516_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__11___boxed(lean_object* v___x_517_, lean_object* v_n_518_){
_start:
{
lean_object* v_res_519_; 
v_res_519_ = l_main___lam__11(v___x_517_, v_n_518_);
lean_dec(v_n_518_);
lean_dec(v___x_517_);
return v_res_519_;
}
}
LEAN_EXPORT lean_object* l_main___lam__12(lean_object* v___x_568_, lean_object* v_n_569_){
_start:
{
uint8_t v___x_570_; 
v___x_570_ = lean_nat_dec_eq(v_n_569_, v___x_568_);
if (v___x_570_ == 0)
{
lean_object* v___x_571_; 
lean_dec(v___x_568_);
v___x_571_ = lean_box(0);
return v___x_571_;
}
else
{
lean_object* v___x_572_; lean_object* v___x_573_; 
v___x_572_ = ((lean_object*)(l_main___lam__12___closed__15));
v___x_573_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_573_, 0, v___x_568_);
lean_ctor_set(v___x_573_, 1, v___x_572_);
return v___x_573_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__12___boxed(lean_object* v___x_574_, lean_object* v_n_575_){
_start:
{
lean_object* v_res_576_; 
v_res_576_ = l_main___lam__12(v___x_574_, v_n_575_);
lean_dec(v_n_575_);
return v_res_576_;
}
}
LEAN_EXPORT lean_object* l_main___lam__13(lean_object* v___x_577_, lean_object* v_n_578_){
_start:
{
lean_object* v___x_579_; uint8_t v___x_580_; 
v___x_579_ = lean_unsigned_to_nat(1u);
v___x_580_ = lean_nat_dec_eq(v_n_578_, v___x_579_);
if (v___x_580_ == 0)
{
lean_inc(v___x_577_);
return v___x_577_;
}
else
{
lean_object* v___x_581_; 
v___x_581_ = lean_unsigned_to_nat(123u);
return v___x_581_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__13___boxed(lean_object* v___x_582_, lean_object* v_n_583_){
_start:
{
lean_object* v_res_584_; 
v_res_584_ = l_main___lam__13(v___x_582_, v_n_583_);
lean_dec(v_n_583_);
lean_dec(v___x_582_);
return v_res_584_;
}
}
LEAN_EXPORT lean_object* l_main___lam__14(lean_object* v___x_588_, lean_object* v_n_589_){
_start:
{
uint8_t v___x_590_; 
v___x_590_ = lean_nat_dec_eq(v_n_589_, v___x_588_);
if (v___x_590_ == 0)
{
lean_object* v___x_591_; 
v___x_591_ = lean_box(0);
return v___x_591_;
}
else
{
lean_object* v___x_592_; 
v___x_592_ = ((lean_object*)(l_main___lam__14___closed__0));
return v___x_592_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__14___boxed(lean_object* v___x_593_, lean_object* v_n_594_){
_start:
{
lean_object* v_res_595_; 
v_res_595_ = l_main___lam__14(v___x_593_, v_n_594_);
lean_dec(v_n_594_);
lean_dec(v___x_593_);
return v_res_595_;
}
}
LEAN_EXPORT lean_object* l_main___lam__15(lean_object* v___x_596_, lean_object* v_n_597_){
_start:
{
lean_inc(v___x_596_);
return v___x_596_;
}
}
LEAN_EXPORT lean_object* l_main___lam__15___boxed(lean_object* v___x_598_, lean_object* v_n_599_){
_start:
{
lean_object* v_res_600_; 
v_res_600_ = l_main___lam__15(v___x_598_, v_n_599_);
lean_dec(v_n_599_);
lean_dec(v___x_598_);
return v_res_600_;
}
}
static lean_object* _init_l_main___lam__16___closed__0(void){
_start:
{
lean_object* v___x_601_; lean_object* v___x_602_; 
v___x_601_ = lean_unsigned_to_nat(1u);
v___x_602_ = lean_nat_to_int(v___x_601_);
return v___x_602_;
}
}
LEAN_EXPORT lean_object* l_main___lam__16(lean_object* v___x_603_, lean_object* v_n_604_){
_start:
{
lean_object* v___x_605_; uint8_t v___x_606_; 
v___x_605_ = lean_unsigned_to_nat(2u);
v___x_606_ = lean_nat_dec_eq(v_n_604_, v___x_605_);
if (v___x_606_ == 0)
{
lean_inc(v___x_603_);
return v___x_603_;
}
else
{
lean_object* v___x_607_; 
v___x_607_ = lean_obj_once(&l_main___lam__16___closed__0, &l_main___lam__16___closed__0_once, _init_l_main___lam__16___closed__0);
return v___x_607_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__16___boxed(lean_object* v___x_608_, lean_object* v_n_609_){
_start:
{
lean_object* v_res_610_; 
v_res_610_ = l_main___lam__16(v___x_608_, v_n_609_);
lean_dec(v_n_609_);
lean_dec(v___x_608_);
return v_res_610_;
}
}
LEAN_EXPORT lean_object* l_main___lam__17(lean_object* v___x_611_, lean_object* v_n_612_){
_start:
{
lean_inc(v___x_611_);
return v___x_611_;
}
}
LEAN_EXPORT lean_object* l_main___lam__17___boxed(lean_object* v___x_613_, lean_object* v_n_614_){
_start:
{
lean_object* v_res_615_; 
v_res_615_ = l_main___lam__17(v___x_613_, v_n_614_);
lean_dec(v_n_614_);
lean_dec(v___x_613_);
return v_res_615_;
}
}
LEAN_EXPORT lean_object* l_main___lam__18(lean_object* v___x_616_, lean_object* v___x_617_, lean_object* v_n_618_){
_start:
{
uint8_t v___x_619_; 
v___x_619_ = lean_nat_dec_eq(v_n_618_, v___x_616_);
if (v___x_619_ == 0)
{
lean_inc(v___x_617_);
return v___x_617_;
}
else
{
lean_object* v___x_620_; 
v___x_620_ = lean_unsigned_to_nat(7u);
return v___x_620_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__18___boxed(lean_object* v___x_621_, lean_object* v___x_622_, lean_object* v_n_623_){
_start:
{
lean_object* v_res_624_; 
v_res_624_ = l_main___lam__18(v___x_621_, v___x_622_, v_n_623_);
lean_dec(v_n_623_);
lean_dec(v___x_622_);
lean_dec(v___x_621_);
return v_res_624_;
}
}
LEAN_EXPORT lean_object* l_main___lam__19(lean_object* v___x_625_, lean_object* v___x_626_, lean_object* v_n_627_){
_start:
{
uint8_t v___x_628_; 
v___x_628_ = lean_nat_dec_eq(v_n_627_, v___x_625_);
if (v___x_628_ == 0)
{
lean_inc(v___x_626_);
return v___x_626_;
}
else
{
lean_inc(v___x_625_);
return v___x_625_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__19___boxed(lean_object* v___x_629_, lean_object* v___x_630_, lean_object* v_n_631_){
_start:
{
lean_object* v_res_632_; 
v_res_632_ = l_main___lam__19(v___x_629_, v___x_630_, v_n_631_);
lean_dec(v_n_631_);
lean_dec(v___x_630_);
lean_dec(v___x_629_);
return v_res_632_;
}
}
LEAN_EXPORT lean_object* l_main___lam__20(lean_object* v___x_633_, lean_object* v___x_634_, lean_object* v___x_635_, lean_object* v_n_636_){
_start:
{
uint8_t v___x_637_; 
v___x_637_ = lean_nat_dec_eq(v_n_636_, v___x_633_);
if (v___x_637_ == 0)
{
lean_inc(v___x_634_);
return v___x_634_;
}
else
{
lean_object* v___x_638_; 
v___x_638_ = lean_int_neg(v___x_635_);
return v___x_638_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__20___boxed(lean_object* v___x_639_, lean_object* v___x_640_, lean_object* v___x_641_, lean_object* v_n_642_){
_start:
{
lean_object* v_res_643_; 
v_res_643_ = l_main___lam__20(v___x_639_, v___x_640_, v___x_641_, v_n_642_);
lean_dec(v_n_642_);
lean_dec(v___x_641_);
lean_dec(v___x_640_);
lean_dec(v___x_639_);
return v_res_643_;
}
}
static lean_object* _init_l_main___lam__21___closed__0(void){
_start:
{
lean_object* v___x_644_; lean_object* v___x_645_; 
v___x_644_ = lean_cstr_to_nat("4294967296");
v___x_645_ = lean_nat_to_int(v___x_644_);
return v___x_645_;
}
}
LEAN_EXPORT lean_object* l_main___lam__21(lean_object* v___x_646_, lean_object* v___x_647_, lean_object* v_n_648_){
_start:
{
uint8_t v___x_649_; 
v___x_649_ = lean_nat_dec_eq(v_n_648_, v___x_646_);
if (v___x_649_ == 0)
{
lean_inc(v___x_647_);
return v___x_647_;
}
else
{
lean_object* v___x_650_; 
v___x_650_ = lean_obj_once(&l_main___lam__21___closed__0, &l_main___lam__21___closed__0_once, _init_l_main___lam__21___closed__0);
return v___x_650_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__21___boxed(lean_object* v___x_651_, lean_object* v___x_652_, lean_object* v_n_653_){
_start:
{
lean_object* v_res_654_; 
v_res_654_ = l_main___lam__21(v___x_651_, v___x_652_, v_n_653_);
lean_dec(v_n_653_);
lean_dec(v___x_652_);
lean_dec(v___x_651_);
return v_res_654_;
}
}
static lean_object* _init_l_main___lam__23___closed__0___boxed__const__1(void){
_start:
{
uint32_t v___x_655_; lean_object* v___x_656_; 
v___x_655_ = 120;
v___x_656_ = lean_box_uint32(v___x_655_);
return v___x_656_;
}
}
static lean_object* _init_l_main___lam__23___closed__0(void){
_start:
{
lean_object* v___x_657_; lean_object* v___x_658_; lean_object* v___x_659_; 
v___x_657_ = lean_box(0);
v___x_658_ = l_main___lam__23___closed__0___boxed__const__1;
v___x_659_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_659_, 0, v___x_658_);
lean_ctor_set(v___x_659_, 1, v___x_657_);
return v___x_659_;
}
}
static lean_object* _init_l_main___lam__23___closed__1(void){
_start:
{
lean_object* v___x_660_; lean_object* v___x_661_; lean_object* v___x_662_; 
v___x_660_ = lean_obj_once(&l_main___lam__23___closed__0, &l_main___lam__23___closed__0_once, _init_l_main___lam__23___closed__0);
v___x_661_ = l_main___lam__8___closed__4___boxed__const__1;
v___x_662_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_662_, 0, v___x_661_);
lean_ctor_set(v___x_662_, 1, v___x_660_);
return v___x_662_;
}
}
static lean_object* _init_l_main___lam__23___closed__2(void){
_start:
{
lean_object* v___x_663_; lean_object* v___x_664_; lean_object* v___x_665_; 
v___x_663_ = lean_obj_once(&l_main___lam__23___closed__1, &l_main___lam__23___closed__1_once, _init_l_main___lam__23___closed__1);
v___x_664_ = l_main___lam__9___closed__3___boxed__const__1;
v___x_665_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_665_, 0, v___x_664_);
lean_ctor_set(v___x_665_, 1, v___x_663_);
return v___x_665_;
}
}
static lean_object* _init_l_main___lam__23___closed__3(void){
_start:
{
lean_object* v___x_666_; lean_object* v___x_667_; 
v___x_666_ = lean_obj_once(&l_main___lam__23___closed__2, &l_main___lam__23___closed__2_once, _init_l_main___lam__23___closed__2);
v___x_667_ = lean_string_mk(v___x_666_);
return v___x_667_;
}
}
LEAN_EXPORT lean_object* l_main___lam__23(lean_object* v___x_668_, lean_object* v_n_669_){
_start:
{
uint8_t v___x_670_; 
v___x_670_ = lean_nat_dec_eq(v_n_669_, v___x_668_);
if (v___x_670_ == 0)
{
lean_object* v___x_671_; 
v___x_671_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_671_;
}
else
{
lean_object* v___x_672_; 
v___x_672_ = lean_obj_once(&l_main___lam__23___closed__3, &l_main___lam__23___closed__3_once, _init_l_main___lam__23___closed__3);
return v___x_672_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__23___boxed(lean_object* v___x_673_, lean_object* v_n_674_){
_start:
{
lean_object* v_res_675_; 
v_res_675_ = l_main___lam__23(v___x_673_, v_n_674_);
lean_dec(v_n_674_);
lean_dec(v___x_673_);
return v_res_675_;
}
}
LEAN_EXPORT lean_object* l_main___lam__22(lean_object* v___x_703_, lean_object* v___x_704_, lean_object* v___x_705_, lean_object* v___x_706_, lean_object* v_n_707_){
_start:
{
uint8_t v___x_708_; 
v___x_708_ = lean_nat_dec_eq(v_n_707_, v___x_703_);
if (v___x_708_ == 0)
{
lean_object* v___x_709_; 
lean_dec(v___x_706_);
lean_dec(v___x_705_);
lean_dec(v___x_704_);
lean_dec(v___x_703_);
v___x_709_ = lean_box(0);
return v___x_709_;
}
else
{
lean_object* v___x_710_; lean_object* v___x_711_; lean_object* v___x_712_; lean_object* v___x_713_; lean_object* v___x_714_; lean_object* v___x_715_; lean_object* v___x_716_; lean_object* v___x_717_; lean_object* v___x_718_; lean_object* v___x_719_; lean_object* v___x_720_; 
v___x_710_ = lean_unsigned_to_nat(255u);
v___x_711_ = lean_unsigned_to_nat(254u);
v___x_712_ = lean_unsigned_to_nat(253u);
v___x_713_ = ((lean_object*)(l_main___lam__22___closed__8));
v___x_714_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_714_, 0, v___x_704_);
lean_ctor_set(v___x_714_, 1, v___x_713_);
v___x_715_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_715_, 0, v___x_712_);
lean_ctor_set(v___x_715_, 1, v___x_714_);
v___x_716_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_716_, 0, v___x_705_);
lean_ctor_set(v___x_716_, 1, v___x_715_);
v___x_717_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_717_, 0, v___x_711_);
lean_ctor_set(v___x_717_, 1, v___x_716_);
v___x_718_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_718_, 0, v___x_706_);
lean_ctor_set(v___x_718_, 1, v___x_717_);
v___x_719_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_719_, 0, v___x_710_);
lean_ctor_set(v___x_719_, 1, v___x_718_);
v___x_720_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_720_, 0, v___x_703_);
lean_ctor_set(v___x_720_, 1, v___x_719_);
return v___x_720_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__22___boxed(lean_object* v___x_721_, lean_object* v___x_722_, lean_object* v___x_723_, lean_object* v___x_724_, lean_object* v_n_725_){
_start:
{
lean_object* v_res_726_; 
v_res_726_ = l_main___lam__22(v___x_721_, v___x_722_, v___x_723_, v___x_724_, v_n_725_);
lean_dec(v_n_725_);
return v_res_726_;
}
}
static lean_object* _init_l_main___lam__24___closed__0(void){
_start:
{
lean_object* v___x_727_; lean_object* v___x_728_; lean_object* v___x_729_; 
v___x_727_ = lean_box(0);
v___x_728_ = l_main___lam__9___closed__2___boxed__const__1;
v___x_729_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_729_, 0, v___x_728_);
lean_ctor_set(v___x_729_, 1, v___x_727_);
return v___x_729_;
}
}
static lean_object* _init_l_main___lam__24___closed__1(void){
_start:
{
lean_object* v___x_730_; lean_object* v___x_731_; lean_object* v___x_732_; 
v___x_730_ = lean_obj_once(&l_main___lam__24___closed__0, &l_main___lam__24___closed__0_once, _init_l_main___lam__24___closed__0);
v___x_731_ = l_main___lam__8___closed__4___boxed__const__1;
v___x_732_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_732_, 0, v___x_731_);
lean_ctor_set(v___x_732_, 1, v___x_730_);
return v___x_732_;
}
}
static lean_object* _init_l_main___lam__24___closed__2(void){
_start:
{
lean_object* v___x_733_; lean_object* v___x_734_; lean_object* v___x_735_; 
v___x_733_ = lean_obj_once(&l_main___lam__24___closed__1, &l_main___lam__24___closed__1_once, _init_l_main___lam__24___closed__1);
v___x_734_ = l_main___lam__7___closed__0___boxed__const__1;
v___x_735_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_735_, 0, v___x_734_);
lean_ctor_set(v___x_735_, 1, v___x_733_);
return v___x_735_;
}
}
static lean_object* _init_l_main___lam__24___closed__3___boxed__const__1(void){
_start:
{
uint32_t v___x_736_; lean_object* v___x_737_; 
v___x_736_ = 119;
v___x_737_ = lean_box_uint32(v___x_736_);
return v___x_737_;
}
}
static lean_object* _init_l_main___lam__24___closed__3(void){
_start:
{
lean_object* v___x_738_; lean_object* v___x_739_; lean_object* v___x_740_; 
v___x_738_ = lean_obj_once(&l_main___lam__24___closed__2, &l_main___lam__24___closed__2_once, _init_l_main___lam__24___closed__2);
v___x_739_ = l_main___lam__24___closed__3___boxed__const__1;
v___x_740_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_740_, 0, v___x_739_);
lean_ctor_set(v___x_740_, 1, v___x_738_);
return v___x_740_;
}
}
static lean_object* _init_l_main___lam__24___closed__4(void){
_start:
{
lean_object* v___x_741_; lean_object* v___x_742_; 
v___x_741_ = lean_obj_once(&l_main___lam__24___closed__3, &l_main___lam__24___closed__3_once, _init_l_main___lam__24___closed__3);
v___x_742_ = lean_string_mk(v___x_741_);
return v___x_742_;
}
}
LEAN_EXPORT lean_object* l_main___lam__24(lean_object* v___x_743_, lean_object* v_n_744_){
_start:
{
uint8_t v___x_745_; 
v___x_745_ = lean_nat_dec_eq(v_n_744_, v___x_743_);
if (v___x_745_ == 0)
{
lean_object* v___x_746_; 
v___x_746_ = lean_obj_once(&l_main___lam__2___closed__0, &l_main___lam__2___closed__0_once, _init_l_main___lam__2___closed__0);
return v___x_746_;
}
else
{
lean_object* v___x_747_; 
v___x_747_ = lean_obj_once(&l_main___lam__24___closed__4, &l_main___lam__24___closed__4_once, _init_l_main___lam__24___closed__4);
return v___x_747_;
}
}
}
LEAN_EXPORT lean_object* l_main___lam__24___boxed(lean_object* v___x_748_, lean_object* v_n_749_){
_start:
{
lean_object* v_res_750_; 
v_res_750_ = l_main___lam__24(v___x_748_, v_n_749_);
lean_dec(v_n_749_);
lean_dec(v___x_748_);
return v_res_750_;
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(lean_object* v_s_751_){
_start:
{
lean_object* v___x_753_; lean_object* v_putStr_754_; lean_object* v___x_755_; 
v___x_753_ = lean_get_stdout();
v_putStr_754_ = lean_ctor_get(v___x_753_, 4);
lean_inc_ref(v_putStr_754_);
lean_dec_ref(v___x_753_);
v___x_755_ = lean_apply_2(v_putStr_754_, v_s_751_, lean_box(0));
return v___x_755_;
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00main_spec__0_spec__0___boxed(lean_object* v_s_756_, lean_object* v_a_757_){
_start:
{
lean_object* v_res_758_; 
v_res_758_ = l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(v_s_756_);
return v_res_758_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0(lean_object* v_s_759_){
_start:
{
uint32_t v___x_761_; lean_object* v___x_762_; lean_object* v___x_763_; 
v___x_761_ = 10;
v___x_762_ = lean_string_push(v_s_759_, v___x_761_);
v___x_763_ = l_IO_print___at___00IO_println___at___00main_spec__0_spec__0(v___x_762_);
return v___x_763_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00main_spec__0___boxed(lean_object* v_s_764_, lean_object* v_a_765_){
_start:
{
lean_object* v_res_766_; 
v_res_766_ = l_IO_println___at___00main_spec__0(v_s_764_);
return v_res_766_;
}
}
static lean_object* _init_l_main___closed__17(void){
_start:
{
lean_object* v___x_795_; lean_object* v___f_796_; 
v___x_795_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___f_796_ = lean_alloc_closure((void*)(l_main___lam__16___boxed), 2, 1);
lean_closure_set(v___f_796_, 0, v___x_795_);
return v___f_796_;
}
}
static lean_object* _init_l_main___closed__18(void){
_start:
{
lean_object* v___x_797_; lean_object* v___f_798_; 
v___x_797_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___f_798_ = lean_alloc_closure((void*)(l_main___lam__17___boxed), 2, 1);
lean_closure_set(v___f_798_, 0, v___x_797_);
return v___f_798_;
}
}
static lean_object* _init_l_main___closed__19(void){
_start:
{
lean_object* v___x_799_; lean_object* v___x_800_; lean_object* v___x_801_; lean_object* v___x_802_; lean_object* v_s__0__0_803_; 
v___x_799_ = lean_box(0);
v___x_800_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_801_ = lean_unsigned_to_nat(0u);
v___x_802_ = ((lean_object*)(l_main___closed__10));
v_s__0__0_803_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_s__0__0_803_, 0, v___x_802_);
lean_ctor_set(v_s__0__0_803_, 1, v___x_801_);
lean_ctor_set(v_s__0__0_803_, 2, v___x_800_);
lean_ctor_set(v_s__0__0_803_, 3, v___x_799_);
return v_s__0__0_803_;
}
}
static lean_object* _init_l_main___closed__20(void){
_start:
{
lean_object* v___f_804_; lean_object* v___f_805_; lean_object* v___f_806_; lean_object* v___f_807_; lean_object* v___f_808_; lean_object* v___x_809_; 
v___f_804_ = ((lean_object*)(l_main___closed__12));
v___f_805_ = ((lean_object*)(l_main___closed__11));
v___f_806_ = ((lean_object*)(l_main___closed__6));
v___f_807_ = ((lean_object*)(l_main___closed__5));
v___f_808_ = lean_obj_once(&l_main___closed__17, &l_main___closed__17_once, _init_l_main___closed__17);
v___x_809_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_809_, 0, v___f_808_);
lean_ctor_set(v___x_809_, 1, v___f_807_);
lean_ctor_set(v___x_809_, 2, v___f_806_);
lean_ctor_set(v___x_809_, 3, v___f_805_);
lean_ctor_set(v___x_809_, 4, v___f_804_);
return v___x_809_;
}
}
static lean_object* _init_l_main___closed__21(void){
_start:
{
lean_object* v___x_810_; lean_object* v___x_811_; lean_object* v___x_812_; lean_object* v_s__0__0_813_; lean_object* v___x_814_; lean_object* v_r__0__0_815_; 
v___x_810_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_811_ = lean_obj_once(&l_main___closed__20, &l_main___closed__20_once, _init_l_main___closed__20);
v___x_812_ = lean_unsigned_to_nat(0u);
v_s__0__0_813_ = lean_obj_once(&l_main___closed__19, &l_main___closed__19_once, _init_l_main___closed__19);
v___x_814_ = l_MachineRuntime_model;
v_r__0__0_815_ = l_FormalSpecAgent_TypedMachine_external(v___x_814_, v_s__0__0_813_, v___x_812_, v___x_811_, v___x_810_);
return v_r__0__0_815_;
}
}
static lean_object* _init_l_main___closed__22(void){
_start:
{
lean_object* v_r__0__0_816_; lean_object* v_s__0__0_817_; lean_object* v___x_818_; lean_object* v___x_819_; 
v_r__0__0_816_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v_s__0__0_817_ = lean_obj_once(&l_main___closed__19, &l_main___closed__19_once, _init_l_main___closed__19);
v___x_818_ = l_MachineRuntime_schema;
v___x_819_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_818_, v_s__0__0_817_, v_r__0__0_816_);
return v___x_819_;
}
}
static lean_object* _init_l_main___closed__23(void){
_start:
{
lean_object* v___x_820_; lean_object* v___x_821_; 
v___x_820_ = lean_obj_once(&l_main___closed__22, &l_main___closed__22_once, _init_l_main___closed__22);
v___x_821_ = l_outcomeText(v___x_820_);
return v___x_821_;
}
}
static lean_object* _init_l_main___closed__24(void){
_start:
{
lean_object* v_r__0__0_822_; lean_object* v_s__0__0_823_; lean_object* v___x_824_; 
v_r__0__0_822_ = lean_obj_once(&l_main___closed__21, &l_main___closed__21_once, _init_l_main___closed__21);
v_s__0__0_823_ = lean_obj_once(&l_main___closed__19, &l_main___closed__19_once, _init_l_main___closed__19);
v___x_824_ = l_FormalSpecAgent_TypedMachine_rollback(v_s__0__0_823_, v_r__0__0_822_);
return v___x_824_;
}
}
static lean_object* _init_l_main___closed__25(void){
_start:
{
lean_object* v___f_825_; lean_object* v___f_826_; lean_object* v___f_827_; lean_object* v___f_828_; lean_object* v___f_829_; lean_object* v___x_830_; 
v___f_825_ = ((lean_object*)(l_main___closed__14));
v___f_826_ = ((lean_object*)(l_main___closed__13));
v___f_827_ = ((lean_object*)(l_main___closed__7));
v___f_828_ = ((lean_object*)(l_main___closed__5));
v___f_829_ = lean_obj_once(&l_main___closed__18, &l_main___closed__18_once, _init_l_main___closed__18);
v___x_830_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_830_, 0, v___f_829_);
lean_ctor_set(v___x_830_, 1, v___f_828_);
lean_ctor_set(v___x_830_, 2, v___f_827_);
lean_ctor_set(v___x_830_, 3, v___f_826_);
lean_ctor_set(v___x_830_, 4, v___f_825_);
return v___x_830_;
}
}
static lean_object* _init_l_main___closed__28(void){
_start:
{
lean_object* v___x_837_; lean_object* v___x_838_; lean_object* v___x_839_; lean_object* v___x_840_; lean_object* v___x_841_; lean_object* v___x_842_; 
v___x_837_ = lean_obj_once(&l_main___lam__16___closed__0, &l_main___lam__16___closed__0_once, _init_l_main___lam__16___closed__0);
v___x_838_ = lean_obj_once(&l_main___closed__25, &l_main___closed__25_once, _init_l_main___closed__25);
v___x_839_ = lean_unsigned_to_nat(0u);
v___x_840_ = lean_obj_once(&l_main___closed__24, &l_main___closed__24_once, _init_l_main___closed__24);
v___x_841_ = l_MachineRuntime_model;
v___x_842_ = l_FormalSpecAgent_TypedMachine_external(v___x_841_, v___x_840_, v___x_839_, v___x_838_, v___x_837_);
return v___x_842_;
}
}
static lean_object* _init_l_main___closed__29(void){
_start:
{
lean_object* v___x_843_; lean_object* v___x_844_; lean_object* v___x_845_; lean_object* v___x_846_; 
v___x_843_ = lean_obj_once(&l_main___closed__28, &l_main___closed__28_once, _init_l_main___closed__28);
v___x_844_ = lean_obj_once(&l_main___closed__24, &l_main___closed__24_once, _init_l_main___closed__24);
v___x_845_ = l_MachineRuntime_schema;
v___x_846_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_845_, v___x_844_, v___x_843_);
return v___x_846_;
}
}
static lean_object* _init_l_main___closed__30(void){
_start:
{
lean_object* v___x_847_; lean_object* v___x_848_; 
v___x_847_ = lean_obj_once(&l_main___closed__29, &l_main___closed__29_once, _init_l_main___closed__29);
v___x_848_ = l_outcomeText(v___x_847_);
return v___x_848_;
}
}
static lean_object* _init_l_main___closed__31(void){
_start:
{
lean_object* v___x_849_; lean_object* v___x_850_; lean_object* v___x_851_; 
v___x_849_ = lean_obj_once(&l_main___closed__28, &l_main___closed__28_once, _init_l_main___closed__28);
v___x_850_ = lean_obj_once(&l_main___closed__24, &l_main___closed__24_once, _init_l_main___closed__24);
v___x_851_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_850_, v___x_849_);
return v___x_851_;
}
}
static lean_object* _init_l_main___closed__32(void){
_start:
{
lean_object* v___f_852_; lean_object* v___f_853_; lean_object* v___f_854_; lean_object* v___f_855_; lean_object* v___f_856_; lean_object* v___x_857_; 
v___f_852_ = ((lean_object*)(l_main___closed__26));
v___f_853_ = ((lean_object*)(l_main___closed__15));
v___f_854_ = ((lean_object*)(l_main___closed__8));
v___f_855_ = ((lean_object*)(l_main___closed__1));
v___f_856_ = lean_obj_once(&l_main___closed__18, &l_main___closed__18_once, _init_l_main___closed__18);
v___x_857_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_857_, 0, v___f_856_);
lean_ctor_set(v___x_857_, 1, v___f_855_);
lean_ctor_set(v___x_857_, 2, v___f_854_);
lean_ctor_set(v___x_857_, 3, v___f_853_);
lean_ctor_set(v___x_857_, 4, v___f_852_);
return v___x_857_;
}
}
static lean_object* _init_l_main___closed__33(void){
_start:
{
lean_object* v___x_858_; lean_object* v___x_859_; lean_object* v___x_860_; lean_object* v___f_861_; 
v___x_858_ = lean_obj_once(&l_main___lam__16___closed__0, &l_main___lam__16___closed__0_once, _init_l_main___lam__16___closed__0);
v___x_859_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_860_ = lean_unsigned_to_nat(2u);
v___f_861_ = lean_alloc_closure((void*)(l_main___lam__20___boxed), 4, 3);
lean_closure_set(v___f_861_, 0, v___x_860_);
lean_closure_set(v___f_861_, 1, v___x_859_);
lean_closure_set(v___f_861_, 2, v___x_858_);
return v___f_861_;
}
}
static lean_object* _init_l_main___closed__34(void){
_start:
{
lean_object* v___x_862_; lean_object* v___x_863_; lean_object* v___f_864_; 
v___x_862_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_863_ = lean_unsigned_to_nat(2u);
v___f_864_ = lean_alloc_closure((void*)(l_main___lam__21___boxed), 3, 2);
lean_closure_set(v___f_864_, 0, v___x_863_);
lean_closure_set(v___f_864_, 1, v___x_862_);
return v___f_864_;
}
}
static lean_object* _init_l_main___closed__35(void){
_start:
{
lean_object* v___x_865_; lean_object* v___x_866_; 
v___x_865_ = lean_unsigned_to_nat(2u);
v___x_866_ = lean_nat_to_int(v___x_865_);
return v___x_866_;
}
}
static lean_object* _init_l_main___closed__36(void){
_start:
{
lean_object* v___x_867_; lean_object* v___x_868_; lean_object* v___x_869_; lean_object* v___f_870_; 
v___x_867_ = lean_obj_once(&l_main___closed__35, &l_main___closed__35_once, _init_l_main___closed__35);
v___x_868_ = lean_obj_once(&l_main___lam__0___closed__0, &l_main___lam__0___closed__0_once, _init_l_main___lam__0___closed__0);
v___x_869_ = lean_unsigned_to_nat(2u);
v___f_870_ = lean_alloc_closure((void*)(l_main___lam__20___boxed), 4, 3);
lean_closure_set(v___f_870_, 0, v___x_869_);
lean_closure_set(v___f_870_, 1, v___x_868_);
lean_closure_set(v___f_870_, 2, v___x_867_);
return v___f_870_;
}
}
static lean_object* _init_l_main___closed__37(void){
_start:
{
lean_object* v___x_871_; lean_object* v___x_872_; lean_object* v___x_873_; lean_object* v___x_874_; lean_object* v___x_875_; lean_object* v___x_876_; 
v___x_871_ = lean_obj_once(&l_main___closed__35, &l_main___closed__35_once, _init_l_main___closed__35);
v___x_872_ = lean_obj_once(&l_main___closed__32, &l_main___closed__32_once, _init_l_main___closed__32);
v___x_873_ = lean_unsigned_to_nat(0u);
v___x_874_ = lean_obj_once(&l_main___closed__31, &l_main___closed__31_once, _init_l_main___closed__31);
v___x_875_ = l_MachineRuntime_model;
v___x_876_ = l_FormalSpecAgent_TypedMachine_external(v___x_875_, v___x_874_, v___x_873_, v___x_872_, v___x_871_);
return v___x_876_;
}
}
static lean_object* _init_l_main___closed__38(void){
_start:
{
lean_object* v___x_877_; lean_object* v___x_878_; lean_object* v___x_879_; lean_object* v___x_880_; 
v___x_877_ = lean_obj_once(&l_main___closed__37, &l_main___closed__37_once, _init_l_main___closed__37);
v___x_878_ = lean_obj_once(&l_main___closed__31, &l_main___closed__31_once, _init_l_main___closed__31);
v___x_879_ = l_MachineRuntime_schema;
v___x_880_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_879_, v___x_878_, v___x_877_);
return v___x_880_;
}
}
static lean_object* _init_l_main___closed__39(void){
_start:
{
lean_object* v___x_881_; lean_object* v___x_882_; 
v___x_881_ = lean_obj_once(&l_main___closed__38, &l_main___closed__38_once, _init_l_main___closed__38);
v___x_882_ = l_outcomeText(v___x_881_);
return v___x_882_;
}
}
static lean_object* _init_l_main___closed__40(void){
_start:
{
lean_object* v___x_883_; lean_object* v___x_884_; lean_object* v___x_885_; 
v___x_883_ = lean_obj_once(&l_main___closed__37, &l_main___closed__37_once, _init_l_main___closed__37);
v___x_884_ = lean_obj_once(&l_main___closed__31, &l_main___closed__31_once, _init_l_main___closed__31);
v___x_885_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_884_, v___x_883_);
return v___x_885_;
}
}
static lean_object* _init_l_main___closed__41(void){
_start:
{
lean_object* v___f_886_; lean_object* v___f_887_; lean_object* v___f_888_; lean_object* v___f_889_; lean_object* v___f_890_; lean_object* v___x_891_; 
v___f_886_ = ((lean_object*)(l_main___closed__16));
v___f_887_ = ((lean_object*)(l_main___closed__3));
v___f_888_ = ((lean_object*)(l_main___closed__9));
v___f_889_ = ((lean_object*)(l_main___closed__5));
v___f_890_ = lean_obj_once(&l_main___closed__33, &l_main___closed__33_once, _init_l_main___closed__33);
v___x_891_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_891_, 0, v___f_890_);
lean_ctor_set(v___x_891_, 1, v___f_889_);
lean_ctor_set(v___x_891_, 2, v___f_888_);
lean_ctor_set(v___x_891_, 3, v___f_887_);
lean_ctor_set(v___x_891_, 4, v___f_886_);
return v___x_891_;
}
}
static lean_object* _init_l_main___closed__45(void){
_start:
{
lean_object* v___x_901_; lean_object* v___x_902_; 
v___x_901_ = lean_unsigned_to_nat(3u);
v___x_902_ = lean_nat_to_int(v___x_901_);
return v___x_902_;
}
}
static lean_object* _init_l_main___closed__46(void){
_start:
{
lean_object* v___x_903_; lean_object* v___x_904_; lean_object* v___x_905_; lean_object* v___x_906_; lean_object* v___x_907_; lean_object* v___x_908_; 
v___x_903_ = lean_obj_once(&l_main___closed__45, &l_main___closed__45_once, _init_l_main___closed__45);
v___x_904_ = lean_obj_once(&l_main___closed__41, &l_main___closed__41_once, _init_l_main___closed__41);
v___x_905_ = lean_unsigned_to_nat(0u);
v___x_906_ = lean_obj_once(&l_main___closed__40, &l_main___closed__40_once, _init_l_main___closed__40);
v___x_907_ = l_MachineRuntime_model;
v___x_908_ = l_FormalSpecAgent_TypedMachine_external(v___x_907_, v___x_906_, v___x_905_, v___x_904_, v___x_903_);
return v___x_908_;
}
}
static lean_object* _init_l_main___closed__47(void){
_start:
{
lean_object* v___x_909_; lean_object* v___x_910_; lean_object* v___x_911_; lean_object* v___x_912_; 
v___x_909_ = lean_obj_once(&l_main___closed__46, &l_main___closed__46_once, _init_l_main___closed__46);
v___x_910_ = lean_obj_once(&l_main___closed__40, &l_main___closed__40_once, _init_l_main___closed__40);
v___x_911_ = l_MachineRuntime_schema;
v___x_912_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_911_, v___x_910_, v___x_909_);
return v___x_912_;
}
}
static lean_object* _init_l_main___closed__48(void){
_start:
{
lean_object* v___x_913_; lean_object* v___x_914_; 
v___x_913_ = lean_obj_once(&l_main___closed__47, &l_main___closed__47_once, _init_l_main___closed__47);
v___x_914_ = l_outcomeText(v___x_913_);
return v___x_914_;
}
}
static lean_object* _init_l_main___closed__49(void){
_start:
{
lean_object* v___x_915_; lean_object* v___x_916_; lean_object* v___x_917_; 
v___x_915_ = lean_obj_once(&l_main___closed__46, &l_main___closed__46_once, _init_l_main___closed__46);
v___x_916_ = lean_obj_once(&l_main___closed__40, &l_main___closed__40_once, _init_l_main___closed__40);
v___x_917_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_916_, v___x_915_);
return v___x_917_;
}
}
static lean_object* _init_l_main___closed__50(void){
_start:
{
lean_object* v___f_918_; lean_object* v___f_919_; lean_object* v___f_920_; lean_object* v___f_921_; lean_object* v___f_922_; lean_object* v___x_923_; 
v___f_918_ = ((lean_object*)(l_main___closed__27));
v___f_919_ = ((lean_object*)(l_main___closed__43));
v___f_920_ = ((lean_object*)(l_main___closed__42));
v___f_921_ = ((lean_object*)(l_main___closed__5));
v___f_922_ = lean_obj_once(&l_main___closed__36, &l_main___closed__36_once, _init_l_main___closed__36);
v___x_923_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_923_, 0, v___f_922_);
lean_ctor_set(v___x_923_, 1, v___f_921_);
lean_ctor_set(v___x_923_, 2, v___f_920_);
lean_ctor_set(v___x_923_, 3, v___f_919_);
lean_ctor_set(v___x_923_, 4, v___f_918_);
return v___x_923_;
}
}
static lean_object* _init_l_main___closed__51(void){
_start:
{
lean_object* v___x_924_; lean_object* v___x_925_; 
v___x_924_ = lean_unsigned_to_nat(4u);
v___x_925_ = lean_nat_to_int(v___x_924_);
return v___x_925_;
}
}
static lean_object* _init_l_main___closed__52(void){
_start:
{
lean_object* v___x_926_; lean_object* v___x_927_; lean_object* v___x_928_; lean_object* v___x_929_; lean_object* v___x_930_; lean_object* v___x_931_; 
v___x_926_ = lean_obj_once(&l_main___closed__51, &l_main___closed__51_once, _init_l_main___closed__51);
v___x_927_ = lean_obj_once(&l_main___closed__50, &l_main___closed__50_once, _init_l_main___closed__50);
v___x_928_ = lean_unsigned_to_nat(0u);
v___x_929_ = lean_obj_once(&l_main___closed__49, &l_main___closed__49_once, _init_l_main___closed__49);
v___x_930_ = l_MachineRuntime_model;
v___x_931_ = l_FormalSpecAgent_TypedMachine_external(v___x_930_, v___x_929_, v___x_928_, v___x_927_, v___x_926_);
return v___x_931_;
}
}
static lean_object* _init_l_main___closed__53(void){
_start:
{
lean_object* v___x_932_; lean_object* v___x_933_; lean_object* v___x_934_; lean_object* v___x_935_; 
v___x_932_ = lean_obj_once(&l_main___closed__52, &l_main___closed__52_once, _init_l_main___closed__52);
v___x_933_ = lean_obj_once(&l_main___closed__49, &l_main___closed__49_once, _init_l_main___closed__49);
v___x_934_ = l_MachineRuntime_schema;
v___x_935_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_934_, v___x_933_, v___x_932_);
return v___x_935_;
}
}
static lean_object* _init_l_main___closed__54(void){
_start:
{
lean_object* v___x_936_; lean_object* v___x_937_; 
v___x_936_ = lean_obj_once(&l_main___closed__53, &l_main___closed__53_once, _init_l_main___closed__53);
v___x_937_ = l_outcomeText(v___x_936_);
return v___x_937_;
}
}
static lean_object* _init_l_main___closed__55(void){
_start:
{
lean_object* v___x_938_; lean_object* v___x_939_; lean_object* v___x_940_; 
v___x_938_ = lean_obj_once(&l_main___closed__52, &l_main___closed__52_once, _init_l_main___closed__52);
v___x_939_ = lean_obj_once(&l_main___closed__49, &l_main___closed__49_once, _init_l_main___closed__49);
v___x_940_ = l_FormalSpecAgent_TypedMachine_rollback(v___x_939_, v___x_938_);
return v___x_940_;
}
}
static lean_object* _init_l_main___closed__56(void){
_start:
{
lean_object* v___f_941_; lean_object* v___f_942_; lean_object* v___f_943_; lean_object* v___f_944_; lean_object* v___f_945_; lean_object* v___x_946_; 
v___f_941_ = ((lean_object*)(l_main___closed__16));
v___f_942_ = ((lean_object*)(l_main___closed__3));
v___f_943_ = ((lean_object*)(l_main___closed__44));
v___f_944_ = ((lean_object*)(l_main___closed__5));
v___f_945_ = lean_obj_once(&l_main___closed__34, &l_main___closed__34_once, _init_l_main___closed__34);
v___x_946_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_946_, 0, v___f_945_);
lean_ctor_set(v___x_946_, 1, v___f_944_);
lean_ctor_set(v___x_946_, 2, v___f_943_);
lean_ctor_set(v___x_946_, 3, v___f_942_);
lean_ctor_set(v___x_946_, 4, v___f_941_);
return v___x_946_;
}
}
static lean_object* _init_l_main___closed__57(void){
_start:
{
lean_object* v___x_947_; lean_object* v___x_948_; 
v___x_947_ = lean_unsigned_to_nat(5u);
v___x_948_ = lean_nat_to_int(v___x_947_);
return v___x_948_;
}
}
static lean_object* _init_l_main___closed__58(void){
_start:
{
lean_object* v___x_949_; lean_object* v___x_950_; lean_object* v___x_951_; lean_object* v___x_952_; lean_object* v___x_953_; lean_object* v___x_954_; 
v___x_949_ = lean_obj_once(&l_main___closed__57, &l_main___closed__57_once, _init_l_main___closed__57);
v___x_950_ = lean_obj_once(&l_main___closed__56, &l_main___closed__56_once, _init_l_main___closed__56);
v___x_951_ = lean_unsigned_to_nat(0u);
v___x_952_ = lean_obj_once(&l_main___closed__55, &l_main___closed__55_once, _init_l_main___closed__55);
v___x_953_ = l_MachineRuntime_model;
v___x_954_ = l_FormalSpecAgent_TypedMachine_external(v___x_953_, v___x_952_, v___x_951_, v___x_950_, v___x_949_);
return v___x_954_;
}
}
static lean_object* _init_l_main___closed__59(void){
_start:
{
lean_object* v___x_955_; lean_object* v___x_956_; lean_object* v___x_957_; lean_object* v___x_958_; 
v___x_955_ = lean_obj_once(&l_main___closed__58, &l_main___closed__58_once, _init_l_main___closed__58);
v___x_956_ = lean_obj_once(&l_main___closed__55, &l_main___closed__55_once, _init_l_main___closed__55);
v___x_957_ = l_MachineRuntime_schema;
v___x_958_ = l_FormalSpecAgent_MachineObserve_outcome(v___x_957_, v___x_956_, v___x_955_);
return v___x_958_;
}
}
static lean_object* _init_l_main___closed__60(void){
_start:
{
lean_object* v___x_959_; lean_object* v___x_960_; 
v___x_959_ = lean_obj_once(&l_main___closed__59, &l_main___closed__59_once, _init_l_main___closed__59);
v___x_960_ = l_outcomeText(v___x_959_);
return v___x_960_;
}
}
LEAN_EXPORT lean_object* _lean_main(){
_start:
{
lean_object* v___x_962_; lean_object* v___x_963_; 
v___x_962_ = lean_obj_once(&l_main___closed__23, &l_main___closed__23_once, _init_l_main___closed__23);
v___x_963_ = l_IO_println___at___00main_spec__0(v___x_962_);
if (lean_obj_tag(v___x_963_) == 0)
{
lean_object* v___x_964_; lean_object* v___x_965_; 
lean_dec_ref_known(v___x_963_, 1);
v___x_964_ = lean_obj_once(&l_main___closed__30, &l_main___closed__30_once, _init_l_main___closed__30);
v___x_965_ = l_IO_println___at___00main_spec__0(v___x_964_);
if (lean_obj_tag(v___x_965_) == 0)
{
lean_object* v___x_966_; lean_object* v___x_967_; 
lean_dec_ref_known(v___x_965_, 1);
v___x_966_ = lean_obj_once(&l_main___closed__39, &l_main___closed__39_once, _init_l_main___closed__39);
v___x_967_ = l_IO_println___at___00main_spec__0(v___x_966_);
if (lean_obj_tag(v___x_967_) == 0)
{
lean_object* v___x_968_; lean_object* v___x_969_; 
lean_dec_ref_known(v___x_967_, 1);
v___x_968_ = lean_obj_once(&l_main___closed__48, &l_main___closed__48_once, _init_l_main___closed__48);
v___x_969_ = l_IO_println___at___00main_spec__0(v___x_968_);
if (lean_obj_tag(v___x_969_) == 0)
{
lean_object* v___x_970_; lean_object* v___x_971_; 
lean_dec_ref_known(v___x_969_, 1);
v___x_970_ = lean_obj_once(&l_main___closed__54, &l_main___closed__54_once, _init_l_main___closed__54);
v___x_971_ = l_IO_println___at___00main_spec__0(v___x_970_);
if (lean_obj_tag(v___x_971_) == 0)
{
lean_object* v___x_972_; lean_object* v___x_973_; 
lean_dec_ref_known(v___x_971_, 1);
v___x_972_ = lean_obj_once(&l_main___closed__60, &l_main___closed__60_once, _init_l_main___closed__60);
v___x_973_ = l_IO_println___at___00main_spec__0(v___x_972_);
if (lean_obj_tag(v___x_973_) == 0)
{
lean_object* v___x_975_; uint8_t v_isShared_976_; uint8_t v_isSharedCheck_981_; 
v_isSharedCheck_981_ = !lean_is_exclusive(v___x_973_);
if (v_isSharedCheck_981_ == 0)
{
lean_object* v_unused_982_; 
v_unused_982_ = lean_ctor_get(v___x_973_, 0);
lean_dec(v_unused_982_);
v___x_975_ = v___x_973_;
v_isShared_976_ = v_isSharedCheck_981_;
goto v_resetjp_974_;
}
else
{
lean_dec(v___x_973_);
v___x_975_ = lean_box(0);
v_isShared_976_ = v_isSharedCheck_981_;
goto v_resetjp_974_;
}
v_resetjp_974_:
{
lean_object* v___x_977_; lean_object* v___x_979_; 
v___x_977_ = lean_box(0);
if (v_isShared_976_ == 0)
{
lean_ctor_set(v___x_975_, 0, v___x_977_);
v___x_979_ = v___x_975_;
goto v_reusejp_978_;
}
else
{
lean_object* v_reuseFailAlloc_980_; 
v_reuseFailAlloc_980_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_980_, 0, v___x_977_);
v___x_979_ = v_reuseFailAlloc_980_;
goto v_reusejp_978_;
}
v_reusejp_978_:
{
return v___x_979_;
}
}
}
else
{
return v___x_973_;
}
}
else
{
return v___x_971_;
}
}
else
{
return v___x_969_;
}
}
else
{
return v___x_967_;
}
}
else
{
return v___x_965_;
}
}
else
{
return v___x_963_;
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_a_983_){
_start:
{
lean_object* v_res_984_; 
v_res_984_ = _lean_main();
return v_res_984_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_ModelMachine(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Runner(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ModelMachine(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_main___lam__6___closed__0___boxed__const__1 = _init_l_main___lam__6___closed__0___boxed__const__1();
lean_mark_persistent(l_main___lam__6___closed__0___boxed__const__1);
l_main___lam__6___closed__1___boxed__const__1 = _init_l_main___lam__6___closed__1___boxed__const__1();
lean_mark_persistent(l_main___lam__6___closed__1___boxed__const__1);
l_main___lam__6___closed__2___boxed__const__1 = _init_l_main___lam__6___closed__2___boxed__const__1();
lean_mark_persistent(l_main___lam__6___closed__2___boxed__const__1);
l_main___lam__7___closed__0___boxed__const__1 = _init_l_main___lam__7___closed__0___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__0___boxed__const__1);
l_main___lam__7___closed__1___boxed__const__1 = _init_l_main___lam__7___closed__1___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__1___boxed__const__1);
l_main___lam__7___closed__2___boxed__const__1 = _init_l_main___lam__7___closed__2___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__2___boxed__const__1);
l_main___lam__7___closed__3___boxed__const__1 = _init_l_main___lam__7___closed__3___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__3___boxed__const__1);
l_main___lam__7___closed__4___boxed__const__1 = _init_l_main___lam__7___closed__4___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__4___boxed__const__1);
l_main___lam__7___closed__5___boxed__const__1 = _init_l_main___lam__7___closed__5___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__5___boxed__const__1);
l_main___lam__7___closed__9___boxed__const__1 = _init_l_main___lam__7___closed__9___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__9___boxed__const__1);
l_main___lam__7___closed__10___boxed__const__1 = _init_l_main___lam__7___closed__10___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__10___boxed__const__1);
l_main___lam__7___closed__11___boxed__const__1 = _init_l_main___lam__7___closed__11___boxed__const__1();
lean_mark_persistent(l_main___lam__7___closed__11___boxed__const__1);
l_main___lam__8___closed__2___boxed__const__1 = _init_l_main___lam__8___closed__2___boxed__const__1();
lean_mark_persistent(l_main___lam__8___closed__2___boxed__const__1);
l_main___lam__8___closed__3___boxed__const__1 = _init_l_main___lam__8___closed__3___boxed__const__1();
lean_mark_persistent(l_main___lam__8___closed__3___boxed__const__1);
l_main___lam__8___closed__4___boxed__const__1 = _init_l_main___lam__8___closed__4___boxed__const__1();
lean_mark_persistent(l_main___lam__8___closed__4___boxed__const__1);
l_main___lam__8___closed__5___boxed__const__1 = _init_l_main___lam__8___closed__5___boxed__const__1();
lean_mark_persistent(l_main___lam__8___closed__5___boxed__const__1);
l_main___lam__9___closed__0___boxed__const__1 = _init_l_main___lam__9___closed__0___boxed__const__1();
lean_mark_persistent(l_main___lam__9___closed__0___boxed__const__1);
l_main___lam__9___closed__1___boxed__const__1 = _init_l_main___lam__9___closed__1___boxed__const__1();
lean_mark_persistent(l_main___lam__9___closed__1___boxed__const__1);
l_main___lam__9___closed__2___boxed__const__1 = _init_l_main___lam__9___closed__2___boxed__const__1();
lean_mark_persistent(l_main___lam__9___closed__2___boxed__const__1);
l_main___lam__9___closed__3___boxed__const__1 = _init_l_main___lam__9___closed__3___boxed__const__1();
lean_mark_persistent(l_main___lam__9___closed__3___boxed__const__1);
l_main___lam__23___closed__0___boxed__const__1 = _init_l_main___lam__23___closed__0___boxed__const__1();
lean_mark_persistent(l_main___lam__23___closed__0___boxed__const__1);
l_main___lam__24___closed__3___boxed__const__1 = _init_l_main___lam__24___closed__3___boxed__const__1();
lean_mark_persistent(l_main___lam__24___closed__3___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    return _lean_main();
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_Runner(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
