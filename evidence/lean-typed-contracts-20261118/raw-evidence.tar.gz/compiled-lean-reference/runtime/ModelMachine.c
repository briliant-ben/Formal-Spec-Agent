// Lean compiler output
// Module: ModelMachine
// Imports: public import Init public meta import Init public import MachineObserve
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_string_mk(lean_object*);
static const lean_ctor_object l_MachineRuntime_e0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e0___closed__0 = (const lean_object*)&l_MachineRuntime_e0___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e0 = (const lean_object*)&l_MachineRuntime_e0___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e1___closed__0;
static lean_once_cell_t l_MachineRuntime_e1___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e1___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e1;
static const lean_ctor_object l_MachineRuntime_e2___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e2___closed__0 = (const lean_object*)&l_MachineRuntime_e2___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e2 = (const lean_object*)&l_MachineRuntime_e2___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e3___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e3___closed__0;
static lean_once_cell_t l_MachineRuntime_e3___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e3___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e3;
static const lean_ctor_object l_MachineRuntime_e4___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e4___closed__0 = (const lean_object*)&l_MachineRuntime_e4___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e4 = (const lean_object*)&l_MachineRuntime_e4___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e5___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e5___closed__0 = (const lean_object*)&l_MachineRuntime_e5___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e5 = (const lean_object*)&l_MachineRuntime_e5___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e6___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e6___closed__0 = (const lean_object*)&l_MachineRuntime_e6___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e6 = (const lean_object*)&l_MachineRuntime_e6___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e7___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_MachineRuntime_e5___closed__0_value),((lean_object*)&l_MachineRuntime_e6___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e7___closed__0 = (const lean_object*)&l_MachineRuntime_e7___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e7 = (const lean_object*)&l_MachineRuntime_e7___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e8___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e8___closed__0 = (const lean_object*)&l_MachineRuntime_e8___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e8 = (const lean_object*)&l_MachineRuntime_e8___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e9___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 23}, .m_objs = {((lean_object*)&l_MachineRuntime_e8___closed__0_value)}};
static const lean_object* l_MachineRuntime_e9___closed__0 = (const lean_object*)&l_MachineRuntime_e9___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e9 = (const lean_object*)&l_MachineRuntime_e9___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e10___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e10___closed__0;
static lean_once_cell_t l_MachineRuntime_e10___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e10___closed__1;
LEAN_EXPORT lean_object* l_MachineRuntime_e10;
static lean_once_cell_t l_MachineRuntime_e11___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e11___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e11;
static lean_once_cell_t l_MachineRuntime_e12___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e12___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e12;
static const lean_ctor_object l_MachineRuntime_e13___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e13___closed__0 = (const lean_object*)&l_MachineRuntime_e13___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e13 = (const lean_object*)&l_MachineRuntime_e13___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e14___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 23}, .m_objs = {((lean_object*)&l_MachineRuntime_e13___closed__0_value)}};
static const lean_object* l_MachineRuntime_e14___closed__0 = (const lean_object*)&l_MachineRuntime_e14___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e14 = (const lean_object*)&l_MachineRuntime_e14___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e15___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e15___closed__0 = (const lean_object*)&l_MachineRuntime_e15___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e15 = (const lean_object*)&l_MachineRuntime_e15___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e16___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e16___closed__0 = (const lean_object*)&l_MachineRuntime_e16___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e16 = (const lean_object*)&l_MachineRuntime_e16___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e17___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 18}, .m_objs = {((lean_object*)&l_MachineRuntime_e15___closed__0_value),((lean_object*)&l_MachineRuntime_e16___closed__0_value)}};
static const lean_object* l_MachineRuntime_e17___closed__0 = (const lean_object*)&l_MachineRuntime_e17___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e17 = (const lean_object*)&l_MachineRuntime_e17___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e18___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e18___closed__0 = (const lean_object*)&l_MachineRuntime_e18___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e18 = (const lean_object*)&l_MachineRuntime_e18___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e19___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e19___closed__0 = (const lean_object*)&l_MachineRuntime_e19___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e19 = (const lean_object*)&l_MachineRuntime_e19___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e20___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e20___closed__0 = (const lean_object*)&l_MachineRuntime_e20___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e20 = (const lean_object*)&l_MachineRuntime_e20___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e21___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e21___closed__0 = (const lean_object*)&l_MachineRuntime_e21___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e21 = (const lean_object*)&l_MachineRuntime_e21___closed__0_value;
static const lean_ctor_object l_MachineRuntime_e22___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e22___closed__0 = (const lean_object*)&l_MachineRuntime_e22___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e22 = (const lean_object*)&l_MachineRuntime_e22___closed__0_value;
static lean_once_cell_t l_MachineRuntime_e23___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e23___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e23;
static lean_once_cell_t l_MachineRuntime_e24___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e24___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e24;
static lean_once_cell_t l_MachineRuntime_e25___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_e25___closed__0;
LEAN_EXPORT lean_object* l_MachineRuntime_e25;
static const lean_ctor_object l_MachineRuntime_e26___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_MachineRuntime_e19___closed__0_value),((lean_object*)&l_MachineRuntime_e14___closed__0_value),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_e26___closed__0 = (const lean_object*)&l_MachineRuntime_e26___closed__0_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_e26 = (const lean_object*)&l_MachineRuntime_e26___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_e8___closed__0_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__0 = (const lean_object*)&l_MachineRuntime_rule__0___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_e14___closed__0_value),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__1 = (const lean_object*)&l_MachineRuntime_rule__0___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_MachineRuntime_e17___closed__0_value),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__2 = (const lean_object*)&l_MachineRuntime_rule__0___closed__2_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_e18___closed__0_value),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__3 = (const lean_object*)&l_MachineRuntime_rule__0___closed__3_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e6___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__4 = (const lean_object*)&l_MachineRuntime_rule__0___closed__4_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_e13___closed__0_value),LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__5 = (const lean_object*)&l_MachineRuntime_rule__0___closed__5_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_e19___closed__0_value),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__6 = (const lean_object*)&l_MachineRuntime_rule__0___closed__6_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_MachineRuntime_e20___closed__0_value),LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__7 = (const lean_object*)&l_MachineRuntime_rule__0___closed__7_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)&l_MachineRuntime_e21___closed__0_value),LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__8 = (const lean_object*)&l_MachineRuntime_rule__0___closed__8_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e22___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__0___closed__9 = (const lean_object*)&l_MachineRuntime_rule__0___closed__9_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__9_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__0___closed__10 = (const lean_object*)&l_MachineRuntime_rule__0___closed__10_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__8_value),((lean_object*)&l_MachineRuntime_rule__0___closed__10_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__11 = (const lean_object*)&l_MachineRuntime_rule__0___closed__11_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__7_value),((lean_object*)&l_MachineRuntime_rule__0___closed__11_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__12 = (const lean_object*)&l_MachineRuntime_rule__0___closed__12_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__6_value),((lean_object*)&l_MachineRuntime_rule__0___closed__12_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__13 = (const lean_object*)&l_MachineRuntime_rule__0___closed__13_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__5_value),((lean_object*)&l_MachineRuntime_rule__0___closed__13_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__14 = (const lean_object*)&l_MachineRuntime_rule__0___closed__14_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_MachineRuntime_rule__0___closed__14_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__15 = (const lean_object*)&l_MachineRuntime_rule__0___closed__15_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__15_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__0___closed__16 = (const lean_object*)&l_MachineRuntime_rule__0___closed__16_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__4_value),((lean_object*)&l_MachineRuntime_rule__0___closed__16_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__17 = (const lean_object*)&l_MachineRuntime_rule__0___closed__17_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__3_value),((lean_object*)&l_MachineRuntime_rule__0___closed__17_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__18 = (const lean_object*)&l_MachineRuntime_rule__0___closed__18_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__2_value),((lean_object*)&l_MachineRuntime_rule__0___closed__18_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__19 = (const lean_object*)&l_MachineRuntime_rule__0___closed__19_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__1_value),((lean_object*)&l_MachineRuntime_rule__0___closed__19_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__20 = (const lean_object*)&l_MachineRuntime_rule__0___closed__20_value;
static const lean_ctor_object l_MachineRuntime_rule__0___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__0___closed__0_value),((lean_object*)&l_MachineRuntime_rule__0___closed__20_value)}};
static const lean_object* l_MachineRuntime_rule__0___closed__21 = (const lean_object*)&l_MachineRuntime_rule__0___closed__21_value;
static lean_once_cell_t l_MachineRuntime_rule__0___closed__22_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__0___closed__22;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__0;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_MachineRuntime_e4___closed__0_value),LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* l_MachineRuntime_rule__1___closed__0 = (const lean_object*)&l_MachineRuntime_rule__1___closed__0_value;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_MachineRuntime_rule__0___closed__14_value)}};
static const lean_object* l_MachineRuntime_rule__1___closed__1 = (const lean_object*)&l_MachineRuntime_rule__1___closed__1_value;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__1___closed__1_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_rule__1___closed__2 = (const lean_object*)&l_MachineRuntime_rule__1___closed__2_value;
static const lean_ctor_object l_MachineRuntime_rule__1___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_rule__1___closed__0_value),((lean_object*)&l_MachineRuntime_rule__1___closed__2_value)}};
static const lean_object* l_MachineRuntime_rule__1___closed__3 = (const lean_object*)&l_MachineRuntime_rule__1___closed__3_value;
static lean_once_cell_t l_MachineRuntime_rule__1___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_rule__1___closed__4;
LEAN_EXPORT lean_object* l_MachineRuntime_rule__1;
static const lean_ctor_object l_MachineRuntime_schema___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__0 = (const lean_object*)&l_MachineRuntime_schema___closed__0_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__1 = (const lean_object*)&l_MachineRuntime_schema___closed__1_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__2 = (const lean_object*)&l_MachineRuntime_schema___closed__2_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(3) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__3 = (const lean_object*)&l_MachineRuntime_schema___closed__3_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__4 = (const lean_object*)&l_MachineRuntime_schema___closed__4_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__4_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_schema___closed__5 = (const lean_object*)&l_MachineRuntime_schema___closed__5_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__3_value),((lean_object*)&l_MachineRuntime_schema___closed__5_value)}};
static const lean_object* l_MachineRuntime_schema___closed__6 = (const lean_object*)&l_MachineRuntime_schema___closed__6_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__2_value),((lean_object*)&l_MachineRuntime_schema___closed__6_value)}};
static const lean_object* l_MachineRuntime_schema___closed__7 = (const lean_object*)&l_MachineRuntime_schema___closed__7_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__1_value),((lean_object*)&l_MachineRuntime_schema___closed__7_value)}};
static const lean_object* l_MachineRuntime_schema___closed__8 = (const lean_object*)&l_MachineRuntime_schema___closed__8_value;
static const lean_ctor_object l_MachineRuntime_schema___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_schema___closed__0_value),((lean_object*)&l_MachineRuntime_schema___closed__8_value)}};
static const lean_object* l_MachineRuntime_schema___closed__9 = (const lean_object*)&l_MachineRuntime_schema___closed__9_value;
LEAN_EXPORT const lean_object* l_MachineRuntime_schema = (const lean_object*)&l_MachineRuntime_schema___closed__9_value;
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0___boxed(lean_object*);
static const lean_closure_object l_MachineRuntime_model___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_MachineRuntime_model___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_MachineRuntime_model___closed__0 = (const lean_object*)&l_MachineRuntime_model___closed__0_value;
static lean_once_cell_t l_MachineRuntime_model___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__1;
static lean_once_cell_t l_MachineRuntime_model___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__2;
static const lean_ctor_object l_MachineRuntime_model___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_MachineRuntime_e26___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_model___closed__3 = (const lean_object*)&l_MachineRuntime_model___closed__3_value;
static lean_once_cell_t l_MachineRuntime_model___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__4;
static lean_once_cell_t l_MachineRuntime_model___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__5;
static const lean_ctor_object l_MachineRuntime_model___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_MachineRuntime_model___closed__6 = (const lean_object*)&l_MachineRuntime_model___closed__6_value;
static lean_once_cell_t l_MachineRuntime_model___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_MachineRuntime_model___closed__7;
LEAN_EXPORT lean_object* l_MachineRuntime_model;
static lean_object* _init_l_MachineRuntime_e1___closed__0(void){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_5_ = lean_unsigned_to_nat(0u);
v___x_6_ = lean_nat_to_int(v___x_5_);
return v___x_6_;
}
}
static lean_object* _init_l_MachineRuntime_e1___closed__1(void){
_start:
{
lean_object* v___x_7_; uint8_t v___x_8_; lean_object* v___x_9_; 
v___x_7_ = lean_obj_once(&l_MachineRuntime_e1___closed__0, &l_MachineRuntime_e1___closed__0_once, _init_l_MachineRuntime_e1___closed__0);
v___x_8_ = 0;
v___x_9_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_9_, 0, v___x_7_);
lean_ctor_set_uint8(v___x_9_, sizeof(void*)*1, v___x_8_);
return v___x_9_;
}
}
static lean_object* _init_l_MachineRuntime_e1(void){
_start:
{
lean_object* v___x_10_; 
v___x_10_ = lean_obj_once(&l_MachineRuntime_e1___closed__1, &l_MachineRuntime_e1___closed__1_once, _init_l_MachineRuntime_e1___closed__1);
return v___x_10_;
}
}
static lean_object* _init_l_MachineRuntime_e3___closed__0(void){
_start:
{
lean_object* v___x_15_; lean_object* v___x_16_; 
v___x_15_ = lean_box(0);
v___x_16_ = lean_string_mk(v___x_15_);
return v___x_16_;
}
}
static lean_object* _init_l_MachineRuntime_e3___closed__1(void){
_start:
{
lean_object* v___x_17_; uint8_t v___x_18_; lean_object* v___x_19_; 
v___x_17_ = lean_obj_once(&l_MachineRuntime_e3___closed__0, &l_MachineRuntime_e3___closed__0_once, _init_l_MachineRuntime_e3___closed__0);
v___x_18_ = 2;
v___x_19_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_19_, 0, v___x_17_);
lean_ctor_set_uint8(v___x_19_, sizeof(void*)*1, v___x_18_);
return v___x_19_;
}
}
static lean_object* _init_l_MachineRuntime_e3(void){
_start:
{
lean_object* v___x_20_; 
v___x_20_ = lean_obj_once(&l_MachineRuntime_e3___closed__1, &l_MachineRuntime_e3___closed__1_once, _init_l_MachineRuntime_e3___closed__1);
return v___x_20_;
}
}
static lean_object* _init_l_MachineRuntime_e10___closed__0(void){
_start:
{
lean_object* v___x_47_; lean_object* v___x_48_; 
v___x_47_ = lean_unsigned_to_nat(16u);
v___x_48_ = lean_nat_to_int(v___x_47_);
return v___x_48_;
}
}
static lean_object* _init_l_MachineRuntime_e10___closed__1(void){
_start:
{
lean_object* v___x_49_; uint8_t v___x_50_; lean_object* v___x_51_; 
v___x_49_ = lean_obj_once(&l_MachineRuntime_e10___closed__0, &l_MachineRuntime_e10___closed__0_once, _init_l_MachineRuntime_e10___closed__0);
v___x_50_ = 0;
v___x_51_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_51_, 0, v___x_49_);
lean_ctor_set_uint8(v___x_51_, sizeof(void*)*1, v___x_50_);
return v___x_51_;
}
}
static lean_object* _init_l_MachineRuntime_e10(void){
_start:
{
lean_object* v___x_52_; 
v___x_52_ = lean_obj_once(&l_MachineRuntime_e10___closed__1, &l_MachineRuntime_e10___closed__1_once, _init_l_MachineRuntime_e10___closed__1);
return v___x_52_;
}
}
static lean_object* _init_l_MachineRuntime_e11___closed__0(void){
_start:
{
lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; 
v___x_53_ = l_MachineRuntime_e10;
v___x_54_ = ((lean_object*)(l_MachineRuntime_e9));
v___x_55_ = lean_alloc_ctor(16, 2, 0);
lean_ctor_set(v___x_55_, 0, v___x_54_);
lean_ctor_set(v___x_55_, 1, v___x_53_);
return v___x_55_;
}
}
static lean_object* _init_l_MachineRuntime_e11(void){
_start:
{
lean_object* v___x_56_; 
v___x_56_ = lean_obj_once(&l_MachineRuntime_e11___closed__0, &l_MachineRuntime_e11___closed__0_once, _init_l_MachineRuntime_e11___closed__0);
return v___x_56_;
}
}
static lean_object* _init_l_MachineRuntime_e12___closed__0(void){
_start:
{
lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; 
v___x_57_ = l_MachineRuntime_e11;
v___x_58_ = ((lean_object*)(l_MachineRuntime_e7));
v___x_59_ = lean_alloc_ctor(8, 2, 0);
lean_ctor_set(v___x_59_, 0, v___x_58_);
lean_ctor_set(v___x_59_, 1, v___x_57_);
return v___x_59_;
}
}
static lean_object* _init_l_MachineRuntime_e12(void){
_start:
{
lean_object* v___x_60_; 
v___x_60_ = lean_obj_once(&l_MachineRuntime_e12___closed__0, &l_MachineRuntime_e12___closed__0_once, _init_l_MachineRuntime_e12___closed__0);
return v___x_60_;
}
}
static lean_object* _init_l_MachineRuntime_e23___closed__0(void){
_start:
{
lean_object* v___x_100_; lean_object* v___x_101_; 
v___x_100_ = l_MachineRuntime_e12;
v___x_101_ = lean_alloc_ctor(10, 1, 0);
lean_ctor_set(v___x_101_, 0, v___x_100_);
return v___x_101_;
}
}
static lean_object* _init_l_MachineRuntime_e23(void){
_start:
{
lean_object* v___x_102_; 
v___x_102_ = lean_obj_once(&l_MachineRuntime_e23___closed__0, &l_MachineRuntime_e23___closed__0_once, _init_l_MachineRuntime_e23___closed__0);
return v___x_102_;
}
}
static lean_object* _init_l_MachineRuntime_e24___closed__0(void){
_start:
{
lean_object* v___x_103_; lean_object* v___x_104_; lean_object* v___x_105_; 
v___x_103_ = l_MachineRuntime_e1;
v___x_104_ = ((lean_object*)(l_MachineRuntime_e19));
v___x_105_ = lean_alloc_ctor(17, 2, 0);
lean_ctor_set(v___x_105_, 0, v___x_104_);
lean_ctor_set(v___x_105_, 1, v___x_103_);
return v___x_105_;
}
}
static lean_object* _init_l_MachineRuntime_e24(void){
_start:
{
lean_object* v___x_106_; 
v___x_106_ = lean_obj_once(&l_MachineRuntime_e24___closed__0, &l_MachineRuntime_e24___closed__0_once, _init_l_MachineRuntime_e24___closed__0);
return v___x_106_;
}
}
static lean_object* _init_l_MachineRuntime_e25___closed__0(void){
_start:
{
lean_object* v___x_107_; lean_object* v___x_108_; lean_object* v___x_109_; 
v___x_107_ = l_MachineRuntime_e10;
v___x_108_ = ((lean_object*)(l_MachineRuntime_e19));
v___x_109_ = lean_alloc_ctor(16, 2, 0);
lean_ctor_set(v___x_109_, 0, v___x_108_);
lean_ctor_set(v___x_109_, 1, v___x_107_);
return v___x_109_;
}
}
static lean_object* _init_l_MachineRuntime_e25(void){
_start:
{
lean_object* v___x_110_; 
v___x_110_ = lean_obj_once(&l_MachineRuntime_e25___closed__0, &l_MachineRuntime_e25___closed__0_once, _init_l_MachineRuntime_e25___closed__0);
return v___x_110_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0___closed__22(void){
_start:
{
lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; 
v___x_192_ = ((lean_object*)(l_MachineRuntime_rule__0___closed__21));
v___x_193_ = l_MachineRuntime_e12;
v___x_194_ = lean_unsigned_to_nat(0u);
v___x_195_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_195_, 0, v___x_194_);
lean_ctor_set(v___x_195_, 1, v___x_194_);
lean_ctor_set(v___x_195_, 2, v___x_194_);
lean_ctor_set(v___x_195_, 3, v___x_194_);
lean_ctor_set(v___x_195_, 4, v___x_193_);
lean_ctor_set(v___x_195_, 5, v___x_192_);
return v___x_195_;
}
}
static lean_object* _init_l_MachineRuntime_rule__0(void){
_start:
{
lean_object* v___x_196_; 
v___x_196_ = lean_obj_once(&l_MachineRuntime_rule__0___closed__22, &l_MachineRuntime_rule__0___closed__22_once, _init_l_MachineRuntime_rule__0___closed__22);
return v___x_196_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1___closed__4(void){
_start:
{
lean_object* v___x_210_; lean_object* v___x_211_; lean_object* v___x_212_; lean_object* v___x_213_; lean_object* v___x_214_; 
v___x_210_ = ((lean_object*)(l_MachineRuntime_rule__1___closed__3));
v___x_211_ = l_MachineRuntime_e23;
v___x_212_ = lean_unsigned_to_nat(0u);
v___x_213_ = lean_unsigned_to_nat(1u);
v___x_214_ = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(v___x_214_, 0, v___x_213_);
lean_ctor_set(v___x_214_, 1, v___x_212_);
lean_ctor_set(v___x_214_, 2, v___x_212_);
lean_ctor_set(v___x_214_, 3, v___x_212_);
lean_ctor_set(v___x_214_, 4, v___x_211_);
lean_ctor_set(v___x_214_, 5, v___x_210_);
return v___x_214_;
}
}
static lean_object* _init_l_MachineRuntime_rule__1(void){
_start:
{
lean_object* v___x_215_; 
v___x_215_ = lean_obj_once(&l_MachineRuntime_rule__1___closed__4, &l_MachineRuntime_rule__1___closed__4_once, _init_l_MachineRuntime_rule__1___closed__4);
return v___x_215_;
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0(lean_object* v_n_252_){
_start:
{
lean_object* v___x_253_; 
v___x_253_ = lean_unsigned_to_nat(0u);
return v___x_253_;
}
}
LEAN_EXPORT lean_object* l_MachineRuntime_model___lam__0___boxed(lean_object* v_n_254_){
_start:
{
lean_object* v_res_255_; 
v_res_255_ = l_MachineRuntime_model___lam__0(v_n_254_);
lean_dec(v_n_254_);
return v_res_255_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__1(void){
_start:
{
lean_object* v___x_257_; lean_object* v___x_258_; lean_object* v___x_259_; 
v___x_257_ = lean_box(0);
v___x_258_ = l_MachineRuntime_rule__1;
v___x_259_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_259_, 0, v___x_258_);
lean_ctor_set(v___x_259_, 1, v___x_257_);
return v___x_259_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__2(void){
_start:
{
lean_object* v___x_260_; lean_object* v___x_261_; lean_object* v___x_262_; 
v___x_260_ = lean_obj_once(&l_MachineRuntime_model___closed__1, &l_MachineRuntime_model___closed__1_once, _init_l_MachineRuntime_model___closed__1);
v___x_261_ = l_MachineRuntime_rule__0;
v___x_262_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_262_, 0, v___x_261_);
lean_ctor_set(v___x_262_, 1, v___x_260_);
return v___x_262_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__4(void){
_start:
{
lean_object* v___x_266_; lean_object* v___x_267_; lean_object* v___x_268_; 
v___x_266_ = ((lean_object*)(l_MachineRuntime_model___closed__3));
v___x_267_ = l_MachineRuntime_e25;
v___x_268_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_268_, 0, v___x_267_);
lean_ctor_set(v___x_268_, 1, v___x_266_);
return v___x_268_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__5(void){
_start:
{
lean_object* v___x_269_; lean_object* v___x_270_; lean_object* v___x_271_; 
v___x_269_ = lean_obj_once(&l_MachineRuntime_model___closed__4, &l_MachineRuntime_model___closed__4_once, _init_l_MachineRuntime_model___closed__4);
v___x_270_ = l_MachineRuntime_e24;
v___x_271_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_271_, 0, v___x_270_);
lean_ctor_set(v___x_271_, 1, v___x_269_);
return v___x_271_;
}
}
static lean_object* _init_l_MachineRuntime_model___closed__7(void){
_start:
{
lean_object* v___x_275_; lean_object* v___f_276_; lean_object* v___x_277_; lean_object* v___x_278_; lean_object* v___x_279_; 
v___x_275_ = ((lean_object*)(l_MachineRuntime_model___closed__6));
v___f_276_ = ((lean_object*)(l_MachineRuntime_model___closed__0));
v___x_277_ = lean_obj_once(&l_MachineRuntime_model___closed__5, &l_MachineRuntime_model___closed__5_once, _init_l_MachineRuntime_model___closed__5);
v___x_278_ = lean_obj_once(&l_MachineRuntime_model___closed__2, &l_MachineRuntime_model___closed__2_once, _init_l_MachineRuntime_model___closed__2);
v___x_279_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_279_, 0, v___x_278_);
lean_ctor_set(v___x_279_, 1, v___x_277_);
lean_ctor_set(v___x_279_, 2, v___f_276_);
lean_ctor_set(v___x_279_, 3, v___x_275_);
return v___x_279_;
}
}
static lean_object* _init_l_MachineRuntime_model(void){
_start:
{
lean_object* v___x_280_; 
v___x_280_ = lean_obj_once(&l_MachineRuntime_model___closed__7, &l_MachineRuntime_model___closed__7_once, _init_l_MachineRuntime_model___closed__7);
return v___x_280_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_MachineObserve(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ModelMachine(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_MachineObserve(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_MachineRuntime_e1 = _init_l_MachineRuntime_e1();
lean_mark_persistent(l_MachineRuntime_e1);
l_MachineRuntime_e3 = _init_l_MachineRuntime_e3();
lean_mark_persistent(l_MachineRuntime_e3);
l_MachineRuntime_e10 = _init_l_MachineRuntime_e10();
lean_mark_persistent(l_MachineRuntime_e10);
l_MachineRuntime_e11 = _init_l_MachineRuntime_e11();
lean_mark_persistent(l_MachineRuntime_e11);
l_MachineRuntime_e12 = _init_l_MachineRuntime_e12();
lean_mark_persistent(l_MachineRuntime_e12);
l_MachineRuntime_e23 = _init_l_MachineRuntime_e23();
lean_mark_persistent(l_MachineRuntime_e23);
l_MachineRuntime_e24 = _init_l_MachineRuntime_e24();
lean_mark_persistent(l_MachineRuntime_e24);
l_MachineRuntime_e25 = _init_l_MachineRuntime_e25();
lean_mark_persistent(l_MachineRuntime_e25);
l_MachineRuntime_rule__0 = _init_l_MachineRuntime_rule__0();
lean_mark_persistent(l_MachineRuntime_rule__0);
l_MachineRuntime_rule__1 = _init_l_MachineRuntime_rule__1();
lean_mark_persistent(l_MachineRuntime_rule__1);
l_MachineRuntime_model = _init_l_MachineRuntime_model();
lean_mark_persistent(l_MachineRuntime_model);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
