// Lean compiler output
// Module: MachineObserve
// Imports: public import Init public meta import Init public import TypedMachine
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
uint8_t l_instDecidableEqList___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
lean_object* l_Int_instDecidableEq___boxed(lean_object*, lean_object*);
uint8_t l_instDecidableEqProd___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(uint8_t);
lean_object* lean_string_length(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_Std_Format_joinSep___at___00Prod_repr___at___00Array_repr___at___00Std_Http_Protocol_H1_Reader_instReprBodyState_repr_spec__0_spec__0_spec__2(lean_object*, lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* l_Int_repr(lean_object*);
lean_object* l_Repr_addAppParen(lean_object*, lean_object*);
lean_object* l_Bool_repr___redArg(uint8_t);
lean_object* l_String_quote(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
size_t lean_usize_sub(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_FormalSpecAgent_TypedMachine_rollback(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedIR_getValue(uint8_t, lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_integer_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_integer_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_boolean_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_boolean_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_text_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_text_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_octets_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_octets_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_sequence_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_sequence_elim(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instDecidableEqFin___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(256) << 1) | 1))} };
static const lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq___closed__0 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq___closed__0_value;
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqPacked(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqPacked___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0_spec__1_spec__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0(lean_object*, lean_object*);
static const lean_string_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "[]"};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__0 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__0_value;
static const lean_ctor_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__0_value)}};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__1 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__1_value;
static const lean_string_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "["};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__2 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__2_value;
static const lean_string_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__3 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__3_value;
static const lean_ctor_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__3_value)}};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__4 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__4_value;
static const lean_ctor_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__4_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__5 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__5_value;
static const lean_string_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "]"};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__6 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__6_value;
static lean_once_cell_t l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__7;
static lean_once_cell_t l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8;
static const lean_ctor_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__2_value)}};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__9 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__9_value;
static const lean_ctor_object l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__6_value)}};
static const lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__10 = (const lean_object*)&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__10_value;
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg(lean_object*);
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 46, .m_capacity = 46, .m_length = 45, .m_data = "FormalSpecAgent.MachineObserve.Packed.integer"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__0 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__0_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__0_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__1 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__1_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__1_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__2 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__2_value;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 46, .m_capacity = 46, .m_length = 45, .m_data = "FormalSpecAgent.MachineObserve.Packed.boolean"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__6 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__6_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__6_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__7 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__7_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__7_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__8 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__8_value;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 43, .m_capacity = 43, .m_length = 42, .m_data = "FormalSpecAgent.MachineObserve.Packed.text"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__9 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__9_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__9_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__10 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__10_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__10_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__11 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__11_value;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 45, .m_capacity = 45, .m_length = 44, .m_data = "FormalSpecAgent.MachineObserve.Packed.octets"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__12 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__12_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__12_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__13 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__13_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__13_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__14 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__14_value;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 47, .m_capacity = 47, .m_length = 46, .m_data = "FormalSpecAgent.MachineObserve.Packed.sequence"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__15 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__15_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__15_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__16 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__16_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__16_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__17 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__17_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_MachineObserve_instReprPacked___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_MachineObserve_instReprPacked_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked___closed__0 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked___closed__0_value;
LEAN_EXPORT const lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprPacked___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_packed(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_packed___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___closed__0 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___closed__0_value;
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0_spec__1_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0___redArg(lean_object*);
static const lean_string_object l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "("};
static const lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__0 = (const lean_object*)&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__0_value;
static const lean_string_object l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ")"};
static const lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__1 = (const lean_object*)&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__1_value;
static lean_once_cell_t l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__2;
static lean_once_cell_t l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__3;
static const lean_ctor_object l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__0_value)}};
static const lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__4 = (const lean_object*)&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__4_value;
static const lean_ctor_object l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__1_value)}};
static const lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__5 = (const lean_object*)&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__5_value;
LEAN_EXPORT lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg(lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3_spec__5_spec__7(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3_spec__5(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1___redArg(lean_object*);
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "{ "};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__0 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__0_value;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "state"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__1 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__1_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__1_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__2 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__2_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__2_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__3 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__3_value;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = " := "};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__4 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__4_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__4_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__5 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__5_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__3_value),((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__5_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__6 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__6_value;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__7;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "now"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__8 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__8_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__8_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__9 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__9_value;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__10;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "values"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__11 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__11_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__11_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__12 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__12_value;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__13;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "timers"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__14 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__14_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__14_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__15 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__15_value;
static const lean_string_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = " }"};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__16 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__16_value;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__17_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__17;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__18;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__0_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__19 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__19_value;
static const lean_ctor_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__16_value)}};
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__20 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__20_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___boxed(lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot___closed__0 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot___closed__0_value;
LEAN_EXPORT const lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_insertBySlot___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_insertBySlot(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___redArg(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_ordered___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_ordered(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_snapshot_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_snapshot_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_snapshot(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_message_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_message(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_success_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_success_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_error_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_error_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__0;
static lean_once_cell_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__1;
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___boxed(lean_object*, lean_object*);
static const lean_closure_object l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___closed__0 = (const lean_object*)&l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___closed__0_value;
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_outcome_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_outcome(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_outcome___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorIdx(lean_object* v_x_1_){
_start:
{
switch(lean_obj_tag(v_x_1_))
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
case 2:
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
case 3:
{
lean_object* v___x_5_; 
v___x_5_ = lean_unsigned_to_nat(3u);
return v___x_5_;
}
default: 
{
lean_object* v___x_6_; 
v___x_6_ = lean_unsigned_to_nat(4u);
return v___x_6_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorIdx___boxed(lean_object* v_x_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = l_FormalSpecAgent_MachineObserve_Packed_ctorIdx(v_x_7_);
lean_dec_ref(v_x_7_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(lean_object* v_t_9_, lean_object* v_k_10_){
_start:
{
switch(lean_obj_tag(v_t_9_))
{
case 1:
{
uint8_t v_a_11_; lean_object* v___x_12_; lean_object* v___x_13_; 
v_a_11_ = lean_ctor_get_uint8(v_t_9_, 0);
lean_dec_ref_known(v_t_9_, 0);
v___x_12_ = lean_box(v_a_11_);
v___x_13_ = lean_apply_1(v_k_10_, v___x_12_);
return v___x_13_;
}
case 2:
{
lean_object* v_a_14_; lean_object* v___x_15_; 
v_a_14_ = lean_ctor_get(v_t_9_, 0);
lean_inc_ref(v_a_14_);
lean_dec_ref_known(v_t_9_, 1);
v___x_15_ = lean_apply_1(v_k_10_, v_a_14_);
return v___x_15_;
}
default: 
{
lean_object* v_a_16_; lean_object* v___x_17_; 
v_a_16_ = lean_ctor_get(v_t_9_, 0);
lean_inc(v_a_16_);
lean_dec_ref(v_t_9_);
v___x_17_ = lean_apply_1(v_k_10_, v_a_16_);
return v___x_17_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorElim(lean_object* v_motive_18_, lean_object* v_ctorIdx_19_, lean_object* v_t_20_, lean_object* v_h_21_, lean_object* v_k_22_){
_start:
{
lean_object* v___x_23_; 
v___x_23_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_20_, v_k_22_);
return v___x_23_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_ctorElim___boxed(lean_object* v_motive_24_, lean_object* v_ctorIdx_25_, lean_object* v_t_26_, lean_object* v_h_27_, lean_object* v_k_28_){
_start:
{
lean_object* v_res_29_; 
v_res_29_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim(v_motive_24_, v_ctorIdx_25_, v_t_26_, v_h_27_, v_k_28_);
lean_dec(v_ctorIdx_25_);
return v_res_29_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_integer_elim___redArg(lean_object* v_t_30_, lean_object* v_integer_31_){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_30_, v_integer_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_integer_elim(lean_object* v_motive_33_, lean_object* v_t_34_, lean_object* v_h_35_, lean_object* v_integer_36_){
_start:
{
lean_object* v___x_37_; 
v___x_37_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_34_, v_integer_36_);
return v___x_37_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_boolean_elim___redArg(lean_object* v_t_38_, lean_object* v_boolean_39_){
_start:
{
lean_object* v___x_40_; 
v___x_40_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_38_, v_boolean_39_);
return v___x_40_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_boolean_elim(lean_object* v_motive_41_, lean_object* v_t_42_, lean_object* v_h_43_, lean_object* v_boolean_44_){
_start:
{
lean_object* v___x_45_; 
v___x_45_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_42_, v_boolean_44_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_text_elim___redArg(lean_object* v_t_46_, lean_object* v_text_47_){
_start:
{
lean_object* v___x_48_; 
v___x_48_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_46_, v_text_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_text_elim(lean_object* v_motive_49_, lean_object* v_t_50_, lean_object* v_h_51_, lean_object* v_text_52_){
_start:
{
lean_object* v___x_53_; 
v___x_53_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_50_, v_text_52_);
return v___x_53_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_octets_elim___redArg(lean_object* v_t_54_, lean_object* v_octets_55_){
_start:
{
lean_object* v___x_56_; 
v___x_56_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_54_, v_octets_55_);
return v___x_56_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_octets_elim(lean_object* v_motive_57_, lean_object* v_t_58_, lean_object* v_h_59_, lean_object* v_octets_60_){
_start:
{
lean_object* v___x_61_; 
v___x_61_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_58_, v_octets_60_);
return v___x_61_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_sequence_elim___redArg(lean_object* v_t_62_, lean_object* v_sequence_63_){
_start:
{
lean_object* v___x_64_; 
v___x_64_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_62_, v_sequence_63_);
return v___x_64_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Packed_sequence_elim(lean_object* v_motive_65_, lean_object* v_t_66_, lean_object* v_h_67_, lean_object* v_sequence_68_){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = l_FormalSpecAgent_MachineObserve_Packed_ctorElim___redArg(v_t_66_, v_sequence_68_);
return v___x_69_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq(lean_object* v_x_72_, lean_object* v_x_73_){
_start:
{
switch(lean_obj_tag(v_x_72_))
{
case 0:
{
if (lean_obj_tag(v_x_73_) == 0)
{
lean_object* v_a_74_; lean_object* v_a_75_; uint8_t v___x_76_; 
v_a_74_ = lean_ctor_get(v_x_72_, 0);
lean_inc(v_a_74_);
lean_dec_ref_known(v_x_72_, 1);
v_a_75_ = lean_ctor_get(v_x_73_, 0);
lean_inc(v_a_75_);
lean_dec_ref_known(v_x_73_, 1);
v___x_76_ = lean_int_dec_eq(v_a_74_, v_a_75_);
lean_dec(v_a_75_);
lean_dec(v_a_74_);
return v___x_76_;
}
else
{
uint8_t v___x_77_; 
lean_dec_ref_known(v_x_72_, 1);
lean_dec_ref(v_x_73_);
v___x_77_ = 0;
return v___x_77_;
}
}
case 1:
{
if (lean_obj_tag(v_x_73_) == 1)
{
uint8_t v_a_78_; 
v_a_78_ = lean_ctor_get_uint8(v_x_73_, 0);
lean_dec_ref_known(v_x_73_, 0);
if (v_a_78_ == 0)
{
uint8_t v_a_79_; 
v_a_79_ = lean_ctor_get_uint8(v_x_72_, 0);
lean_dec_ref_known(v_x_72_, 0);
if (v_a_79_ == 0)
{
uint8_t v___x_80_; 
v___x_80_ = 1;
return v___x_80_;
}
else
{
return v_a_78_;
}
}
else
{
uint8_t v_a_81_; 
v_a_81_ = lean_ctor_get_uint8(v_x_72_, 0);
lean_dec_ref_known(v_x_72_, 0);
return v_a_81_;
}
}
else
{
uint8_t v___x_82_; 
lean_dec_ref_known(v_x_72_, 0);
lean_dec_ref(v_x_73_);
v___x_82_ = 0;
return v___x_82_;
}
}
case 2:
{
if (lean_obj_tag(v_x_73_) == 2)
{
lean_object* v_a_83_; lean_object* v_a_84_; uint8_t v___x_85_; 
v_a_83_ = lean_ctor_get(v_x_72_, 0);
lean_inc_ref(v_a_83_);
lean_dec_ref_known(v_x_72_, 1);
v_a_84_ = lean_ctor_get(v_x_73_, 0);
lean_inc_ref(v_a_84_);
lean_dec_ref_known(v_x_73_, 1);
v___x_85_ = lean_string_dec_eq(v_a_83_, v_a_84_);
lean_dec_ref(v_a_84_);
lean_dec_ref(v_a_83_);
return v___x_85_;
}
else
{
uint8_t v___x_86_; 
lean_dec_ref_known(v_x_72_, 1);
lean_dec_ref(v_x_73_);
v___x_86_ = 0;
return v___x_86_;
}
}
case 3:
{
if (lean_obj_tag(v_x_73_) == 3)
{
lean_object* v_a_87_; lean_object* v_a_88_; lean_object* v___x_89_; uint8_t v___x_90_; 
v_a_87_ = lean_ctor_get(v_x_72_, 0);
lean_inc(v_a_87_);
lean_dec_ref_known(v_x_72_, 1);
v_a_88_ = lean_ctor_get(v_x_73_, 0);
lean_inc(v_a_88_);
lean_dec_ref_known(v_x_73_, 1);
v___x_89_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq___closed__0));
v___x_90_ = l_instDecidableEqList___redArg(v___x_89_, v_a_87_, v_a_88_);
return v___x_90_;
}
else
{
uint8_t v___x_91_; 
lean_dec_ref_known(v_x_72_, 1);
lean_dec_ref(v_x_73_);
v___x_91_ = 0;
return v___x_91_;
}
}
default: 
{
if (lean_obj_tag(v_x_73_) == 4)
{
lean_object* v_a_92_; lean_object* v_a_93_; uint8_t v___x_94_; 
v_a_92_ = lean_ctor_get(v_x_72_, 0);
lean_inc(v_a_92_);
lean_dec_ref_known(v_x_72_, 1);
v_a_93_ = lean_ctor_get(v_x_73_, 0);
lean_inc(v_a_93_);
lean_dec_ref_known(v_x_73_, 1);
v___x_94_ = lean_nat_dec_eq(v_a_92_, v_a_93_);
lean_dec(v_a_93_);
lean_dec(v_a_92_);
return v___x_94_;
}
else
{
uint8_t v___x_95_; 
lean_dec_ref_known(v_x_72_, 1);
lean_dec_ref(v_x_73_);
v___x_95_ = 0;
return v___x_95_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq___boxed(lean_object* v_x_96_, lean_object* v_x_97_){
_start:
{
uint8_t v_res_98_; lean_object* v_r_99_; 
v_res_98_ = l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq(v_x_96_, v_x_97_);
v_r_99_ = lean_box(v_res_98_);
return v_r_99_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqPacked(lean_object* v_x_100_, lean_object* v_x_101_){
_start:
{
uint8_t v___x_102_; 
v___x_102_ = l_FormalSpecAgent_MachineObserve_instDecidableEqPacked_decEq(v_x_100_, v_x_101_);
return v___x_102_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqPacked___boxed(lean_object* v_x_103_, lean_object* v_x_104_){
_start:
{
uint8_t v_res_105_; lean_object* v_r_106_; 
v_res_105_ = l_FormalSpecAgent_MachineObserve_instDecidableEqPacked(v_x_103_, v_x_104_);
v_r_106_ = lean_box(v_res_105_);
return v_r_106_;
}
}
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0___lam__0(lean_object* v___y_107_){
_start:
{
lean_object* v___x_108_; lean_object* v___x_109_; 
v___x_108_ = l_Nat_reprFast(v___y_107_);
v___x_109_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_109_, 0, v___x_108_);
return v___x_109_;
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0_spec__1_spec__2(lean_object* v_x_110_, lean_object* v_x_111_, lean_object* v_x_112_){
_start:
{
if (lean_obj_tag(v_x_112_) == 0)
{
lean_dec(v_x_110_);
return v_x_111_;
}
else
{
lean_object* v_head_113_; lean_object* v_tail_114_; lean_object* v___x_116_; uint8_t v_isShared_117_; uint8_t v_isSharedCheck_125_; 
v_head_113_ = lean_ctor_get(v_x_112_, 0);
v_tail_114_ = lean_ctor_get(v_x_112_, 1);
v_isSharedCheck_125_ = !lean_is_exclusive(v_x_112_);
if (v_isSharedCheck_125_ == 0)
{
v___x_116_ = v_x_112_;
v_isShared_117_ = v_isSharedCheck_125_;
goto v_resetjp_115_;
}
else
{
lean_inc(v_tail_114_);
lean_inc(v_head_113_);
lean_dec(v_x_112_);
v___x_116_ = lean_box(0);
v_isShared_117_ = v_isSharedCheck_125_;
goto v_resetjp_115_;
}
v_resetjp_115_:
{
lean_object* v___x_119_; 
lean_inc(v_x_110_);
if (v_isShared_117_ == 0)
{
lean_ctor_set_tag(v___x_116_, 5);
lean_ctor_set(v___x_116_, 1, v_x_110_);
lean_ctor_set(v___x_116_, 0, v_x_111_);
v___x_119_ = v___x_116_;
goto v_reusejp_118_;
}
else
{
lean_object* v_reuseFailAlloc_124_; 
v_reuseFailAlloc_124_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_124_, 0, v_x_111_);
lean_ctor_set(v_reuseFailAlloc_124_, 1, v_x_110_);
v___x_119_ = v_reuseFailAlloc_124_;
goto v_reusejp_118_;
}
v_reusejp_118_:
{
lean_object* v___x_120_; lean_object* v___x_121_; lean_object* v___x_122_; 
v___x_120_ = l_Nat_reprFast(v_head_113_);
v___x_121_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_121_, 0, v___x_120_);
v___x_122_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_122_, 0, v___x_119_);
lean_ctor_set(v___x_122_, 1, v___x_121_);
v_x_111_ = v___x_122_;
v_x_112_ = v_tail_114_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0_spec__1(lean_object* v_x_126_, lean_object* v_x_127_, lean_object* v_x_128_){
_start:
{
if (lean_obj_tag(v_x_128_) == 0)
{
lean_dec(v_x_126_);
return v_x_127_;
}
else
{
lean_object* v_head_129_; lean_object* v_tail_130_; lean_object* v___x_132_; uint8_t v_isShared_133_; uint8_t v_isSharedCheck_141_; 
v_head_129_ = lean_ctor_get(v_x_128_, 0);
v_tail_130_ = lean_ctor_get(v_x_128_, 1);
v_isSharedCheck_141_ = !lean_is_exclusive(v_x_128_);
if (v_isSharedCheck_141_ == 0)
{
v___x_132_ = v_x_128_;
v_isShared_133_ = v_isSharedCheck_141_;
goto v_resetjp_131_;
}
else
{
lean_inc(v_tail_130_);
lean_inc(v_head_129_);
lean_dec(v_x_128_);
v___x_132_ = lean_box(0);
v_isShared_133_ = v_isSharedCheck_141_;
goto v_resetjp_131_;
}
v_resetjp_131_:
{
lean_object* v___x_135_; 
lean_inc(v_x_126_);
if (v_isShared_133_ == 0)
{
lean_ctor_set_tag(v___x_132_, 5);
lean_ctor_set(v___x_132_, 1, v_x_126_);
lean_ctor_set(v___x_132_, 0, v_x_127_);
v___x_135_ = v___x_132_;
goto v_reusejp_134_;
}
else
{
lean_object* v_reuseFailAlloc_140_; 
v_reuseFailAlloc_140_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_140_, 0, v_x_127_);
lean_ctor_set(v_reuseFailAlloc_140_, 1, v_x_126_);
v___x_135_ = v_reuseFailAlloc_140_;
goto v_reusejp_134_;
}
v_reusejp_134_:
{
lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; 
v___x_136_ = l_Nat_reprFast(v_head_129_);
v___x_137_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_137_, 0, v___x_136_);
v___x_138_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_138_, 0, v___x_135_);
lean_ctor_set(v___x_138_, 1, v___x_137_);
v___x_139_ = l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0_spec__1_spec__2(v_x_126_, v___x_138_, v_tail_130_);
return v___x_139_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0(lean_object* v_x_142_, lean_object* v_x_143_){
_start:
{
if (lean_obj_tag(v_x_142_) == 0)
{
lean_object* v___x_144_; 
lean_dec(v_x_143_);
v___x_144_ = lean_box(0);
return v___x_144_;
}
else
{
lean_object* v_tail_145_; 
v_tail_145_ = lean_ctor_get(v_x_142_, 1);
if (lean_obj_tag(v_tail_145_) == 0)
{
lean_object* v_head_146_; lean_object* v___x_147_; 
lean_dec(v_x_143_);
v_head_146_ = lean_ctor_get(v_x_142_, 0);
lean_inc(v_head_146_);
lean_dec_ref_known(v_x_142_, 2);
v___x_147_ = l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0___lam__0(v_head_146_);
return v___x_147_;
}
else
{
lean_object* v_head_148_; lean_object* v___x_149_; lean_object* v___x_150_; 
lean_inc(v_tail_145_);
v_head_148_ = lean_ctor_get(v_x_142_, 0);
lean_inc(v_head_148_);
lean_dec_ref_known(v_x_142_, 2);
v___x_149_ = l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0___lam__0(v_head_148_);
v___x_150_ = l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0_spec__1(v_x_143_, v___x_149_, v_tail_145_);
return v___x_150_;
}
}
}
}
static lean_object* _init_l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__7(void){
_start:
{
lean_object* v___x_162_; lean_object* v___x_163_; 
v___x_162_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__2));
v___x_163_ = lean_string_length(v___x_162_);
return v___x_163_;
}
}
static lean_object* _init_l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8(void){
_start:
{
lean_object* v___x_164_; lean_object* v___x_165_; 
v___x_164_ = lean_obj_once(&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__7, &l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__7_once, _init_l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__7);
v___x_165_ = lean_nat_to_int(v___x_164_);
return v___x_165_;
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg(lean_object* v_a_170_){
_start:
{
if (lean_obj_tag(v_a_170_) == 0)
{
lean_object* v___x_171_; 
v___x_171_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__1));
return v___x_171_;
}
else
{
lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; lean_object* v___x_179_; uint8_t v___x_180_; lean_object* v___x_181_; 
v___x_172_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__5));
v___x_173_ = l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0_spec__0(v_a_170_, v___x_172_);
v___x_174_ = lean_obj_once(&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8, &l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8_once, _init_l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8);
v___x_175_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__9));
v___x_176_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_176_, 0, v___x_175_);
lean_ctor_set(v___x_176_, 1, v___x_173_);
v___x_177_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__10));
v___x_178_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_178_, 0, v___x_176_);
lean_ctor_set(v___x_178_, 1, v___x_177_);
v___x_179_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_179_, 0, v___x_174_);
lean_ctor_set(v___x_179_, 1, v___x_178_);
v___x_180_ = 0;
v___x_181_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_181_, 0, v___x_179_);
lean_ctor_set_uint8(v___x_181_, sizeof(void*)*1, v___x_180_);
return v___x_181_;
}
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3(void){
_start:
{
lean_object* v___x_188_; lean_object* v___x_189_; 
v___x_188_ = lean_unsigned_to_nat(0u);
v___x_189_ = lean_nat_to_int(v___x_188_);
return v___x_189_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4(void){
_start:
{
lean_object* v___x_190_; lean_object* v___x_191_; 
v___x_190_ = lean_unsigned_to_nat(2u);
v___x_191_ = lean_nat_to_int(v___x_190_);
return v___x_191_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5(void){
_start:
{
lean_object* v___x_192_; lean_object* v___x_193_; 
v___x_192_ = lean_unsigned_to_nat(1u);
v___x_193_ = lean_nat_to_int(v___x_192_);
return v___x_193_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr(lean_object* v_x_218_, lean_object* v_prec_219_){
_start:
{
lean_object* v___y_221_; lean_object* v___y_222_; lean_object* v___y_223_; 
switch(lean_obj_tag(v_x_218_))
{
case 0:
{
lean_object* v_a_229_; lean_object* v___x_231_; uint8_t v_isShared_232_; uint8_t v_isSharedCheck_252_; 
v_a_229_ = lean_ctor_get(v_x_218_, 0);
v_isSharedCheck_252_ = !lean_is_exclusive(v_x_218_);
if (v_isSharedCheck_252_ == 0)
{
v___x_231_ = v_x_218_;
v_isShared_232_ = v_isSharedCheck_252_;
goto v_resetjp_230_;
}
else
{
lean_inc(v_a_229_);
lean_dec(v_x_218_);
v___x_231_ = lean_box(0);
v_isShared_232_ = v_isSharedCheck_252_;
goto v_resetjp_230_;
}
v_resetjp_230_:
{
lean_object* v___y_234_; lean_object* v___x_248_; uint8_t v___x_249_; 
v___x_248_ = lean_unsigned_to_nat(1024u);
v___x_249_ = lean_nat_dec_le(v___x_248_, v_prec_219_);
if (v___x_249_ == 0)
{
lean_object* v___x_250_; 
v___x_250_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4);
v___y_234_ = v___x_250_;
goto v___jp_233_;
}
else
{
lean_object* v___x_251_; 
v___x_251_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5);
v___y_234_ = v___x_251_;
goto v___jp_233_;
}
v___jp_233_:
{
lean_object* v___x_235_; lean_object* v___x_236_; uint8_t v___x_237_; 
v___x_235_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__2));
v___x_236_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3);
v___x_237_ = lean_int_dec_lt(v_a_229_, v___x_236_);
if (v___x_237_ == 0)
{
lean_object* v___x_238_; lean_object* v___x_240_; 
v___x_238_ = l_Int_repr(v_a_229_);
lean_dec(v_a_229_);
if (v_isShared_232_ == 0)
{
lean_ctor_set_tag(v___x_231_, 3);
lean_ctor_set(v___x_231_, 0, v___x_238_);
v___x_240_ = v___x_231_;
goto v_reusejp_239_;
}
else
{
lean_object* v_reuseFailAlloc_241_; 
v_reuseFailAlloc_241_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_241_, 0, v___x_238_);
v___x_240_ = v_reuseFailAlloc_241_;
goto v_reusejp_239_;
}
v_reusejp_239_:
{
v___y_221_ = v___y_234_;
v___y_222_ = v___x_235_;
v___y_223_ = v___x_240_;
goto v___jp_220_;
}
}
else
{
lean_object* v___x_242_; lean_object* v___x_243_; lean_object* v___x_245_; 
v___x_242_ = lean_unsigned_to_nat(1024u);
v___x_243_ = l_Int_repr(v_a_229_);
lean_dec(v_a_229_);
if (v_isShared_232_ == 0)
{
lean_ctor_set_tag(v___x_231_, 3);
lean_ctor_set(v___x_231_, 0, v___x_243_);
v___x_245_ = v___x_231_;
goto v_reusejp_244_;
}
else
{
lean_object* v_reuseFailAlloc_247_; 
v_reuseFailAlloc_247_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_247_, 0, v___x_243_);
v___x_245_ = v_reuseFailAlloc_247_;
goto v_reusejp_244_;
}
v_reusejp_244_:
{
lean_object* v___x_246_; 
v___x_246_ = l_Repr_addAppParen(v___x_245_, v___x_242_);
v___y_221_ = v___y_234_;
v___y_222_ = v___x_235_;
v___y_223_ = v___x_246_;
goto v___jp_220_;
}
}
}
}
}
case 1:
{
uint8_t v_a_253_; lean_object* v___y_255_; lean_object* v___x_263_; uint8_t v___x_264_; 
v_a_253_ = lean_ctor_get_uint8(v_x_218_, 0);
lean_dec_ref_known(v_x_218_, 0);
v___x_263_ = lean_unsigned_to_nat(1024u);
v___x_264_ = lean_nat_dec_le(v___x_263_, v_prec_219_);
if (v___x_264_ == 0)
{
lean_object* v___x_265_; 
v___x_265_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4);
v___y_255_ = v___x_265_;
goto v___jp_254_;
}
else
{
lean_object* v___x_266_; 
v___x_266_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5);
v___y_255_ = v___x_266_;
goto v___jp_254_;
}
v___jp_254_:
{
lean_object* v___x_256_; lean_object* v___x_257_; lean_object* v___x_258_; lean_object* v___x_259_; uint8_t v___x_260_; lean_object* v___x_261_; lean_object* v___x_262_; 
v___x_256_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__8));
v___x_257_ = l_Bool_repr___redArg(v_a_253_);
v___x_258_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_258_, 0, v___x_256_);
lean_ctor_set(v___x_258_, 1, v___x_257_);
lean_inc(v___y_255_);
v___x_259_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_259_, 0, v___y_255_);
lean_ctor_set(v___x_259_, 1, v___x_258_);
v___x_260_ = 0;
v___x_261_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_261_, 0, v___x_259_);
lean_ctor_set_uint8(v___x_261_, sizeof(void*)*1, v___x_260_);
v___x_262_ = l_Repr_addAppParen(v___x_261_, v_prec_219_);
return v___x_262_;
}
}
case 2:
{
lean_object* v_a_267_; lean_object* v___x_269_; uint8_t v_isShared_270_; uint8_t v_isSharedCheck_287_; 
v_a_267_ = lean_ctor_get(v_x_218_, 0);
v_isSharedCheck_287_ = !lean_is_exclusive(v_x_218_);
if (v_isSharedCheck_287_ == 0)
{
v___x_269_ = v_x_218_;
v_isShared_270_ = v_isSharedCheck_287_;
goto v_resetjp_268_;
}
else
{
lean_inc(v_a_267_);
lean_dec(v_x_218_);
v___x_269_ = lean_box(0);
v_isShared_270_ = v_isSharedCheck_287_;
goto v_resetjp_268_;
}
v_resetjp_268_:
{
lean_object* v___y_272_; lean_object* v___x_283_; uint8_t v___x_284_; 
v___x_283_ = lean_unsigned_to_nat(1024u);
v___x_284_ = lean_nat_dec_le(v___x_283_, v_prec_219_);
if (v___x_284_ == 0)
{
lean_object* v___x_285_; 
v___x_285_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4);
v___y_272_ = v___x_285_;
goto v___jp_271_;
}
else
{
lean_object* v___x_286_; 
v___x_286_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5);
v___y_272_ = v___x_286_;
goto v___jp_271_;
}
v___jp_271_:
{
lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_276_; 
v___x_273_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__11));
v___x_274_ = l_String_quote(v_a_267_);
if (v_isShared_270_ == 0)
{
lean_ctor_set_tag(v___x_269_, 3);
lean_ctor_set(v___x_269_, 0, v___x_274_);
v___x_276_ = v___x_269_;
goto v_reusejp_275_;
}
else
{
lean_object* v_reuseFailAlloc_282_; 
v_reuseFailAlloc_282_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_282_, 0, v___x_274_);
v___x_276_ = v_reuseFailAlloc_282_;
goto v_reusejp_275_;
}
v_reusejp_275_:
{
lean_object* v___x_277_; lean_object* v___x_278_; uint8_t v___x_279_; lean_object* v___x_280_; lean_object* v___x_281_; 
v___x_277_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_277_, 0, v___x_273_);
lean_ctor_set(v___x_277_, 1, v___x_276_);
lean_inc(v___y_272_);
v___x_278_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_278_, 0, v___y_272_);
lean_ctor_set(v___x_278_, 1, v___x_277_);
v___x_279_ = 0;
v___x_280_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_280_, 0, v___x_278_);
lean_ctor_set_uint8(v___x_280_, sizeof(void*)*1, v___x_279_);
v___x_281_ = l_Repr_addAppParen(v___x_280_, v_prec_219_);
return v___x_281_;
}
}
}
}
case 3:
{
lean_object* v_a_288_; lean_object* v___y_290_; lean_object* v___x_298_; uint8_t v___x_299_; 
v_a_288_ = lean_ctor_get(v_x_218_, 0);
lean_inc(v_a_288_);
lean_dec_ref_known(v_x_218_, 1);
v___x_298_ = lean_unsigned_to_nat(1024u);
v___x_299_ = lean_nat_dec_le(v___x_298_, v_prec_219_);
if (v___x_299_ == 0)
{
lean_object* v___x_300_; 
v___x_300_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4);
v___y_290_ = v___x_300_;
goto v___jp_289_;
}
else
{
lean_object* v___x_301_; 
v___x_301_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5);
v___y_290_ = v___x_301_;
goto v___jp_289_;
}
v___jp_289_:
{
lean_object* v___x_291_; lean_object* v___x_292_; lean_object* v___x_293_; lean_object* v___x_294_; uint8_t v___x_295_; lean_object* v___x_296_; lean_object* v___x_297_; 
v___x_291_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__14));
v___x_292_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg(v_a_288_);
v___x_293_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_293_, 0, v___x_291_);
lean_ctor_set(v___x_293_, 1, v___x_292_);
lean_inc(v___y_290_);
v___x_294_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_294_, 0, v___y_290_);
lean_ctor_set(v___x_294_, 1, v___x_293_);
v___x_295_ = 0;
v___x_296_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_296_, 0, v___x_294_);
lean_ctor_set_uint8(v___x_296_, sizeof(void*)*1, v___x_295_);
v___x_297_ = l_Repr_addAppParen(v___x_296_, v_prec_219_);
return v___x_297_;
}
}
default: 
{
lean_object* v_a_302_; lean_object* v___x_304_; uint8_t v_isShared_305_; uint8_t v_isSharedCheck_322_; 
v_a_302_ = lean_ctor_get(v_x_218_, 0);
v_isSharedCheck_322_ = !lean_is_exclusive(v_x_218_);
if (v_isSharedCheck_322_ == 0)
{
v___x_304_ = v_x_218_;
v_isShared_305_ = v_isSharedCheck_322_;
goto v_resetjp_303_;
}
else
{
lean_inc(v_a_302_);
lean_dec(v_x_218_);
v___x_304_ = lean_box(0);
v_isShared_305_ = v_isSharedCheck_322_;
goto v_resetjp_303_;
}
v_resetjp_303_:
{
lean_object* v___y_307_; lean_object* v___x_318_; uint8_t v___x_319_; 
v___x_318_ = lean_unsigned_to_nat(1024u);
v___x_319_ = lean_nat_dec_le(v___x_318_, v_prec_219_);
if (v___x_319_ == 0)
{
lean_object* v___x_320_; 
v___x_320_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__4);
v___y_307_ = v___x_320_;
goto v___jp_306_;
}
else
{
lean_object* v___x_321_; 
v___x_321_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__5);
v___y_307_ = v___x_321_;
goto v___jp_306_;
}
v___jp_306_:
{
lean_object* v___x_308_; lean_object* v___x_309_; lean_object* v___x_311_; 
v___x_308_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__17));
v___x_309_ = l_Nat_reprFast(v_a_302_);
if (v_isShared_305_ == 0)
{
lean_ctor_set_tag(v___x_304_, 3);
lean_ctor_set(v___x_304_, 0, v___x_309_);
v___x_311_ = v___x_304_;
goto v_reusejp_310_;
}
else
{
lean_object* v_reuseFailAlloc_317_; 
v_reuseFailAlloc_317_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_317_, 0, v___x_309_);
v___x_311_ = v_reuseFailAlloc_317_;
goto v_reusejp_310_;
}
v_reusejp_310_:
{
lean_object* v___x_312_; lean_object* v___x_313_; uint8_t v___x_314_; lean_object* v___x_315_; lean_object* v___x_316_; 
v___x_312_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_312_, 0, v___x_308_);
lean_ctor_set(v___x_312_, 1, v___x_311_);
lean_inc(v___y_307_);
v___x_313_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_313_, 0, v___y_307_);
lean_ctor_set(v___x_313_, 1, v___x_312_);
v___x_314_ = 0;
v___x_315_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_315_, 0, v___x_313_);
lean_ctor_set_uint8(v___x_315_, sizeof(void*)*1, v___x_314_);
v___x_316_ = l_Repr_addAppParen(v___x_315_, v_prec_219_);
return v___x_316_;
}
}
}
}
}
v___jp_220_:
{
lean_object* v___x_224_; lean_object* v___x_225_; uint8_t v___x_226_; lean_object* v___x_227_; lean_object* v___x_228_; 
lean_inc(v___y_222_);
v___x_224_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_224_, 0, v___y_222_);
lean_ctor_set(v___x_224_, 1, v___y_223_);
lean_inc(v___y_221_);
v___x_225_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_225_, 0, v___y_221_);
lean_ctor_set(v___x_225_, 1, v___x_224_);
v___x_226_ = 0;
v___x_227_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_227_, 0, v___x_225_);
lean_ctor_set_uint8(v___x_227_, sizeof(void*)*1, v___x_226_);
v___x_228_ = l_Repr_addAppParen(v___x_227_, v_prec_219_);
return v___x_228_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprPacked_repr___boxed(lean_object* v_x_323_, lean_object* v_prec_324_){
_start:
{
lean_object* v_res_325_; 
v_res_325_ = l_FormalSpecAgent_MachineObserve_instReprPacked_repr(v_x_323_, v_prec_324_);
lean_dec(v_prec_324_);
return v_res_325_;
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0(lean_object* v_a_326_, lean_object* v_n_327_){
_start:
{
lean_object* v___x_328_; 
v___x_328_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg(v_a_326_);
return v___x_328_;
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___boxed(lean_object* v_a_329_, lean_object* v_n_330_){
_start:
{
lean_object* v_res_331_; 
v_res_331_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0(v_a_329_, v_n_330_);
lean_dec(v_n_330_);
return v_res_331_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_packed(uint8_t v_k_334_, lean_object* v_v_335_){
_start:
{
switch(v_k_334_)
{
case 0:
{
lean_object* v___x_336_; 
v___x_336_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_336_, 0, v_v_335_);
return v___x_336_;
}
case 1:
{
lean_object* v___x_337_; uint8_t v___x_338_; 
v___x_337_ = lean_alloc_ctor(1, 0, 1);
v___x_338_ = lean_unbox(v_v_335_);
lean_dec(v_v_335_);
lean_ctor_set_uint8(v___x_337_, 0, v___x_338_);
return v___x_337_;
}
case 2:
{
lean_object* v___x_339_; 
v___x_339_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_339_, 0, v_v_335_);
return v___x_339_;
}
case 3:
{
lean_object* v___x_340_; 
v___x_340_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_340_, 0, v_v_335_);
return v___x_340_;
}
default: 
{
lean_object* v___x_341_; 
v___x_341_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_341_, 0, v_v_335_);
return v___x_341_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_packed___boxed(lean_object* v_k_342_, lean_object* v_v_343_){
_start:
{
uint8_t v_k_boxed_344_; lean_object* v_res_345_; 
v_k_boxed_344_ = lean_unbox(v_k_342_);
v_res_345_ = l_FormalSpecAgent_MachineObserve_packed(v_k_boxed_344_, v_v_343_);
return v_res_345_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___lam__0(lean_object* v_a_346_, lean_object* v_b_347_){
_start:
{
lean_object* v___x_348_; lean_object* v___x_349_; uint8_t v___x_350_; 
v___x_348_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
v___x_349_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
v___x_350_ = l_instDecidableEqProd___redArg(v___x_348_, v___x_349_, v_a_346_, v_b_347_);
return v___x_350_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___lam__0___boxed(lean_object* v_a_351_, lean_object* v_b_352_){
_start:
{
uint8_t v_res_353_; lean_object* v_r_354_; 
v_res_353_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___lam__0(v_a_351_, v_b_352_);
v_r_354_ = lean_box(v_res_353_);
return v_r_354_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(lean_object* v_x_356_, lean_object* v_x_357_){
_start:
{
lean_object* v_state_358_; lean_object* v_now_359_; lean_object* v_values_360_; lean_object* v_timers_361_; lean_object* v_state_362_; lean_object* v_now_363_; lean_object* v_values_364_; lean_object* v_timers_365_; uint8_t v___x_366_; 
v_state_358_ = lean_ctor_get(v_x_356_, 0);
lean_inc(v_state_358_);
v_now_359_ = lean_ctor_get(v_x_356_, 1);
lean_inc(v_now_359_);
v_values_360_ = lean_ctor_get(v_x_356_, 2);
lean_inc(v_values_360_);
v_timers_361_ = lean_ctor_get(v_x_356_, 3);
lean_inc(v_timers_361_);
lean_dec_ref(v_x_356_);
v_state_362_ = lean_ctor_get(v_x_357_, 0);
lean_inc(v_state_362_);
v_now_363_ = lean_ctor_get(v_x_357_, 1);
lean_inc(v_now_363_);
v_values_364_ = lean_ctor_get(v_x_357_, 2);
lean_inc(v_values_364_);
v_timers_365_ = lean_ctor_get(v_x_357_, 3);
lean_inc(v_timers_365_);
lean_dec_ref(v_x_357_);
v___x_366_ = lean_nat_dec_eq(v_state_358_, v_state_362_);
lean_dec(v_state_362_);
lean_dec(v_state_358_);
if (v___x_366_ == 0)
{
lean_dec(v_timers_365_);
lean_dec(v_values_364_);
lean_dec(v_now_363_);
lean_dec(v_timers_361_);
lean_dec(v_values_360_);
lean_dec(v_now_359_);
return v___x_366_;
}
else
{
uint8_t v___x_367_; 
v___x_367_ = lean_int_dec_eq(v_now_359_, v_now_363_);
lean_dec(v_now_363_);
lean_dec(v_now_359_);
if (v___x_367_ == 0)
{
lean_dec(v_timers_365_);
lean_dec(v_values_364_);
lean_dec(v_timers_361_);
lean_dec(v_values_360_);
return v___x_367_;
}
else
{
lean_object* v___x_368_; uint8_t v___x_369_; 
v___x_368_ = lean_alloc_closure((void*)(l_FormalSpecAgent_MachineObserve_instDecidableEqPacked___boxed), 2, 0);
v___x_369_ = l_instDecidableEqList___redArg(v___x_368_, v_values_360_, v_values_364_);
if (v___x_369_ == 0)
{
lean_dec(v_timers_365_);
lean_dec(v_timers_361_);
return v___x_369_;
}
else
{
lean_object* v___f_370_; uint8_t v___x_371_; 
v___f_370_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___closed__0));
v___x_371_ = l_instDecidableEqList___redArg(v___f_370_, v_timers_361_, v_timers_365_);
return v___x_371_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq___boxed(lean_object* v_x_372_, lean_object* v_x_373_){
_start:
{
uint8_t v_res_374_; lean_object* v_r_375_; 
v_res_374_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(v_x_372_, v_x_373_);
v_r_375_ = lean_box(v_res_374_);
return v_r_375_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot(lean_object* v_x_376_, lean_object* v_x_377_){
_start:
{
uint8_t v___x_378_; 
v___x_378_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(v_x_376_, v_x_377_);
return v___x_378_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot___boxed(lean_object* v_x_379_, lean_object* v_x_380_){
_start:
{
uint8_t v_res_381_; lean_object* v_r_382_; 
v_res_381_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot(v_x_379_, v_x_380_);
v_r_382_ = lean_box(v_res_381_);
return v_r_382_;
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0_spec__1_spec__3(lean_object* v_x_383_, lean_object* v_x_384_, lean_object* v_x_385_){
_start:
{
if (lean_obj_tag(v_x_385_) == 0)
{
lean_dec(v_x_383_);
return v_x_384_;
}
else
{
lean_object* v_head_386_; lean_object* v_tail_387_; lean_object* v___x_389_; uint8_t v_isShared_390_; uint8_t v_isSharedCheck_398_; 
v_head_386_ = lean_ctor_get(v_x_385_, 0);
v_tail_387_ = lean_ctor_get(v_x_385_, 1);
v_isSharedCheck_398_ = !lean_is_exclusive(v_x_385_);
if (v_isSharedCheck_398_ == 0)
{
v___x_389_ = v_x_385_;
v_isShared_390_ = v_isSharedCheck_398_;
goto v_resetjp_388_;
}
else
{
lean_inc(v_tail_387_);
lean_inc(v_head_386_);
lean_dec(v_x_385_);
v___x_389_ = lean_box(0);
v_isShared_390_ = v_isSharedCheck_398_;
goto v_resetjp_388_;
}
v_resetjp_388_:
{
lean_object* v___x_392_; 
lean_inc(v_x_383_);
if (v_isShared_390_ == 0)
{
lean_ctor_set_tag(v___x_389_, 5);
lean_ctor_set(v___x_389_, 1, v_x_383_);
lean_ctor_set(v___x_389_, 0, v_x_384_);
v___x_392_ = v___x_389_;
goto v_reusejp_391_;
}
else
{
lean_object* v_reuseFailAlloc_397_; 
v_reuseFailAlloc_397_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_397_, 0, v_x_384_);
lean_ctor_set(v_reuseFailAlloc_397_, 1, v_x_383_);
v___x_392_ = v_reuseFailAlloc_397_;
goto v_reusejp_391_;
}
v_reusejp_391_:
{
lean_object* v___x_393_; lean_object* v___x_394_; lean_object* v___x_395_; 
v___x_393_ = lean_unsigned_to_nat(0u);
v___x_394_ = l_FormalSpecAgent_MachineObserve_instReprPacked_repr(v_head_386_, v___x_393_);
v___x_395_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_395_, 0, v___x_392_);
lean_ctor_set(v___x_395_, 1, v___x_394_);
v_x_384_ = v___x_395_;
v_x_385_ = v_tail_387_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0_spec__1(lean_object* v_x_399_, lean_object* v_x_400_, lean_object* v_x_401_){
_start:
{
if (lean_obj_tag(v_x_401_) == 0)
{
lean_dec(v_x_399_);
return v_x_400_;
}
else
{
lean_object* v_head_402_; lean_object* v_tail_403_; lean_object* v___x_405_; uint8_t v_isShared_406_; uint8_t v_isSharedCheck_414_; 
v_head_402_ = lean_ctor_get(v_x_401_, 0);
v_tail_403_ = lean_ctor_get(v_x_401_, 1);
v_isSharedCheck_414_ = !lean_is_exclusive(v_x_401_);
if (v_isSharedCheck_414_ == 0)
{
v___x_405_ = v_x_401_;
v_isShared_406_ = v_isSharedCheck_414_;
goto v_resetjp_404_;
}
else
{
lean_inc(v_tail_403_);
lean_inc(v_head_402_);
lean_dec(v_x_401_);
v___x_405_ = lean_box(0);
v_isShared_406_ = v_isSharedCheck_414_;
goto v_resetjp_404_;
}
v_resetjp_404_:
{
lean_object* v___x_408_; 
lean_inc(v_x_399_);
if (v_isShared_406_ == 0)
{
lean_ctor_set_tag(v___x_405_, 5);
lean_ctor_set(v___x_405_, 1, v_x_399_);
lean_ctor_set(v___x_405_, 0, v_x_400_);
v___x_408_ = v___x_405_;
goto v_reusejp_407_;
}
else
{
lean_object* v_reuseFailAlloc_413_; 
v_reuseFailAlloc_413_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_413_, 0, v_x_400_);
lean_ctor_set(v_reuseFailAlloc_413_, 1, v_x_399_);
v___x_408_ = v_reuseFailAlloc_413_;
goto v_reusejp_407_;
}
v_reusejp_407_:
{
lean_object* v___x_409_; lean_object* v___x_410_; lean_object* v___x_411_; lean_object* v___x_412_; 
v___x_409_ = lean_unsigned_to_nat(0u);
v___x_410_ = l_FormalSpecAgent_MachineObserve_instReprPacked_repr(v_head_402_, v___x_409_);
v___x_411_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_411_, 0, v___x_408_);
lean_ctor_set(v___x_411_, 1, v___x_410_);
v___x_412_ = l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0_spec__1_spec__3(v_x_399_, v___x_411_, v_tail_403_);
return v___x_412_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0___lam__0(lean_object* v___y_415_){
_start:
{
lean_object* v___x_416_; lean_object* v___x_417_; 
v___x_416_ = lean_unsigned_to_nat(0u);
v___x_417_ = l_FormalSpecAgent_MachineObserve_instReprPacked_repr(v___y_415_, v___x_416_);
return v___x_417_;
}
}
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0(lean_object* v_x_418_, lean_object* v_x_419_){
_start:
{
if (lean_obj_tag(v_x_418_) == 0)
{
lean_object* v___x_420_; 
lean_dec(v_x_419_);
v___x_420_ = lean_box(0);
return v___x_420_;
}
else
{
lean_object* v_tail_421_; 
v_tail_421_ = lean_ctor_get(v_x_418_, 1);
if (lean_obj_tag(v_tail_421_) == 0)
{
lean_object* v_head_422_; lean_object* v___x_423_; 
lean_dec(v_x_419_);
v_head_422_ = lean_ctor_get(v_x_418_, 0);
lean_inc(v_head_422_);
lean_dec_ref_known(v_x_418_, 2);
v___x_423_ = l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0___lam__0(v_head_422_);
return v___x_423_;
}
else
{
lean_object* v_head_424_; lean_object* v___x_425_; lean_object* v___x_426_; 
lean_inc(v_tail_421_);
v_head_424_ = lean_ctor_get(v_x_418_, 0);
lean_inc(v_head_424_);
lean_dec_ref_known(v_x_418_, 2);
v___x_425_ = l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0___lam__0(v_head_424_);
v___x_426_ = l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0_spec__1(v_x_419_, v___x_425_, v_tail_421_);
return v___x_426_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0___redArg(lean_object* v_a_427_){
_start:
{
if (lean_obj_tag(v_a_427_) == 0)
{
lean_object* v___x_428_; 
v___x_428_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__1));
return v___x_428_;
}
else
{
lean_object* v___x_429_; lean_object* v___x_430_; lean_object* v___x_431_; lean_object* v___x_432_; lean_object* v___x_433_; lean_object* v___x_434_; lean_object* v___x_435_; lean_object* v___x_436_; uint8_t v___x_437_; lean_object* v___x_438_; 
v___x_429_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__5));
v___x_430_ = l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0_spec__0(v_a_427_, v___x_429_);
v___x_431_ = lean_obj_once(&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8, &l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8_once, _init_l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8);
v___x_432_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__9));
v___x_433_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_433_, 0, v___x_432_);
lean_ctor_set(v___x_433_, 1, v___x_430_);
v___x_434_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__10));
v___x_435_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_435_, 0, v___x_433_);
lean_ctor_set(v___x_435_, 1, v___x_434_);
v___x_436_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_436_, 0, v___x_431_);
lean_ctor_set(v___x_436_, 1, v___x_435_);
v___x_437_ = 0;
v___x_438_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_438_, 0, v___x_436_);
lean_ctor_set_uint8(v___x_438_, sizeof(void*)*1, v___x_437_);
return v___x_438_;
}
}
}
static lean_object* _init_l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__2(void){
_start:
{
lean_object* v___x_441_; lean_object* v___x_442_; 
v___x_441_ = ((lean_object*)(l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__0));
v___x_442_ = lean_string_length(v___x_441_);
return v___x_442_;
}
}
static lean_object* _init_l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__3(void){
_start:
{
lean_object* v___x_443_; lean_object* v___x_444_; 
v___x_443_ = lean_obj_once(&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__2, &l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__2_once, _init_l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__2);
v___x_444_ = lean_nat_to_int(v___x_443_);
return v___x_444_;
}
}
LEAN_EXPORT lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg(lean_object* v_x_449_){
_start:
{
lean_object* v_fst_450_; lean_object* v_snd_451_; lean_object* v___x_453_; uint8_t v_isShared_454_; uint8_t v_isSharedCheck_483_; 
v_fst_450_ = lean_ctor_get(v_x_449_, 0);
v_snd_451_ = lean_ctor_get(v_x_449_, 1);
v_isSharedCheck_483_ = !lean_is_exclusive(v_x_449_);
if (v_isSharedCheck_483_ == 0)
{
v___x_453_ = v_x_449_;
v_isShared_454_ = v_isSharedCheck_483_;
goto v_resetjp_452_;
}
else
{
lean_inc(v_snd_451_);
lean_inc(v_fst_450_);
lean_dec(v_x_449_);
v___x_453_ = lean_box(0);
v_isShared_454_ = v_isSharedCheck_483_;
goto v_resetjp_452_;
}
v_resetjp_452_:
{
lean_object* v___x_455_; lean_object* v___x_456_; lean_object* v___x_457_; lean_object* v___x_459_; 
v___x_455_ = l_Nat_reprFast(v_fst_450_);
v___x_456_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_456_, 0, v___x_455_);
v___x_457_ = lean_box(0);
if (v_isShared_454_ == 0)
{
lean_ctor_set_tag(v___x_453_, 1);
lean_ctor_set(v___x_453_, 1, v___x_457_);
lean_ctor_set(v___x_453_, 0, v___x_456_);
v___x_459_ = v___x_453_;
goto v_reusejp_458_;
}
else
{
lean_object* v_reuseFailAlloc_482_; 
v_reuseFailAlloc_482_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_482_, 0, v___x_456_);
lean_ctor_set(v_reuseFailAlloc_482_, 1, v___x_457_);
v___x_459_ = v_reuseFailAlloc_482_;
goto v_reusejp_458_;
}
v_reusejp_458_:
{
lean_object* v___y_461_; lean_object* v___x_474_; lean_object* v___x_475_; uint8_t v___x_476_; 
v___x_474_ = lean_unsigned_to_nat(0u);
v___x_475_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3);
v___x_476_ = lean_int_dec_lt(v_snd_451_, v___x_475_);
if (v___x_476_ == 0)
{
lean_object* v___x_477_; lean_object* v___x_478_; 
v___x_477_ = l_Int_repr(v_snd_451_);
lean_dec(v_snd_451_);
v___x_478_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_478_, 0, v___x_477_);
v___y_461_ = v___x_478_;
goto v___jp_460_;
}
else
{
lean_object* v___x_479_; lean_object* v___x_480_; lean_object* v___x_481_; 
v___x_479_ = l_Int_repr(v_snd_451_);
lean_dec(v_snd_451_);
v___x_480_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_480_, 0, v___x_479_);
v___x_481_ = l_Repr_addAppParen(v___x_480_, v___x_474_);
v___y_461_ = v___x_481_;
goto v___jp_460_;
}
v___jp_460_:
{
lean_object* v___x_462_; lean_object* v___x_463_; lean_object* v___x_464_; lean_object* v___x_465_; lean_object* v___x_466_; lean_object* v___x_467_; lean_object* v___x_468_; lean_object* v___x_469_; lean_object* v___x_470_; lean_object* v___x_471_; uint8_t v___x_472_; lean_object* v___x_473_; 
v___x_462_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_462_, 0, v___y_461_);
lean_ctor_set(v___x_462_, 1, v___x_459_);
v___x_463_ = l_List_reverse___redArg(v___x_462_);
v___x_464_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__5));
v___x_465_ = l_Std_Format_joinSep___at___00Prod_repr___at___00Array_repr___at___00Std_Http_Protocol_H1_Reader_instReprBodyState_repr_spec__0_spec__0_spec__2(v___x_463_, v___x_464_);
v___x_466_ = lean_obj_once(&l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__3, &l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__3_once, _init_l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__3);
v___x_467_ = ((lean_object*)(l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__4));
v___x_468_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_468_, 0, v___x_467_);
lean_ctor_set(v___x_468_, 1, v___x_465_);
v___x_469_ = ((lean_object*)(l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg___closed__5));
v___x_470_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_470_, 0, v___x_468_);
lean_ctor_set(v___x_470_, 1, v___x_469_);
v___x_471_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_471_, 0, v___x_466_);
lean_ctor_set(v___x_471_, 1, v___x_470_);
v___x_472_ = 0;
v___x_473_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_473_, 0, v___x_471_);
lean_ctor_set_uint8(v___x_473_, sizeof(void*)*1, v___x_472_);
return v___x_473_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3_spec__5_spec__7(lean_object* v_x_484_, lean_object* v_x_485_, lean_object* v_x_486_){
_start:
{
if (lean_obj_tag(v_x_486_) == 0)
{
lean_dec(v_x_484_);
return v_x_485_;
}
else
{
lean_object* v_head_487_; lean_object* v_tail_488_; lean_object* v___x_490_; uint8_t v_isShared_491_; uint8_t v_isSharedCheck_498_; 
v_head_487_ = lean_ctor_get(v_x_486_, 0);
v_tail_488_ = lean_ctor_get(v_x_486_, 1);
v_isSharedCheck_498_ = !lean_is_exclusive(v_x_486_);
if (v_isSharedCheck_498_ == 0)
{
v___x_490_ = v_x_486_;
v_isShared_491_ = v_isSharedCheck_498_;
goto v_resetjp_489_;
}
else
{
lean_inc(v_tail_488_);
lean_inc(v_head_487_);
lean_dec(v_x_486_);
v___x_490_ = lean_box(0);
v_isShared_491_ = v_isSharedCheck_498_;
goto v_resetjp_489_;
}
v_resetjp_489_:
{
lean_object* v___x_493_; 
lean_inc(v_x_484_);
if (v_isShared_491_ == 0)
{
lean_ctor_set_tag(v___x_490_, 5);
lean_ctor_set(v___x_490_, 1, v_x_484_);
lean_ctor_set(v___x_490_, 0, v_x_485_);
v___x_493_ = v___x_490_;
goto v_reusejp_492_;
}
else
{
lean_object* v_reuseFailAlloc_497_; 
v_reuseFailAlloc_497_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_497_, 0, v_x_485_);
lean_ctor_set(v_reuseFailAlloc_497_, 1, v_x_484_);
v___x_493_ = v_reuseFailAlloc_497_;
goto v_reusejp_492_;
}
v_reusejp_492_:
{
lean_object* v___x_494_; lean_object* v___x_495_; 
v___x_494_ = l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg(v_head_487_);
v___x_495_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_495_, 0, v___x_493_);
lean_ctor_set(v___x_495_, 1, v___x_494_);
v_x_485_ = v___x_495_;
v_x_486_ = v_tail_488_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3_spec__5(lean_object* v_x_499_, lean_object* v_x_500_, lean_object* v_x_501_){
_start:
{
if (lean_obj_tag(v_x_501_) == 0)
{
lean_dec(v_x_499_);
return v_x_500_;
}
else
{
lean_object* v_head_502_; lean_object* v_tail_503_; lean_object* v___x_505_; uint8_t v_isShared_506_; uint8_t v_isSharedCheck_513_; 
v_head_502_ = lean_ctor_get(v_x_501_, 0);
v_tail_503_ = lean_ctor_get(v_x_501_, 1);
v_isSharedCheck_513_ = !lean_is_exclusive(v_x_501_);
if (v_isSharedCheck_513_ == 0)
{
v___x_505_ = v_x_501_;
v_isShared_506_ = v_isSharedCheck_513_;
goto v_resetjp_504_;
}
else
{
lean_inc(v_tail_503_);
lean_inc(v_head_502_);
lean_dec(v_x_501_);
v___x_505_ = lean_box(0);
v_isShared_506_ = v_isSharedCheck_513_;
goto v_resetjp_504_;
}
v_resetjp_504_:
{
lean_object* v___x_508_; 
lean_inc(v_x_499_);
if (v_isShared_506_ == 0)
{
lean_ctor_set_tag(v___x_505_, 5);
lean_ctor_set(v___x_505_, 1, v_x_499_);
lean_ctor_set(v___x_505_, 0, v_x_500_);
v___x_508_ = v___x_505_;
goto v_reusejp_507_;
}
else
{
lean_object* v_reuseFailAlloc_512_; 
v_reuseFailAlloc_512_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_512_, 0, v_x_500_);
lean_ctor_set(v_reuseFailAlloc_512_, 1, v_x_499_);
v___x_508_ = v_reuseFailAlloc_512_;
goto v_reusejp_507_;
}
v_reusejp_507_:
{
lean_object* v___x_509_; lean_object* v___x_510_; lean_object* v___x_511_; 
v___x_509_ = l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg(v_head_502_);
v___x_510_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_510_, 0, v___x_508_);
lean_ctor_set(v___x_510_, 1, v___x_509_);
v___x_511_ = l_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3_spec__5_spec__7(v_x_499_, v___x_510_, v_tail_503_);
return v___x_511_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3(lean_object* v_x_514_, lean_object* v_x_515_){
_start:
{
if (lean_obj_tag(v_x_514_) == 0)
{
lean_object* v___x_516_; 
lean_dec(v_x_515_);
v___x_516_ = lean_box(0);
return v___x_516_;
}
else
{
lean_object* v_tail_517_; 
v_tail_517_ = lean_ctor_get(v_x_514_, 1);
if (lean_obj_tag(v_tail_517_) == 0)
{
lean_object* v_head_518_; lean_object* v___x_519_; 
lean_dec(v_x_515_);
v_head_518_ = lean_ctor_get(v_x_514_, 0);
lean_inc(v_head_518_);
lean_dec_ref_known(v_x_514_, 2);
v___x_519_ = l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg(v_head_518_);
return v___x_519_;
}
else
{
lean_object* v_head_520_; lean_object* v___x_521_; lean_object* v___x_522_; 
lean_inc(v_tail_517_);
v_head_520_ = lean_ctor_get(v_x_514_, 0);
lean_inc(v_head_520_);
lean_dec_ref_known(v_x_514_, 2);
v___x_521_ = l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg(v_head_520_);
v___x_522_ = l_List_foldl___at___00Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3_spec__5(v_x_515_, v___x_521_, v_tail_517_);
return v___x_522_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1___redArg(lean_object* v_a_523_){
_start:
{
if (lean_obj_tag(v_a_523_) == 0)
{
lean_object* v___x_524_; 
v___x_524_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__1));
return v___x_524_;
}
else
{
lean_object* v___x_525_; lean_object* v___x_526_; lean_object* v___x_527_; lean_object* v___x_528_; lean_object* v___x_529_; lean_object* v___x_530_; lean_object* v___x_531_; lean_object* v___x_532_; uint8_t v___x_533_; lean_object* v___x_534_; 
v___x_525_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__5));
v___x_526_ = l_Std_Format_joinSep___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__3(v_a_523_, v___x_525_);
v___x_527_ = lean_obj_once(&l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8, &l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8_once, _init_l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__8);
v___x_528_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__9));
v___x_529_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_529_, 0, v___x_528_);
lean_ctor_set(v___x_529_, 1, v___x_526_);
v___x_530_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__10));
v___x_531_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_531_, 0, v___x_529_);
lean_ctor_set(v___x_531_, 1, v___x_530_);
v___x_532_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_532_, 0, v___x_527_);
lean_ctor_set(v___x_532_, 1, v___x_531_);
v___x_533_ = 0;
v___x_534_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_534_, 0, v___x_532_);
lean_ctor_set_uint8(v___x_534_, sizeof(void*)*1, v___x_533_);
return v___x_534_;
}
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__7(void){
_start:
{
lean_object* v___x_548_; lean_object* v___x_549_; 
v___x_548_ = lean_unsigned_to_nat(9u);
v___x_549_ = lean_nat_to_int(v___x_548_);
return v___x_549_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__10(void){
_start:
{
lean_object* v___x_553_; lean_object* v___x_554_; 
v___x_553_ = lean_unsigned_to_nat(7u);
v___x_554_ = lean_nat_to_int(v___x_553_);
return v___x_554_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__13(void){
_start:
{
lean_object* v___x_558_; lean_object* v___x_559_; 
v___x_558_ = lean_unsigned_to_nat(10u);
v___x_559_ = lean_nat_to_int(v___x_558_);
return v___x_559_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__17(void){
_start:
{
lean_object* v___x_564_; lean_object* v___x_565_; 
v___x_564_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__0));
v___x_565_ = lean_string_length(v___x_564_);
return v___x_565_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__18(void){
_start:
{
lean_object* v___x_566_; lean_object* v___x_567_; 
v___x_566_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__17, &l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__17_once, _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__17);
v___x_567_ = lean_nat_to_int(v___x_566_);
return v___x_567_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg(lean_object* v_x_572_){
_start:
{
lean_object* v_state_573_; lean_object* v_now_574_; lean_object* v_values_575_; lean_object* v_timers_576_; lean_object* v___x_577_; lean_object* v___x_578_; lean_object* v___x_579_; lean_object* v___x_580_; lean_object* v___x_581_; lean_object* v___x_582_; uint8_t v___x_583_; lean_object* v___x_584_; lean_object* v___x_585_; lean_object* v___x_586_; lean_object* v___x_587_; lean_object* v___x_588_; lean_object* v___x_589_; lean_object* v___x_590_; lean_object* v___x_591_; lean_object* v___x_592_; lean_object* v___x_593_; lean_object* v___y_595_; lean_object* v___x_625_; lean_object* v___x_626_; uint8_t v___x_627_; 
v_state_573_ = lean_ctor_get(v_x_572_, 0);
lean_inc(v_state_573_);
v_now_574_ = lean_ctor_get(v_x_572_, 1);
lean_inc(v_now_574_);
v_values_575_ = lean_ctor_get(v_x_572_, 2);
lean_inc(v_values_575_);
v_timers_576_ = lean_ctor_get(v_x_572_, 3);
lean_inc(v_timers_576_);
lean_dec_ref(v_x_572_);
v___x_577_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__5));
v___x_578_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__6));
v___x_579_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__7, &l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__7_once, _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__7);
v___x_580_ = l_Nat_reprFast(v_state_573_);
v___x_581_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_581_, 0, v___x_580_);
v___x_582_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_582_, 0, v___x_579_);
lean_ctor_set(v___x_582_, 1, v___x_581_);
v___x_583_ = 0;
v___x_584_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_584_, 0, v___x_582_);
lean_ctor_set_uint8(v___x_584_, sizeof(void*)*1, v___x_583_);
v___x_585_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_585_, 0, v___x_578_);
lean_ctor_set(v___x_585_, 1, v___x_584_);
v___x_586_ = ((lean_object*)(l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprPacked_repr_spec__0___redArg___closed__4));
v___x_587_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_587_, 0, v___x_585_);
lean_ctor_set(v___x_587_, 1, v___x_586_);
v___x_588_ = lean_box(1);
v___x_589_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_589_, 0, v___x_587_);
lean_ctor_set(v___x_589_, 1, v___x_588_);
v___x_590_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__9));
v___x_591_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_591_, 0, v___x_589_);
lean_ctor_set(v___x_591_, 1, v___x_590_);
v___x_592_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_592_, 0, v___x_591_);
lean_ctor_set(v___x_592_, 1, v___x_577_);
v___x_593_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__10, &l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__10_once, _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__10);
v___x_625_ = lean_unsigned_to_nat(0u);
v___x_626_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3, &l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3_once, _init_l_FormalSpecAgent_MachineObserve_instReprPacked_repr___closed__3);
v___x_627_ = lean_int_dec_lt(v_now_574_, v___x_626_);
if (v___x_627_ == 0)
{
lean_object* v___x_628_; lean_object* v___x_629_; 
v___x_628_ = l_Int_repr(v_now_574_);
lean_dec(v_now_574_);
v___x_629_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_629_, 0, v___x_628_);
v___y_595_ = v___x_629_;
goto v___jp_594_;
}
else
{
lean_object* v___x_630_; lean_object* v___x_631_; lean_object* v___x_632_; 
v___x_630_ = l_Int_repr(v_now_574_);
lean_dec(v_now_574_);
v___x_631_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_631_, 0, v___x_630_);
v___x_632_ = l_Repr_addAppParen(v___x_631_, v___x_625_);
v___y_595_ = v___x_632_;
goto v___jp_594_;
}
v___jp_594_:
{
lean_object* v___x_596_; lean_object* v___x_597_; lean_object* v___x_598_; lean_object* v___x_599_; lean_object* v___x_600_; lean_object* v___x_601_; lean_object* v___x_602_; lean_object* v___x_603_; lean_object* v___x_604_; lean_object* v___x_605_; lean_object* v___x_606_; lean_object* v___x_607_; lean_object* v___x_608_; lean_object* v___x_609_; lean_object* v___x_610_; lean_object* v___x_611_; lean_object* v___x_612_; lean_object* v___x_613_; lean_object* v___x_614_; lean_object* v___x_615_; lean_object* v___x_616_; lean_object* v___x_617_; lean_object* v___x_618_; lean_object* v___x_619_; lean_object* v___x_620_; lean_object* v___x_621_; lean_object* v___x_622_; lean_object* v___x_623_; lean_object* v___x_624_; 
v___x_596_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_596_, 0, v___x_593_);
lean_ctor_set(v___x_596_, 1, v___y_595_);
v___x_597_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_597_, 0, v___x_596_);
lean_ctor_set_uint8(v___x_597_, sizeof(void*)*1, v___x_583_);
v___x_598_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_598_, 0, v___x_592_);
lean_ctor_set(v___x_598_, 1, v___x_597_);
v___x_599_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_599_, 0, v___x_598_);
lean_ctor_set(v___x_599_, 1, v___x_586_);
v___x_600_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_600_, 0, v___x_599_);
lean_ctor_set(v___x_600_, 1, v___x_588_);
v___x_601_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__12));
v___x_602_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_602_, 0, v___x_600_);
lean_ctor_set(v___x_602_, 1, v___x_601_);
v___x_603_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_603_, 0, v___x_602_);
lean_ctor_set(v___x_603_, 1, v___x_577_);
v___x_604_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__13, &l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__13_once, _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__13);
v___x_605_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0___redArg(v_values_575_);
v___x_606_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_606_, 0, v___x_604_);
lean_ctor_set(v___x_606_, 1, v___x_605_);
v___x_607_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_607_, 0, v___x_606_);
lean_ctor_set_uint8(v___x_607_, sizeof(void*)*1, v___x_583_);
v___x_608_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_608_, 0, v___x_603_);
lean_ctor_set(v___x_608_, 1, v___x_607_);
v___x_609_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_609_, 0, v___x_608_);
lean_ctor_set(v___x_609_, 1, v___x_586_);
v___x_610_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_610_, 0, v___x_609_);
lean_ctor_set(v___x_610_, 1, v___x_588_);
v___x_611_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__15));
v___x_612_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_612_, 0, v___x_610_);
lean_ctor_set(v___x_612_, 1, v___x_611_);
v___x_613_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_613_, 0, v___x_612_);
lean_ctor_set(v___x_613_, 1, v___x_577_);
v___x_614_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1___redArg(v_timers_576_);
v___x_615_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_615_, 0, v___x_604_);
lean_ctor_set(v___x_615_, 1, v___x_614_);
v___x_616_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_616_, 0, v___x_615_);
lean_ctor_set_uint8(v___x_616_, sizeof(void*)*1, v___x_583_);
v___x_617_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_617_, 0, v___x_613_);
lean_ctor_set(v___x_617_, 1, v___x_616_);
v___x_618_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__18, &l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__18_once, _init_l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__18);
v___x_619_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__19));
v___x_620_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_620_, 0, v___x_619_);
lean_ctor_set(v___x_620_, 1, v___x_617_);
v___x_621_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg___closed__20));
v___x_622_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_622_, 0, v___x_620_);
lean_ctor_set(v___x_622_, 1, v___x_621_);
v___x_623_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_623_, 0, v___x_618_);
lean_ctor_set(v___x_623_, 1, v___x_622_);
v___x_624_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_624_, 0, v___x_623_);
lean_ctor_set_uint8(v___x_624_, sizeof(void*)*1, v___x_583_);
return v___x_624_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr(lean_object* v_x_633_, lean_object* v_prec_634_){
_start:
{
lean_object* v___x_635_; 
v___x_635_ = l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___redArg(v_x_633_);
return v___x_635_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr___boxed(lean_object* v_x_636_, lean_object* v_prec_637_){
_start:
{
lean_object* v_res_638_; 
v_res_638_ = l_FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr(v_x_636_, v_prec_637_);
lean_dec(v_prec_637_);
return v_res_638_;
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0(lean_object* v_a_639_, lean_object* v_n_640_){
_start:
{
lean_object* v___x_641_; 
v___x_641_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0___redArg(v_a_639_);
return v___x_641_;
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0___boxed(lean_object* v_a_642_, lean_object* v_n_643_){
_start:
{
lean_object* v_res_644_; 
v_res_644_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__0(v_a_642_, v_n_643_);
lean_dec(v_n_643_);
return v_res_644_;
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1(lean_object* v_a_645_, lean_object* v_n_646_){
_start:
{
lean_object* v___x_647_; 
v___x_647_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1___redArg(v_a_645_);
return v___x_647_;
}
}
LEAN_EXPORT lean_object* l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1___boxed(lean_object* v_a_648_, lean_object* v_n_649_){
_start:
{
lean_object* v_res_650_; 
v_res_650_ = l_List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1(v_a_648_, v_n_649_);
lean_dec(v_n_649_);
return v_res_650_;
}
}
LEAN_EXPORT lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2(lean_object* v_x_651_, lean_object* v_x_652_){
_start:
{
lean_object* v___x_653_; 
v___x_653_ = l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___redArg(v_x_651_);
return v___x_653_;
}
}
LEAN_EXPORT lean_object* l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2___boxed(lean_object* v_x_654_, lean_object* v_x_655_){
_start:
{
lean_object* v_res_656_; 
v_res_656_ = l_Prod_repr___at___00List_repr___at___00FormalSpecAgent_MachineObserve_instReprSeenSnapshot_repr_spec__1_spec__2(v_x_654_, v_x_655_);
lean_dec(v_x_655_);
return v_res_656_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_insertBySlot___redArg(lean_object* v_entry_659_, lean_object* v_x_660_){
_start:
{
if (lean_obj_tag(v_x_660_) == 0)
{
lean_object* v___x_661_; 
v___x_661_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_661_, 0, v_entry_659_);
lean_ctor_set(v___x_661_, 1, v_x_660_);
return v___x_661_;
}
else
{
lean_object* v_head_662_; lean_object* v_tail_663_; lean_object* v_fst_664_; lean_object* v_fst_665_; uint8_t v___x_666_; 
v_head_662_ = lean_ctor_get(v_x_660_, 0);
lean_inc(v_head_662_);
v_tail_663_ = lean_ctor_get(v_x_660_, 1);
v_fst_664_ = lean_ctor_get(v_entry_659_, 0);
v_fst_665_ = lean_ctor_get(v_head_662_, 0);
v___x_666_ = lean_nat_dec_le(v_fst_664_, v_fst_665_);
if (v___x_666_ == 0)
{
lean_object* v___x_668_; uint8_t v_isShared_669_; uint8_t v_isSharedCheck_674_; 
lean_inc(v_tail_663_);
v_isSharedCheck_674_ = !lean_is_exclusive(v_x_660_);
if (v_isSharedCheck_674_ == 0)
{
lean_object* v_unused_675_; lean_object* v_unused_676_; 
v_unused_675_ = lean_ctor_get(v_x_660_, 1);
lean_dec(v_unused_675_);
v_unused_676_ = lean_ctor_get(v_x_660_, 0);
lean_dec(v_unused_676_);
v___x_668_ = v_x_660_;
v_isShared_669_ = v_isSharedCheck_674_;
goto v_resetjp_667_;
}
else
{
lean_dec(v_x_660_);
v___x_668_ = lean_box(0);
v_isShared_669_ = v_isSharedCheck_674_;
goto v_resetjp_667_;
}
v_resetjp_667_:
{
lean_object* v___x_670_; lean_object* v___x_672_; 
v___x_670_ = l_FormalSpecAgent_MachineObserve_insertBySlot___redArg(v_entry_659_, v_tail_663_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v___x_670_);
v___x_672_ = v___x_668_;
goto v_reusejp_671_;
}
else
{
lean_object* v_reuseFailAlloc_673_; 
v_reuseFailAlloc_673_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_673_, 0, v_head_662_);
lean_ctor_set(v_reuseFailAlloc_673_, 1, v___x_670_);
v___x_672_ = v_reuseFailAlloc_673_;
goto v_reusejp_671_;
}
v_reusejp_671_:
{
return v___x_672_;
}
}
}
else
{
lean_object* v___x_678_; uint8_t v_isShared_679_; uint8_t v_isSharedCheck_683_; 
v_isSharedCheck_683_ = !lean_is_exclusive(v_head_662_);
if (v_isSharedCheck_683_ == 0)
{
lean_object* v_unused_684_; lean_object* v_unused_685_; 
v_unused_684_ = lean_ctor_get(v_head_662_, 1);
lean_dec(v_unused_684_);
v_unused_685_ = lean_ctor_get(v_head_662_, 0);
lean_dec(v_unused_685_);
v___x_678_ = v_head_662_;
v_isShared_679_ = v_isSharedCheck_683_;
goto v_resetjp_677_;
}
else
{
lean_dec(v_head_662_);
v___x_678_ = lean_box(0);
v_isShared_679_ = v_isSharedCheck_683_;
goto v_resetjp_677_;
}
v_resetjp_677_:
{
lean_object* v___x_681_; 
if (v_isShared_679_ == 0)
{
lean_ctor_set_tag(v___x_678_, 1);
lean_ctor_set(v___x_678_, 1, v_x_660_);
lean_ctor_set(v___x_678_, 0, v_entry_659_);
v___x_681_ = v___x_678_;
goto v_reusejp_680_;
}
else
{
lean_object* v_reuseFailAlloc_682_; 
v_reuseFailAlloc_682_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_682_, 0, v_entry_659_);
lean_ctor_set(v_reuseFailAlloc_682_, 1, v_x_660_);
v___x_681_ = v_reuseFailAlloc_682_;
goto v_reusejp_680_;
}
v_reusejp_680_:
{
return v___x_681_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_insertBySlot(lean_object* v_00_u03b1_686_, lean_object* v_entry_687_, lean_object* v_x_688_){
_start:
{
lean_object* v___x_689_; 
v___x_689_ = l_FormalSpecAgent_MachineObserve_insertBySlot___redArg(v_entry_687_, v_x_688_);
return v___x_689_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___redArg(lean_object* v_as_690_, size_t v_i_691_, size_t v_stop_692_, lean_object* v_b_693_){
_start:
{
uint8_t v___x_694_; 
v___x_694_ = lean_usize_dec_eq(v_i_691_, v_stop_692_);
if (v___x_694_ == 0)
{
size_t v___x_695_; size_t v___x_696_; lean_object* v___x_697_; lean_object* v___x_698_; 
v___x_695_ = ((size_t)1ULL);
v___x_696_ = lean_usize_sub(v_i_691_, v___x_695_);
v___x_697_ = lean_array_uget_borrowed(v_as_690_, v___x_696_);
lean_inc(v___x_697_);
v___x_698_ = l_FormalSpecAgent_MachineObserve_insertBySlot___redArg(v___x_697_, v_b_693_);
v_i_691_ = v___x_696_;
v_b_693_ = v___x_698_;
goto _start;
}
else
{
return v_b_693_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___redArg___boxed(lean_object* v_as_700_, lean_object* v_i_701_, lean_object* v_stop_702_, lean_object* v_b_703_){
_start:
{
size_t v_i_boxed_704_; size_t v_stop_boxed_705_; lean_object* v_res_706_; 
v_i_boxed_704_ = lean_unbox_usize(v_i_701_);
lean_dec(v_i_701_);
v_stop_boxed_705_ = lean_unbox_usize(v_stop_702_);
lean_dec(v_stop_702_);
v_res_706_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___redArg(v_as_700_, v_i_boxed_704_, v_stop_boxed_705_, v_b_703_);
lean_dec_ref(v_as_700_);
return v_res_706_;
}
}
LEAN_EXPORT lean_object* l_List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0___redArg(lean_object* v_init_707_, lean_object* v_l_708_){
_start:
{
lean_object* v___x_709_; lean_object* v___x_710_; lean_object* v___x_711_; uint8_t v___x_712_; 
v___x_709_ = lean_array_mk(v_l_708_);
v___x_710_ = lean_array_get_size(v___x_709_);
v___x_711_ = lean_unsigned_to_nat(0u);
v___x_712_ = lean_nat_dec_lt(v___x_711_, v___x_710_);
if (v___x_712_ == 0)
{
lean_dec_ref(v___x_709_);
return v_init_707_;
}
else
{
size_t v___x_713_; size_t v___x_714_; lean_object* v___x_715_; 
v___x_713_ = lean_usize_of_nat(v___x_710_);
v___x_714_ = ((size_t)0ULL);
v___x_715_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___redArg(v___x_709_, v___x_713_, v___x_714_, v_init_707_);
lean_dec_ref(v___x_709_);
return v___x_715_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_ordered___redArg(lean_object* v_entries_716_){
_start:
{
lean_object* v___x_717_; lean_object* v___x_718_; 
v___x_717_ = lean_box(0);
v___x_718_ = l_List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0___redArg(v___x_717_, v_entries_716_);
return v___x_718_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_ordered(lean_object* v_00_u03b1_719_, lean_object* v_entries_720_){
_start:
{
lean_object* v___x_721_; 
v___x_721_ = l_FormalSpecAgent_MachineObserve_ordered___redArg(v_entries_720_);
return v___x_721_;
}
}
LEAN_EXPORT lean_object* l_List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0(lean_object* v_00_u03b1_722_, lean_object* v_init_723_, lean_object* v_l_724_){
_start:
{
lean_object* v___x_725_; 
v___x_725_ = l_List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0___redArg(v_init_723_, v_l_724_);
return v___x_725_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0(lean_object* v_00_u03b1_726_, lean_object* v_as_727_, size_t v_i_728_, size_t v_stop_729_, lean_object* v_b_730_){
_start:
{
lean_object* v___x_731_; 
v___x_731_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___redArg(v_as_727_, v_i_728_, v_stop_729_, v_b_730_);
return v___x_731_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0___boxed(lean_object* v_00_u03b1_732_, lean_object* v_as_733_, lean_object* v_i_734_, lean_object* v_stop_735_, lean_object* v_b_736_){
_start:
{
size_t v_i_boxed_737_; size_t v_stop_boxed_738_; lean_object* v_res_739_; 
v_i_boxed_737_ = lean_unbox_usize(v_i_734_);
lean_dec(v_i_734_);
v_stop_boxed_738_ = lean_unbox_usize(v_stop_735_);
lean_dec(v_stop_735_);
v_res_739_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00List_foldrTR___at___00FormalSpecAgent_MachineObserve_ordered_spec__0_spec__0(v_00_u03b1_732_, v_as_733_, v_i_boxed_737_, v_stop_boxed_738_, v_b_736_);
lean_dec_ref(v_as_733_);
return v_res_739_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_snapshot_spec__1(lean_object* v_a_740_, lean_object* v_a_741_){
_start:
{
if (lean_obj_tag(v_a_740_) == 0)
{
lean_object* v___x_742_; 
v___x_742_ = l_List_reverse___redArg(v_a_741_);
return v___x_742_;
}
else
{
lean_object* v_head_743_; lean_object* v_tail_744_; lean_object* v___x_746_; uint8_t v_isShared_747_; uint8_t v_isSharedCheck_761_; 
v_head_743_ = lean_ctor_get(v_a_740_, 0);
v_tail_744_ = lean_ctor_get(v_a_740_, 1);
v_isSharedCheck_761_ = !lean_is_exclusive(v_a_740_);
if (v_isSharedCheck_761_ == 0)
{
v___x_746_ = v_a_740_;
v_isShared_747_ = v_isSharedCheck_761_;
goto v_resetjp_745_;
}
else
{
lean_inc(v_tail_744_);
lean_inc(v_head_743_);
lean_dec(v_a_740_);
v___x_746_ = lean_box(0);
v_isShared_747_ = v_isSharedCheck_761_;
goto v_resetjp_745_;
}
v_resetjp_745_:
{
lean_object* v_timer_748_; lean_object* v_due_749_; lean_object* v___x_751_; uint8_t v_isShared_752_; uint8_t v_isSharedCheck_760_; 
v_timer_748_ = lean_ctor_get(v_head_743_, 0);
v_due_749_ = lean_ctor_get(v_head_743_, 1);
v_isSharedCheck_760_ = !lean_is_exclusive(v_head_743_);
if (v_isSharedCheck_760_ == 0)
{
v___x_751_ = v_head_743_;
v_isShared_752_ = v_isSharedCheck_760_;
goto v_resetjp_750_;
}
else
{
lean_inc(v_due_749_);
lean_inc(v_timer_748_);
lean_dec(v_head_743_);
v___x_751_ = lean_box(0);
v_isShared_752_ = v_isSharedCheck_760_;
goto v_resetjp_750_;
}
v_resetjp_750_:
{
lean_object* v___x_754_; 
if (v_isShared_752_ == 0)
{
v___x_754_ = v___x_751_;
goto v_reusejp_753_;
}
else
{
lean_object* v_reuseFailAlloc_759_; 
v_reuseFailAlloc_759_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_759_, 0, v_timer_748_);
lean_ctor_set(v_reuseFailAlloc_759_, 1, v_due_749_);
v___x_754_ = v_reuseFailAlloc_759_;
goto v_reusejp_753_;
}
v_reusejp_753_:
{
lean_object* v___x_756_; 
if (v_isShared_747_ == 0)
{
lean_ctor_set(v___x_746_, 1, v_a_741_);
lean_ctor_set(v___x_746_, 0, v___x_754_);
v___x_756_ = v___x_746_;
goto v_reusejp_755_;
}
else
{
lean_object* v_reuseFailAlloc_758_; 
v_reuseFailAlloc_758_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_758_, 0, v___x_754_);
lean_ctor_set(v_reuseFailAlloc_758_, 1, v_a_741_);
v___x_756_ = v_reuseFailAlloc_758_;
goto v_reusejp_755_;
}
v_reusejp_755_:
{
v_a_740_ = v_tail_744_;
v_a_741_ = v___x_756_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_snapshot_spec__0(lean_object* v_s_762_, lean_object* v_a_763_, lean_object* v_a_764_){
_start:
{
if (lean_obj_tag(v_a_763_) == 0)
{
lean_object* v___x_765_; 
lean_dec_ref(v_s_762_);
v___x_765_ = l_List_reverse___redArg(v_a_764_);
return v___x_765_;
}
else
{
lean_object* v_head_766_; lean_object* v_tail_767_; lean_object* v___x_769_; uint8_t v_isShared_770_; uint8_t v_isSharedCheck_782_; 
v_head_766_ = lean_ctor_get(v_a_763_, 0);
v_tail_767_ = lean_ctor_get(v_a_763_, 1);
v_isSharedCheck_782_ = !lean_is_exclusive(v_a_763_);
if (v_isSharedCheck_782_ == 0)
{
v___x_769_ = v_a_763_;
v_isShared_770_ = v_isSharedCheck_782_;
goto v_resetjp_768_;
}
else
{
lean_inc(v_tail_767_);
lean_inc(v_head_766_);
lean_dec(v_a_763_);
v___x_769_ = lean_box(0);
v_isShared_770_ = v_isSharedCheck_782_;
goto v_resetjp_768_;
}
v_resetjp_768_:
{
lean_object* v_fst_771_; lean_object* v_snd_772_; lean_object* v_values_773_; uint8_t v___x_774_; lean_object* v___x_775_; uint8_t v___x_776_; lean_object* v___x_777_; lean_object* v___x_779_; 
v_fst_771_ = lean_ctor_get(v_head_766_, 0);
lean_inc(v_fst_771_);
v_snd_772_ = lean_ctor_get(v_head_766_, 1);
lean_inc(v_snd_772_);
lean_dec(v_head_766_);
v_values_773_ = lean_ctor_get(v_s_762_, 0);
v___x_774_ = lean_unbox(v_fst_771_);
lean_inc_ref(v_values_773_);
v___x_775_ = l_FormalSpecAgent_TypedIR_getValue(v___x_774_, v_values_773_, v_snd_772_);
v___x_776_ = lean_unbox(v_fst_771_);
lean_dec(v_fst_771_);
v___x_777_ = l_FormalSpecAgent_MachineObserve_packed(v___x_776_, v___x_775_);
if (v_isShared_770_ == 0)
{
lean_ctor_set(v___x_769_, 1, v_a_764_);
lean_ctor_set(v___x_769_, 0, v___x_777_);
v___x_779_ = v___x_769_;
goto v_reusejp_778_;
}
else
{
lean_object* v_reuseFailAlloc_781_; 
v_reuseFailAlloc_781_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_781_, 0, v___x_777_);
lean_ctor_set(v_reuseFailAlloc_781_, 1, v_a_764_);
v___x_779_ = v_reuseFailAlloc_781_;
goto v_reusejp_778_;
}
v_reusejp_778_:
{
v_a_763_ = v_tail_767_;
v_a_764_ = v___x_779_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_snapshot(lean_object* v_schema_783_, lean_object* v_s_784_){
_start:
{
lean_object* v_state_785_; lean_object* v_now_786_; lean_object* v_timers_787_; lean_object* v___x_788_; lean_object* v___x_789_; lean_object* v___x_790_; lean_object* v___x_791_; lean_object* v___x_792_; 
v_state_785_ = lean_ctor_get(v_s_784_, 1);
lean_inc(v_state_785_);
v_now_786_ = lean_ctor_get(v_s_784_, 2);
lean_inc(v_now_786_);
v_timers_787_ = lean_ctor_get(v_s_784_, 3);
lean_inc(v_timers_787_);
v___x_788_ = lean_box(0);
v___x_789_ = l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_snapshot_spec__0(v_s_784_, v_schema_783_, v___x_788_);
v___x_790_ = l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_snapshot_spec__1(v_timers_787_, v___x_788_);
v___x_791_ = l_FormalSpecAgent_MachineObserve_ordered___redArg(v___x_790_);
v___x_792_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_792_, 0, v_state_785_);
lean_ctor_set(v___x_792_, 1, v_now_786_);
lean_ctor_set(v___x_792_, 2, v___x_789_);
lean_ctor_set(v___x_792_, 3, v___x_791_);
return v___x_792_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_message_spec__0(lean_object* v_a_793_, lean_object* v_a_794_){
_start:
{
if (lean_obj_tag(v_a_793_) == 0)
{
lean_object* v___x_795_; 
v___x_795_ = l_List_reverse___redArg(v_a_794_);
return v___x_795_;
}
else
{
lean_object* v_head_796_; lean_object* v_tail_797_; lean_object* v___x_799_; uint8_t v_isShared_800_; uint8_t v_isSharedCheck_810_; 
v_head_796_ = lean_ctor_get(v_a_793_, 0);
v_tail_797_ = lean_ctor_get(v_a_793_, 1);
v_isSharedCheck_810_ = !lean_is_exclusive(v_a_793_);
if (v_isSharedCheck_810_ == 0)
{
v___x_799_ = v_a_793_;
v_isShared_800_ = v_isSharedCheck_810_;
goto v_resetjp_798_;
}
else
{
lean_inc(v_tail_797_);
lean_inc(v_head_796_);
lean_dec(v_a_793_);
v___x_799_ = lean_box(0);
v_isShared_800_ = v_isSharedCheck_810_;
goto v_resetjp_798_;
}
v_resetjp_798_:
{
lean_object* v_slot_801_; uint8_t v_kind_802_; lean_object* v_value_803_; lean_object* v___x_804_; lean_object* v___x_805_; lean_object* v___x_807_; 
v_slot_801_ = lean_ctor_get(v_head_796_, 0);
lean_inc(v_slot_801_);
v_kind_802_ = lean_ctor_get_uint8(v_head_796_, sizeof(void*)*2);
v_value_803_ = lean_ctor_get(v_head_796_, 1);
lean_inc(v_value_803_);
lean_dec(v_head_796_);
v___x_804_ = l_FormalSpecAgent_MachineObserve_packed(v_kind_802_, v_value_803_);
v___x_805_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_805_, 0, v_slot_801_);
lean_ctor_set(v___x_805_, 1, v___x_804_);
if (v_isShared_800_ == 0)
{
lean_ctor_set(v___x_799_, 1, v_a_794_);
lean_ctor_set(v___x_799_, 0, v___x_805_);
v___x_807_ = v___x_799_;
goto v_reusejp_806_;
}
else
{
lean_object* v_reuseFailAlloc_809_; 
v_reuseFailAlloc_809_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_809_, 0, v___x_805_);
lean_ctor_set(v_reuseFailAlloc_809_, 1, v_a_794_);
v___x_807_ = v_reuseFailAlloc_809_;
goto v_reusejp_806_;
}
v_reusejp_806_:
{
v_a_793_ = v_tail_797_;
v_a_794_ = v___x_807_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_message(lean_object* v_m_811_){
_start:
{
lean_object* v_name_812_; lean_object* v_fields_813_; lean_object* v___x_815_; uint8_t v_isShared_816_; uint8_t v_isSharedCheck_823_; 
v_name_812_ = lean_ctor_get(v_m_811_, 0);
v_fields_813_ = lean_ctor_get(v_m_811_, 1);
v_isSharedCheck_823_ = !lean_is_exclusive(v_m_811_);
if (v_isSharedCheck_823_ == 0)
{
v___x_815_ = v_m_811_;
v_isShared_816_ = v_isSharedCheck_823_;
goto v_resetjp_814_;
}
else
{
lean_inc(v_fields_813_);
lean_inc(v_name_812_);
lean_dec(v_m_811_);
v___x_815_ = lean_box(0);
v_isShared_816_ = v_isSharedCheck_823_;
goto v_resetjp_814_;
}
v_resetjp_814_:
{
lean_object* v___x_817_; lean_object* v___x_818_; lean_object* v___x_819_; lean_object* v___x_821_; 
v___x_817_ = lean_box(0);
v___x_818_ = l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_message_spec__0(v_fields_813_, v___x_817_);
v___x_819_ = l_FormalSpecAgent_MachineObserve_ordered___redArg(v___x_818_);
if (v_isShared_816_ == 0)
{
lean_ctor_set(v___x_815_, 1, v___x_819_);
v___x_821_ = v___x_815_;
goto v_reusejp_820_;
}
else
{
lean_object* v_reuseFailAlloc_822_; 
v_reuseFailAlloc_822_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_822_, 0, v_name_812_);
lean_ctor_set(v_reuseFailAlloc_822_, 1, v___x_819_);
v___x_821_ = v_reuseFailAlloc_822_;
goto v_reusejp_820_;
}
v_reusejp_820_:
{
return v___x_821_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorIdx(lean_object* v_x_824_){
_start:
{
if (lean_obj_tag(v_x_824_) == 0)
{
lean_object* v___x_825_; 
v___x_825_ = lean_unsigned_to_nat(0u);
return v___x_825_;
}
else
{
lean_object* v___x_826_; 
v___x_826_ = lean_unsigned_to_nat(1u);
return v___x_826_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorIdx___boxed(lean_object* v_x_827_){
_start:
{
lean_object* v_res_828_; 
v_res_828_ = l_FormalSpecAgent_MachineObserve_Outcome_ctorIdx(v_x_827_);
lean_dec_ref(v_x_827_);
return v_res_828_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___redArg(lean_object* v_t_829_, lean_object* v_k_830_){
_start:
{
if (lean_obj_tag(v_t_829_) == 0)
{
lean_object* v_a_831_; lean_object* v_a_832_; lean_object* v_a_833_; lean_object* v_a_834_; lean_object* v___x_835_; 
v_a_831_ = lean_ctor_get(v_t_829_, 0);
lean_inc(v_a_831_);
v_a_832_ = lean_ctor_get(v_t_829_, 1);
lean_inc(v_a_832_);
v_a_833_ = lean_ctor_get(v_t_829_, 2);
lean_inc_ref(v_a_833_);
v_a_834_ = lean_ctor_get(v_t_829_, 3);
lean_inc(v_a_834_);
lean_dec_ref_known(v_t_829_, 4);
v___x_835_ = lean_apply_4(v_k_830_, v_a_831_, v_a_832_, v_a_833_, v_a_834_);
return v___x_835_;
}
else
{
uint8_t v_a_836_; lean_object* v_a_837_; lean_object* v___x_838_; lean_object* v___x_839_; 
v_a_836_ = lean_ctor_get_uint8(v_t_829_, sizeof(void*)*1);
v_a_837_ = lean_ctor_get(v_t_829_, 0);
lean_inc_ref(v_a_837_);
lean_dec_ref_known(v_t_829_, 1);
v___x_838_ = lean_box(v_a_836_);
v___x_839_ = lean_apply_2(v_k_830_, v___x_838_, v_a_837_);
return v___x_839_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorElim(lean_object* v_motive_840_, lean_object* v_ctorIdx_841_, lean_object* v_t_842_, lean_object* v_h_843_, lean_object* v_k_844_){
_start:
{
lean_object* v___x_845_; 
v___x_845_ = l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___redArg(v_t_842_, v_k_844_);
return v___x_845_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___boxed(lean_object* v_motive_846_, lean_object* v_ctorIdx_847_, lean_object* v_t_848_, lean_object* v_h_849_, lean_object* v_k_850_){
_start:
{
lean_object* v_res_851_; 
v_res_851_ = l_FormalSpecAgent_MachineObserve_Outcome_ctorElim(v_motive_846_, v_ctorIdx_847_, v_t_848_, v_h_849_, v_k_850_);
lean_dec(v_ctorIdx_847_);
return v_res_851_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_success_elim___redArg(lean_object* v_t_852_, lean_object* v_success_853_){
_start:
{
lean_object* v___x_854_; 
v___x_854_ = l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___redArg(v_t_852_, v_success_853_);
return v___x_854_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_success_elim(lean_object* v_motive_855_, lean_object* v_t_856_, lean_object* v_h_857_, lean_object* v_success_858_){
_start:
{
lean_object* v___x_859_; 
v___x_859_ = l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___redArg(v_t_856_, v_success_858_);
return v___x_859_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_error_elim___redArg(lean_object* v_t_860_, lean_object* v_error_861_){
_start:
{
lean_object* v___x_862_; 
v___x_862_ = l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___redArg(v_t_860_, v_error_861_);
return v___x_862_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_Outcome_error_elim(lean_object* v_motive_863_, lean_object* v_t_864_, lean_object* v_h_865_, lean_object* v_error_866_){
_start:
{
lean_object* v___x_867_; 
v___x_867_ = l_FormalSpecAgent_MachineObserve_Outcome_ctorElim___redArg(v_t_864_, v_error_866_);
return v___x_867_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__0(lean_object* v___x_868_, lean_object* v_a_869_, lean_object* v_b_870_){
_start:
{
lean_object* v___x_871_; uint8_t v___x_872_; 
v___x_871_ = lean_alloc_closure((void*)(l_FormalSpecAgent_MachineObserve_instDecidableEqPacked___boxed), 2, 0);
v___x_872_ = l_instDecidableEqProd___redArg(v___x_868_, v___x_871_, v_a_869_, v_b_870_);
return v___x_872_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__0___boxed(lean_object* v___x_873_, lean_object* v_a_874_, lean_object* v_b_875_){
_start:
{
uint8_t v_res_876_; lean_object* v_r_877_; 
v_res_876_ = l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__0(v___x_873_, v_a_874_, v_b_875_);
v_r_877_ = lean_box(v_res_876_);
return v_r_877_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__1(lean_object* v___f_878_, lean_object* v_a_879_, lean_object* v_b_880_){
_start:
{
uint8_t v___x_881_; 
v___x_881_ = l_instDecidableEqList___redArg(v___f_878_, v_a_879_, v_b_880_);
return v___x_881_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__1___boxed(lean_object* v___f_882_, lean_object* v_a_883_, lean_object* v_b_884_){
_start:
{
uint8_t v_res_885_; lean_object* v_r_886_; 
v_res_885_ = l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__1(v___f_882_, v_a_883_, v_b_884_);
v_r_886_ = lean_box(v_res_885_);
return v_r_886_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__0(void){
_start:
{
lean_object* v___x_887_; lean_object* v___f_888_; 
v___x_887_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
v___f_888_ = lean_alloc_closure((void*)(l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__0___boxed), 3, 1);
lean_closure_set(v___f_888_, 0, v___x_887_);
return v___f_888_;
}
}
static lean_object* _init_l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__1(void){
_start:
{
lean_object* v___f_889_; lean_object* v___f_890_; 
v___f_889_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__0, &l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__0_once, _init_l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__0);
v___f_890_ = lean_alloc_closure((void*)(l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__1___boxed), 3, 1);
lean_closure_set(v___f_890_, 0, v___f_889_);
return v___f_890_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2(lean_object* v_a_891_, lean_object* v_b_892_){
_start:
{
lean_object* v___x_893_; lean_object* v___f_894_; uint8_t v___x_895_; 
v___x_893_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
v___f_894_ = lean_obj_once(&l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__1, &l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__1_once, _init_l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___closed__1);
v___x_895_ = l_instDecidableEqProd___redArg(v___x_893_, v___f_894_, v_a_891_, v_b_892_);
return v___x_895_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2___boxed(lean_object* v_a_896_, lean_object* v_b_897_){
_start:
{
uint8_t v_res_898_; lean_object* v_r_899_; 
v_res_898_ = l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___lam__2(v_a_896_, v_b_897_);
v_r_899_ = lean_box(v_res_898_);
return v_r_899_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq(lean_object* v_x_901_, lean_object* v_x_902_){
_start:
{
if (lean_obj_tag(v_x_901_) == 0)
{
if (lean_obj_tag(v_x_902_) == 0)
{
lean_object* v_a_903_; lean_object* v_a_904_; lean_object* v_a_905_; lean_object* v_a_906_; lean_object* v_a_907_; lean_object* v_a_908_; lean_object* v_a_909_; lean_object* v_a_910_; uint8_t v___x_911_; 
v_a_903_ = lean_ctor_get(v_x_901_, 0);
lean_inc(v_a_903_);
v_a_904_ = lean_ctor_get(v_x_901_, 1);
lean_inc(v_a_904_);
v_a_905_ = lean_ctor_get(v_x_901_, 2);
lean_inc_ref(v_a_905_);
v_a_906_ = lean_ctor_get(v_x_901_, 3);
lean_inc(v_a_906_);
lean_dec_ref_known(v_x_901_, 4);
v_a_907_ = lean_ctor_get(v_x_902_, 0);
lean_inc(v_a_907_);
v_a_908_ = lean_ctor_get(v_x_902_, 1);
lean_inc(v_a_908_);
v_a_909_ = lean_ctor_get(v_x_902_, 2);
lean_inc_ref(v_a_909_);
v_a_910_ = lean_ctor_get(v_x_902_, 3);
lean_inc(v_a_910_);
lean_dec_ref_known(v_x_902_, 4);
v___x_911_ = lean_nat_dec_eq(v_a_903_, v_a_907_);
lean_dec(v_a_907_);
lean_dec(v_a_903_);
if (v___x_911_ == 0)
{
lean_dec(v_a_910_);
lean_dec_ref(v_a_909_);
lean_dec(v_a_908_);
lean_dec(v_a_906_);
lean_dec_ref(v_a_905_);
lean_dec(v_a_904_);
return v___x_911_;
}
else
{
uint8_t v___x_912_; 
v___x_912_ = lean_nat_dec_eq(v_a_904_, v_a_908_);
lean_dec(v_a_908_);
lean_dec(v_a_904_);
if (v___x_912_ == 0)
{
lean_dec(v_a_910_);
lean_dec_ref(v_a_909_);
lean_dec(v_a_906_);
lean_dec_ref(v_a_905_);
return v___x_912_;
}
else
{
uint8_t v___x_913_; 
v___x_913_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(v_a_905_, v_a_909_);
if (v___x_913_ == 0)
{
lean_dec(v_a_910_);
lean_dec(v_a_906_);
return v___x_913_;
}
else
{
lean_object* v___f_914_; uint8_t v___x_915_; 
v___f_914_ = ((lean_object*)(l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___closed__0));
v___x_915_ = l_instDecidableEqList___redArg(v___f_914_, v_a_906_, v_a_910_);
return v___x_915_;
}
}
}
}
else
{
uint8_t v___x_916_; 
lean_dec_ref_known(v_x_902_, 1);
lean_dec_ref_known(v_x_901_, 4);
v___x_916_ = 0;
return v___x_916_;
}
}
else
{
if (lean_obj_tag(v_x_902_) == 0)
{
uint8_t v___x_917_; 
lean_dec_ref_known(v_x_902_, 4);
lean_dec_ref_known(v_x_901_, 1);
v___x_917_ = 0;
return v___x_917_;
}
else
{
uint8_t v_a_918_; lean_object* v_a_919_; uint8_t v_a_920_; lean_object* v_a_921_; lean_object* v___x_922_; lean_object* v___x_923_; uint8_t v___x_924_; 
v_a_918_ = lean_ctor_get_uint8(v_x_901_, sizeof(void*)*1);
v_a_919_ = lean_ctor_get(v_x_901_, 0);
lean_inc_ref(v_a_919_);
lean_dec_ref_known(v_x_901_, 1);
v_a_920_ = lean_ctor_get_uint8(v_x_902_, sizeof(void*)*1);
v_a_921_ = lean_ctor_get(v_x_902_, 0);
lean_inc_ref(v_a_921_);
lean_dec_ref_known(v_x_902_, 1);
v___x_922_ = l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(v_a_918_);
v___x_923_ = l_FormalSpecAgent_TypedMachine_Fault_ctorIdx(v_a_920_);
v___x_924_ = lean_nat_dec_eq(v___x_922_, v___x_923_);
lean_dec(v___x_923_);
lean_dec(v___x_922_);
if (v___x_924_ == 0)
{
lean_dec_ref(v_a_921_);
lean_dec_ref(v_a_919_);
return v___x_924_;
}
else
{
uint8_t v___x_925_; 
v___x_925_ = l_FormalSpecAgent_MachineObserve_instDecidableEqSeenSnapshot_decEq(v_a_919_, v_a_921_);
return v___x_925_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq___boxed(lean_object* v_x_926_, lean_object* v_x_927_){
_start:
{
uint8_t v_res_928_; lean_object* v_r_929_; 
v_res_928_ = l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq(v_x_926_, v_x_927_);
v_r_929_ = lean_box(v_res_928_);
return v_r_929_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome(lean_object* v_x_930_, lean_object* v_x_931_){
_start:
{
uint8_t v___x_932_; 
v___x_932_ = l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome_decEq(v_x_930_, v_x_931_);
return v___x_932_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome___boxed(lean_object* v_x_933_, lean_object* v_x_934_){
_start:
{
uint8_t v_res_935_; lean_object* v_r_936_; 
v_res_935_ = l_FormalSpecAgent_MachineObserve_instDecidableEqOutcome(v_x_933_, v_x_934_);
v_r_936_ = lean_box(v_res_935_);
return v_r_936_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_outcome_spec__0(lean_object* v_a_937_, lean_object* v_a_938_){
_start:
{
if (lean_obj_tag(v_a_937_) == 0)
{
lean_object* v___x_939_; 
v___x_939_ = l_List_reverse___redArg(v_a_938_);
return v___x_939_;
}
else
{
lean_object* v_head_940_; lean_object* v_tail_941_; lean_object* v___x_943_; uint8_t v_isShared_944_; uint8_t v_isSharedCheck_950_; 
v_head_940_ = lean_ctor_get(v_a_937_, 0);
v_tail_941_ = lean_ctor_get(v_a_937_, 1);
v_isSharedCheck_950_ = !lean_is_exclusive(v_a_937_);
if (v_isSharedCheck_950_ == 0)
{
v___x_943_ = v_a_937_;
v_isShared_944_ = v_isSharedCheck_950_;
goto v_resetjp_942_;
}
else
{
lean_inc(v_tail_941_);
lean_inc(v_head_940_);
lean_dec(v_a_937_);
v___x_943_ = lean_box(0);
v_isShared_944_ = v_isSharedCheck_950_;
goto v_resetjp_942_;
}
v_resetjp_942_:
{
lean_object* v___x_945_; lean_object* v___x_947_; 
v___x_945_ = l_FormalSpecAgent_MachineObserve_message(v_head_940_);
if (v_isShared_944_ == 0)
{
lean_ctor_set(v___x_943_, 1, v_a_938_);
lean_ctor_set(v___x_943_, 0, v___x_945_);
v___x_947_ = v___x_943_;
goto v_reusejp_946_;
}
else
{
lean_object* v_reuseFailAlloc_949_; 
v_reuseFailAlloc_949_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_949_, 0, v___x_945_);
lean_ctor_set(v_reuseFailAlloc_949_, 1, v_a_938_);
v___x_947_ = v_reuseFailAlloc_949_;
goto v_reusejp_946_;
}
v_reusejp_946_:
{
v_a_937_ = v_tail_941_;
v_a_938_ = v___x_947_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_outcome(lean_object* v_schema_951_, lean_object* v_initial_952_, lean_object* v_result_953_){
_start:
{
if (lean_obj_tag(v_result_953_) == 0)
{
lean_object* v_a_954_; lean_object* v___x_955_; lean_object* v___x_956_; lean_object* v___x_957_; uint8_t v___x_958_; 
v_a_954_ = lean_ctor_get(v_result_953_, 0);
lean_inc(v_a_954_);
v___x_955_ = l_FormalSpecAgent_TypedMachine_rollback(v_initial_952_, v_result_953_);
lean_dec_ref_known(v_result_953_, 1);
v___x_956_ = l_FormalSpecAgent_MachineObserve_snapshot(v_schema_951_, v___x_955_);
v___x_957_ = lean_alloc_ctor(1, 1, 1);
lean_ctor_set(v___x_957_, 0, v___x_956_);
v___x_958_ = lean_unbox(v_a_954_);
lean_dec(v_a_954_);
lean_ctor_set_uint8(v___x_957_, sizeof(void*)*1, v___x_958_);
return v___x_957_;
}
else
{
lean_object* v_a_959_; lean_object* v_after_960_; lean_object* v_rule_961_; lean_object* v_event_962_; lean_object* v_emitted_963_; lean_object* v___x_964_; lean_object* v___x_965_; lean_object* v___x_966_; lean_object* v___x_967_; 
v_a_959_ = lean_ctor_get(v_result_953_, 0);
lean_inc(v_a_959_);
lean_dec_ref_known(v_result_953_, 1);
v_after_960_ = lean_ctor_get(v_a_959_, 0);
lean_inc_ref(v_after_960_);
v_rule_961_ = lean_ctor_get(v_a_959_, 1);
lean_inc(v_rule_961_);
v_event_962_ = lean_ctor_get(v_a_959_, 2);
lean_inc(v_event_962_);
v_emitted_963_ = lean_ctor_get(v_a_959_, 4);
lean_inc(v_emitted_963_);
lean_dec(v_a_959_);
v___x_964_ = l_FormalSpecAgent_MachineObserve_snapshot(v_schema_951_, v_after_960_);
v___x_965_ = lean_box(0);
v___x_966_ = l_List_mapTR_loop___at___00FormalSpecAgent_MachineObserve_outcome_spec__0(v_emitted_963_, v___x_965_);
v___x_967_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_967_, 0, v_rule_961_);
lean_ctor_set(v___x_967_, 1, v_event_962_);
lean_ctor_set(v___x_967_, 2, v___x_964_);
lean_ctor_set(v___x_967_, 3, v___x_966_);
return v___x_967_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_MachineObserve_outcome___boxed(lean_object* v_schema_968_, lean_object* v_initial_969_, lean_object* v_result_970_){
_start:
{
lean_object* v_res_971_; 
v_res_971_ = l_FormalSpecAgent_MachineObserve_outcome(v_schema_968_, v_initial_969_, v_result_970_);
lean_dec_ref(v_initial_969_);
return v_res_971_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TypedMachine(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_MachineObserve(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TypedMachine(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
