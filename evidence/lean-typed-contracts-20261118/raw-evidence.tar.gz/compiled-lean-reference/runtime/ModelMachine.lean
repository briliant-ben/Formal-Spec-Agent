import MachineObserve

set_option maxRecDepth 16384

namespace MachineRuntime

def e0 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([] : FormalSpecAgent.Bytes)

def e1 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (0)

def e2 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e3 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [])

def e4 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean false

def e5 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.field .boolean 4

def e6 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean true

def e7 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.equal .boolean e5 e6

def e8 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.field .octets 0

def e9 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e8

def e10 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (16)

def e11 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e9 e10

def e12 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolAnd e7 e11

def e13 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 0

def e14 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e13

def e15 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.field .sequence 1

def e16 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 2

def e17 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.seqAdd e15 e16

def e18 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.field .text 3

def e19 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 1

def e20 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.variable .sequence 2

def e21 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.variable .text 3

def e22 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 4

def e23 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolNot e12

def e24 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e19 e1

def e25 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e19 e10

def e26 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.equal .integer e19 e14

def rule_0 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 0, source := 0, target := 0, event := 0, guard := e12, actions := [FormalSpecAgent.TypedMachine.Action.assign .octets 0 e8, FormalSpecAgent.TypedMachine.Action.assign .integer 1 e14, FormalSpecAgent.TypedMachine.Action.assign .sequence 2 e17, FormalSpecAgent.TypedMachine.Action.assign .text 3 e18, FormalSpecAgent.TypedMachine.Action.assign .boolean 4 e6, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .octets, e13⟩, ⟨1, .integer, e19⟩, ⟨2, .sequence, e20⟩, ⟨3, .text, e21⟩, ⟨4, .boolean, e22⟩]] }

def rule_1 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 1, source := 0, target := 0, event := 0, guard := e23, actions := [FormalSpecAgent.TypedMachine.Action.assign .boolean 4 e4, FormalSpecAgent.TypedMachine.Action.emit 1 [⟨0, .octets, e13⟩, ⟨1, .integer, e19⟩, ⟨2, .sequence, e20⟩, ⟨3, .text, e21⟩, ⟨4, .boolean, e22⟩]] }

def schema : List (FormalSpecAgent.TypedIR.Kind × Nat) := [(.octets, 0), (.integer, 1), (.sequence, 2), (.text, 3), (.boolean, 4)]

def model : FormalSpecAgent.TypedMachine.Model :=
  { rules := [rule_0, rule_1], invariants := [e24, e25, e26], timerEvents := fun n => 0, externalEvents := [0] }

end MachineRuntime
