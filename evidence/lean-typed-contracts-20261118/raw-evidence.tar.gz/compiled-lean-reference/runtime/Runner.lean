import ModelMachine
open FormalSpecAgent.MachineObserve

def array (xs : List String) : String := "[" ++ String.intercalate "," xs ++ "]"
def pvalue : Packed → String
  | .integer v => "{\"kind\":\"int\",\"value\":" ++ toString v ++ "}"
  | .boolean v => "{\"kind\":\"bool\",\"value\":" ++ toString v ++ "}"
  | .text v => "{\"kind\":\"string\",\"value\":" ++ array (v.toList.map fun c => toString c.toNat) ++ "}"
  | .octets v => "{\"kind\":\"bytes\",\"value\":" ++ array (v.map fun b => toString b.val) ++ "}"
  | .sequence v => "{\"kind\":\"seq32\",\"value\":" ++ toString v ++ "}"
def ss (s : SeenSnapshot) : String :=
  "{\"state\":" ++ toString s.state ++ ",\"now_ms\":" ++ toString s.now ++
  ",\"variables\":" ++ array (s.values.map pvalue) ++ ",\"timers\":" ++
  array (s.timers.map fun (n,t) => array [toString n,toString t]) ++ "}"
def msg (m : SeenMessage) : String :=
  "{\"message\":" ++ toString m.1 ++ ",\"fields\":" ++
  array (m.2.map fun (n,v) => array [toString n,pvalue v]) ++ "}"
def faultName : FormalSpecAgent.TypedMachine.Fault → String
  | .uncovered => "uncovered" | .conflict => "conflict" | .badDelay => "badDelay"
  | .invariant => "invariant" | .time => "time" | .timerInjection => "timerInjection"
  | .pendingTimer => "pendingTimer" | .noTimer => "noTimer"
def outcomeText : Outcome → String
  | .success r e s emitted => "{\"status\":\"ok\",\"rule\":" ++ toString r ++
      ",\"event\":" ++ toString e ++ ",\"after\":" ++ ss s ++
      ",\"emitted\":" ++ array (emitted.map msg) ++ "}"
  | .error f s => "{\"status\":\"error\",\"fault\":\"" ++ faultName f ++
      "\",\"after\":" ++ ss s ++ ",\"emitted\":[]}"

def main : IO Unit := do
  let s_0_0 := ({ values := ({ integers := fun n => if n = 1 then (0) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
  let r_0_0 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_0 0 ({ integers := fun n => if n = 2 then (1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_0 r_0_0))
  let s_0_1 := FormalSpecAgent.TypedMachine.rollback s_0_0 r_0_0
  let r_0_1 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_1 0 ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 111, Char.ofNat 118, Char.ofNat 101, Char.ofNat 114]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨1, by decide⟩, ⟨2, by decide⟩, ⟨3, by decide⟩, ⟨4, by decide⟩, ⟨5, by decide⟩, ⟨6, by decide⟩, ⟨7, by decide⟩, ⟨8, by decide⟩, ⟨9, by decide⟩, ⟨10, by decide⟩, ⟨11, by decide⟩, ⟨12, by decide⟩, ⟨13, by decide⟩, ⟨14, by decide⟩, ⟨15, by decide⟩, ⟨16, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨123, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (1)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_1 r_0_1))
  let s_0_2 := FormalSpecAgent.TypedMachine.rollback s_0_1 r_0_1
  let r_0_2 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_2 0 ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 100, Char.ofNat 105, Char.ofNat 115, Char.ofNat 97, Char.ofNat 98, Char.ofNat 108, Char.ofNat 101, Char.ofNat 100]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨9, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨7, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (2)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_2 r_0_2))
  let s_0_3 := FormalSpecAgent.TypedMachine.rollback s_0_2 r_0_2
  let r_0_3 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_3 0 ({ integers := fun n => if n = 2 then (-1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 101, Char.ofNat 109, Char.ofNat 112, Char.ofNat 116, Char.ofNat 121]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (3)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_3 r_0_3))
  let s_0_4 := FormalSpecAgent.TypedMachine.rollback s_0_3 r_0_3
  let r_0_4 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_4 0 ({ integers := fun n => if n = 2 then (-2) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 109, Char.ofNat 97, Char.ofNat 120]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨255, by decide⟩, ⟨1, by decide⟩, ⟨254, by decide⟩, ⟨2, by decide⟩, ⟨253, by decide⟩, ⟨3, by decide⟩, ⟨252, by decide⟩, ⟨4, by decide⟩, ⟨251, by decide⟩, ⟨5, by decide⟩, ⟨250, by decide⟩, ⟨6, by decide⟩, ⟨249, by decide⟩, ⟨7, by decide⟩, ⟨248, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨1, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (4)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_4 r_0_4))
  let s_0_5 := FormalSpecAgent.TypedMachine.rollback s_0_4 r_0_4
  let r_0_5 := FormalSpecAgent.TypedMachine.external MachineRuntime.model s_0_5 0 ({ integers := fun n => if n = 2 then (4294967296) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 119, Char.ofNat 114, Char.ofNat 97, Char.ofNat 112]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)
  IO.println (outcomeText (outcome MachineRuntime.schema s_0_5 r_0_5))
  let s_0_6 := FormalSpecAgent.TypedMachine.rollback s_0_5 r_0_5
