import Proofs

example : Approved.initial_valid := Proofs.initial_valid
#print axioms Proofs.initial_valid
example : Approved.preserve_0 := Proofs.preserve_0
#print axioms Proofs.preserve_0
example : Approved.preserve_1 := Proofs.preserve_1
#print axioms Proofs.preserve_1
example : Approved.guards_disjoint := Proofs.guards_disjoint
#print axioms Proofs.guards_disjoint
example : Approved.coverage := Proofs.coverage
#print axioms Proofs.coverage
example : Approved.context_valid_0 := Proofs.context_valid_0
#print axioms Proofs.context_valid_0
example : Approved.live_0 := Proofs.live_0
#print axioms Proofs.live_0
example : Approved.live_1 := Proofs.live_1
#print axioms Proofs.live_1
example : Approved.execution_0_0 := Proofs.execution_0_0
#print axioms Proofs.execution_0_0
example : Approved.execution_0_1 := Proofs.execution_0_1
#print axioms Proofs.execution_0_1
example : Approved.execution_0_2 := Proofs.execution_0_2
#print axioms Proofs.execution_0_2
example : Approved.execution_0_3 := Proofs.execution_0_3
#print axioms Proofs.execution_0_3
example : Approved.execution_0_4 := Proofs.execution_0_4
#print axioms Proofs.execution_0_4
example : Approved.execution_0_5 := Proofs.execution_0_5
#print axioms Proofs.execution_0_5
#print axioms FormalSpecAgent.TypedContracts.candidate
#print axioms FormalSpecAgent.TypedContracts.RulePreserves
#print axioms FormalSpecAgent.TypedContracts.InitialValid
#print axioms FormalSpecAgent.TypedContracts.GuardsDisjoint
#print axioms FormalSpecAgent.TypedContracts.Covers
#print axioms FormalSpecAgent.TypedContracts.Enables
#print axioms FormalSpecAgent.TypedContracts.runRule_eq_filter
#print axioms FormalSpecAgent.TypedContracts.preserving_rule_succeeds
