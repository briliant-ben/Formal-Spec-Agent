import Approved

set_option maxRecDepth 16384

namespace Proofs

theorem initial_valid : Approved.initial_valid := by
  unfold Approved.initial_valid
  try
    simp_all [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1]
  try
    rfl
  try
    omega

theorem preserve_0 : Approved.preserve_0 := by
  unfold Approved.preserve_0
  unfold FormalSpecAgent.TypedContracts.RulePreserves
  intro snapshot fields hInv hSrc hGuard
  try
    simp_all [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1]
  try
    rfl
  try
    omega
  try
    exact of_decide_eq_true hGuard.2

theorem preserve_1 : Approved.preserve_1 := by
  unfold Approved.preserve_1
  unfold FormalSpecAgent.TypedContracts.RulePreserves
  intro snapshot fields hInv hSrc hGuard
  try
    simp_all [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1]
  try
    rfl
  try
    omega
  try
    exact hInv.2

theorem guards_disjoint : Approved.guards_disjoint := by
  unfold Approved.guards_disjoint FormalSpecAgent.TypedContracts.GuardsDisjoint
  intro snapshot fields hInv event r1 r2 hr1 hr2 hne hsrc1 hsrc2 hev1 hev2
  have guard_cases := Bool.eq_false_or_eq_true (FormalSpecAgent.TypedMachine.eval snapshot fields Approved.rule_0.guard)
  cases guard_cases
  ·
    try
      simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
    cases hr1
    ·
      cases hr2
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
    ·
      cases hr2
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
  ·
    try
      simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
    cases hr1
    ·
      cases hr2
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
    ·
      cases hr2
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
      ·
        try
          simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]

theorem coverage : Approved.coverage := by
  unfold Approved.coverage FormalSpecAgent.TypedContracts.Covers
  intro snapshot event fields hstate hevent hInv
  have guard_cases := Bool.eq_false_or_eq_true (FormalSpecAgent.TypedMachine.eval snapshot fields Approved.rule_0.guard)
  cases guard_cases
  ·
    try
      simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]
  ·
    try
      simp_all [FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, Approved.model_rules, Approved.model_external_events, Approved.guard_not_0_1, Approved.rule_id_0, Approved.rule_source_0, Approved.rule_event_0, Approved.rule_id_1, Approved.rule_source_1, Approved.rule_event_1]

theorem context_valid_0 : Approved.context_valid_0 := by
  unfold Approved.context_valid_0
  try
    simp_all [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1]
  try
    rfl
  try
    omega

theorem live_0 : Approved.live_0 := by
  unfold Approved.live_0
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

theorem live_1 : Approved.live_1 := by
  unfold Approved.live_1
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

theorem execution_0_0 : Approved.execution_0_0 := by
  unfold Approved.execution_0_0
  simp only [Approved.result_0_0, Approved.initial_0, FormalSpecAgent.TypedMachine.rollback]
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

theorem execution_0_1 : Approved.execution_0_1 := by
  have prior0 := Proofs.execution_0_0
  unfold Approved.execution_0_0 at prior0
  unfold Approved.execution_0_1
  simp only [Approved.result_0_1, Approved.after_0_0, Approved.initial_0, prior0, FormalSpecAgent.TypedMachine.rollback]
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

theorem execution_0_2 : Approved.execution_0_2 := by
  have prior0 := Proofs.execution_0_0
  unfold Approved.execution_0_0 at prior0
  have prior1 := Proofs.execution_0_1
  unfold Approved.execution_0_1 at prior1
  unfold Approved.execution_0_2
  simp only [Approved.result_0_2, Approved.after_0_0, Approved.after_0_1, Approved.initial_0, prior0, prior1, FormalSpecAgent.TypedMachine.rollback]
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

theorem execution_0_3 : Approved.execution_0_3 := by
  have prior0 := Proofs.execution_0_0
  unfold Approved.execution_0_0 at prior0
  have prior1 := Proofs.execution_0_1
  unfold Approved.execution_0_1 at prior1
  have prior2 := Proofs.execution_0_2
  unfold Approved.execution_0_2 at prior2
  unfold Approved.execution_0_3
  simp only [Approved.result_0_3, Approved.after_0_0, Approved.after_0_1, Approved.after_0_2, Approved.initial_0, prior0, prior1, prior2, FormalSpecAgent.TypedMachine.rollback]
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

theorem execution_0_4 : Approved.execution_0_4 := by
  have prior0 := Proofs.execution_0_0
  unfold Approved.execution_0_0 at prior0
  have prior1 := Proofs.execution_0_1
  unfold Approved.execution_0_1 at prior1
  have prior2 := Proofs.execution_0_2
  unfold Approved.execution_0_2 at prior2
  have prior3 := Proofs.execution_0_3
  unfold Approved.execution_0_3 at prior3
  unfold Approved.execution_0_4
  simp only [Approved.result_0_4, Approved.after_0_0, Approved.after_0_1, Approved.after_0_2, Approved.after_0_3, Approved.initial_0, prior0, prior1, prior2, prior3, FormalSpecAgent.TypedMachine.rollback]
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

theorem execution_0_5 : Approved.execution_0_5 := by
  have prior0 := Proofs.execution_0_0
  unfold Approved.execution_0_0 at prior0
  have prior1 := Proofs.execution_0_1
  unfold Approved.execution_0_1 at prior1
  have prior2 := Proofs.execution_0_2
  unfold Approved.execution_0_2 at prior2
  have prior3 := Proofs.execution_0_3
  unfold Approved.execution_0_3 at prior3
  have prior4 := Proofs.execution_0_4
  unfold Approved.execution_0_4 at prior4
  unfold Approved.execution_0_5
  simp only [Approved.result_0_5, Approved.after_0_0, Approved.after_0_1, Approved.after_0_2, Approved.after_0_3, Approved.after_0_4, Approved.initial_0, prior0, prior1, prior2, prior3, prior4, FormalSpecAgent.TypedMachine.rollback]
  try
    simp [FormalSpecAgent.TypedContracts.InitialValid, FormalSpecAgent.TypedContracts.RulePreserves, FormalSpecAgent.TypedContracts.GuardsDisjoint, FormalSpecAgent.TypedContracts.Covers, FormalSpecAgent.TypedContracts.Enables, FormalSpecAgent.TypedContracts.candidate, FormalSpecAgent.TypedMachine.invariantsHold, FormalSpecAgent.TypedMachine.work, FormalSpecAgent.TypedMachine.withoutFiring, FormalSpecAgent.TypedMachine.setValue, FormalSpecAgent.TypedMachine.context, FormalSpecAgent.TypedMachine.eval, FormalSpecAgent.TypedMachine.external, FormalSpecAgent.TypedMachine.enabled, FormalSpecAgent.TypedMachine.fire, FormalSpecAgent.TypedMachine.runRule, FormalSpecAgent.TypedMachine.nextTimer, FormalSpecAgent.TypedMachine.zeroValues, FormalSpecAgent.TypedMachine.rollback, FormalSpecAgent.TypedIR.eval, FormalSpecAgent.TypedIR.getValue, FormalSpecAgent.TypedIR.equalValue, FormalSpecAgent.StoreFacts.function_update_shadow, FormalSpecAgent.StoreFacts.function_update_order, FormalSpecAgent.StoreFacts.function_cond_constant, FormalSpecAgent.StoreFacts.function_bool_or_order, FormalSpecAgent.StoreFacts.function_bool_remove, Approved.model_rules, Approved.model_invariants, Approved.model_external_events, Approved.initial, Approved.initial_0, List.filter_cons, Approved.e0, Approved.e1, Approved.e2, Approved.e3, Approved.e4, Approved.e5, Approved.e6, Approved.e7, Approved.e8, Approved.e9, Approved.e10, Approved.e11, Approved.e12, Approved.e13, Approved.e14, Approved.e15, Approved.e16, Approved.e17, Approved.e18, Approved.e19, Approved.e20, Approved.e21, Approved.e22, Approved.e23, Approved.e24, Approved.e25, Approved.e26, Approved.rule_0, Approved.rule_1, FormalSpecAgent.ValueOps.seqAdd, FormalSpecAgent.StoreFacts.serial_wrap]
  try
    rfl
  try
    omega

end Proofs
