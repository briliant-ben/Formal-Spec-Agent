import TypedContracts
import MachineObserve
import StoreFacts

set_option maxRecDepth 16384

namespace Approved

def e0 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([] : FormalSpecAgent.Bytes)

def e1 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (0)

def e2 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e3 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [])

def e4 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean false

def e5 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.field .boolean 4

def e6 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean true

def e7 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.equal .boolean e5 e6

def e8 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.field .octets 0

def e9 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e8

def e10 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (16)

def e11 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e9 e10

def e12 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolAnd e7 e11

def e13 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 0

def e14 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e13

def e15 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.field .sequence 1

def e16 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 2

def e17 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.seqAdd e15 e16

def e18 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.field .text 3

def e19 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 1

def e20 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.variable .sequence 2

def e21 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.variable .text 3

def e22 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 4

def e23 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolNot e12

def e24 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e19 e1

def e25 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e19 e10

def e26 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.equal .integer e19 e14

def rule_0 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 0, source := 0, target := 0, event := 0, guard := e12, actions := [FormalSpecAgent.TypedMachine.Action.assign .octets 0 e8, FormalSpecAgent.TypedMachine.Action.assign .integer 1 e14, FormalSpecAgent.TypedMachine.Action.assign .sequence 2 e17, FormalSpecAgent.TypedMachine.Action.assign .text 3 e18, FormalSpecAgent.TypedMachine.Action.assign .boolean 4 e6, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .octets, e13⟩, ⟨1, .integer, e19⟩, ⟨2, .sequence, e20⟩, ⟨3, .text, e21⟩, ⟨4, .boolean, e22⟩]] }

def rule_1 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 1, source := 0, target := 0, event := 0, guard := e23, actions := [FormalSpecAgent.TypedMachine.Action.assign .boolean 4 e4, FormalSpecAgent.TypedMachine.Action.emit 1 [⟨0, .octets, e13⟩, ⟨1, .integer, e19⟩, ⟨2, .sequence, e20⟩, ⟨3, .text, e21⟩, ⟨4, .boolean, e22⟩]] }

def schema : List (FormalSpecAgent.TypedIR.Kind × Nat) := [(.octets, 0), (.integer, 1), (.sequence, 2), (.text, 3), (.boolean, 4)]

def model : FormalSpecAgent.TypedMachine.Model :=
  { rules := [rule_0, rule_1], invariants := [e24, e25, e26], timerEvents := fun n => 0, externalEvents := [0] }

theorem model_rules : model.rules = [rule_0, rule_1] := rfl

theorem model_invariants : model.invariants = [e24, e25, e26] := rfl

theorem model_external_events : model.externalEvents = [0] := rfl

theorem rule_id_0 : rule_0.id = 0 := rfl

theorem rule_source_0 : rule_0.source = 0 := rfl

theorem rule_event_0 : rule_0.event = 0 := rfl

theorem guard_not_0_1 (s : FormalSpecAgent.TypedMachine.Snapshot) (f : FormalSpecAgent.TypedIR.Values) : FormalSpecAgent.TypedMachine.eval s f rule_1.guard = !(FormalSpecAgent.TypedMachine.eval s f rule_0.guard) := rfl

theorem rule_id_1 : rule_1.id = 1 := rfl

theorem rule_source_1 : rule_1.source = 0 := rfl

theorem rule_event_1 : rule_1.event = 0 := rfl

def initial : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 1 then (0) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def initial_0 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 1 then (0) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_0_0 := FormalSpecAgent.TypedMachine.external model initial_0 0 ({ integers := fun n => if n = 2 then (1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_0_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback initial_0 result_0_0

def result_0_1 := FormalSpecAgent.TypedMachine.external model after_0_0 0 ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 111, Char.ofNat 118, Char.ofNat 101, Char.ofNat 114]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨1, by decide⟩, ⟨2, by decide⟩, ⟨3, by decide⟩, ⟨4, by decide⟩, ⟨5, by decide⟩, ⟨6, by decide⟩, ⟨7, by decide⟩, ⟨8, by decide⟩, ⟨9, by decide⟩, ⟨10, by decide⟩, ⟨11, by decide⟩, ⟨12, by decide⟩, ⟨13, by decide⟩, ⟨14, by decide⟩, ⟨15, by decide⟩, ⟨16, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨123, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (1)

def after_0_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_0 result_0_1

def result_0_2 := FormalSpecAgent.TypedMachine.external model after_0_1 0 ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 100, Char.ofNat 105, Char.ofNat 115, Char.ofNat 97, Char.ofNat 98, Char.ofNat 108, Char.ofNat 101, Char.ofNat 100]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨9, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨7, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (2)

def after_0_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_1 result_0_2

def result_0_3 := FormalSpecAgent.TypedMachine.external model after_0_2 0 ({ integers := fun n => if n = 2 then (-1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 101, Char.ofNat 109, Char.ofNat 112, Char.ofNat 116, Char.ofNat 121]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (3)

def after_0_3 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_2 result_0_3

def result_0_4 := FormalSpecAgent.TypedMachine.external model after_0_3 0 ({ integers := fun n => if n = 2 then (-2) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 109, Char.ofNat 97, Char.ofNat 120]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨255, by decide⟩, ⟨1, by decide⟩, ⟨254, by decide⟩, ⟨2, by decide⟩, ⟨253, by decide⟩, ⟨3, by decide⟩, ⟨252, by decide⟩, ⟨4, by decide⟩, ⟨251, by decide⟩, ⟨5, by decide⟩, ⟨250, by decide⟩, ⟨6, by decide⟩, ⟨249, by decide⟩, ⟨7, by decide⟩, ⟨248, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨1, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (4)

def after_0_4 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_3 result_0_4

def result_0_5 := FormalSpecAgent.TypedMachine.external model after_0_4 0 ({ integers := fun n => if n = 2 then (4294967296) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 119, Char.ofNat 114, Char.ofNat 97, Char.ofNat 112]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)

def after_0_5 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.TypedMachine.rollback after_0_4 result_0_5
def initial_valid : Prop :=
  FormalSpecAgent.TypedContracts.InitialValid model initial

def preserve_0 : Prop :=
  FormalSpecAgent.TypedContracts.RulePreserves model rule_0

def preserve_1 : Prop :=
  FormalSpecAgent.TypedContracts.RulePreserves model rule_1

def guards_disjoint : Prop :=
  FormalSpecAgent.TypedContracts.GuardsDisjoint model

def coverage : Prop :=
  FormalSpecAgent.TypedContracts.Covers model [0]

def context_valid_0 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_0 = true

def live_0 : Prop :=
  FormalSpecAgent.TypedContracts.Enables model rule_0 ({ values := ({ integers := fun n => if n = 1 then (0) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList []) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot) ({ integers := fun n => if n = 2 then (1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) ({ after := ({ values := ({ integers := fun n => if n = 1 then (4) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 0, event := 0, fields := ({ integers := fun n => if n = 2 then (1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 0, fields := [⟨0, .octets, ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (4)⟩, ⟨2, .sequence, (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])⟩, ⟨4, .boolean, true⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

def live_1 : Prop :=
  FormalSpecAgent.TypedContracts.Enables model rule_1 ({ values := ({ integers := fun n => if n = 1 then (4) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (1), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot) ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 111, Char.ofNat 118, Char.ofNat 101, Char.ofNat 114]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨1, by decide⟩, ⟨2, by decide⟩, ⟨3, by decide⟩, ⟨4, by decide⟩, ⟨5, by decide⟩, ⟨6, by decide⟩, ⟨7, by decide⟩, ⟨8, by decide⟩, ⟨9, by decide⟩, ⟨10, by decide⟩, ⟨11, by decide⟩, ⟨12, by decide⟩, ⟨13, by decide⟩, ⟨14, by decide⟩, ⟨15, by decide⟩, ⟨16, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨123, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) ({ after := ({ values := ({ integers := fun n => if n = 1 then (4) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (1), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 1, event := 0, fields := ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 111, Char.ofNat 118, Char.ofNat 101, Char.ofNat 114]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨1, by decide⟩, ⟨2, by decide⟩, ⟨3, by decide⟩, ⟨4, by decide⟩, ⟨5, by decide⟩, ⟨6, by decide⟩, ⟨7, by decide⟩, ⟨8, by decide⟩, ⟨9, by decide⟩, ⟨10, by decide⟩, ⟨11, by decide⟩, ⟨12, by decide⟩, ⟨13, by decide⟩, ⟨14, by decide⟩, ⟨15, by decide⟩, ⟨16, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨123, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 1, fields := [⟨0, .octets, ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (4)⟩, ⟨2, .sequence, (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])⟩, ⟨4, .boolean, false⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

def execution_0_0 : Prop :=
  result_0_0 = .ok ({ after := ({ values := ({ integers := fun n => if n = 1 then (4) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 0, event := 0, fields := ({ integers := fun n => if n = 2 then (1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 0, fields := [⟨0, .octets, ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (4)⟩, ⟨2, .sequence, (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])⟩, ⟨4, .boolean, true⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

def execution_0_1 : Prop :=
  result_0_1 = .ok ({ after := ({ values := ({ integers := fun n => if n = 1 then (4) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (1), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 1, event := 0, fields := ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 111, Char.ofNat 118, Char.ofNat 101, Char.ofNat 114]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨1, by decide⟩, ⟨2, by decide⟩, ⟨3, by decide⟩, ⟨4, by decide⟩, ⟨5, by decide⟩, ⟨6, by decide⟩, ⟨7, by decide⟩, ⟨8, by decide⟩, ⟨9, by decide⟩, ⟨10, by decide⟩, ⟨11, by decide⟩, ⟨12, by decide⟩, ⟨13, by decide⟩, ⟨14, by decide⟩, ⟨15, by decide⟩, ⟨16, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨123, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 1, fields := [⟨0, .octets, ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (4)⟩, ⟨2, .sequence, (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])⟩, ⟨4, .boolean, false⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

def execution_0_2 : Prop :=
  result_0_2 = .ok ({ after := ({ values := ({ integers := fun n => if n = 1 then (4) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (2), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 1, event := 0, fields := ({ integers := fun n => if n = 2 then (0) else (0), booleans := fun n => if n = 4 then false else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 105, Char.ofNat 103, Char.ofNat 110, Char.ofNat 111, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 45, Char.ofNat 100, Char.ofNat 105, Char.ofNat 115, Char.ofNat 97, Char.ofNat 98, Char.ofNat 108, Char.ofNat 101, Char.ofNat 100]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨9, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨7, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 1, fields := [⟨0, .octets, ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (4)⟩, ⟨2, .sequence, (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])⟩, ⟨4, .boolean, false⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

def execution_0_3 : Prop :=
  result_0_3 = .ok ({ after := ({ values := ({ integers := fun n => if n = 1 then (0) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 101, Char.ofNat 109, Char.ofNat 112, Char.ofNat 116, Char.ofNat 121]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (3), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 0, event := 0, fields := ({ integers := fun n => if n = 2 then (-1) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 101, Char.ofNat 109, Char.ofNat 112, Char.ofNat 116, Char.ofNat 121]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 0, fields := [⟨0, .octets, ([] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (0)⟩, ⟨2, .sequence, (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 101, Char.ofNat 109, Char.ofNat 112, Char.ofNat 116, Char.ofNat 121])⟩, ⟨4, .boolean, true⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

def execution_0_4 : Prop :=
  result_0_4 = .ok ({ after := ({ values := ({ integers := fun n => if n = 1 then (16) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 109, Char.ofNat 97, Char.ofNat 120]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨255, by decide⟩, ⟨1, by decide⟩, ⟨254, by decide⟩, ⟨2, by decide⟩, ⟨253, by decide⟩, ⟨3, by decide⟩, ⟨252, by decide⟩, ⟨4, by decide⟩, ⟨251, by decide⟩, ⟨5, by decide⟩, ⟨250, by decide⟩, ⟨6, by decide⟩, ⟨249, by decide⟩, ⟨7, by decide⟩, ⟨248, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (4), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 0, event := 0, fields := ({ integers := fun n => if n = 2 then (-2) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 109, Char.ofNat 97, Char.ofNat 120]) else (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨255, by decide⟩, ⟨1, by decide⟩, ⟨254, by decide⟩, ⟨2, by decide⟩, ⟨253, by decide⟩, ⟨3, by decide⟩, ⟨252, by decide⟩, ⟨4, by decide⟩, ⟨251, by decide⟩, ⟨5, by decide⟩, ⟨250, by decide⟩, ⟨6, by decide⟩, ⟨249, by decide⟩, ⟨7, by decide⟩, ⟨248, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨1, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 0, fields := [⟨0, .octets, ([⟨0, by decide⟩, ⟨255, by decide⟩, ⟨1, by decide⟩, ⟨254, by decide⟩, ⟨2, by decide⟩, ⟨253, by decide⟩, ⟨3, by decide⟩, ⟨252, by decide⟩, ⟨4, by decide⟩, ⟨251, by decide⟩, ⟨5, by decide⟩, ⟨250, by decide⟩, ⟨6, by decide⟩, ⟨249, by decide⟩, ⟨7, by decide⟩, ⟨248, by decide⟩] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (16)⟩, ⟨2, .sequence, (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 109, Char.ofNat 97, Char.ofNat 120])⟩, ⟨4, .boolean, true⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

def execution_0_5 : Prop :=
  result_0_5 = .ok ({ after := ({ values := ({ integers := fun n => if n = 1 then (0) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 119, Char.ofNat 114, Char.ofNat 97, Char.ofNat 112]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), rule := 0, event := 0, fields := ({ integers := fun n => if n = 2 then (4294967296) else (0), booleans := fun n => if n = 4 then true else false, texts := fun n => if n = 3 then (String.ofList [Char.ofNat 119, Char.ofNat 114, Char.ofNat 97, Char.ofNat 112]) else (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 1 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), emitted := [({ name := 0, fields := [⟨0, .octets, ([] : FormalSpecAgent.Bytes)⟩, ⟨1, .integer, (0)⟩, ⟨2, .sequence, (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)⟩, ⟨3, .text, (String.ofList [Char.ofNat 119, Char.ofNat 114, Char.ofNat 97, Char.ofNat 112])⟩, ⟨4, .boolean, true⟩] } : FormalSpecAgent.TypedMachine.Message)] } : FormalSpecAgent.TypedMachine.Transition)

end Approved
