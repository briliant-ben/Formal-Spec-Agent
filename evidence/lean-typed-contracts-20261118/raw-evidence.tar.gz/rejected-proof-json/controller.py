from pathlib import Path
import json,sys,os,time,hashlib,traceback
P=Path('/home/blxu/protocol-flow');O=P/'candidates/lean-typed-efsm-proofs-20261118-0256';O.mkdir(exist_ok=False)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def st(s,**kw):save('status.json',dict(status=s,pid=os.getpid(),updated_at=time.time(),**kw))
(O/'controller.py').write_bytes(Path(__file__).read_bytes())
try:
 data=(P/'incoming/fsa-typed-0256-input.json').read_bytes();(O/'input.json').write_bytes(data);save('input-hash.json',dict(sha256=hashlib.sha256(data).hexdigest()))
 messages=[dict(role='system',content='Propose only finite proof-data JSON for the exact controller-owned frozen statements and renderer. No source edits, execution, options, axioms, admissions or self-approval.'),dict(role='user',content=data.decode())]
 st('running',stage='frozen_proof_data_proposal');sys.path.insert(0,str(P/'controllers/tcp-reasoning-authorized-v2'));from deepseek_gateway import request
 a=request(messages,P/'private/api-ledger',P/'private/deepseek.key',model='deepseek-v4-pro',max_calls=None,max_tokens=12000,thinking='disabled',reasoning_effort=None,timeout=900)
 response=json.loads((P/'private/api-ledger'/a['response_file']).read_text())['response'];save('response.json',response);save('usage.json',{k:a.get(k)for k in ['usage','cached','request_sha256']})
 assert set(response)=={'files','findings','limitations'} and type(response['files'])is dict and set(response['files'])=={'proofs.json'} and type(response['files']['proofs.json'])is str and all(type(response[k])is list for k in ['findings','limitations'])
 st('proof_data_received_requires_controller_gate')
except Exception as e:
 (O/'traceback.txt').write_text(traceback.format_exc());st('failed_or_rejected_no_retry',error_type=type(e).__name__)
