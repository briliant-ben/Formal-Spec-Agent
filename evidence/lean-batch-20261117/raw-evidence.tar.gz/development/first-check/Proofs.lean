import Approved

set_option maxRecDepth 16384

namespace Proofs

theorem timer_progress : Approved.timer_progress := by
  exact FormalSpecAgent.TimerProgress.step_progress

theorem rollback_error : Approved.rollback_error := by
  exact FormalSpecAgent.BatchMachine.rollback_error

theorem initial_valid_0 : Approved.initial_valid_0 := by
  simp only [Approved.initial_valid_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_0_0 : Approved.witness_0_0 := by
  simp only [Approved.witness_0_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_0_1 : Approved.witness_0_1 := by
  simp only [Approved.witness_0_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_0_2 : Approved.witness_0_2 := by
  simp only [Approved.witness_0_2, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem initial_valid_1 : Approved.initial_valid_1 := by
  simp only [Approved.initial_valid_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_1_0 : Approved.witness_1_0 := by
  simp only [Approved.witness_1_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_1_1 : Approved.witness_1_1 := by
  simp only [Approved.witness_1_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_1_2 : Approved.witness_1_2 := by
  simp only [Approved.witness_1_2, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem initial_valid_2 : Approved.initial_valid_2 := by
  simp only [Approved.initial_valid_2, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_2_0 : Approved.witness_2_0 := by
  simp only [Approved.witness_2_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_2_1 : Approved.witness_2_1 := by
  simp only [Approved.witness_2_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_2_2 : Approved.witness_2_2 := by
  simp only [Approved.witness_2_2, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_2_3 : Approved.witness_2_3 := by
  simp only [Approved.witness_2_3, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_2_4 : Approved.witness_2_4 := by
  simp only [Approved.witness_2_4, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem initial_valid_3 : Approved.initial_valid_3 := by
  simp only [Approved.initial_valid_3, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_3_0 : Approved.witness_3_0 := by
  simp only [Approved.witness_3_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_3_1 : Approved.witness_3_1 := by
  simp only [Approved.witness_3_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_3_2 : Approved.witness_3_2 := by
  simp only [Approved.witness_3_2, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem initial_valid_4 : Approved.initial_valid_4 := by
  simp only [Approved.initial_valid_4, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_4_0 : Approved.witness_4_0 := by
  simp only [Approved.witness_4_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_4_1 : Approved.witness_4_1 := by
  simp only [Approved.witness_4_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_4_2 : Approved.witness_4_2 := by
  simp only [Approved.witness_4_2, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_4_3 : Approved.witness_4_3 := by
  simp only [Approved.witness_4_3, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem initial_valid_5 : Approved.initial_valid_5 := by
  simp only [Approved.initial_valid_5, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_5_0 : Approved.witness_5_0 := by
  simp only [Approved.witness_5_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_5_1 : Approved.witness_5_1 := by
  simp only [Approved.witness_5_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem initial_valid_6 : Approved.initial_valid_6 := by
  simp only [Approved.initial_valid_6, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_6_0 : Approved.witness_6_0 := by
  simp only [Approved.witness_6_0, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

theorem witness_6_1 : Approved.witness_6_1 := by
  simp only [Approved.witness_6_1, FormalSpecAgent.TimerRank.WellTimed]
  try
    decide

end Proofs
