import BatchObserve

set_option maxRecDepth 16384

namespace Approved

def e0 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (0)

def e1 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean false

def e2 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e3 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([] : FormalSpecAgent.Bytes)

def e4 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116])

def e5 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean true

def e6 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.field .octets 0

def e7 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (4)

def e8 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.variable .integer 0

def e9 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (1)

def e10 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.add e8 e9

def e11 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.variable .sequence 2

def e12 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.seqAdd e11 e9

def e13 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.literal .text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0])

def e14 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 1

def e15 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 3

def e16 : FormalSpecAgent.TypedIR.Expr .text :=
  FormalSpecAgent.TypedIR.Expr.variable .text 4

def e17 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.stateIs 0

def e18 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.timerActive 0

def e19 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.timerActive 2

def e20 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (5)

def e21 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (10)

def e22 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.field .integer 0

def e23 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (-1)

def e24 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.variable .boolean 5

def e25 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolNot e24

def e26 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolAnd e19 e25

def e27 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (3)

def e28 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (7)

def e29 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.boolAnd e19 e24

def e30 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (99)

def e31 : FormalSpecAgent.TypedIR.Expr .sequence :=
  FormalSpecAgent.TypedIR.Expr.literal .sequence (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32)

def e32 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes)

def e33 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (2)

def e34 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e8 e9

def e35 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e8 e33

def e36 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intGe e8 e0

def e37 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e15

def e38 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (4096)

def e39 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e37 e38

def rule_0 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 0, source := 0, target := 1, event := 0, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .octets 3 e6, FormalSpecAgent.TypedMachine.Action.assign .integer 0 e7, FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.assign .boolean 1 e5, FormalSpecAgent.TypedMachine.Action.assign .sequence 2 e12, FormalSpecAgent.TypedMachine.Action.assign .text 4 e13, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 2 e20, FormalSpecAgent.TypedMachine.Action.arm 0 e20] }

def rule_1 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 1, source := 0, target := 1, event := 1, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e21, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 0 e22] }

def rule_2 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 2, source := 0, target := 2, event := 2, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e23, FormalSpecAgent.TypedMachine.Action.arm 0 e20, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_3 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 3, source := 1, target := 1, event := 6, guard := e18, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_4 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 4, source := 1, target := 2, event := 7, guard := e26, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.cancel 0] }

def rule_5 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 5, source := 1, target := 1, event := 3, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.arm 0 e27, FormalSpecAgent.TypedMachine.Action.arm 0 e28, FormalSpecAgent.TypedMachine.Action.cancel 2, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def rule_6 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 6, source := 0, target := 0, event := 4, guard := e5, actions := [] }

def rule_7 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 7, source := 0, target := 1, event := 4, guard := e5, actions := [] }

def rule_8 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 8, source := 1, target := 2, event := 7, guard := e29, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e30, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 0 e0] }

def rule_9 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 9, source := 1, target := 1, event := 9, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .boolean 5 e5] }

def rule_10 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 10, source := 1, target := 1, event := 10, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .boolean 5 e1] }

def rule_11 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 11, source := 0, target := 1, event := 8, guard := e5, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e0, FormalSpecAgent.TypedMachine.Action.assign .boolean 1 e5, FormalSpecAgent.TypedMachine.Action.assign .sequence 2 e31, FormalSpecAgent.TypedMachine.Action.assign .octets 3 e32, FormalSpecAgent.TypedMachine.Action.assign .text 4 e13, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 1 e33] }

def rule_12 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 12, source := 1, target := 1, event := 11, guard := e34, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩], FormalSpecAgent.TypedMachine.Action.arm 1 e33] }

def rule_13 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 13, source := 1, target := 2, event := 11, guard := e35, actions := [FormalSpecAgent.TypedMachine.Action.assign .integer 0 e10, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .integer, e8⟩, ⟨1, .boolean, e14⟩, ⟨2, .sequence, e11⟩, ⟨3, .octets, e15⟩, ⟨4, .text, e16⟩, ⟨5, .boolean, e17⟩, ⟨6, .boolean, e18⟩, ⟨7, .boolean, e19⟩]] }

def schema : List (FormalSpecAgent.TypedIR.Kind × Nat) := [(.integer, 0), (.boolean, 1), (.sequence, 2), (.octets, 3), (.text, 4), (.boolean, 5)]

def model : FormalSpecAgent.TypedMachine.Model :=
  { rules := [rule_0, rule_1, rule_2, rule_3, rule_4, rule_5, rule_6, rule_7, rule_8, rule_9, rule_10, rule_11, rule_12, rule_13], invariants := [e36, e39], timerEvents := fun n => if n = 0 then 6 else if n = 1 then 11 else if n = 2 then 7 else 0, externalEvents := [0, 1, 2, 3, 4, 5, 8, 9, 10] }

def eventSchemas (n : Nat) : List (FormalSpecAgent.TypedIR.Kind × Nat) := if n = 0 then [(.octets, 0)] else if n = 1 then [(.integer, 0)] else if n = 2 then [] else if n = 3 then [] else if n = 4 then [] else if n = 5 then [] else if n = 6 then [] else if n = 7 then [] else if n = 8 then [] else if n = 9 then [] else if n = 10 then [] else if n = 11 then [] else []

def initial_0 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_0_0 := FormalSpecAgent.BatchMachine.dispatch model initial_0 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_0_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback initial_0 result_0_0

def result_0_1 := FormalSpecAgent.BatchMachine.tick model after_0_0 (5)

def after_0_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_0_0 result_0_1

def result_0_2 := FormalSpecAgent.BatchMachine.tick model after_0_1 (10)

def after_0_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_0_1 result_0_2

def initial_1 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_1_0 := FormalSpecAgent.BatchMachine.dispatch model initial_1 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_1_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback initial_1 result_1_0

def result_1_1 := FormalSpecAgent.BatchMachine.dispatch model after_1_0 5 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)

def after_1_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_1_0 result_1_1

def result_1_2 := FormalSpecAgent.BatchMachine.tick model after_1_1 (5)

def after_1_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_1_1 result_1_2

def initial_2 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_2_0 := FormalSpecAgent.BatchMachine.dispatch model initial_2 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_2_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback initial_2 result_2_0

def result_2_1 := FormalSpecAgent.BatchMachine.dispatch model after_2_0 9 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_2_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_2_0 result_2_1

def result_2_2 := FormalSpecAgent.BatchMachine.tick model after_2_1 (5)

def after_2_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_2_1 result_2_2

def result_2_3 := FormalSpecAgent.BatchMachine.dispatch model after_2_2 10 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_2_3 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_2_2 result_2_3

def result_2_4 := FormalSpecAgent.BatchMachine.tick model after_2_3 (5)

def after_2_4 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_2_3 result_2_4

def initial_3 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_3_0 := FormalSpecAgent.BatchMachine.dispatch model initial_3 8 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_3_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback initial_3 result_3_0

def result_3_1 := FormalSpecAgent.BatchMachine.tick model after_3_0 (10)

def after_3_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_3_0 result_3_1

def result_3_2 := FormalSpecAgent.BatchMachine.tick model after_3_1 (12)

def after_3_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_3_1 result_3_2

def initial_4 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_4_0 := FormalSpecAgent.BatchMachine.dispatch model initial_4 4 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (10)

def after_4_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback initial_4 result_4_0

def result_4_1 := FormalSpecAgent.BatchMachine.dispatch model after_4_0 2 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (10)

def after_4_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_4_0 result_4_1

def result_4_2 := FormalSpecAgent.BatchMachine.dispatch model after_4_1 1 ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (10)

def after_4_2 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_4_1 result_4_2

def result_4_3 := FormalSpecAgent.BatchMachine.tick model after_4_2 (-1)

def after_4_3 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_4_2 result_4_3

def initial_5 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_5_0 := FormalSpecAgent.BatchMachine.dispatch model initial_5 6 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (5)

def after_5_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback initial_5 result_5_0

def result_5_1 := FormalSpecAgent.BatchMachine.tick model after_5_0 (5)

def after_5_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_5_0 result_5_1

def initial_6 : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then false else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 97, Char.ofNat 114, Char.ofNat 116]) else (String.ofList []), buffers := fun n => if n = 3 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨4294967295, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)

def result_6_0 := FormalSpecAgent.BatchMachine.dispatch model initial_6 0 ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values) (0)

def after_6_0 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback initial_6 result_6_0

def result_6_1 := FormalSpecAgent.BatchMachine.tick model after_6_0 (5)

def after_6_1 : FormalSpecAgent.TypedMachine.Snapshot := FormalSpecAgent.BatchMachine.rollback after_6_0 result_6_1
def timer_progress : Prop :=
  ∀ (m : FormalSpecAgent.TypedMachine.Model) (s : FormalSpecAgent.TypedMachine.Snapshot) (limit : Int) (entry : FormalSpecAgent.TypedMachine.TimerEntry) (t : FormalSpecAgent.TypedMachine.Transition), FormalSpecAgent.TimerRank.WellTimed s → s.now ≤ limit → FormalSpecAgent.TypedMachine.nextTimer s = some entry → entry.due ≤ limit → FormalSpecAgent.TypedMachine.stepTimer m s entry.due = .ok t → FormalSpecAgent.TimerRank.WellTimed t.after ∧ t.after.now = entry.due ∧ Prod.Lex Nat.lt Nat.lt (FormalSpecAgent.TimerRank.rank limit t.after) (FormalSpecAgent.TimerRank.rank limit s)

def rollback_error : Prop :=
  ∀ (s : FormalSpecAgent.TypedMachine.Snapshot) (f : FormalSpecAgent.TypedMachine.Fault), FormalSpecAgent.BatchMachine.rollback s (.error f) = s

def initial_valid_0 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_0 = true ∧ FormalSpecAgent.TimerRank.WellTimed initial_0

def witness_0_0 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas initial_0 result_0_0 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 0, event := 0, fields := [(FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (5))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_0_1 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_0_0 result_0_1 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 3, event := 6, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (6))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean true))])] } : FormalSpecAgent.BatchObserve.SeenTransition), ({ rule := 4, event := 7, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (7))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_0_2 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_0_1 result_0_2 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (10), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) []

def initial_valid_1 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_1 = true ∧ FormalSpecAgent.TimerRank.WellTimed initial_1

def witness_1_0 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas initial_1 result_1_0 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 0, event := 0, fields := [(FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (5))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_1_1 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_1_0 result_1_1 = FormalSpecAgent.BatchObserve.Outcome.error .uncovered (FormalSpecAgent.MachineObserve.snapshot schema after_1_0)

def witness_1_2 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_1_1 result_1_2 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 3, event := 6, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (6))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean true))])] } : FormalSpecAgent.BatchObserve.SeenTransition), ({ rule := 4, event := 7, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (7))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def initial_valid_2 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_2 = true ∧ FormalSpecAgent.TimerRank.WellTimed initial_2

def witness_2_0 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas initial_2 result_2_0 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 0, event := 0, fields := [(FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (5))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_2_1 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_2_0 result_2_1 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 9, event := 9, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then true else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_2_2 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_2_1 result_2_2 = FormalSpecAgent.BatchObserve.Outcome.error .badDelay (FormalSpecAgent.MachineObserve.snapshot schema after_2_1)

def witness_2_3 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_2_2 result_2_3 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 10, event := 10, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_2_4 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_2_3 result_2_4 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 3, event := 6, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (6))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean true))])] } : FormalSpecAgent.BatchObserve.SeenTransition), ({ rule := 4, event := 7, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (7))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def initial_valid_3 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_3 = true ∧ FormalSpecAgent.TimerRank.WellTimed initial_3

def witness_3_0 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas initial_3 result_3_0 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨1, (2)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 11, event := 8, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (0) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨1, (2)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (0))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_3_1 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_3_0 result_3_1 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (3) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (10), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 12, event := 11, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (1) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (2), timers := [⟨1, (4)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (1))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition), ({ rule := 12, event := 11, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (2) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (4), timers := [⟨1, (6)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (2))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition), ({ rule := 13, event := 11, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (3) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (6), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (3))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_3_2 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_3_1 result_3_2 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (3) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (12), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) []

def initial_valid_4 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_4 = true ∧ FormalSpecAgent.TimerRank.WellTimed initial_4

def witness_4_0 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas initial_4 result_4_0 = FormalSpecAgent.BatchObserve.Outcome.error .conflict (FormalSpecAgent.MachineObserve.snapshot schema initial_4)

def witness_4_1 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_4_0 result_4_1 = FormalSpecAgent.BatchObserve.Outcome.error .invariant (FormalSpecAgent.MachineObserve.snapshot schema after_4_0)

def witness_4_2 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_4_1 result_4_2 = FormalSpecAgent.BatchObserve.Outcome.error .badDelay (FormalSpecAgent.MachineObserve.snapshot schema after_4_1)

def witness_4_3 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_4_2 result_4_3 = FormalSpecAgent.BatchObserve.Outcome.error .time (FormalSpecAgent.MachineObserve.snapshot schema after_4_2)

def initial_valid_5 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_5 = true ∧ FormalSpecAgent.TimerRank.WellTimed initial_5

def witness_5_0 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas initial_5 result_5_0 = FormalSpecAgent.BatchObserve.Outcome.error .timerInjection (FormalSpecAgent.MachineObserve.snapshot schema initial_5)

def witness_5_1 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_5_0 result_5_1 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 3, event := 6, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (6))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean true))])] } : FormalSpecAgent.BatchObserve.SeenTransition), ({ rule := 4, event := 7, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (7))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets ([⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨7, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def initial_valid_6 : Prop :=
  FormalSpecAgent.TypedMachine.invariantsHold model initial_6 = true ∧ FormalSpecAgent.TimerRank.WellTimed initial_6

def witness_6_0 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas initial_6 result_6_0 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 0, event := 0, fields := [(FormalSpecAgent.MachineObserve.Packed.octets (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes))], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (5) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (0), timers := [⟨0, (5)⟩, ⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (5))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

def witness_6_1 : Prop :=
  FormalSpecAgent.BatchObserve.outcome schema eventSchemas after_6_0 result_6_1 = FormalSpecAgent.BatchObserve.Outcome.success (FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)) [({ rule := 3, event := 6, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (6) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 1, now := (5), timers := [⟨2, (5)⟩] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (6))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean true))])] } : FormalSpecAgent.BatchObserve.SeenTransition), ({ rule := 4, event := 7, fields := [], after := FormalSpecAgent.MachineObserve.snapshot schema ({ values := ({ integers := fun n => if n = 0 then (7) else (0), booleans := fun n => if n = 1 then true else if n = 5 then false else false, texts := fun n => if n = 4 then (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]) else (String.ofList []), buffers := fun n => if n = 3 then (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => if n = 2 then (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) else (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 2, now := (5), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot), emitted := [(0, [(0, (FormalSpecAgent.MachineObserve.Packed.integer (7))), (1, (FormalSpecAgent.MachineObserve.Packed.boolean true)), (2, (FormalSpecAgent.MachineObserve.Packed.sequence 0)), (3, (FormalSpecAgent.MachineObserve.Packed.octets (List.replicate 4090 (⟨7, by decide⟩ : FormalSpecAgent.Byte) ++ [⟨0, by decide⟩, ⟨128, by decide⟩, ⟨255, by decide⟩, ⟨6, by decide⟩, ⟨2, by decide⟩, ⟨0, by decide⟩] : FormalSpecAgent.Bytes))), (4, (FormalSpecAgent.MachineObserve.Packed.text (String.ofList [Char.ofNat 24320, Char.ofNat 10, Char.ofNat 0]))), (5, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (6, (FormalSpecAgent.MachineObserve.Packed.boolean false)), (7, (FormalSpecAgent.MachineObserve.Packed.boolean false))])] } : FormalSpecAgent.BatchObserve.SeenTransition)]

end Approved
