// Lean compiler output
// Module: BatchMachine
// Imports: public import Init public meta import Init public import TimerProgress
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_int_dec_le(lean_object*, lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_nextTimer(lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_stepTimer(lean_object*, lean_object*, lean_object*);
uint8_t l_FormalSpecAgent_TypedMachine_invariantsHold(lean_object*, lean_object*);
uint8_t l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_TypedMachine_external(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_appendTR___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_List_all___at___00FormalSpecAgent_BatchMachine_advance___aux__1_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_all___at___00FormalSpecAgent_BatchMachine_advance___aux__1_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchMachine_advance___aux__1(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advance___aux__1___boxed(lean_object*);
static const lean_ctor_object l_FormalSpecAgent_BatchMachine_advance___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_BatchMachine_advance___closed__0 = (const lean_object*)&l_FormalSpecAgent_BatchMachine_advance___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advance(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_BatchMachine_tick___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_BatchMachine_tick___closed__0 = (const lean_object*)&l_FormalSpecAgent_BatchMachine_tick___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_tick(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_FormalSpecAgent_BatchMachine_dispatch___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(5) << 1) | 1))}};
static const lean_object* l_FormalSpecAgent_BatchMachine_dispatch___closed__0 = (const lean_object*)&l_FormalSpecAgent_BatchMachine_dispatch___closed__0_value;
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_dispatch(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux___redArg(lean_object* v_model_1_, lean_object* v_snapshot_2_, lean_object* v_limit_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = l_FormalSpecAgent_TypedMachine_nextTimer(v_snapshot_2_);
if (lean_obj_tag(v___x_4_) == 0)
{
lean_object* v_values_5_; lean_object* v_state_6_; lean_object* v_timers_7_; lean_object* v___x_9_; uint8_t v_isShared_10_; uint8_t v_isSharedCheck_17_; 
lean_dec_ref(v_model_1_);
v_values_5_ = lean_ctor_get(v_snapshot_2_, 0);
v_state_6_ = lean_ctor_get(v_snapshot_2_, 1);
v_timers_7_ = lean_ctor_get(v_snapshot_2_, 3);
v_isSharedCheck_17_ = !lean_is_exclusive(v_snapshot_2_);
if (v_isSharedCheck_17_ == 0)
{
lean_object* v_unused_18_; 
v_unused_18_ = lean_ctor_get(v_snapshot_2_, 2);
lean_dec(v_unused_18_);
v___x_9_ = v_snapshot_2_;
v_isShared_10_ = v_isSharedCheck_17_;
goto v_resetjp_8_;
}
else
{
lean_inc(v_timers_7_);
lean_inc(v_state_6_);
lean_inc(v_values_5_);
lean_dec(v_snapshot_2_);
v___x_9_ = lean_box(0);
v_isShared_10_ = v_isSharedCheck_17_;
goto v_resetjp_8_;
}
v_resetjp_8_:
{
lean_object* v___x_12_; 
if (v_isShared_10_ == 0)
{
lean_ctor_set(v___x_9_, 2, v_limit_3_);
v___x_12_ = v___x_9_;
goto v_reusejp_11_;
}
else
{
lean_object* v_reuseFailAlloc_16_; 
v_reuseFailAlloc_16_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_16_, 0, v_values_5_);
lean_ctor_set(v_reuseFailAlloc_16_, 1, v_state_6_);
lean_ctor_set(v_reuseFailAlloc_16_, 2, v_limit_3_);
lean_ctor_set(v_reuseFailAlloc_16_, 3, v_timers_7_);
v___x_12_ = v_reuseFailAlloc_16_;
goto v_reusejp_11_;
}
v_reusejp_11_:
{
lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v___x_15_; 
v___x_13_ = lean_box(0);
v___x_14_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_14_, 0, v___x_12_);
lean_ctor_set(v___x_14_, 1, v___x_13_);
v___x_15_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_15_, 0, v___x_14_);
return v___x_15_;
}
}
}
else
{
lean_object* v_val_19_; lean_object* v___x_21_; uint8_t v_isShared_22_; uint8_t v_isSharedCheck_80_; 
v_val_19_ = lean_ctor_get(v___x_4_, 0);
v_isSharedCheck_80_ = !lean_is_exclusive(v___x_4_);
if (v_isSharedCheck_80_ == 0)
{
v___x_21_ = v___x_4_;
v_isShared_22_ = v_isSharedCheck_80_;
goto v_resetjp_20_;
}
else
{
lean_inc(v_val_19_);
lean_dec(v___x_4_);
v___x_21_ = lean_box(0);
v_isShared_22_ = v_isSharedCheck_80_;
goto v_resetjp_20_;
}
v_resetjp_20_:
{
lean_object* v_due_23_; lean_object* v___x_25_; uint8_t v_isShared_26_; uint8_t v_isSharedCheck_78_; 
v_due_23_ = lean_ctor_get(v_val_19_, 1);
v_isSharedCheck_78_ = !lean_is_exclusive(v_val_19_);
if (v_isSharedCheck_78_ == 0)
{
lean_object* v_unused_79_; 
v_unused_79_ = lean_ctor_get(v_val_19_, 0);
lean_dec(v_unused_79_);
v___x_25_ = v_val_19_;
v_isShared_26_ = v_isSharedCheck_78_;
goto v_resetjp_24_;
}
else
{
lean_inc(v_due_23_);
lean_dec(v_val_19_);
v___x_25_ = lean_box(0);
v_isShared_26_ = v_isSharedCheck_78_;
goto v_resetjp_24_;
}
v_resetjp_24_:
{
uint8_t v___x_27_; 
v___x_27_ = lean_int_dec_le(v_due_23_, v_limit_3_);
if (v___x_27_ == 0)
{
lean_object* v_values_28_; lean_object* v_state_29_; lean_object* v_timers_30_; lean_object* v___x_32_; uint8_t v_isShared_33_; uint8_t v_isSharedCheck_44_; 
lean_dec(v_due_23_);
lean_dec_ref(v_model_1_);
v_values_28_ = lean_ctor_get(v_snapshot_2_, 0);
v_state_29_ = lean_ctor_get(v_snapshot_2_, 1);
v_timers_30_ = lean_ctor_get(v_snapshot_2_, 3);
v_isSharedCheck_44_ = !lean_is_exclusive(v_snapshot_2_);
if (v_isSharedCheck_44_ == 0)
{
lean_object* v_unused_45_; 
v_unused_45_ = lean_ctor_get(v_snapshot_2_, 2);
lean_dec(v_unused_45_);
v___x_32_ = v_snapshot_2_;
v_isShared_33_ = v_isSharedCheck_44_;
goto v_resetjp_31_;
}
else
{
lean_inc(v_timers_30_);
lean_inc(v_state_29_);
lean_inc(v_values_28_);
lean_dec(v_snapshot_2_);
v___x_32_ = lean_box(0);
v_isShared_33_ = v_isSharedCheck_44_;
goto v_resetjp_31_;
}
v_resetjp_31_:
{
lean_object* v___x_35_; 
if (v_isShared_33_ == 0)
{
lean_ctor_set(v___x_32_, 2, v_limit_3_);
v___x_35_ = v___x_32_;
goto v_reusejp_34_;
}
else
{
lean_object* v_reuseFailAlloc_43_; 
v_reuseFailAlloc_43_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_43_, 0, v_values_28_);
lean_ctor_set(v_reuseFailAlloc_43_, 1, v_state_29_);
lean_ctor_set(v_reuseFailAlloc_43_, 2, v_limit_3_);
lean_ctor_set(v_reuseFailAlloc_43_, 3, v_timers_30_);
v___x_35_ = v_reuseFailAlloc_43_;
goto v_reusejp_34_;
}
v_reusejp_34_:
{
lean_object* v___x_36_; lean_object* v___x_38_; 
v___x_36_ = lean_box(0);
if (v_isShared_26_ == 0)
{
lean_ctor_set(v___x_25_, 1, v___x_36_);
lean_ctor_set(v___x_25_, 0, v___x_35_);
v___x_38_ = v___x_25_;
goto v_reusejp_37_;
}
else
{
lean_object* v_reuseFailAlloc_42_; 
v_reuseFailAlloc_42_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_42_, 0, v___x_35_);
lean_ctor_set(v_reuseFailAlloc_42_, 1, v___x_36_);
v___x_38_ = v_reuseFailAlloc_42_;
goto v_reusejp_37_;
}
v_reusejp_37_:
{
lean_object* v___x_40_; 
if (v_isShared_22_ == 0)
{
lean_ctor_set(v___x_21_, 0, v___x_38_);
v___x_40_ = v___x_21_;
goto v_reusejp_39_;
}
else
{
lean_object* v_reuseFailAlloc_41_; 
v_reuseFailAlloc_41_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_41_, 0, v___x_38_);
v___x_40_ = v_reuseFailAlloc_41_;
goto v_reusejp_39_;
}
v_reusejp_39_:
{
return v___x_40_;
}
}
}
}
}
else
{
lean_object* v___x_46_; 
lean_del_object(v___x_21_);
lean_inc_ref(v_model_1_);
v___x_46_ = l_FormalSpecAgent_TypedMachine_stepTimer(v_model_1_, v_snapshot_2_, v_due_23_);
if (lean_obj_tag(v___x_46_) == 0)
{
lean_object* v_a_47_; lean_object* v___x_49_; uint8_t v_isShared_50_; uint8_t v_isSharedCheck_54_; 
lean_del_object(v___x_25_);
lean_dec(v_limit_3_);
lean_dec_ref(v_model_1_);
v_a_47_ = lean_ctor_get(v___x_46_, 0);
v_isSharedCheck_54_ = !lean_is_exclusive(v___x_46_);
if (v_isSharedCheck_54_ == 0)
{
v___x_49_ = v___x_46_;
v_isShared_50_ = v_isSharedCheck_54_;
goto v_resetjp_48_;
}
else
{
lean_inc(v_a_47_);
lean_dec(v___x_46_);
v___x_49_ = lean_box(0);
v_isShared_50_ = v_isSharedCheck_54_;
goto v_resetjp_48_;
}
v_resetjp_48_:
{
lean_object* v___x_52_; 
if (v_isShared_50_ == 0)
{
v___x_52_ = v___x_49_;
goto v_reusejp_51_;
}
else
{
lean_object* v_reuseFailAlloc_53_; 
v_reuseFailAlloc_53_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_53_, 0, v_a_47_);
v___x_52_ = v_reuseFailAlloc_53_;
goto v_reusejp_51_;
}
v_reusejp_51_:
{
return v___x_52_;
}
}
}
else
{
lean_object* v_a_55_; lean_object* v_after_56_; lean_object* v___x_57_; 
v_a_55_ = lean_ctor_get(v___x_46_, 0);
lean_inc(v_a_55_);
lean_dec_ref_known(v___x_46_, 1);
v_after_56_ = lean_ctor_get(v_a_55_, 0);
lean_inc_ref(v_after_56_);
v___x_57_ = l_FormalSpecAgent_BatchMachine_advanceAux___redArg(v_model_1_, v_after_56_, v_limit_3_);
if (lean_obj_tag(v___x_57_) == 0)
{
lean_dec(v_a_55_);
lean_del_object(v___x_25_);
return v___x_57_;
}
else
{
lean_object* v_a_58_; lean_object* v___x_60_; uint8_t v_isShared_61_; uint8_t v_isSharedCheck_77_; 
v_a_58_ = lean_ctor_get(v___x_57_, 0);
v_isSharedCheck_77_ = !lean_is_exclusive(v___x_57_);
if (v_isSharedCheck_77_ == 0)
{
v___x_60_ = v___x_57_;
v_isShared_61_ = v_isSharedCheck_77_;
goto v_resetjp_59_;
}
else
{
lean_inc(v_a_58_);
lean_dec(v___x_57_);
v___x_60_ = lean_box(0);
v_isShared_61_ = v_isSharedCheck_77_;
goto v_resetjp_59_;
}
v_resetjp_59_:
{
lean_object* v_after_62_; lean_object* v_trace_63_; lean_object* v___x_65_; uint8_t v_isShared_66_; uint8_t v_isSharedCheck_76_; 
v_after_62_ = lean_ctor_get(v_a_58_, 0);
v_trace_63_ = lean_ctor_get(v_a_58_, 1);
v_isSharedCheck_76_ = !lean_is_exclusive(v_a_58_);
if (v_isSharedCheck_76_ == 0)
{
v___x_65_ = v_a_58_;
v_isShared_66_ = v_isSharedCheck_76_;
goto v_resetjp_64_;
}
else
{
lean_inc(v_trace_63_);
lean_inc(v_after_62_);
lean_dec(v_a_58_);
v___x_65_ = lean_box(0);
v_isShared_66_ = v_isSharedCheck_76_;
goto v_resetjp_64_;
}
v_resetjp_64_:
{
lean_object* v___x_68_; 
if (v_isShared_26_ == 0)
{
lean_ctor_set_tag(v___x_25_, 1);
lean_ctor_set(v___x_25_, 1, v_trace_63_);
lean_ctor_set(v___x_25_, 0, v_a_55_);
v___x_68_ = v___x_25_;
goto v_reusejp_67_;
}
else
{
lean_object* v_reuseFailAlloc_75_; 
v_reuseFailAlloc_75_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_75_, 0, v_a_55_);
lean_ctor_set(v_reuseFailAlloc_75_, 1, v_trace_63_);
v___x_68_ = v_reuseFailAlloc_75_;
goto v_reusejp_67_;
}
v_reusejp_67_:
{
lean_object* v___x_70_; 
if (v_isShared_66_ == 0)
{
lean_ctor_set(v___x_65_, 1, v___x_68_);
v___x_70_ = v___x_65_;
goto v_reusejp_69_;
}
else
{
lean_object* v_reuseFailAlloc_74_; 
v_reuseFailAlloc_74_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_74_, 0, v_after_62_);
lean_ctor_set(v_reuseFailAlloc_74_, 1, v___x_68_);
v___x_70_ = v_reuseFailAlloc_74_;
goto v_reusejp_69_;
}
v_reusejp_69_:
{
lean_object* v___x_72_; 
if (v_isShared_61_ == 0)
{
lean_ctor_set(v___x_60_, 0, v___x_70_);
v___x_72_ = v___x_60_;
goto v_reusejp_71_;
}
else
{
lean_object* v_reuseFailAlloc_73_; 
v_reuseFailAlloc_73_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_73_, 0, v___x_70_);
v___x_72_ = v_reuseFailAlloc_73_;
goto v_reusejp_71_;
}
v_reusejp_71_:
{
return v___x_72_;
}
}
}
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advanceAux(lean_object* v_model_81_, lean_object* v_snapshot_82_, lean_object* v_limit_83_, lean_object* v_hwell_84_, lean_object* v_hbound_85_){
_start:
{
lean_object* v___x_86_; 
v___x_86_ = l_FormalSpecAgent_BatchMachine_advanceAux___redArg(v_model_81_, v_snapshot_82_, v_limit_83_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter___redArg(lean_object* v_x_87_, lean_object* v_h__1_88_, lean_object* v_h__2_89_){
_start:
{
if (lean_obj_tag(v_x_87_) == 0)
{
lean_object* v___x_90_; 
lean_dec(v_h__2_89_);
v___x_90_ = lean_apply_1(v_h__1_88_, lean_box(0));
return v___x_90_;
}
else
{
lean_object* v_val_91_; lean_object* v___x_92_; 
lean_dec(v_h__1_88_);
v_val_91_ = lean_ctor_get(v_x_87_, 0);
lean_inc(v_val_91_);
lean_dec_ref_known(v_x_87_, 1);
v___x_92_ = lean_apply_2(v_h__2_89_, v_val_91_, lean_box(0));
return v___x_92_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter(lean_object* v_motive_93_, lean_object* v_x_94_, lean_object* v_h__1_95_, lean_object* v_h__2_96_){
_start:
{
if (lean_obj_tag(v_x_94_) == 0)
{
lean_object* v___x_97_; 
lean_dec(v_h__2_96_);
v___x_97_ = lean_apply_1(v_h__1_95_, lean_box(0));
return v___x_97_;
}
else
{
lean_object* v_val_98_; lean_object* v___x_99_; 
lean_dec(v_h__1_95_);
v_val_98_ = lean_ctor_get(v_x_94_, 0);
lean_inc(v_val_98_);
lean_dec_ref_known(v_x_94_, 1);
v___x_99_ = lean_apply_2(v_h__2_96_, v_val_98_, lean_box(0));
return v___x_99_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter___redArg(lean_object* v_x_100_, lean_object* v_h__1_101_, lean_object* v_h__2_102_){
_start:
{
if (lean_obj_tag(v_x_100_) == 0)
{
lean_object* v_a_103_; lean_object* v___x_104_; 
lean_dec(v_h__2_102_);
v_a_103_ = lean_ctor_get(v_x_100_, 0);
lean_inc(v_a_103_);
lean_dec_ref_known(v_x_100_, 1);
v___x_104_ = lean_apply_2(v_h__1_101_, v_a_103_, lean_box(0));
return v___x_104_;
}
else
{
lean_object* v_a_105_; lean_object* v___x_106_; 
lean_dec(v_h__1_101_);
v_a_105_ = lean_ctor_get(v_x_100_, 0);
lean_inc(v_a_105_);
lean_dec_ref_known(v_x_100_, 1);
v___x_106_ = lean_apply_2(v_h__2_102_, v_a_105_, lean_box(0));
return v___x_106_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter(lean_object* v_motive_107_, lean_object* v_x_108_, lean_object* v_h__1_109_, lean_object* v_h__2_110_){
_start:
{
if (lean_obj_tag(v_x_108_) == 0)
{
lean_object* v_a_111_; lean_object* v___x_112_; 
lean_dec(v_h__2_110_);
v_a_111_ = lean_ctor_get(v_x_108_, 0);
lean_inc(v_a_111_);
lean_dec_ref_known(v_x_108_, 1);
v___x_112_ = lean_apply_2(v_h__1_109_, v_a_111_, lean_box(0));
return v___x_112_;
}
else
{
lean_object* v_a_113_; lean_object* v___x_114_; 
lean_dec(v_h__1_109_);
v_a_113_ = lean_ctor_get(v_x_108_, 0);
lean_inc(v_a_113_);
lean_dec_ref_known(v_x_108_, 1);
v___x_114_ = lean_apply_2(v_h__2_110_, v_a_113_, lean_box(0));
return v___x_114_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter___redArg(lean_object* v_x_115_, lean_object* v_h__1_116_, lean_object* v_h__2_117_){
_start:
{
if (lean_obj_tag(v_x_115_) == 0)
{
lean_object* v_a_118_; lean_object* v___x_119_; 
lean_dec(v_h__2_117_);
v_a_118_ = lean_ctor_get(v_x_115_, 0);
lean_inc(v_a_118_);
lean_dec_ref_known(v_x_115_, 1);
v___x_119_ = lean_apply_1(v_h__1_116_, v_a_118_);
return v___x_119_;
}
else
{
lean_object* v_a_120_; lean_object* v___x_121_; 
lean_dec(v_h__1_116_);
v_a_120_ = lean_ctor_get(v_x_115_, 0);
lean_inc(v_a_120_);
lean_dec_ref_known(v_x_115_, 1);
v___x_121_ = lean_apply_1(v_h__2_117_, v_a_120_);
return v___x_121_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter(lean_object* v_motive_122_, lean_object* v_x_123_, lean_object* v_h__1_124_, lean_object* v_h__2_125_){
_start:
{
if (lean_obj_tag(v_x_123_) == 0)
{
lean_object* v_a_126_; lean_object* v___x_127_; 
lean_dec(v_h__2_125_);
v_a_126_ = lean_ctor_get(v_x_123_, 0);
lean_inc(v_a_126_);
lean_dec_ref_known(v_x_123_, 1);
v___x_127_ = lean_apply_1(v_h__1_124_, v_a_126_);
return v___x_127_;
}
else
{
lean_object* v_a_128_; lean_object* v___x_129_; 
lean_dec(v_h__1_124_);
v_a_128_ = lean_ctor_get(v_x_123_, 0);
lean_inc(v_a_128_);
lean_dec_ref_known(v_x_123_, 1);
v___x_129_ = lean_apply_1(v_h__2_125_, v_a_128_);
return v___x_129_;
}
}
}
LEAN_EXPORT uint8_t l_List_all___at___00FormalSpecAgent_BatchMachine_advance___aux__1_spec__0(lean_object* v_snapshot_130_, lean_object* v_x_131_){
_start:
{
if (lean_obj_tag(v_x_131_) == 0)
{
uint8_t v___x_132_; 
v___x_132_ = 1;
return v___x_132_;
}
else
{
lean_object* v_head_133_; lean_object* v_tail_134_; lean_object* v_now_135_; lean_object* v_due_136_; uint8_t v___x_137_; 
v_head_133_ = lean_ctor_get(v_x_131_, 0);
v_tail_134_ = lean_ctor_get(v_x_131_, 1);
v_now_135_ = lean_ctor_get(v_snapshot_130_, 2);
v_due_136_ = lean_ctor_get(v_head_133_, 1);
v___x_137_ = lean_int_dec_le(v_now_135_, v_due_136_);
if (v___x_137_ == 0)
{
return v___x_137_;
}
else
{
v_x_131_ = v_tail_134_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_List_all___at___00FormalSpecAgent_BatchMachine_advance___aux__1_spec__0___boxed(lean_object* v_snapshot_139_, lean_object* v_x_140_){
_start:
{
uint8_t v_res_141_; lean_object* v_r_142_; 
v_res_141_ = l_List_all___at___00FormalSpecAgent_BatchMachine_advance___aux__1_spec__0(v_snapshot_139_, v_x_140_);
lean_dec(v_x_140_);
lean_dec_ref(v_snapshot_139_);
v_r_142_ = lean_box(v_res_141_);
return v_r_142_;
}
}
LEAN_EXPORT uint8_t l_FormalSpecAgent_BatchMachine_advance___aux__1(lean_object* v_snapshot_143_){
_start:
{
lean_object* v_timers_144_; uint8_t v___x_145_; 
v_timers_144_ = lean_ctor_get(v_snapshot_143_, 3);
v___x_145_ = l_List_all___at___00FormalSpecAgent_BatchMachine_advance___aux__1_spec__0(v_snapshot_143_, v_timers_144_);
return v___x_145_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advance___aux__1___boxed(lean_object* v_snapshot_146_){
_start:
{
uint8_t v_res_147_; lean_object* v_r_148_; 
v_res_147_ = l_FormalSpecAgent_BatchMachine_advance___aux__1(v_snapshot_146_);
lean_dec_ref(v_snapshot_146_);
v_r_148_ = lean_box(v_res_147_);
return v_r_148_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_advance(lean_object* v_model_152_, lean_object* v_snapshot_153_, lean_object* v_limit_154_){
_start:
{
lean_object* v_now_155_; lean_object* v_timers_156_; uint8_t v___x_157_; 
v_now_155_ = lean_ctor_get(v_snapshot_153_, 2);
v_timers_156_ = lean_ctor_get(v_snapshot_153_, 3);
v___x_157_ = lean_int_dec_lt(v_limit_154_, v_now_155_);
if (v___x_157_ == 0)
{
uint8_t v___x_158_; 
v___x_158_ = l_List_all___at___00FormalSpecAgent_BatchMachine_advance___aux__1_spec__0(v_snapshot_153_, v_timers_156_);
if (v___x_158_ == 0)
{
lean_object* v___x_159_; 
lean_dec(v_limit_154_);
lean_dec_ref(v_snapshot_153_);
lean_dec_ref(v_model_152_);
v___x_159_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_advance___closed__0));
return v___x_159_;
}
else
{
lean_object* v___x_160_; 
v___x_160_ = l_FormalSpecAgent_BatchMachine_advanceAux___redArg(v_model_152_, v_snapshot_153_, v_limit_154_);
return v___x_160_;
}
}
else
{
lean_object* v___x_161_; 
lean_dec(v_limit_154_);
lean_dec_ref(v_snapshot_153_);
lean_dec_ref(v_model_152_);
v___x_161_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_advance___closed__0));
return v___x_161_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_tick(lean_object* v_model_165_, lean_object* v_snapshot_166_, lean_object* v_limit_167_){
_start:
{
lean_object* v___x_168_; 
lean_inc_ref(v_model_165_);
v___x_168_ = l_FormalSpecAgent_BatchMachine_advance(v_model_165_, v_snapshot_166_, v_limit_167_);
if (lean_obj_tag(v___x_168_) == 0)
{
lean_dec_ref(v_model_165_);
return v___x_168_;
}
else
{
lean_object* v_a_169_; lean_object* v_after_170_; uint8_t v___x_171_; 
v_a_169_ = lean_ctor_get(v___x_168_, 0);
lean_inc(v_a_169_);
v_after_170_ = lean_ctor_get(v_a_169_, 0);
lean_inc_ref(v_after_170_);
lean_dec(v_a_169_);
v___x_171_ = l_FormalSpecAgent_TypedMachine_invariantsHold(v_model_165_, v_after_170_);
if (v___x_171_ == 0)
{
lean_object* v___x_172_; 
lean_dec_ref_known(v___x_168_, 1);
v___x_172_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_tick___closed__0));
return v___x_172_;
}
else
{
return v___x_168_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_dispatch(lean_object* v_model_176_, lean_object* v_snapshot_177_, lean_object* v_event_178_, lean_object* v_fields_179_, lean_object* v_limit_180_){
_start:
{
lean_object* v_externalEvents_181_; uint8_t v___x_182_; 
v_externalEvents_181_ = lean_ctor_get(v_model_176_, 3);
v___x_182_ = l_List_elem___at___00Lean_Meta_Occurrences_contains_spec__0(v_event_178_, v_externalEvents_181_);
if (v___x_182_ == 0)
{
lean_object* v___x_183_; 
lean_dec(v_limit_180_);
lean_dec_ref(v_fields_179_);
lean_dec(v_event_178_);
lean_dec_ref(v_snapshot_177_);
lean_dec_ref(v_model_176_);
v___x_183_ = ((lean_object*)(l_FormalSpecAgent_BatchMachine_dispatch___closed__0));
return v___x_183_;
}
else
{
lean_object* v___x_184_; 
lean_inc_ref(v_model_176_);
v___x_184_ = l_FormalSpecAgent_BatchMachine_advance(v_model_176_, v_snapshot_177_, v_limit_180_);
if (lean_obj_tag(v___x_184_) == 0)
{
lean_dec_ref(v_fields_179_);
lean_dec(v_event_178_);
lean_dec_ref(v_model_176_);
return v___x_184_;
}
else
{
lean_object* v_a_185_; lean_object* v_after_186_; lean_object* v_trace_187_; lean_object* v___x_189_; uint8_t v_isShared_190_; uint8_t v_isSharedCheck_216_; 
v_a_185_ = lean_ctor_get(v___x_184_, 0);
lean_inc(v_a_185_);
lean_dec_ref_known(v___x_184_, 1);
v_after_186_ = lean_ctor_get(v_a_185_, 0);
v_trace_187_ = lean_ctor_get(v_a_185_, 1);
v_isSharedCheck_216_ = !lean_is_exclusive(v_a_185_);
if (v_isSharedCheck_216_ == 0)
{
v___x_189_ = v_a_185_;
v_isShared_190_ = v_isSharedCheck_216_;
goto v_resetjp_188_;
}
else
{
lean_inc(v_trace_187_);
lean_inc(v_after_186_);
lean_dec(v_a_185_);
v___x_189_ = lean_box(0);
v_isShared_190_ = v_isSharedCheck_216_;
goto v_resetjp_188_;
}
v_resetjp_188_:
{
lean_object* v_now_191_; lean_object* v___x_192_; 
v_now_191_ = lean_ctor_get(v_after_186_, 2);
lean_inc(v_now_191_);
v___x_192_ = l_FormalSpecAgent_TypedMachine_external(v_model_176_, v_after_186_, v_event_178_, v_fields_179_, v_now_191_);
lean_dec_ref(v_after_186_);
if (lean_obj_tag(v___x_192_) == 0)
{
lean_object* v_a_193_; lean_object* v___x_195_; uint8_t v_isShared_196_; uint8_t v_isSharedCheck_200_; 
lean_del_object(v___x_189_);
lean_dec(v_trace_187_);
v_a_193_ = lean_ctor_get(v___x_192_, 0);
v_isSharedCheck_200_ = !lean_is_exclusive(v___x_192_);
if (v_isSharedCheck_200_ == 0)
{
v___x_195_ = v___x_192_;
v_isShared_196_ = v_isSharedCheck_200_;
goto v_resetjp_194_;
}
else
{
lean_inc(v_a_193_);
lean_dec(v___x_192_);
v___x_195_ = lean_box(0);
v_isShared_196_ = v_isSharedCheck_200_;
goto v_resetjp_194_;
}
v_resetjp_194_:
{
lean_object* v___x_198_; 
if (v_isShared_196_ == 0)
{
v___x_198_ = v___x_195_;
goto v_reusejp_197_;
}
else
{
lean_object* v_reuseFailAlloc_199_; 
v_reuseFailAlloc_199_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_199_, 0, v_a_193_);
v___x_198_ = v_reuseFailAlloc_199_;
goto v_reusejp_197_;
}
v_reusejp_197_:
{
return v___x_198_;
}
}
}
else
{
lean_object* v_a_201_; lean_object* v___x_203_; uint8_t v_isShared_204_; uint8_t v_isSharedCheck_215_; 
v_a_201_ = lean_ctor_get(v___x_192_, 0);
v_isSharedCheck_215_ = !lean_is_exclusive(v___x_192_);
if (v_isSharedCheck_215_ == 0)
{
v___x_203_ = v___x_192_;
v_isShared_204_ = v_isSharedCheck_215_;
goto v_resetjp_202_;
}
else
{
lean_inc(v_a_201_);
lean_dec(v___x_192_);
v___x_203_ = lean_box(0);
v_isShared_204_ = v_isSharedCheck_215_;
goto v_resetjp_202_;
}
v_resetjp_202_:
{
lean_object* v_after_205_; lean_object* v___x_206_; lean_object* v___x_207_; lean_object* v___x_208_; lean_object* v___x_210_; 
v_after_205_ = lean_ctor_get(v_a_201_, 0);
lean_inc_ref(v_after_205_);
v___x_206_ = lean_box(0);
v___x_207_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_207_, 0, v_a_201_);
lean_ctor_set(v___x_207_, 1, v___x_206_);
v___x_208_ = l_List_appendTR___redArg(v_trace_187_, v___x_207_);
if (v_isShared_190_ == 0)
{
lean_ctor_set(v___x_189_, 1, v___x_208_);
lean_ctor_set(v___x_189_, 0, v_after_205_);
v___x_210_ = v___x_189_;
goto v_reusejp_209_;
}
else
{
lean_object* v_reuseFailAlloc_214_; 
v_reuseFailAlloc_214_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_214_, 0, v_after_205_);
lean_ctor_set(v_reuseFailAlloc_214_, 1, v___x_208_);
v___x_210_ = v_reuseFailAlloc_214_;
goto v_reusejp_209_;
}
v_reusejp_209_:
{
lean_object* v___x_212_; 
if (v_isShared_204_ == 0)
{
lean_ctor_set(v___x_203_, 0, v___x_210_);
v___x_212_ = v___x_203_;
goto v_reusejp_211_;
}
else
{
lean_object* v_reuseFailAlloc_213_; 
v_reuseFailAlloc_213_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_213_, 0, v___x_210_);
v___x_212_ = v_reuseFailAlloc_213_;
goto v_reusejp_211_;
}
v_reusejp_211_:
{
return v___x_212_;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback(lean_object* v_initial_217_, lean_object* v_result_218_){
_start:
{
if (lean_obj_tag(v_result_218_) == 0)
{
lean_inc_ref(v_initial_217_);
return v_initial_217_;
}
else
{
lean_object* v_a_219_; lean_object* v_after_220_; 
v_a_219_ = lean_ctor_get(v_result_218_, 0);
v_after_220_ = lean_ctor_get(v_a_219_, 0);
lean_inc_ref(v_after_220_);
return v_after_220_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchMachine_rollback___boxed(lean_object* v_initial_221_, lean_object* v_result_222_){
_start:
{
lean_object* v_res_223_; 
v_res_223_ = l_FormalSpecAgent_BatchMachine_rollback(v_initial_221_, v_result_222_);
lean_dec_ref(v_result_222_);
lean_dec_ref(v_initial_221_);
return v_res_223_;
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter___redArg(lean_object* v_result_224_, lean_object* v_h__1_225_, lean_object* v_h__2_226_){
_start:
{
if (lean_obj_tag(v_result_224_) == 0)
{
lean_object* v_a_227_; lean_object* v___x_228_; 
lean_dec(v_h__1_225_);
v_a_227_ = lean_ctor_get(v_result_224_, 0);
lean_inc(v_a_227_);
lean_dec_ref_known(v_result_224_, 1);
v___x_228_ = lean_apply_1(v_h__2_226_, v_a_227_);
return v___x_228_;
}
else
{
lean_object* v_a_229_; lean_object* v___x_230_; 
lean_dec(v_h__2_226_);
v_a_229_ = lean_ctor_get(v_result_224_, 0);
lean_inc(v_a_229_);
lean_dec_ref_known(v_result_224_, 1);
v___x_230_ = lean_apply_1(v_h__1_225_, v_a_229_);
return v___x_230_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchMachine_0__FormalSpecAgent_BatchMachine_rollback_match__1_splitter(lean_object* v_motive_231_, lean_object* v_result_232_, lean_object* v_h__1_233_, lean_object* v_h__2_234_){
_start:
{
if (lean_obj_tag(v_result_232_) == 0)
{
lean_object* v_a_235_; lean_object* v___x_236_; 
lean_dec(v_h__1_233_);
v_a_235_ = lean_ctor_get(v_result_232_, 0);
lean_inc(v_a_235_);
lean_dec_ref_known(v_result_232_, 1);
v___x_236_ = lean_apply_1(v_h__2_234_, v_a_235_);
return v___x_236_;
}
else
{
lean_object* v_a_237_; lean_object* v___x_238_; 
lean_dec(v_h__2_234_);
v_a_237_ = lean_ctor_get(v_result_232_, 0);
lean_inc(v_a_237_);
lean_dec_ref_known(v_result_232_, 1);
v___x_238_ = lean_apply_1(v_h__1_233_, v_a_237_);
return v___x_238_;
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TimerProgress(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_BatchMachine(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TimerProgress(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
