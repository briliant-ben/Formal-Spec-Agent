// Lean compiler output
// Module: TimerRank
// Imports: public import Init public meta import Init public import TypedMachine
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_List_reverse___redArg(lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* l_Int_toNat(lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_dueCount(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(lean_object* v_s_1_, lean_object* v_a_2_, lean_object* v_a_3_){
_start:
{
if (lean_obj_tag(v_a_2_) == 0)
{
lean_object* v___x_4_; 
v___x_4_ = l_List_reverse___redArg(v_a_3_);
return v___x_4_;
}
else
{
lean_object* v_head_5_; lean_object* v_tail_6_; lean_object* v___x_8_; uint8_t v_isShared_9_; uint8_t v_isSharedCheck_18_; 
v_head_5_ = lean_ctor_get(v_a_2_, 0);
v_tail_6_ = lean_ctor_get(v_a_2_, 1);
v_isSharedCheck_18_ = !lean_is_exclusive(v_a_2_);
if (v_isSharedCheck_18_ == 0)
{
v___x_8_ = v_a_2_;
v_isShared_9_ = v_isSharedCheck_18_;
goto v_resetjp_7_;
}
else
{
lean_inc(v_tail_6_);
lean_inc(v_head_5_);
lean_dec(v_a_2_);
v___x_8_ = lean_box(0);
v_isShared_9_ = v_isSharedCheck_18_;
goto v_resetjp_7_;
}
v_resetjp_7_:
{
lean_object* v_due_10_; lean_object* v_now_11_; uint8_t v___x_12_; 
v_due_10_ = lean_ctor_get(v_head_5_, 1);
v_now_11_ = lean_ctor_get(v_s_1_, 2);
v___x_12_ = lean_int_dec_le(v_due_10_, v_now_11_);
if (v___x_12_ == 0)
{
lean_del_object(v___x_8_);
lean_dec(v_head_5_);
v_a_2_ = v_tail_6_;
goto _start;
}
else
{
lean_object* v___x_15_; 
if (v_isShared_9_ == 0)
{
lean_ctor_set(v___x_8_, 1, v_a_3_);
v___x_15_ = v___x_8_;
goto v_reusejp_14_;
}
else
{
lean_object* v_reuseFailAlloc_17_; 
v_reuseFailAlloc_17_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_17_, 0, v_head_5_);
lean_ctor_set(v_reuseFailAlloc_17_, 1, v_a_3_);
v___x_15_ = v_reuseFailAlloc_17_;
goto v_reusejp_14_;
}
v_reusejp_14_:
{
v_a_2_ = v_tail_6_;
v_a_3_ = v___x_15_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0___boxed(lean_object* v_s_19_, lean_object* v_a_20_, lean_object* v_a_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(v_s_19_, v_a_20_, v_a_21_);
lean_dec_ref(v_s_19_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_dueCount(lean_object* v_s_23_){
_start:
{
lean_object* v_timers_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_27_; 
v_timers_24_ = lean_ctor_get(v_s_23_, 3);
lean_inc(v_timers_24_);
v___x_25_ = lean_box(0);
v___x_26_ = l_List_filterTR_loop___at___00FormalSpecAgent_TimerRank_dueCount_spec__0(v_s_23_, v_timers_24_, v___x_25_);
lean_dec_ref(v_s_23_);
v___x_27_ = l_List_lengthTR___redArg(v___x_26_);
lean_dec(v___x_26_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank(lean_object* v_limit_28_, lean_object* v_s_29_){
_start:
{
lean_object* v_now_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; 
v_now_30_ = lean_ctor_get(v_s_29_, 2);
v___x_31_ = lean_int_sub(v_limit_28_, v_now_30_);
v___x_32_ = l_Int_toNat(v___x_31_);
lean_dec(v___x_31_);
v___x_33_ = l_FormalSpecAgent_TimerRank_dueCount(v_s_29_);
v___x_34_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_34_, 0, v___x_32_);
lean_ctor_set(v___x_34_, 1, v___x_33_);
return v___x_34_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_TimerRank_rank___boxed(lean_object* v_limit_35_, lean_object* v_s_36_){
_start:
{
lean_object* v_res_37_; 
v_res_37_ = l_FormalSpecAgent_TimerRank_rank(v_limit_35_, v_s_36_);
lean_dec(v_limit_35_);
return v_res_37_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_TypedMachine(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_TimerRank(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_TypedMachine(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
