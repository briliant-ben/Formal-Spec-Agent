// Lean compiler output
// Module: BatchReplay
// Imports: public import Init public meta import Init public import BatchMachine
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchReplay_prepend(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchReplay_prepend_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchReplay_prepend_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_dispatch_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_dispatch_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_BatchReplay_prepend(lean_object* v_transition_1_, lean_object* v_rest_2_){
_start:
{
if (lean_obj_tag(v_rest_2_) == 0)
{
lean_dec_ref(v_transition_1_);
return v_rest_2_;
}
else
{
lean_object* v_a_3_; lean_object* v___x_5_; uint8_t v_isShared_6_; uint8_t v_isSharedCheck_20_; 
v_a_3_ = lean_ctor_get(v_rest_2_, 0);
v_isSharedCheck_20_ = !lean_is_exclusive(v_rest_2_);
if (v_isSharedCheck_20_ == 0)
{
v___x_5_ = v_rest_2_;
v_isShared_6_ = v_isSharedCheck_20_;
goto v_resetjp_4_;
}
else
{
lean_inc(v_a_3_);
lean_dec(v_rest_2_);
v___x_5_ = lean_box(0);
v_isShared_6_ = v_isSharedCheck_20_;
goto v_resetjp_4_;
}
v_resetjp_4_:
{
lean_object* v_after_7_; lean_object* v_trace_8_; lean_object* v___x_10_; uint8_t v_isShared_11_; uint8_t v_isSharedCheck_19_; 
v_after_7_ = lean_ctor_get(v_a_3_, 0);
v_trace_8_ = lean_ctor_get(v_a_3_, 1);
v_isSharedCheck_19_ = !lean_is_exclusive(v_a_3_);
if (v_isSharedCheck_19_ == 0)
{
v___x_10_ = v_a_3_;
v_isShared_11_ = v_isSharedCheck_19_;
goto v_resetjp_9_;
}
else
{
lean_inc(v_trace_8_);
lean_inc(v_after_7_);
lean_dec(v_a_3_);
v___x_10_ = lean_box(0);
v_isShared_11_ = v_isSharedCheck_19_;
goto v_resetjp_9_;
}
v_resetjp_9_:
{
lean_object* v___x_12_; lean_object* v___x_14_; 
v___x_12_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_12_, 0, v_transition_1_);
lean_ctor_set(v___x_12_, 1, v_trace_8_);
if (v_isShared_11_ == 0)
{
lean_ctor_set(v___x_10_, 1, v___x_12_);
v___x_14_ = v___x_10_;
goto v_reusejp_13_;
}
else
{
lean_object* v_reuseFailAlloc_18_; 
v_reuseFailAlloc_18_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_18_, 0, v_after_7_);
lean_ctor_set(v_reuseFailAlloc_18_, 1, v___x_12_);
v___x_14_ = v_reuseFailAlloc_18_;
goto v_reusejp_13_;
}
v_reusejp_13_:
{
lean_object* v___x_16_; 
if (v_isShared_6_ == 0)
{
lean_ctor_set(v___x_5_, 0, v___x_14_);
v___x_16_ = v___x_5_;
goto v_reusejp_15_;
}
else
{
lean_object* v_reuseFailAlloc_17_; 
v_reuseFailAlloc_17_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_17_, 0, v___x_14_);
v___x_16_ = v_reuseFailAlloc_17_;
goto v_reusejp_15_;
}
v_reusejp_15_:
{
return v___x_16_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter___redArg(lean_object* v_x_21_, lean_object* v_h__1_22_, lean_object* v_h__2_23_){
_start:
{
if (lean_obj_tag(v_x_21_) == 0)
{
lean_object* v___x_24_; 
lean_dec(v_h__2_23_);
v___x_24_ = lean_apply_1(v_h__1_22_, lean_box(0));
return v___x_24_;
}
else
{
lean_object* v_val_25_; lean_object* v___x_26_; 
lean_dec(v_h__1_22_);
v_val_25_ = lean_ctor_get(v_x_21_, 0);
lean_inc(v_val_25_);
lean_dec_ref_known(v_x_21_, 1);
v___x_26_ = lean_apply_2(v_h__2_23_, v_val_25_, lean_box(0));
return v___x_26_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__5_splitter(lean_object* v_motive_27_, lean_object* v_x_28_, lean_object* v_h__1_29_, lean_object* v_h__2_30_){
_start:
{
if (lean_obj_tag(v_x_28_) == 0)
{
lean_object* v___x_31_; 
lean_dec(v_h__2_30_);
v___x_31_ = lean_apply_1(v_h__1_29_, lean_box(0));
return v___x_31_;
}
else
{
lean_object* v_val_32_; lean_object* v___x_33_; 
lean_dec(v_h__1_29_);
v_val_32_ = lean_ctor_get(v_x_28_, 0);
lean_inc(v_val_32_);
lean_dec_ref_known(v_x_28_, 1);
v___x_33_ = lean_apply_2(v_h__2_30_, v_val_32_, lean_box(0));
return v___x_33_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter___redArg(lean_object* v_x_34_, lean_object* v_h__1_35_, lean_object* v_h__2_36_){
_start:
{
if (lean_obj_tag(v_x_34_) == 0)
{
lean_object* v_a_37_; lean_object* v___x_38_; 
lean_dec(v_h__2_36_);
v_a_37_ = lean_ctor_get(v_x_34_, 0);
lean_inc(v_a_37_);
lean_dec_ref_known(v_x_34_, 1);
v___x_38_ = lean_apply_2(v_h__1_35_, v_a_37_, lean_box(0));
return v___x_38_;
}
else
{
lean_object* v_a_39_; lean_object* v___x_40_; 
lean_dec(v_h__1_35_);
v_a_39_ = lean_ctor_get(v_x_34_, 0);
lean_inc(v_a_39_);
lean_dec_ref_known(v_x_34_, 1);
v___x_40_ = lean_apply_2(v_h__2_36_, v_a_39_, lean_box(0));
return v___x_40_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__3_splitter(lean_object* v_motive_41_, lean_object* v_x_42_, lean_object* v_h__1_43_, lean_object* v_h__2_44_){
_start:
{
if (lean_obj_tag(v_x_42_) == 0)
{
lean_object* v_a_45_; lean_object* v___x_46_; 
lean_dec(v_h__2_44_);
v_a_45_ = lean_ctor_get(v_x_42_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v_x_42_, 1);
v___x_46_ = lean_apply_2(v_h__1_43_, v_a_45_, lean_box(0));
return v___x_46_;
}
else
{
lean_object* v_a_47_; lean_object* v___x_48_; 
lean_dec(v_h__1_43_);
v_a_47_ = lean_ctor_get(v_x_42_, 0);
lean_inc(v_a_47_);
lean_dec_ref_known(v_x_42_, 1);
v___x_48_ = lean_apply_2(v_h__2_44_, v_a_47_, lean_box(0));
return v___x_48_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter___redArg(lean_object* v_x_49_, lean_object* v_h__1_50_, lean_object* v_h__2_51_){
_start:
{
if (lean_obj_tag(v_x_49_) == 0)
{
lean_object* v_a_52_; lean_object* v___x_53_; 
lean_dec(v_h__2_51_);
v_a_52_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_52_);
lean_dec_ref_known(v_x_49_, 1);
v___x_53_ = lean_apply_1(v_h__1_50_, v_a_52_);
return v___x_53_;
}
else
{
lean_object* v_a_54_; lean_object* v___x_55_; 
lean_dec(v_h__1_50_);
v_a_54_ = lean_ctor_get(v_x_49_, 0);
lean_inc(v_a_54_);
lean_dec_ref_known(v_x_49_, 1);
v___x_55_ = lean_apply_1(v_h__2_51_, v_a_54_);
return v___x_55_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_advanceAux_match__1_splitter(lean_object* v_motive_56_, lean_object* v_x_57_, lean_object* v_h__1_58_, lean_object* v_h__2_59_){
_start:
{
if (lean_obj_tag(v_x_57_) == 0)
{
lean_object* v_a_60_; lean_object* v___x_61_; 
lean_dec(v_h__2_59_);
v_a_60_ = lean_ctor_get(v_x_57_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v_x_57_, 1);
v___x_61_ = lean_apply_1(v_h__1_58_, v_a_60_);
return v___x_61_;
}
else
{
lean_object* v_a_62_; lean_object* v___x_63_; 
lean_dec(v_h__1_58_);
v_a_62_ = lean_ctor_get(v_x_57_, 0);
lean_inc(v_a_62_);
lean_dec_ref_known(v_x_57_, 1);
v___x_63_ = lean_apply_1(v_h__2_59_, v_a_62_);
return v___x_63_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchReplay_prepend_match__1_splitter___redArg(lean_object* v_rest_64_, lean_object* v_h__1_65_, lean_object* v_h__2_66_){
_start:
{
if (lean_obj_tag(v_rest_64_) == 0)
{
lean_object* v_a_67_; lean_object* v___x_68_; 
lean_dec(v_h__2_66_);
v_a_67_ = lean_ctor_get(v_rest_64_, 0);
lean_inc(v_a_67_);
lean_dec_ref_known(v_rest_64_, 1);
v___x_68_ = lean_apply_1(v_h__1_65_, v_a_67_);
return v___x_68_;
}
else
{
lean_object* v_a_69_; lean_object* v___x_70_; 
lean_dec(v_h__1_65_);
v_a_69_ = lean_ctor_get(v_rest_64_, 0);
lean_inc(v_a_69_);
lean_dec_ref_known(v_rest_64_, 1);
v___x_70_ = lean_apply_1(v_h__2_66_, v_a_69_);
return v___x_70_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchReplay_prepend_match__1_splitter(lean_object* v_motive_71_, lean_object* v_rest_72_, lean_object* v_h__1_73_, lean_object* v_h__2_74_){
_start:
{
if (lean_obj_tag(v_rest_72_) == 0)
{
lean_object* v_a_75_; lean_object* v___x_76_; 
lean_dec(v_h__2_74_);
v_a_75_ = lean_ctor_get(v_rest_72_, 0);
lean_inc(v_a_75_);
lean_dec_ref_known(v_rest_72_, 1);
v___x_76_ = lean_apply_1(v_h__1_73_, v_a_75_);
return v___x_76_;
}
else
{
lean_object* v_a_77_; lean_object* v___x_78_; 
lean_dec(v_h__1_73_);
v_a_77_ = lean_ctor_get(v_rest_72_, 0);
lean_inc(v_a_77_);
lean_dec_ref_known(v_rest_72_, 1);
v___x_78_ = lean_apply_1(v_h__2_74_, v_a_77_);
return v___x_78_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_dispatch_match__1_splitter___redArg(lean_object* v_x_79_, lean_object* v_h__1_80_, lean_object* v_h__2_81_){
_start:
{
if (lean_obj_tag(v_x_79_) == 0)
{
lean_object* v_a_82_; lean_object* v___x_83_; 
lean_dec(v_h__2_81_);
v_a_82_ = lean_ctor_get(v_x_79_, 0);
lean_inc(v_a_82_);
lean_dec_ref_known(v_x_79_, 1);
v___x_83_ = lean_apply_1(v_h__1_80_, v_a_82_);
return v___x_83_;
}
else
{
lean_object* v_a_84_; lean_object* v___x_85_; 
lean_dec(v_h__1_80_);
v_a_84_ = lean_ctor_get(v_x_79_, 0);
lean_inc(v_a_84_);
lean_dec_ref_known(v_x_79_, 1);
v___x_85_ = lean_apply_1(v_h__2_81_, v_a_84_);
return v___x_85_;
}
}
}
LEAN_EXPORT lean_object* l___private_BatchReplay_0__FormalSpecAgent_BatchMachine_dispatch_match__1_splitter(lean_object* v_motive_86_, lean_object* v_x_87_, lean_object* v_h__1_88_, lean_object* v_h__2_89_){
_start:
{
if (lean_obj_tag(v_x_87_) == 0)
{
lean_object* v_a_90_; lean_object* v___x_91_; 
lean_dec(v_h__2_89_);
v_a_90_ = lean_ctor_get(v_x_87_, 0);
lean_inc(v_a_90_);
lean_dec_ref_known(v_x_87_, 1);
v___x_91_ = lean_apply_1(v_h__1_88_, v_a_90_);
return v___x_91_;
}
else
{
lean_object* v_a_92_; lean_object* v___x_93_; 
lean_dec(v_h__1_88_);
v_a_92_ = lean_ctor_get(v_x_87_, 0);
lean_inc(v_a_92_);
lean_dec_ref_known(v_x_87_, 1);
v___x_93_ = lean_apply_1(v_h__2_89_, v_a_92_);
return v___x_93_;
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_BatchMachine(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_BatchReplay(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_BatchMachine(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
