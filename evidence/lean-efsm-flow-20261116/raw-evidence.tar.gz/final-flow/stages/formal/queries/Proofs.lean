import Approved

namespace Proofs

theorem initial_valid : Approved.initial_valid := by
  unfold Approved.initial_valid
  decide

theorem preserve_0 : Approved.preserve_0 := by
  unfold Approved.preserve_0
  intro v0 f0 Hinv Hguard
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem preserve_1 : Approved.preserve_1 := by
  unfold Approved.preserve_1
  intro v0 f0 Hinv Hguard
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem preserve_2 : Approved.preserve_2 := by
  unfold Approved.preserve_2
  intro v0 f0 Hinv Hguard
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem preserve_3 : Approved.preserve_3 := by
  unfold Approved.preserve_3
  intro v0 f0 Hinv Hguard
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem preserve_4 : Approved.preserve_4 := by
  unfold Approved.preserve_4
  intro v0 Hinv Hguard
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem preserve_5 : Approved.preserve_5 := by
  unfold Approved.preserve_5
  intro v0 Hinv Hguard
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem overlap_0_1 : Approved.overlap_0_1 := by
  unfold Approved.overlap_0_1
  intro v0 f0 Hinv
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem overlap_2_3 : Approved.overlap_2_3 := by
  unfold Approved.overlap_2_3
  intro v0 f0 Hinv
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem cover_0_0 : Approved.cover_0_0 := by
  unfold Approved.cover_0_0
  intro v0 f0 Hinv
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem cover_0_1 : Approved.cover_0_1 := by
  unfold Approved.cover_0_1
  intro v0 Hinv
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem cover_1_0 : Approved.cover_1_0 := by
  unfold Approved.cover_1_0
  intro v0 f0 Hinv
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem cover_1_1 : Approved.cover_1_1 := by
  unfold Approved.cover_1_1
  intro v0 Hinv
  simp_all [Approved.invariants, Approved.rule_0, Approved.rule_1, Approved.rule_2, Approved.rule_3, Approved.rule_4, Approved.rule_5, FormalSpecAgent.EfsmSubset.invariantsHold, FormalSpecAgent.EfsmSubset.guardHolds, FormalSpecAgent.EfsmSubset.evalPredicate, FormalSpecAgent.EfsmSubset.covered, FormalSpecAgent.StateSubset.work, FormalSpecAgent.StateSubset.evalInteger]
  all_goals
    omega

theorem live_0 : Approved.live_0 := by
  unfold Approved.live_0
  decide

theorem live_1 : Approved.live_1 := by
  unfold Approved.live_1
  decide

theorem live_2 : Approved.live_2 := by
  unfold Approved.live_2
  decide

theorem live_3 : Approved.live_3 := by
  unfold Approved.live_3
  decide

theorem live_4 : Approved.live_4 := by
  unfold Approved.live_4
  decide

theorem live_5 : Approved.live_5 := by
  unfold Approved.live_5
  decide

theorem witness_0 : Approved.witness_0 := by
  unfold Approved.witness_0
  decide

theorem witness_1 : Approved.witness_1 := by
  unfold Approved.witness_1
  decide

theorem witness_2 : Approved.witness_2 := by
  unfold Approved.witness_2
  decide

theorem witness_3 : Approved.witness_3 := by
  unfold Approved.witness_3
  decide

theorem witness_4 : Approved.witness_4 := by
  unfold Approved.witness_4
  decide

theorem witness_5 : Approved.witness_5 := by
  unfold Approved.witness_5
  decide

end Proofs
