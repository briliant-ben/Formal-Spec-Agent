import Proofs

example : Approved.initial_valid := Proofs.initial_valid
#print axioms Proofs.initial_valid
example : Approved.preserve_0 := Proofs.preserve_0
#print axioms Proofs.preserve_0
example : Approved.preserve_1 := Proofs.preserve_1
#print axioms Proofs.preserve_1
example : Approved.preserve_2 := Proofs.preserve_2
#print axioms Proofs.preserve_2
example : Approved.preserve_3 := Proofs.preserve_3
#print axioms Proofs.preserve_3
example : Approved.preserve_4 := Proofs.preserve_4
#print axioms Proofs.preserve_4
example : Approved.preserve_5 := Proofs.preserve_5
#print axioms Proofs.preserve_5
example : Approved.overlap_0_1 := Proofs.overlap_0_1
#print axioms Proofs.overlap_0_1
example : Approved.overlap_2_3 := Proofs.overlap_2_3
#print axioms Proofs.overlap_2_3
example : Approved.cover_0_0 := Proofs.cover_0_0
#print axioms Proofs.cover_0_0
example : Approved.cover_0_1 := Proofs.cover_0_1
#print axioms Proofs.cover_0_1
example : Approved.cover_1_0 := Proofs.cover_1_0
#print axioms Proofs.cover_1_0
example : Approved.cover_1_1 := Proofs.cover_1_1
#print axioms Proofs.cover_1_1
example : Approved.live_0 := Proofs.live_0
#print axioms Proofs.live_0
example : Approved.live_1 := Proofs.live_1
#print axioms Proofs.live_1
example : Approved.live_2 := Proofs.live_2
#print axioms Proofs.live_2
example : Approved.live_3 := Proofs.live_3
#print axioms Proofs.live_3
example : Approved.live_4 := Proofs.live_4
#print axioms Proofs.live_4
example : Approved.live_5 := Proofs.live_5
#print axioms Proofs.live_5
example : Approved.witness_0 := Proofs.witness_0
#print axioms Proofs.witness_0
example : Approved.witness_1 := Proofs.witness_1
#print axioms Proofs.witness_1
example : Approved.witness_2 := Proofs.witness_2
#print axioms Proofs.witness_2
example : Approved.witness_3 := Proofs.witness_3
#print axioms Proofs.witness_3
example : Approved.witness_4 := Proofs.witness_4
#print axioms Proofs.witness_4
example : Approved.witness_5 := Proofs.witness_5
#print axioms Proofs.witness_5
