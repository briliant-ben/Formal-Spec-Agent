import EfsmSubset

namespace Approved

def invariants : List FormalSpecAgent.EfsmSubset.Predicate :=
  [(FormalSpecAgent.EfsmSubset.Predicate.disjunction (FormalSpecAgent.EfsmSubset.Predicate.conjunction (FormalSpecAgent.EfsmSubset.Predicate.atState 0) (FormalSpecAgent.EfsmSubset.Predicate.equal (FormalSpecAgent.StateSubset.IntegerExpr.variable 0) (FormalSpecAgent.StateSubset.IntegerExpr.literal (0)))) (FormalSpecAgent.EfsmSubset.Predicate.conjunction (FormalSpecAgent.EfsmSubset.Predicate.atState 1) (FormalSpecAgent.EfsmSubset.Predicate.conjunction (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.literal (1)) (FormalSpecAgent.StateSubset.IntegerExpr.variable 0)) (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.variable 0) (FormalSpecAgent.StateSubset.IntegerExpr.literal (255))))))]

def rule_0 : FormalSpecAgent.EfsmSubset.Rule :=
  { source := 0, target := 1, event := 0, guard := (FormalSpecAgent.EfsmSubset.Predicate.conjunction (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.literal (1)) (FormalSpecAgent.StateSubset.IntegerExpr.field 0)) (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.field 0) (FormalSpecAgent.StateSubset.IntegerExpr.literal (255)))), actions := [(FormalSpecAgent.StateSubset.Action.assign 0 (FormalSpecAgent.StateSubset.IntegerExpr.field 0)), (FormalSpecAgent.StateSubset.Action.emit 0 (FormalSpecAgent.StateSubset.IntegerExpr.field 0))] }

def rule_1 : FormalSpecAgent.EfsmSubset.Rule :=
  { source := 0, target := 0, event := 0, guard := (FormalSpecAgent.EfsmSubset.Predicate.negation (FormalSpecAgent.EfsmSubset.Predicate.conjunction (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.literal (1)) (FormalSpecAgent.StateSubset.IntegerExpr.field 0)) (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.field 0) (FormalSpecAgent.StateSubset.IntegerExpr.literal (255))))), actions := [(FormalSpecAgent.StateSubset.Action.emit 1 (FormalSpecAgent.StateSubset.IntegerExpr.field 0))] }

def rule_2 : FormalSpecAgent.EfsmSubset.Rule :=
  { source := 1, target := 1, event := 0, guard := (FormalSpecAgent.EfsmSubset.Predicate.conjunction (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.literal (1)) (FormalSpecAgent.StateSubset.IntegerExpr.field 0)) (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.field 0) (FormalSpecAgent.StateSubset.IntegerExpr.literal (255)))), actions := [(FormalSpecAgent.StateSubset.Action.assign 0 (FormalSpecAgent.StateSubset.IntegerExpr.field 0)), (FormalSpecAgent.StateSubset.Action.emit 0 (FormalSpecAgent.StateSubset.IntegerExpr.field 0))] }

def rule_3 : FormalSpecAgent.EfsmSubset.Rule :=
  { source := 1, target := 1, event := 0, guard := (FormalSpecAgent.EfsmSubset.Predicate.negation (FormalSpecAgent.EfsmSubset.Predicate.conjunction (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.literal (1)) (FormalSpecAgent.StateSubset.IntegerExpr.field 0)) (FormalSpecAgent.EfsmSubset.Predicate.lessEqual (FormalSpecAgent.StateSubset.IntegerExpr.field 0) (FormalSpecAgent.StateSubset.IntegerExpr.literal (255))))), actions := [(FormalSpecAgent.StateSubset.Action.emit 1 (FormalSpecAgent.StateSubset.IntegerExpr.field 0))] }

def rule_4 : FormalSpecAgent.EfsmSubset.Rule :=
  { source := 0, target := 0, event := 1, guard := (FormalSpecAgent.EfsmSubset.Predicate.literal true), actions := [(FormalSpecAgent.StateSubset.Action.emit 3 (FormalSpecAgent.StateSubset.IntegerExpr.variable 0))] }

def rule_5 : FormalSpecAgent.EfsmSubset.Rule :=
  { source := 1, target := 0, event := 1, guard := (FormalSpecAgent.EfsmSubset.Predicate.literal true), actions := [(FormalSpecAgent.StateSubset.Action.emit 2 (FormalSpecAgent.StateSubset.IntegerExpr.variable 0)), (FormalSpecAgent.StateSubset.Action.assign 0 (FormalSpecAgent.StateSubset.IntegerExpr.literal (0)))] }

def rules : List FormalSpecAgent.EfsmSubset.Rule := [rule_0, rule_1, rule_2, rule_3, rule_4, rule_5]

def initial_valid : Prop :=
  FormalSpecAgent.EfsmSubset.invariantsHold invariants 0 [(0)] = true

def preserve_0 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_0.source [v0] = true → FormalSpecAgent.EfsmSubset.guardHolds rule_0 [v0] [f0] = true → FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_0.target (FormalSpecAgent.StateSubset.work rule_0.actions [v0] [f0] []).1 = true

def preserve_1 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_1.source [v0] = true → FormalSpecAgent.EfsmSubset.guardHolds rule_1 [v0] [f0] = true → FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_1.target (FormalSpecAgent.StateSubset.work rule_1.actions [v0] [f0] []).1 = true

def preserve_2 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_2.source [v0] = true → FormalSpecAgent.EfsmSubset.guardHolds rule_2 [v0] [f0] = true → FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_2.target (FormalSpecAgent.StateSubset.work rule_2.actions [v0] [f0] []).1 = true

def preserve_3 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_3.source [v0] = true → FormalSpecAgent.EfsmSubset.guardHolds rule_3 [v0] [f0] = true → FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_3.target (FormalSpecAgent.StateSubset.work rule_3.actions [v0] [f0] []).1 = true

def preserve_4 : Prop :=
  ∀ (v0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_4.source [v0] = true → FormalSpecAgent.EfsmSubset.guardHolds rule_4 [v0] [] = true → FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_4.target (FormalSpecAgent.StateSubset.work rule_4.actions [v0] [] []).1 = true

def preserve_5 : Prop :=
  ∀ (v0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_5.source [v0] = true → FormalSpecAgent.EfsmSubset.guardHolds rule_5 [v0] [] = true → FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_5.target (FormalSpecAgent.StateSubset.work rule_5.actions [v0] [] []).1 = true

def overlap_0_1 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_0.source [v0] = true → ¬ (FormalSpecAgent.EfsmSubset.guardHolds rule_0 [v0] [f0] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_1 [v0] [f0] = true)

def overlap_2_3 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_2.source [v0] = true → ¬ (FormalSpecAgent.EfsmSubset.guardHolds rule_2 [v0] [f0] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_3 [v0] [f0] = true)

def cover_0_0 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants 0 [v0] = true → FormalSpecAgent.EfsmSubset.covered [rule_0.guard, rule_1.guard] 0 [v0] [f0] = true

def cover_0_1 : Prop :=
  ∀ (v0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants 0 [v0] = true → FormalSpecAgent.EfsmSubset.covered [rule_4.guard] 0 [v0] [] = true

def cover_1_0 : Prop :=
  ∀ (v0 : Int) (f0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants 1 [v0] = true → FormalSpecAgent.EfsmSubset.covered [rule_2.guard, rule_3.guard] 1 [v0] [f0] = true

def cover_1_1 : Prop :=
  ∀ (v0 : Int), FormalSpecAgent.EfsmSubset.invariantsHold invariants 1 [v0] = true → FormalSpecAgent.EfsmSubset.covered [rule_5.guard] 1 [v0] [] = true

def live_0 : Prop :=
  FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_0.source [(0)] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_0 [(0)] [(65)] = true

def live_1 : Prop :=
  FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_1.source [(0)] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_1 [(0)] [(0)] = true

def live_2 : Prop :=
  FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_2.source [(65)] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_2 [(65)] [(255)] = true

def live_3 : Prop :=
  FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_3.source [(65)] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_3 [(65)] [(256)] = true

def live_4 : Prop :=
  FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_4.source [(0)] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_4 [(0)] [] = true

def live_5 : Prop :=
  FormalSpecAgent.EfsmSubset.invariantsHold invariants rule_5.source [(65)] = true ∧ FormalSpecAgent.EfsmSubset.guardHolds rule_5 [(65)] [] = true

def witness_0 : Prop :=
  FormalSpecAgent.EfsmSubset.candidate rule_0 [(0)] [(65)] = (1, ([(65)], [(0, (65))]))

def witness_1 : Prop :=
  FormalSpecAgent.EfsmSubset.candidate rule_1 [(0)] [(0)] = (0, ([(0)], [(1, (0))]))

def witness_2 : Prop :=
  FormalSpecAgent.EfsmSubset.candidate rule_2 [(65)] [(255)] = (1, ([(255)], [(0, (255))]))

def witness_3 : Prop :=
  FormalSpecAgent.EfsmSubset.candidate rule_3 [(65)] [(256)] = (1, ([(65)], [(1, (256))]))

def witness_4 : Prop :=
  FormalSpecAgent.EfsmSubset.candidate rule_4 [(0)] [] = (0, ([(0)], [(3, (0))]))

def witness_5 : Prop :=
  FormalSpecAgent.EfsmSubset.candidate rule_5 [(65)] [] = (0, ([(0)], [(2, (65))]))

end Approved
