import Foundation
namespace CompileWaveTest
theorem alpha (n : Nat) : n = n := rfl
end CompileWaveTest
