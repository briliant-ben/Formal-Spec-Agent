import Foundation
theorem rejectedWave : False := by rfl
