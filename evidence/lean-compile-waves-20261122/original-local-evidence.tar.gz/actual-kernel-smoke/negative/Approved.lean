import BatchObserve
import TimedObligations

set_option maxRecDepth 16384

namespace Approved

def e0 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.literal .octets ([] : FormalSpecAgent.Bytes)

def e1 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.field .octets 0

def e2 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e1

def e3 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.literal .integer (8)

def e4 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e2 e3

def e5 : FormalSpecAgent.TypedIR.Expr .octets :=
  FormalSpecAgent.TypedIR.Expr.variable .octets 0

def e6 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.literal .boolean true

def e7 : FormalSpecAgent.TypedIR.Expr .integer :=
  FormalSpecAgent.TypedIR.Expr.bytesLength e5

def e8 : FormalSpecAgent.TypedIR.Expr .boolean :=
  FormalSpecAgent.TypedIR.Expr.intLe e7 e3

def rule_0 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 0, source := 0, target := 0, event := 0, guard := e4, actions := [FormalSpecAgent.TypedMachine.Action.assign .octets 0 e1, FormalSpecAgent.TypedMachine.Action.emit 0 [⟨0, .octets, e5⟩]] }

def rule_1 : FormalSpecAgent.TypedMachine.Rule :=
  { id := 1, source := 0, target := 0, event := 1, guard := e6, actions := [FormalSpecAgent.TypedMachine.Action.assign .octets 0 e0] }

def schema : List (FormalSpecAgent.TypedIR.Kind × Nat) := [(.octets, 0)]

def model : FormalSpecAgent.TypedMachine.Model :=
  { rules := [rule_0, rule_1], invariants := [e8], timerEvents := fun n => 0, externalEvents := [0, 1] }

def eventSchemas (n : Nat) : List (FormalSpecAgent.TypedIR.Kind × Nat) := if n = 0 then [(.octets, 0)] else if n = 1 then [] else []

theorem model_rules : model.rules = [rule_0, rule_1] := rfl

theorem model_invariants : model.invariants = [e8] := rfl

theorem model_external_events : model.externalEvents = [0, 1] := rfl

theorem model_timer_event (n : Nat) : model.timerEvents n = 0 := rfl

def initial : FormalSpecAgent.TypedMachine.Snapshot := ({ values := ({ integers := fun n => (0), booleans := fun n => false, texts := fun n => (String.ofList []), buffers := fun n => if n = 0 then ([] : FormalSpecAgent.Bytes) else ([] : FormalSpecAgent.Bytes), sequences := fun n => (⟨0, by decide⟩ : FormalSpecAgent.ValueOps.Seq32) } : FormalSpecAgent.TypedIR.Values), state := 0, now := (0), timers := [] } : FormalSpecAgent.TypedMachine.Snapshot)
def declaredStates : List Nat := [0]
def declaredTimers : List Nat := []

def conflictGroup_0 : List FormalSpecAgent.TypedMachine.Rule := [rule_0]

def conflictGroup_1 : List FormalSpecAgent.TypedMachine.Rule := [rule_1]

def rawCatalog : List (FormalSpecAgent.TypedMachine.Rule × Option Nat) := [(rule_0, none), (rule_1, none)]

def conflictCatalog : List (List FormalSpecAgent.TypedMachine.Rule) := [conflictGroup_0, conflictGroup_1]
def initial_admitted : Prop := FormalSpecAgent.BatchTotality.Admitted model declaredStates declaredTimers initial
def targets_declared : Prop := FormalSpecAgent.BatchTotality.TargetsDeclared model declaredStates
def arms_declared : Prop := FormalSpecAgent.TimerDomain.ArmsDeclared declaredTimers model
def rule_ids_unique : Prop := (model.rules.map FormalSpecAgent.TypedMachine.Rule.id).Nodup
def timer_coverage : Prop := FormalSpecAgent.TimedSelection.CoversTimers model declaredStates declaredTimers
def external_coverage : Prop := FormalSpecAgent.TypedContracts.Covers model declaredStates
def raw_0_external : Prop := FormalSpecAgent.TypedFiringContracts.FiringPreserves model rule_0 none
def raw_1_external : Prop := FormalSpecAgent.TypedFiringContracts.FiringPreserves model rule_1 none
def conflict_0 : Prop := FormalSpecAgent.TimedObligations.ConflictFree model conflictGroup_0
def conflict_1 : Prop := FormalSpecAgent.TimedObligations.ConflictFree model conflictGroup_1
def raw_catalog_exact : Prop := FormalSpecAgent.TimedObligations.rawChecks model declaredTimers = rawCatalog
def conflict_catalog_exact : Prop := FormalSpecAgent.TimedObligations.conflictChecks model = conflictCatalog

end Approved
