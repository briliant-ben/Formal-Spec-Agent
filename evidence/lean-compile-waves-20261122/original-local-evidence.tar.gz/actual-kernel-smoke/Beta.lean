import Foundation
namespace CompileWaveTest
theorem beta (n : Nat) : n = n := rfl
end CompileWaveTest
