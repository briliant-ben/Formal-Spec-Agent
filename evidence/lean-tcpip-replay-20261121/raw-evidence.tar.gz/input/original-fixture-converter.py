import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

def canonical(value):
    return (json.dumps(value, indent=2) + '\n').encode()

archive = Path('../TCPIP-Model/artifacts/ipv4-prototype-final-9289/linux-peer-original.zip')
def digest(contents):
    return hashlib.sha256(contents).hexdigest()

with ZipFile(archive) as z:
    paths = ('live/scenario.json','live/native/session.json','live/native/native.stdout',
             'verification/difference.json','live/capture.pcap')
    raw = {path: z.read(path) for path in paths}
scenario = json.loads(raw[paths[0]])
session = json.loads(raw[paths[1]])
observed = [json.loads(line) for line in raw[paths[2]].splitlines()]
report = json.loads(raw[paths[3]])
assert report['status'] == 'pass' and report['data']['observed'] == observed
assert session['process_starts'] == 1 and session['returncode'] == 0
assert len(session['operations']) == 1 + len(scenario['steps'])
assert session['operations'][0]['line'].strip() == 'B' and observed[0]['status'] == 'ready'
initial = dict(observed[0]['snapshot'], now_ms=0)
steps = []
for cmd, op in zip(scenario['steps'], session['operations'][1:], strict=True):
    assert op['pid'] == session['pid']
    parsed = op['line'].strip().split()
    assert parsed[:3] == ['D', str(cmd['at_ms']), cmd['event']]
    rows = observed[op['row_start']:op['row_end']]
    assert rows[-1]['status'] == 'ok' and all(row['status'] == 'transition' for row in rows[:-1])
    trace = [dict(rule=row['transition'], event=row['event'], at_ms=row['time_ms'],
                  after=dict(row['after'], now_ms=row['time_ms']), emitted=row['emitted'])
             for row in rows[:-1]]
    after = dict(rows[-1]['snapshot'], now_ms=cmd['at_ms'])
    assert trace and trace[-1]['after'] == after
    assert trace[-1]['event'] == {'name':cmd['event'],'fields':cmd['fields']}
    steps.append(dict(kind='dispatch', **cmd, expected=dict(status='ok',after=after,trace=trace)))
assert len(steps) == 19 and sum(len(step['expected']['trace']) for step in steps) == 19
fixture = canonical([dict(id='linux-peer-composed-92896425',initial=initial,steps=steps)])
Path('/tmp/fsa-tcpip-input/peer-replay-9289.json').write_bytes(fixture)
receipt = dict(archive_sha256=digest(archive.read_bytes()),
               original_members={path:digest(content) for path,content in raw.items()},
               case_sha256=digest(fixture),operations=len(steps),
               observed_transitions=sum(len(step['expected']['trace']) for step in steps))
Path('/tmp/fsa-tcpip-input/peer-replay-9289-provenance.json').write_bytes(canonical(receipt))
print(json.dumps(receipt))
