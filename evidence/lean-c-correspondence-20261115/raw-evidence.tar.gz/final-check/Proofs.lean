import Approved

namespace Proofs

theorem read_model_equivalent : Approved.read_model_equivalent := by
  unfold Approved.read_model_equivalent
  intro xs i
  unfold FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  split
  ·
    simp_all
  ·
    split
    ·
      simp_all [List.getD_eq_getElem?_getD, List.getElem?_eq_none]
    ·
      simp_all

theorem valid_index_bound : Approved.valid_index_bound := by
  unfold Approved.valid_index_bound
  intro len i hn hlt
  exact (Int.toNat_lt hn).mpr hlt

theorem lowering_correct : Approved.lowering_correct := by
  unfold Approved.lowering_correct
  intro k e ctx
  have hread := Proofs.read_model_equivalent
  unfold Approved.read_model_equivalent at hread
  induction e
  all_goals
    simp_all [FormalSpecAgent.CSubset.lower, FormalSpecAgent.CSubset.evalC, FormalSpecAgent.CSubset.evalIR]

theorem actual_lowering : Approved.actual_lowering := by
  unfold Approved.actual_lowering
  rfl

theorem actual_refines : Approved.actual_refines := by
  intro ctx hctx
  have hmatch := Proofs.actual_lowering
  unfold Approved.actual_lowering at hmatch
  have hcorrect := Proofs.lowering_correct FormalSpecAgent.CSubset.Kind.integer Approved.originalIR ctx
  exact Eq.trans (congrArg (fun e => FormalSpecAgent.CSubset.evalC e ctx) hmatch) hcorrect

theorem native_context_witness : Approved.native_context_witness := by
  unfold Approved.native_context_witness FormalSpecAgent.CSubset.NativeContext Approved.environment
  constructor
  ·
    intro n
    simp
    all_goals
      split
      ·
        decide
      ·
        decide
  ·
    intro n
    simp
    all_goals
      split
      ·
        decide
      ·
        decide

theorem witness_valid : Approved.witness_valid := by
  unfold Approved.witness_valid
  decide

theorem witness_negative : Approved.witness_negative := by
  unfold Approved.witness_negative
  decide

theorem witness_outside : Approved.witness_outside := by
  unfold Approved.witness_outside
  decide

theorem witness_disabled : Approved.witness_disabled := by
  unfold Approved.witness_disabled
  decide

theorem witness_maximum : Approved.witness_maximum := by
  unfold Approved.witness_maximum
  decide

end Proofs
