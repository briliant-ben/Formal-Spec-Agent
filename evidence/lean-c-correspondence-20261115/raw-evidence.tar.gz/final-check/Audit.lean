import Proofs

example : Approved.read_model_equivalent := Proofs.read_model_equivalent
#print axioms Proofs.read_model_equivalent
example : Approved.valid_index_bound := Proofs.valid_index_bound
#print axioms Proofs.valid_index_bound
example : Approved.lowering_correct := Proofs.lowering_correct
#print axioms Proofs.lowering_correct
example : Approved.actual_lowering := Proofs.actual_lowering
#print axioms Proofs.actual_lowering
example : Approved.actual_refines := Proofs.actual_refines
#print axioms Proofs.actual_refines
example : Approved.native_context_witness := Proofs.native_context_witness
#print axioms Proofs.native_context_witness
example : Approved.witness_valid := Proofs.witness_valid
#print axioms Proofs.witness_valid
example : Approved.witness_negative := Proofs.witness_negative
#print axioms Proofs.witness_negative
example : Approved.witness_outside := Proofs.witness_outside
#print axioms Proofs.witness_outside
example : Approved.witness_disabled := Proofs.witness_disabled
#print axioms Proofs.witness_disabled
example : Approved.witness_maximum := Proofs.witness_maximum
#print axioms Proofs.witness_maximum
