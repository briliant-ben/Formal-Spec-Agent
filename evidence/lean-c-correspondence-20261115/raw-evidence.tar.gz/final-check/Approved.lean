import CSubset

namespace Approved

def originalIR : FormalSpecAgent.CSubset.IRExpr .integer :=
  (FormalSpecAgent.CSubset.IRExpr.choose (FormalSpecAgent.CSubset.IRExpr.boolField 2) (FormalSpecAgent.CSubset.IRExpr.read (FormalSpecAgent.CSubset.IRExpr.bytesField 0) (FormalSpecAgent.CSubset.IRExpr.intField 1)) (FormalSpecAgent.CSubset.IRExpr.integer (0)))

def actualC : FormalSpecAgent.CSubset.CExpr .integer :=
  (FormalSpecAgent.CSubset.CExpr.conditional (FormalSpecAgent.CSubset.CExpr.boolSlot 2) (FormalSpecAgent.CSubset.CExpr.callRead (FormalSpecAgent.CSubset.CExpr.bytesSlot 0) (FormalSpecAgent.CSubset.CExpr.intSlot 1)) (FormalSpecAgent.CSubset.CExpr.integer (0)))

def environment (f0 : FormalSpecAgent.Bytes) (f1 : Int) (f2 : Bool) : FormalSpecAgent.CSubset.Context :=
  { integers := fun n => if n = 1 then f1 else 0, booleans := fun n => if n = 2 then f2 else false, buffers := fun n => if n = 0 then f0 else [] }

def read_model_equivalent : Prop :=
  ∀ (xs : FormalSpecAgent.Bytes) (i : Int), FormalSpecAgent.CSubset.cRead xs i = FormalSpecAgent.byteAt xs i

def valid_index_bound : Prop :=
  ∀ (len : Nat) (i : Int), 0 <= i → i < Int.ofNat len → i.toNat < len

def lowering_correct : Prop :=
  ∀ (k : FormalSpecAgent.CSubset.Kind) (e : FormalSpecAgent.CSubset.IRExpr k) (ctx : FormalSpecAgent.CSubset.Context), FormalSpecAgent.CSubset.evalC (FormalSpecAgent.CSubset.lower e) ctx = FormalSpecAgent.CSubset.evalIR e ctx

def actual_lowering : Prop :=
  actualC = FormalSpecAgent.CSubset.lower originalIR

def actual_refines : Prop :=
  ∀ (ctx : FormalSpecAgent.CSubset.Context), FormalSpecAgent.CSubset.NativeContext ctx → FormalSpecAgent.CSubset.evalC actualC ctx = FormalSpecAgent.CSubset.evalIR originalIR ctx

def native_context_witness : Prop :=
  FormalSpecAgent.CSubset.NativeContext (environment ([⟨65, by decide⟩, ⟨128, by decide⟩]) ((0)) (true))

def witness_valid : Prop :=
  FormalSpecAgent.CSubset.evalC actualC (environment ([⟨65, by decide⟩, ⟨128, by decide⟩]) ((0)) (true)) = (65)

def witness_negative : Prop :=
  FormalSpecAgent.CSubset.evalC actualC (environment ([⟨65, by decide⟩]) ((-1)) (true)) = (0)

def witness_outside : Prop :=
  FormalSpecAgent.CSubset.evalC actualC (environment ([⟨65, by decide⟩]) ((3)) (true)) = (0)

def witness_disabled : Prop :=
  FormalSpecAgent.CSubset.evalC actualC (environment ([⟨65, by decide⟩]) ((0)) (false)) = (0)

def witness_maximum : Prop :=
  FormalSpecAgent.CSubset.evalC actualC (environment ([⟨255, by decide⟩]) ((0)) (true)) = (255)

end Approved
