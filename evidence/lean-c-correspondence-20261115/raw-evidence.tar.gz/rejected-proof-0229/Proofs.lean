import Approved

namespace Proofs

theorem read_model_equivalent : Approved.read_model_equivalent := by
  unfold FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  intro xs i
  split
  ·
    intro hneg
    simp
    omega
  ·
    intro hnonneg
    split
    ·
      intro hout
      have hget := List.getD_eq_getElem?_getD xs i.toNat 0
      have hnone := List.getElem?_eq_none (xs) i.toNat
      simp_all
    ·
      intro hin
      have hget := List.getD_eq_getElem?_getD xs i.toNat 0
      simp_all
      omega

theorem valid_index_bound : Approved.valid_index_bound := by
  intro len i
  intro hge hlt
  omega

theorem lowering_correct : Approved.lowering_correct := by
  intro k e ctx
  induction e
  all_goals
    unfold FormalSpecAgent.CSubset.lower FormalSpecAgent.CSubset.evalC FormalSpecAgent.CSubset.evalIR Proofs.read_model_equivalent
    simp_all

theorem actual_lowering : Approved.actual_lowering := by
  unfold Approved.actualC Approved.originalIR FormalSpecAgent.CSubset.lower
  rfl

theorem actual_refines : Approved.actual_refines := by
  intro ctx hctx
  have hlower := Proofs.lowering_correct (FormalSpecAgent.CSubset.Kind.integer) (Approved.originalIR) ctx
  unfold Approved.actualC Approved.originalIR FormalSpecAgent.CSubset.lower
  apply Eq.trans
  apply Eq.symm
  exact Proofs.actual_lowering
  exact hlower

theorem witness_valid : Approved.witness_valid := by
  unfold Approved.witness_valid Approved.actualC Approved.originalIR Approved.environment FormalSpecAgent.CSubset.evalC FormalSpecAgent.CSubset.evalIR FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  decide

theorem witness_negative : Approved.witness_negative := by
  unfold Approved.witness_negative Approved.actualC Approved.originalIR Approved.environment FormalSpecAgent.CSubset.evalC FormalSpecAgent.CSubset.evalIR FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  decide

theorem witness_outside : Approved.witness_outside := by
  unfold Approved.witness_outside Approved.actualC Approved.originalIR Approved.environment FormalSpecAgent.CSubset.evalC FormalSpecAgent.CSubset.evalIR FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  decide

theorem witness_disabled : Approved.witness_disabled := by
  unfold Approved.witness_disabled Approved.actualC Approved.originalIR Approved.environment FormalSpecAgent.CSubset.evalC FormalSpecAgent.CSubset.evalIR FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  decide

theorem witness_maximum : Approved.witness_maximum := by
  unfold Approved.witness_maximum Approved.actualC Approved.originalIR Approved.environment FormalSpecAgent.CSubset.evalC FormalSpecAgent.CSubset.evalIR FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  decide

end Proofs
