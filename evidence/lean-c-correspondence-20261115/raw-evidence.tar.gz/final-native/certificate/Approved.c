// Lean compiler output
// Module: Approved
// Imports: public import Init public meta import Init public import CSubset
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
static const lean_ctor_object l_Approved_originalIR___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_Approved_originalIR___closed__0 = (const lean_object*)&l_Approved_originalIR___closed__0_value;
static const lean_ctor_object l_Approved_originalIR___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 4}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_Approved_originalIR___closed__1 = (const lean_object*)&l_Approved_originalIR___closed__1_value;
static const lean_ctor_object l_Approved_originalIR___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_Approved_originalIR___closed__2 = (const lean_object*)&l_Approved_originalIR___closed__2_value;
static const lean_ctor_object l_Approved_originalIR___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_Approved_originalIR___closed__1_value),((lean_object*)&l_Approved_originalIR___closed__2_value)}};
static const lean_object* l_Approved_originalIR___closed__3 = (const lean_object*)&l_Approved_originalIR___closed__3_value;
static lean_once_cell_t l_Approved_originalIR___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_Approved_originalIR___closed__4;
static lean_once_cell_t l_Approved_originalIR___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_Approved_originalIR___closed__5;
static lean_once_cell_t l_Approved_originalIR___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_Approved_originalIR___closed__6;
LEAN_EXPORT lean_object* l_Approved_originalIR;
static const lean_ctor_object l_Approved_actualC___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))}};
static const lean_object* l_Approved_actualC___closed__0 = (const lean_object*)&l_Approved_actualC___closed__0_value;
static const lean_ctor_object l_Approved_actualC___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 4}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_Approved_actualC___closed__1 = (const lean_object*)&l_Approved_actualC___closed__1_value;
static const lean_ctor_object l_Approved_actualC___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_Approved_actualC___closed__2 = (const lean_object*)&l_Approved_actualC___closed__2_value;
static const lean_ctor_object l_Approved_actualC___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&l_Approved_actualC___closed__1_value),((lean_object*)&l_Approved_actualC___closed__2_value)}};
static const lean_object* l_Approved_actualC___closed__3 = (const lean_object*)&l_Approved_actualC___closed__3_value;
static lean_once_cell_t l_Approved_actualC___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_Approved_actualC___closed__4;
static lean_once_cell_t l_Approved_actualC___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_Approved_actualC___closed__5;
LEAN_EXPORT lean_object* l_Approved_actualC;
LEAN_EXPORT lean_object* l_Approved_environment___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Approved_environment___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_Approved_environment___lam__1(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_Approved_environment___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Approved_environment___lam__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Approved_environment___lam__2___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Approved_environment(lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* l_Approved_environment___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* _init_l_Approved_originalIR___closed__4(void){
_start:
{
lean_object* v___x_10_; lean_object* v___x_11_; 
v___x_10_ = lean_unsigned_to_nat(0u);
v___x_11_ = lean_nat_to_int(v___x_10_);
return v___x_11_;
}
}
static lean_object* _init_l_Approved_originalIR___closed__5(void){
_start:
{
lean_object* v___x_12_; lean_object* v___x_13_; 
v___x_12_ = lean_obj_once(&l_Approved_originalIR___closed__4, &l_Approved_originalIR___closed__4_once, _init_l_Approved_originalIR___closed__4);
v___x_13_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_13_, 0, v___x_12_);
return v___x_13_;
}
}
static lean_object* _init_l_Approved_originalIR___closed__6(void){
_start:
{
lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; uint8_t v___x_17_; lean_object* v___x_18_; 
v___x_14_ = lean_obj_once(&l_Approved_originalIR___closed__5, &l_Approved_originalIR___closed__5_once, _init_l_Approved_originalIR___closed__5);
v___x_15_ = ((lean_object*)(l_Approved_originalIR___closed__3));
v___x_16_ = ((lean_object*)(l_Approved_originalIR___closed__0));
v___x_17_ = 0;
v___x_18_ = lean_alloc_ctor(6, 3, 1);
lean_ctor_set(v___x_18_, 0, v___x_16_);
lean_ctor_set(v___x_18_, 1, v___x_15_);
lean_ctor_set(v___x_18_, 2, v___x_14_);
lean_ctor_set_uint8(v___x_18_, sizeof(void*)*3, v___x_17_);
return v___x_18_;
}
}
static lean_object* _init_l_Approved_originalIR(void){
_start:
{
lean_object* v___x_19_; 
v___x_19_ = lean_obj_once(&l_Approved_originalIR___closed__6, &l_Approved_originalIR___closed__6_once, _init_l_Approved_originalIR___closed__6);
return v___x_19_;
}
}
static lean_object* _init_l_Approved_actualC___closed__4(void){
_start:
{
lean_object* v___x_29_; lean_object* v___x_30_; 
v___x_29_ = lean_obj_once(&l_Approved_originalIR___closed__4, &l_Approved_originalIR___closed__4_once, _init_l_Approved_originalIR___closed__4);
v___x_30_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_30_, 0, v___x_29_);
return v___x_30_;
}
}
static lean_object* _init_l_Approved_actualC___closed__5(void){
_start:
{
lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; uint8_t v___x_34_; lean_object* v___x_35_; 
v___x_31_ = lean_obj_once(&l_Approved_actualC___closed__4, &l_Approved_actualC___closed__4_once, _init_l_Approved_actualC___closed__4);
v___x_32_ = ((lean_object*)(l_Approved_actualC___closed__3));
v___x_33_ = ((lean_object*)(l_Approved_actualC___closed__0));
v___x_34_ = 0;
v___x_35_ = lean_alloc_ctor(6, 3, 1);
lean_ctor_set(v___x_35_, 0, v___x_33_);
lean_ctor_set(v___x_35_, 1, v___x_32_);
lean_ctor_set(v___x_35_, 2, v___x_31_);
lean_ctor_set_uint8(v___x_35_, sizeof(void*)*3, v___x_34_);
return v___x_35_;
}
}
static lean_object* _init_l_Approved_actualC(void){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = lean_obj_once(&l_Approved_actualC___closed__5, &l_Approved_actualC___closed__5_once, _init_l_Approved_actualC___closed__5);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* l_Approved_environment___lam__0(lean_object* v_f1_37_, lean_object* v_n_38_){
_start:
{
lean_object* v___x_39_; uint8_t v___x_40_; 
v___x_39_ = lean_unsigned_to_nat(1u);
v___x_40_ = lean_nat_dec_eq(v_n_38_, v___x_39_);
if (v___x_40_ == 0)
{
lean_object* v___x_41_; 
v___x_41_ = lean_obj_once(&l_Approved_originalIR___closed__4, &l_Approved_originalIR___closed__4_once, _init_l_Approved_originalIR___closed__4);
return v___x_41_;
}
else
{
lean_inc(v_f1_37_);
return v_f1_37_;
}
}
}
LEAN_EXPORT lean_object* l_Approved_environment___lam__0___boxed(lean_object* v_f1_42_, lean_object* v_n_43_){
_start:
{
lean_object* v_res_44_; 
v_res_44_ = l_Approved_environment___lam__0(v_f1_42_, v_n_43_);
lean_dec(v_n_43_);
lean_dec(v_f1_42_);
return v_res_44_;
}
}
LEAN_EXPORT uint8_t l_Approved_environment___lam__1(uint8_t v_f2_45_, lean_object* v_n_46_){
_start:
{
lean_object* v___x_47_; uint8_t v___x_48_; 
v___x_47_ = lean_unsigned_to_nat(2u);
v___x_48_ = lean_nat_dec_eq(v_n_46_, v___x_47_);
if (v___x_48_ == 0)
{
return v___x_48_;
}
else
{
return v_f2_45_;
}
}
}
LEAN_EXPORT lean_object* l_Approved_environment___lam__1___boxed(lean_object* v_f2_49_, lean_object* v_n_50_){
_start:
{
uint8_t v_f2_boxed_51_; uint8_t v_res_52_; lean_object* v_r_53_; 
v_f2_boxed_51_ = lean_unbox(v_f2_49_);
v_res_52_ = l_Approved_environment___lam__1(v_f2_boxed_51_, v_n_50_);
lean_dec(v_n_50_);
v_r_53_ = lean_box(v_res_52_);
return v_r_53_;
}
}
LEAN_EXPORT lean_object* l_Approved_environment___lam__2(lean_object* v_f0_54_, lean_object* v_n_55_){
_start:
{
lean_object* v___x_56_; uint8_t v___x_57_; 
v___x_56_ = lean_unsigned_to_nat(0u);
v___x_57_ = lean_nat_dec_eq(v_n_55_, v___x_56_);
if (v___x_57_ == 0)
{
lean_object* v___x_58_; 
v___x_58_ = lean_box(0);
return v___x_58_;
}
else
{
lean_inc(v_f0_54_);
return v_f0_54_;
}
}
}
LEAN_EXPORT lean_object* l_Approved_environment___lam__2___boxed(lean_object* v_f0_59_, lean_object* v_n_60_){
_start:
{
lean_object* v_res_61_; 
v_res_61_ = l_Approved_environment___lam__2(v_f0_59_, v_n_60_);
lean_dec(v_n_60_);
lean_dec(v_f0_59_);
return v_res_61_;
}
}
LEAN_EXPORT lean_object* l_Approved_environment(lean_object* v_f0_62_, lean_object* v_f1_63_, uint8_t v_f2_64_){
_start:
{
lean_object* v___f_65_; lean_object* v___x_66_; lean_object* v___f_67_; lean_object* v___f_68_; lean_object* v___x_69_; 
v___f_65_ = lean_alloc_closure((void*)(l_Approved_environment___lam__0___boxed), 2, 1);
lean_closure_set(v___f_65_, 0, v_f1_63_);
v___x_66_ = lean_box(v_f2_64_);
v___f_67_ = lean_alloc_closure((void*)(l_Approved_environment___lam__1___boxed), 2, 1);
lean_closure_set(v___f_67_, 0, v___x_66_);
v___f_68_ = lean_alloc_closure((void*)(l_Approved_environment___lam__2___boxed), 2, 1);
lean_closure_set(v___f_68_, 0, v_f0_62_);
v___x_69_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_69_, 0, v___f_65_);
lean_ctor_set(v___x_69_, 1, v___f_67_);
lean_ctor_set(v___x_69_, 2, v___f_68_);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* l_Approved_environment___boxed(lean_object* v_f0_70_, lean_object* v_f1_71_, lean_object* v_f2_72_){
_start:
{
uint8_t v_f2_boxed_73_; lean_object* v_res_74_; 
v_f2_boxed_73_ = lean_unbox(v_f2_72_);
v_res_74_ = l_Approved_environment(v_f0_70_, v_f1_71_, v_f2_boxed_73_);
return v_res_74_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_CSubset(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Approved(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_CSubset(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Approved_originalIR = _init_l_Approved_originalIR();
lean_mark_persistent(l_Approved_originalIR);
l_Approved_actualC = _init_l_Approved_actualC();
lean_mark_persistent(l_Approved_actualC);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
