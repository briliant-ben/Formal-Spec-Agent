// Lean compiler output
// Module: CSubset
// Imports: public import Init public meta import Init public import Foundation
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* l_Int_toNat(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* l_List_getD___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_FormalSpecAgent_byteAt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_integer_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_integer_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_integer_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolean_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolean_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolean_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_intField_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_intField_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_intField_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolField_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolField_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolField_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_bytesField_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_bytesField_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_bytesField_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_read_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_read_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_read_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_choose_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_choose_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_choose_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx___redArg(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_integer_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_integer_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_integer_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolean_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolean_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolean_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_intSlot_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_intSlot_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_intSlot_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolSlot_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolSlot_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolSlot_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_bytesSlot_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_bytesSlot_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_bytesSlot_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_callRead_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_callRead_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_callRead_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_conditional_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_conditional_elim(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_conditional_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_FormalSpecAgent_CSubset_cRead___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_CSubset_cRead___closed__0;
static lean_once_cell_t l_FormalSpecAgent_CSubset_cRead___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_FormalSpecAgent_CSubset_cRead___closed__1;
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_cRead(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_cRead___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalIR___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalIR(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalIR___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_lower(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_lower___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalC___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalC(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalC___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorIdx(uint8_t v_x_1_){
_start:
{
switch(v_x_1_)
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
default: 
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorIdx___boxed(lean_object* v_x_5_){
_start:
{
uint8_t v_x_boxed_6_; lean_object* v_res_7_; 
v_x_boxed_6_ = lean_unbox(v_x_5_);
v_res_7_ = l_FormalSpecAgent_CSubset_Kind_ctorIdx(v_x_boxed_6_);
return v_res_7_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim___redArg(lean_object* v_k_8_){
_start:
{
lean_inc(v_k_8_);
return v_k_8_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim___redArg___boxed(lean_object* v_k_9_){
_start:
{
lean_object* v_res_10_; 
v_res_10_ = l_FormalSpecAgent_CSubset_Kind_ctorElim___redArg(v_k_9_);
lean_dec(v_k_9_);
return v_res_10_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim(lean_object* v_motive_11_, lean_object* v_ctorIdx_12_, uint8_t v_t_13_, lean_object* v_h_14_, lean_object* v_k_15_){
_start:
{
lean_inc(v_k_15_);
return v_k_15_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_ctorElim___boxed(lean_object* v_motive_16_, lean_object* v_ctorIdx_17_, lean_object* v_t_18_, lean_object* v_h_19_, lean_object* v_k_20_){
_start:
{
uint8_t v_t_boxed_21_; lean_object* v_res_22_; 
v_t_boxed_21_ = lean_unbox(v_t_18_);
v_res_22_ = l_FormalSpecAgent_CSubset_Kind_ctorElim(v_motive_16_, v_ctorIdx_17_, v_t_boxed_21_, v_h_19_, v_k_20_);
lean_dec(v_k_20_);
lean_dec(v_ctorIdx_17_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim___redArg(lean_object* v_integer_23_){
_start:
{
lean_inc(v_integer_23_);
return v_integer_23_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim___redArg___boxed(lean_object* v_integer_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = l_FormalSpecAgent_CSubset_Kind_integer_elim___redArg(v_integer_24_);
lean_dec(v_integer_24_);
return v_res_25_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim(lean_object* v_motive_26_, uint8_t v_t_27_, lean_object* v_h_28_, lean_object* v_integer_29_){
_start:
{
lean_inc(v_integer_29_);
return v_integer_29_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_integer_elim___boxed(lean_object* v_motive_30_, lean_object* v_t_31_, lean_object* v_h_32_, lean_object* v_integer_33_){
_start:
{
uint8_t v_t_boxed_34_; lean_object* v_res_35_; 
v_t_boxed_34_ = lean_unbox(v_t_31_);
v_res_35_ = l_FormalSpecAgent_CSubset_Kind_integer_elim(v_motive_30_, v_t_boxed_34_, v_h_32_, v_integer_33_);
lean_dec(v_integer_33_);
return v_res_35_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim___redArg(lean_object* v_boolean_36_){
_start:
{
lean_inc(v_boolean_36_);
return v_boolean_36_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim___redArg___boxed(lean_object* v_boolean_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = l_FormalSpecAgent_CSubset_Kind_boolean_elim___redArg(v_boolean_37_);
lean_dec(v_boolean_37_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim(lean_object* v_motive_39_, uint8_t v_t_40_, lean_object* v_h_41_, lean_object* v_boolean_42_){
_start:
{
lean_inc(v_boolean_42_);
return v_boolean_42_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_boolean_elim___boxed(lean_object* v_motive_43_, lean_object* v_t_44_, lean_object* v_h_45_, lean_object* v_boolean_46_){
_start:
{
uint8_t v_t_boxed_47_; lean_object* v_res_48_; 
v_t_boxed_47_ = lean_unbox(v_t_44_);
v_res_48_ = l_FormalSpecAgent_CSubset_Kind_boolean_elim(v_motive_43_, v_t_boxed_47_, v_h_45_, v_boolean_46_);
lean_dec(v_boolean_46_);
return v_res_48_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim___redArg(lean_object* v_bytes_49_){
_start:
{
lean_inc(v_bytes_49_);
return v_bytes_49_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim___redArg___boxed(lean_object* v_bytes_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = l_FormalSpecAgent_CSubset_Kind_bytes_elim___redArg(v_bytes_50_);
lean_dec(v_bytes_50_);
return v_res_51_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim(lean_object* v_motive_52_, uint8_t v_t_53_, lean_object* v_h_54_, lean_object* v_bytes_55_){
_start:
{
lean_inc(v_bytes_55_);
return v_bytes_55_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_Kind_bytes_elim___boxed(lean_object* v_motive_56_, lean_object* v_t_57_, lean_object* v_h_58_, lean_object* v_bytes_59_){
_start:
{
uint8_t v_t_boxed_60_; lean_object* v_res_61_; 
v_t_boxed_60_ = lean_unbox(v_t_57_);
v_res_61_ = l_FormalSpecAgent_CSubset_Kind_bytes_elim(v_motive_56_, v_t_boxed_60_, v_h_58_, v_bytes_59_);
lean_dec(v_bytes_59_);
return v_res_61_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___redArg(lean_object* v_x_62_){
_start:
{
switch(lean_obj_tag(v_x_62_))
{
case 0:
{
lean_object* v___x_63_; 
v___x_63_ = lean_unsigned_to_nat(0u);
return v___x_63_;
}
case 1:
{
lean_object* v___x_64_; 
v___x_64_ = lean_unsigned_to_nat(1u);
return v___x_64_;
}
case 2:
{
lean_object* v___x_65_; 
v___x_65_ = lean_unsigned_to_nat(2u);
return v___x_65_;
}
case 3:
{
lean_object* v___x_66_; 
v___x_66_ = lean_unsigned_to_nat(3u);
return v___x_66_;
}
case 4:
{
lean_object* v___x_67_; 
v___x_67_ = lean_unsigned_to_nat(4u);
return v___x_67_;
}
case 5:
{
lean_object* v___x_68_; 
v___x_68_ = lean_unsigned_to_nat(5u);
return v___x_68_;
}
default: 
{
lean_object* v___x_69_; 
v___x_69_ = lean_unsigned_to_nat(6u);
return v___x_69_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___redArg___boxed(lean_object* v_x_70_){
_start:
{
lean_object* v_res_71_; 
v_res_71_ = l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___redArg(v_x_70_);
lean_dec_ref(v_x_70_);
return v_res_71_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx(uint8_t v_a_72_, lean_object* v_x_73_){
_start:
{
lean_object* v___x_74_; 
v___x_74_ = l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___redArg(v_x_73_);
return v___x_74_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorIdx___boxed(lean_object* v_a_75_, lean_object* v_x_76_){
_start:
{
uint8_t v_a_47__boxed_77_; lean_object* v_res_78_; 
v_a_47__boxed_77_ = lean_unbox(v_a_75_);
v_res_78_ = l_FormalSpecAgent_CSubset_IRExpr_ctorIdx(v_a_47__boxed_77_, v_x_76_);
lean_dec_ref(v_x_76_);
return v_res_78_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(lean_object* v_t_79_, lean_object* v_k_80_){
_start:
{
switch(lean_obj_tag(v_t_79_))
{
case 1:
{
uint8_t v_a_81_; lean_object* v___x_82_; lean_object* v___x_83_; 
v_a_81_ = lean_ctor_get_uint8(v_t_79_, 0);
lean_dec_ref_known(v_t_79_, 0);
v___x_82_ = lean_box(v_a_81_);
v___x_83_ = lean_apply_1(v_k_80_, v___x_82_);
return v___x_83_;
}
case 5:
{
lean_object* v_a_84_; lean_object* v_a_85_; lean_object* v___x_86_; 
v_a_84_ = lean_ctor_get(v_t_79_, 0);
lean_inc_ref(v_a_84_);
v_a_85_ = lean_ctor_get(v_t_79_, 1);
lean_inc_ref(v_a_85_);
lean_dec_ref_known(v_t_79_, 2);
v___x_86_ = lean_apply_2(v_k_80_, v_a_84_, v_a_85_);
return v___x_86_;
}
case 6:
{
uint8_t v_k_87_; lean_object* v_a_88_; lean_object* v_a_89_; lean_object* v_a_90_; lean_object* v___x_91_; lean_object* v___x_92_; 
v_k_87_ = lean_ctor_get_uint8(v_t_79_, sizeof(void*)*3);
v_a_88_ = lean_ctor_get(v_t_79_, 0);
lean_inc_ref(v_a_88_);
v_a_89_ = lean_ctor_get(v_t_79_, 1);
lean_inc_ref(v_a_89_);
v_a_90_ = lean_ctor_get(v_t_79_, 2);
lean_inc_ref(v_a_90_);
lean_dec_ref_known(v_t_79_, 3);
v___x_91_ = lean_box(v_k_87_);
v___x_92_ = lean_apply_4(v_k_80_, v___x_91_, v_a_88_, v_a_89_, v_a_90_);
return v___x_92_;
}
default: 
{
lean_object* v_a_93_; lean_object* v___x_94_; 
v_a_93_ = lean_ctor_get(v_t_79_, 0);
lean_inc(v_a_93_);
lean_dec_ref(v_t_79_);
v___x_94_ = lean_apply_1(v_k_80_, v_a_93_);
return v___x_94_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorElim(lean_object* v_motive_95_, lean_object* v_ctorIdx_96_, uint8_t v_a_97_, lean_object* v_t_98_, lean_object* v_h_99_, lean_object* v_k_100_){
_start:
{
lean_object* v___x_101_; 
v___x_101_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_98_, v_k_100_);
return v___x_101_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_ctorElim___boxed(lean_object* v_motive_102_, lean_object* v_ctorIdx_103_, lean_object* v_a_104_, lean_object* v_t_105_, lean_object* v_h_106_, lean_object* v_k_107_){
_start:
{
uint8_t v_a_62__boxed_108_; lean_object* v_res_109_; 
v_a_62__boxed_108_ = lean_unbox(v_a_104_);
v_res_109_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim(v_motive_102_, v_ctorIdx_103_, v_a_62__boxed_108_, v_t_105_, v_h_106_, v_k_107_);
lean_dec(v_ctorIdx_103_);
return v_res_109_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_integer_elim___redArg(lean_object* v_t_110_, lean_object* v_integer_111_){
_start:
{
lean_object* v___x_112_; 
v___x_112_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_110_, v_integer_111_);
return v___x_112_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_integer_elim(lean_object* v_motive_113_, uint8_t v_a_114_, lean_object* v_t_115_, lean_object* v_h_116_, lean_object* v_integer_117_){
_start:
{
lean_object* v___x_118_; 
v___x_118_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_115_, v_integer_117_);
return v___x_118_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_integer_elim___boxed(lean_object* v_motive_119_, lean_object* v_a_120_, lean_object* v_t_121_, lean_object* v_h_122_, lean_object* v_integer_123_){
_start:
{
uint8_t v_a_12__boxed_124_; lean_object* v_res_125_; 
v_a_12__boxed_124_ = lean_unbox(v_a_120_);
v_res_125_ = l_FormalSpecAgent_CSubset_IRExpr_integer_elim(v_motive_119_, v_a_12__boxed_124_, v_t_121_, v_h_122_, v_integer_123_);
return v_res_125_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolean_elim___redArg(lean_object* v_t_126_, lean_object* v_boolean_127_){
_start:
{
lean_object* v___x_128_; 
v___x_128_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_126_, v_boolean_127_);
return v___x_128_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolean_elim(lean_object* v_motive_129_, uint8_t v_a_130_, lean_object* v_t_131_, lean_object* v_h_132_, lean_object* v_boolean_133_){
_start:
{
lean_object* v___x_134_; 
v___x_134_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_131_, v_boolean_133_);
return v___x_134_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolean_elim___boxed(lean_object* v_motive_135_, lean_object* v_a_136_, lean_object* v_t_137_, lean_object* v_h_138_, lean_object* v_boolean_139_){
_start:
{
uint8_t v_a_12__boxed_140_; lean_object* v_res_141_; 
v_a_12__boxed_140_ = lean_unbox(v_a_136_);
v_res_141_ = l_FormalSpecAgent_CSubset_IRExpr_boolean_elim(v_motive_135_, v_a_12__boxed_140_, v_t_137_, v_h_138_, v_boolean_139_);
return v_res_141_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_intField_elim___redArg(lean_object* v_t_142_, lean_object* v_intField_143_){
_start:
{
lean_object* v___x_144_; 
v___x_144_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_142_, v_intField_143_);
return v___x_144_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_intField_elim(lean_object* v_motive_145_, uint8_t v_a_146_, lean_object* v_t_147_, lean_object* v_h_148_, lean_object* v_intField_149_){
_start:
{
lean_object* v___x_150_; 
v___x_150_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_147_, v_intField_149_);
return v___x_150_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_intField_elim___boxed(lean_object* v_motive_151_, lean_object* v_a_152_, lean_object* v_t_153_, lean_object* v_h_154_, lean_object* v_intField_155_){
_start:
{
uint8_t v_a_12__boxed_156_; lean_object* v_res_157_; 
v_a_12__boxed_156_ = lean_unbox(v_a_152_);
v_res_157_ = l_FormalSpecAgent_CSubset_IRExpr_intField_elim(v_motive_151_, v_a_12__boxed_156_, v_t_153_, v_h_154_, v_intField_155_);
return v_res_157_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolField_elim___redArg(lean_object* v_t_158_, lean_object* v_boolField_159_){
_start:
{
lean_object* v___x_160_; 
v___x_160_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_158_, v_boolField_159_);
return v___x_160_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolField_elim(lean_object* v_motive_161_, uint8_t v_a_162_, lean_object* v_t_163_, lean_object* v_h_164_, lean_object* v_boolField_165_){
_start:
{
lean_object* v___x_166_; 
v___x_166_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_163_, v_boolField_165_);
return v___x_166_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_boolField_elim___boxed(lean_object* v_motive_167_, lean_object* v_a_168_, lean_object* v_t_169_, lean_object* v_h_170_, lean_object* v_boolField_171_){
_start:
{
uint8_t v_a_12__boxed_172_; lean_object* v_res_173_; 
v_a_12__boxed_172_ = lean_unbox(v_a_168_);
v_res_173_ = l_FormalSpecAgent_CSubset_IRExpr_boolField_elim(v_motive_167_, v_a_12__boxed_172_, v_t_169_, v_h_170_, v_boolField_171_);
return v_res_173_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_bytesField_elim___redArg(lean_object* v_t_174_, lean_object* v_bytesField_175_){
_start:
{
lean_object* v___x_176_; 
v___x_176_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_174_, v_bytesField_175_);
return v___x_176_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_bytesField_elim(lean_object* v_motive_177_, uint8_t v_a_178_, lean_object* v_t_179_, lean_object* v_h_180_, lean_object* v_bytesField_181_){
_start:
{
lean_object* v___x_182_; 
v___x_182_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_179_, v_bytesField_181_);
return v___x_182_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_bytesField_elim___boxed(lean_object* v_motive_183_, lean_object* v_a_184_, lean_object* v_t_185_, lean_object* v_h_186_, lean_object* v_bytesField_187_){
_start:
{
uint8_t v_a_12__boxed_188_; lean_object* v_res_189_; 
v_a_12__boxed_188_ = lean_unbox(v_a_184_);
v_res_189_ = l_FormalSpecAgent_CSubset_IRExpr_bytesField_elim(v_motive_183_, v_a_12__boxed_188_, v_t_185_, v_h_186_, v_bytesField_187_);
return v_res_189_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_read_elim___redArg(lean_object* v_t_190_, lean_object* v_read_191_){
_start:
{
lean_object* v___x_192_; 
v___x_192_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_190_, v_read_191_);
return v___x_192_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_read_elim(lean_object* v_motive_193_, uint8_t v_a_194_, lean_object* v_t_195_, lean_object* v_h_196_, lean_object* v_read_197_){
_start:
{
lean_object* v___x_198_; 
v___x_198_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_195_, v_read_197_);
return v___x_198_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_read_elim___boxed(lean_object* v_motive_199_, lean_object* v_a_200_, lean_object* v_t_201_, lean_object* v_h_202_, lean_object* v_read_203_){
_start:
{
uint8_t v_a_12__boxed_204_; lean_object* v_res_205_; 
v_a_12__boxed_204_ = lean_unbox(v_a_200_);
v_res_205_ = l_FormalSpecAgent_CSubset_IRExpr_read_elim(v_motive_199_, v_a_12__boxed_204_, v_t_201_, v_h_202_, v_read_203_);
return v_res_205_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_choose_elim___redArg(lean_object* v_t_206_, lean_object* v_choose_207_){
_start:
{
lean_object* v___x_208_; 
v___x_208_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_206_, v_choose_207_);
return v___x_208_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_choose_elim(lean_object* v_motive_209_, uint8_t v_a_210_, lean_object* v_t_211_, lean_object* v_h_212_, lean_object* v_choose_213_){
_start:
{
lean_object* v___x_214_; 
v___x_214_ = l_FormalSpecAgent_CSubset_IRExpr_ctorElim___redArg(v_t_211_, v_choose_213_);
return v___x_214_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_IRExpr_choose_elim___boxed(lean_object* v_motive_215_, lean_object* v_a_216_, lean_object* v_t_217_, lean_object* v_h_218_, lean_object* v_choose_219_){
_start:
{
uint8_t v_a_12__boxed_220_; lean_object* v_res_221_; 
v_a_12__boxed_220_ = lean_unbox(v_a_216_);
v_res_221_ = l_FormalSpecAgent_CSubset_IRExpr_choose_elim(v_motive_215_, v_a_12__boxed_220_, v_t_217_, v_h_218_, v_choose_219_);
return v_res_221_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx___redArg(lean_object* v_x_222_){
_start:
{
switch(lean_obj_tag(v_x_222_))
{
case 0:
{
lean_object* v___x_223_; 
v___x_223_ = lean_unsigned_to_nat(0u);
return v___x_223_;
}
case 1:
{
lean_object* v___x_224_; 
v___x_224_ = lean_unsigned_to_nat(1u);
return v___x_224_;
}
case 2:
{
lean_object* v___x_225_; 
v___x_225_ = lean_unsigned_to_nat(2u);
return v___x_225_;
}
case 3:
{
lean_object* v___x_226_; 
v___x_226_ = lean_unsigned_to_nat(3u);
return v___x_226_;
}
case 4:
{
lean_object* v___x_227_; 
v___x_227_ = lean_unsigned_to_nat(4u);
return v___x_227_;
}
case 5:
{
lean_object* v___x_228_; 
v___x_228_ = lean_unsigned_to_nat(5u);
return v___x_228_;
}
default: 
{
lean_object* v___x_229_; 
v___x_229_ = lean_unsigned_to_nat(6u);
return v___x_229_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx___redArg___boxed(lean_object* v_x_230_){
_start:
{
lean_object* v_res_231_; 
v_res_231_ = l_FormalSpecAgent_CSubset_CExpr_ctorIdx___redArg(v_x_230_);
lean_dec_ref(v_x_230_);
return v_res_231_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx(uint8_t v_a_232_, lean_object* v_x_233_){
_start:
{
lean_object* v___x_234_; 
v___x_234_ = l_FormalSpecAgent_CSubset_CExpr_ctorIdx___redArg(v_x_233_);
return v___x_234_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorIdx___boxed(lean_object* v_a_235_, lean_object* v_x_236_){
_start:
{
uint8_t v_a_47__boxed_237_; lean_object* v_res_238_; 
v_a_47__boxed_237_ = lean_unbox(v_a_235_);
v_res_238_ = l_FormalSpecAgent_CSubset_CExpr_ctorIdx(v_a_47__boxed_237_, v_x_236_);
lean_dec_ref(v_x_236_);
return v_res_238_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(lean_object* v_t_239_, lean_object* v_k_240_){
_start:
{
switch(lean_obj_tag(v_t_239_))
{
case 1:
{
uint8_t v_a_241_; lean_object* v___x_242_; lean_object* v___x_243_; 
v_a_241_ = lean_ctor_get_uint8(v_t_239_, 0);
lean_dec_ref_known(v_t_239_, 0);
v___x_242_ = lean_box(v_a_241_);
v___x_243_ = lean_apply_1(v_k_240_, v___x_242_);
return v___x_243_;
}
case 5:
{
lean_object* v_a_244_; lean_object* v_a_245_; lean_object* v___x_246_; 
v_a_244_ = lean_ctor_get(v_t_239_, 0);
lean_inc_ref(v_a_244_);
v_a_245_ = lean_ctor_get(v_t_239_, 1);
lean_inc_ref(v_a_245_);
lean_dec_ref_known(v_t_239_, 2);
v___x_246_ = lean_apply_2(v_k_240_, v_a_244_, v_a_245_);
return v___x_246_;
}
case 6:
{
uint8_t v_k_247_; lean_object* v_a_248_; lean_object* v_a_249_; lean_object* v_a_250_; lean_object* v___x_251_; lean_object* v___x_252_; 
v_k_247_ = lean_ctor_get_uint8(v_t_239_, sizeof(void*)*3);
v_a_248_ = lean_ctor_get(v_t_239_, 0);
lean_inc_ref(v_a_248_);
v_a_249_ = lean_ctor_get(v_t_239_, 1);
lean_inc_ref(v_a_249_);
v_a_250_ = lean_ctor_get(v_t_239_, 2);
lean_inc_ref(v_a_250_);
lean_dec_ref_known(v_t_239_, 3);
v___x_251_ = lean_box(v_k_247_);
v___x_252_ = lean_apply_4(v_k_240_, v___x_251_, v_a_248_, v_a_249_, v_a_250_);
return v___x_252_;
}
default: 
{
lean_object* v_a_253_; lean_object* v___x_254_; 
v_a_253_ = lean_ctor_get(v_t_239_, 0);
lean_inc(v_a_253_);
lean_dec_ref(v_t_239_);
v___x_254_ = lean_apply_1(v_k_240_, v_a_253_);
return v___x_254_;
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorElim(lean_object* v_motive_255_, lean_object* v_ctorIdx_256_, uint8_t v_a_257_, lean_object* v_t_258_, lean_object* v_h_259_, lean_object* v_k_260_){
_start:
{
lean_object* v___x_261_; 
v___x_261_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_258_, v_k_260_);
return v___x_261_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_ctorElim___boxed(lean_object* v_motive_262_, lean_object* v_ctorIdx_263_, lean_object* v_a_264_, lean_object* v_t_265_, lean_object* v_h_266_, lean_object* v_k_267_){
_start:
{
uint8_t v_a_62__boxed_268_; lean_object* v_res_269_; 
v_a_62__boxed_268_ = lean_unbox(v_a_264_);
v_res_269_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim(v_motive_262_, v_ctorIdx_263_, v_a_62__boxed_268_, v_t_265_, v_h_266_, v_k_267_);
lean_dec(v_ctorIdx_263_);
return v_res_269_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_integer_elim___redArg(lean_object* v_t_270_, lean_object* v_integer_271_){
_start:
{
lean_object* v___x_272_; 
v___x_272_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_270_, v_integer_271_);
return v___x_272_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_integer_elim(lean_object* v_motive_273_, uint8_t v_a_274_, lean_object* v_t_275_, lean_object* v_h_276_, lean_object* v_integer_277_){
_start:
{
lean_object* v___x_278_; 
v___x_278_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_275_, v_integer_277_);
return v___x_278_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_integer_elim___boxed(lean_object* v_motive_279_, lean_object* v_a_280_, lean_object* v_t_281_, lean_object* v_h_282_, lean_object* v_integer_283_){
_start:
{
uint8_t v_a_12__boxed_284_; lean_object* v_res_285_; 
v_a_12__boxed_284_ = lean_unbox(v_a_280_);
v_res_285_ = l_FormalSpecAgent_CSubset_CExpr_integer_elim(v_motive_279_, v_a_12__boxed_284_, v_t_281_, v_h_282_, v_integer_283_);
return v_res_285_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolean_elim___redArg(lean_object* v_t_286_, lean_object* v_boolean_287_){
_start:
{
lean_object* v___x_288_; 
v___x_288_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_286_, v_boolean_287_);
return v___x_288_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolean_elim(lean_object* v_motive_289_, uint8_t v_a_290_, lean_object* v_t_291_, lean_object* v_h_292_, lean_object* v_boolean_293_){
_start:
{
lean_object* v___x_294_; 
v___x_294_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_291_, v_boolean_293_);
return v___x_294_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolean_elim___boxed(lean_object* v_motive_295_, lean_object* v_a_296_, lean_object* v_t_297_, lean_object* v_h_298_, lean_object* v_boolean_299_){
_start:
{
uint8_t v_a_12__boxed_300_; lean_object* v_res_301_; 
v_a_12__boxed_300_ = lean_unbox(v_a_296_);
v_res_301_ = l_FormalSpecAgent_CSubset_CExpr_boolean_elim(v_motive_295_, v_a_12__boxed_300_, v_t_297_, v_h_298_, v_boolean_299_);
return v_res_301_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_intSlot_elim___redArg(lean_object* v_t_302_, lean_object* v_intSlot_303_){
_start:
{
lean_object* v___x_304_; 
v___x_304_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_302_, v_intSlot_303_);
return v___x_304_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_intSlot_elim(lean_object* v_motive_305_, uint8_t v_a_306_, lean_object* v_t_307_, lean_object* v_h_308_, lean_object* v_intSlot_309_){
_start:
{
lean_object* v___x_310_; 
v___x_310_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_307_, v_intSlot_309_);
return v___x_310_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_intSlot_elim___boxed(lean_object* v_motive_311_, lean_object* v_a_312_, lean_object* v_t_313_, lean_object* v_h_314_, lean_object* v_intSlot_315_){
_start:
{
uint8_t v_a_12__boxed_316_; lean_object* v_res_317_; 
v_a_12__boxed_316_ = lean_unbox(v_a_312_);
v_res_317_ = l_FormalSpecAgent_CSubset_CExpr_intSlot_elim(v_motive_311_, v_a_12__boxed_316_, v_t_313_, v_h_314_, v_intSlot_315_);
return v_res_317_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolSlot_elim___redArg(lean_object* v_t_318_, lean_object* v_boolSlot_319_){
_start:
{
lean_object* v___x_320_; 
v___x_320_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_318_, v_boolSlot_319_);
return v___x_320_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolSlot_elim(lean_object* v_motive_321_, uint8_t v_a_322_, lean_object* v_t_323_, lean_object* v_h_324_, lean_object* v_boolSlot_325_){
_start:
{
lean_object* v___x_326_; 
v___x_326_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_323_, v_boolSlot_325_);
return v___x_326_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_boolSlot_elim___boxed(lean_object* v_motive_327_, lean_object* v_a_328_, lean_object* v_t_329_, lean_object* v_h_330_, lean_object* v_boolSlot_331_){
_start:
{
uint8_t v_a_12__boxed_332_; lean_object* v_res_333_; 
v_a_12__boxed_332_ = lean_unbox(v_a_328_);
v_res_333_ = l_FormalSpecAgent_CSubset_CExpr_boolSlot_elim(v_motive_327_, v_a_12__boxed_332_, v_t_329_, v_h_330_, v_boolSlot_331_);
return v_res_333_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_bytesSlot_elim___redArg(lean_object* v_t_334_, lean_object* v_bytesSlot_335_){
_start:
{
lean_object* v___x_336_; 
v___x_336_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_334_, v_bytesSlot_335_);
return v___x_336_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_bytesSlot_elim(lean_object* v_motive_337_, uint8_t v_a_338_, lean_object* v_t_339_, lean_object* v_h_340_, lean_object* v_bytesSlot_341_){
_start:
{
lean_object* v___x_342_; 
v___x_342_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_339_, v_bytesSlot_341_);
return v___x_342_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_bytesSlot_elim___boxed(lean_object* v_motive_343_, lean_object* v_a_344_, lean_object* v_t_345_, lean_object* v_h_346_, lean_object* v_bytesSlot_347_){
_start:
{
uint8_t v_a_12__boxed_348_; lean_object* v_res_349_; 
v_a_12__boxed_348_ = lean_unbox(v_a_344_);
v_res_349_ = l_FormalSpecAgent_CSubset_CExpr_bytesSlot_elim(v_motive_343_, v_a_12__boxed_348_, v_t_345_, v_h_346_, v_bytesSlot_347_);
return v_res_349_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_callRead_elim___redArg(lean_object* v_t_350_, lean_object* v_callRead_351_){
_start:
{
lean_object* v___x_352_; 
v___x_352_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_350_, v_callRead_351_);
return v___x_352_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_callRead_elim(lean_object* v_motive_353_, uint8_t v_a_354_, lean_object* v_t_355_, lean_object* v_h_356_, lean_object* v_callRead_357_){
_start:
{
lean_object* v___x_358_; 
v___x_358_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_355_, v_callRead_357_);
return v___x_358_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_callRead_elim___boxed(lean_object* v_motive_359_, lean_object* v_a_360_, lean_object* v_t_361_, lean_object* v_h_362_, lean_object* v_callRead_363_){
_start:
{
uint8_t v_a_12__boxed_364_; lean_object* v_res_365_; 
v_a_12__boxed_364_ = lean_unbox(v_a_360_);
v_res_365_ = l_FormalSpecAgent_CSubset_CExpr_callRead_elim(v_motive_359_, v_a_12__boxed_364_, v_t_361_, v_h_362_, v_callRead_363_);
return v_res_365_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_conditional_elim___redArg(lean_object* v_t_366_, lean_object* v_conditional_367_){
_start:
{
lean_object* v___x_368_; 
v___x_368_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_366_, v_conditional_367_);
return v___x_368_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_conditional_elim(lean_object* v_motive_369_, uint8_t v_a_370_, lean_object* v_t_371_, lean_object* v_h_372_, lean_object* v_conditional_373_){
_start:
{
lean_object* v___x_374_; 
v___x_374_ = l_FormalSpecAgent_CSubset_CExpr_ctorElim___redArg(v_t_371_, v_conditional_373_);
return v___x_374_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_CExpr_conditional_elim___boxed(lean_object* v_motive_375_, lean_object* v_a_376_, lean_object* v_t_377_, lean_object* v_h_378_, lean_object* v_conditional_379_){
_start:
{
uint8_t v_a_12__boxed_380_; lean_object* v_res_381_; 
v_a_12__boxed_380_ = lean_unbox(v_a_376_);
v_res_381_ = l_FormalSpecAgent_CSubset_CExpr_conditional_elim(v_motive_375_, v_a_12__boxed_380_, v_t_377_, v_h_378_, v_conditional_379_);
return v_res_381_;
}
}
static lean_object* _init_l_FormalSpecAgent_CSubset_cRead___closed__0(void){
_start:
{
lean_object* v___x_382_; lean_object* v___x_383_; 
v___x_382_ = lean_unsigned_to_nat(0u);
v___x_383_ = lean_nat_to_int(v___x_382_);
return v___x_383_;
}
}
static lean_object* _init_l_FormalSpecAgent_CSubset_cRead___closed__1(void){
_start:
{
lean_object* v___x_384_; lean_object* v___x_385_; lean_object* v___x_386_; 
v___x_384_ = lean_unsigned_to_nat(256u);
v___x_385_ = lean_unsigned_to_nat(0u);
v___x_386_ = lean_nat_mod(v___x_385_, v___x_384_);
return v___x_386_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_cRead(lean_object* v_xs_387_, lean_object* v_i_388_){
_start:
{
lean_object* v___x_389_; uint8_t v___x_390_; 
v___x_389_ = lean_obj_once(&l_FormalSpecAgent_CSubset_cRead___closed__0, &l_FormalSpecAgent_CSubset_cRead___closed__0_once, _init_l_FormalSpecAgent_CSubset_cRead___closed__0);
v___x_390_ = lean_int_dec_lt(v_i_388_, v___x_389_);
if (v___x_390_ == 0)
{
lean_object* v___x_391_; lean_object* v___x_392_; uint8_t v___x_393_; 
v___x_391_ = l_List_lengthTR___redArg(v_xs_387_);
v___x_392_ = l_Int_toNat(v_i_388_);
v___x_393_ = lean_nat_dec_le(v___x_391_, v___x_392_);
lean_dec(v___x_391_);
if (v___x_393_ == 0)
{
lean_object* v___x_394_; lean_object* v___x_395_; lean_object* v___x_396_; 
v___x_394_ = lean_obj_once(&l_FormalSpecAgent_CSubset_cRead___closed__1, &l_FormalSpecAgent_CSubset_cRead___closed__1_once, _init_l_FormalSpecAgent_CSubset_cRead___closed__1);
v___x_395_ = l_List_getD___redArg(v_xs_387_, v___x_392_, v___x_394_);
v___x_396_ = lean_nat_to_int(v___x_395_);
return v___x_396_;
}
else
{
lean_dec(v___x_392_);
return v___x_389_;
}
}
else
{
return v___x_389_;
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_cRead___boxed(lean_object* v_xs_397_, lean_object* v_i_398_){
_start:
{
lean_object* v_res_399_; 
v_res_399_ = l_FormalSpecAgent_CSubset_cRead(v_xs_397_, v_i_398_);
lean_dec(v_i_398_);
lean_dec(v_xs_397_);
return v_res_399_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalIR___redArg(lean_object* v_e_400_, lean_object* v_ctx_401_){
_start:
{
switch(lean_obj_tag(v_e_400_))
{
case 0:
{
lean_object* v_a_402_; 
lean_dec_ref(v_ctx_401_);
v_a_402_ = lean_ctor_get(v_e_400_, 0);
lean_inc(v_a_402_);
lean_dec_ref_known(v_e_400_, 1);
return v_a_402_;
}
case 1:
{
uint8_t v_a_403_; lean_object* v___x_404_; 
lean_dec_ref(v_ctx_401_);
v_a_403_ = lean_ctor_get_uint8(v_e_400_, 0);
lean_dec_ref_known(v_e_400_, 0);
v___x_404_ = lean_box(v_a_403_);
return v___x_404_;
}
case 2:
{
lean_object* v_a_405_; lean_object* v_integers_406_; lean_object* v___x_407_; 
v_a_405_ = lean_ctor_get(v_e_400_, 0);
lean_inc(v_a_405_);
lean_dec_ref_known(v_e_400_, 1);
v_integers_406_ = lean_ctor_get(v_ctx_401_, 0);
lean_inc_ref(v_integers_406_);
lean_dec_ref(v_ctx_401_);
v___x_407_ = lean_apply_1(v_integers_406_, v_a_405_);
return v___x_407_;
}
case 3:
{
lean_object* v_a_408_; lean_object* v_booleans_409_; lean_object* v___x_410_; 
v_a_408_ = lean_ctor_get(v_e_400_, 0);
lean_inc(v_a_408_);
lean_dec_ref_known(v_e_400_, 1);
v_booleans_409_ = lean_ctor_get(v_ctx_401_, 1);
lean_inc_ref(v_booleans_409_);
lean_dec_ref(v_ctx_401_);
v___x_410_ = lean_apply_1(v_booleans_409_, v_a_408_);
return v___x_410_;
}
case 4:
{
lean_object* v_a_411_; lean_object* v_buffers_412_; lean_object* v___x_413_; 
v_a_411_ = lean_ctor_get(v_e_400_, 0);
lean_inc(v_a_411_);
lean_dec_ref_known(v_e_400_, 1);
v_buffers_412_ = lean_ctor_get(v_ctx_401_, 2);
lean_inc_ref(v_buffers_412_);
lean_dec_ref(v_ctx_401_);
v___x_413_ = lean_apply_1(v_buffers_412_, v_a_411_);
return v___x_413_;
}
case 5:
{
lean_object* v_a_414_; lean_object* v_a_415_; lean_object* v___x_416_; lean_object* v___x_417_; lean_object* v___x_418_; 
v_a_414_ = lean_ctor_get(v_e_400_, 0);
lean_inc_ref(v_a_414_);
v_a_415_ = lean_ctor_get(v_e_400_, 1);
lean_inc_ref(v_a_415_);
lean_dec_ref_known(v_e_400_, 2);
lean_inc_ref(v_ctx_401_);
v___x_416_ = l_FormalSpecAgent_CSubset_evalIR___redArg(v_a_414_, v_ctx_401_);
v___x_417_ = l_FormalSpecAgent_CSubset_evalIR___redArg(v_a_415_, v_ctx_401_);
v___x_418_ = l_FormalSpecAgent_byteAt(v___x_416_, v___x_417_);
lean_dec(v___x_417_);
lean_dec(v___x_416_);
return v___x_418_;
}
default: 
{
lean_object* v_a_419_; lean_object* v_a_420_; lean_object* v_a_421_; lean_object* v___x_422_; uint8_t v___x_423_; 
v_a_419_ = lean_ctor_get(v_e_400_, 0);
lean_inc_ref(v_a_419_);
v_a_420_ = lean_ctor_get(v_e_400_, 1);
lean_inc_ref(v_a_420_);
v_a_421_ = lean_ctor_get(v_e_400_, 2);
lean_inc_ref(v_a_421_);
lean_dec_ref_known(v_e_400_, 3);
lean_inc_ref(v_ctx_401_);
v___x_422_ = l_FormalSpecAgent_CSubset_evalIR___redArg(v_a_419_, v_ctx_401_);
v___x_423_ = lean_unbox(v___x_422_);
lean_dec(v___x_422_);
if (v___x_423_ == 0)
{
lean_dec_ref(v_a_420_);
v_e_400_ = v_a_421_;
goto _start;
}
else
{
lean_dec_ref(v_a_421_);
v_e_400_ = v_a_420_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalIR(uint8_t v_k_426_, lean_object* v_e_427_, lean_object* v_ctx_428_){
_start:
{
lean_object* v___x_429_; 
v___x_429_ = l_FormalSpecAgent_CSubset_evalIR___redArg(v_e_427_, v_ctx_428_);
return v___x_429_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalIR___boxed(lean_object* v_k_430_, lean_object* v_e_431_, lean_object* v_ctx_432_){
_start:
{
uint8_t v_k_boxed_433_; lean_object* v_res_434_; 
v_k_boxed_433_ = lean_unbox(v_k_430_);
v_res_434_ = l_FormalSpecAgent_CSubset_evalIR(v_k_boxed_433_, v_e_431_, v_ctx_432_);
return v_res_434_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_lower(uint8_t v_k_435_, lean_object* v_e_436_){
_start:
{
switch(lean_obj_tag(v_e_436_))
{
case 0:
{
lean_object* v_a_437_; lean_object* v___x_439_; uint8_t v_isShared_440_; uint8_t v_isSharedCheck_444_; 
v_a_437_ = lean_ctor_get(v_e_436_, 0);
v_isSharedCheck_444_ = !lean_is_exclusive(v_e_436_);
if (v_isSharedCheck_444_ == 0)
{
v___x_439_ = v_e_436_;
v_isShared_440_ = v_isSharedCheck_444_;
goto v_resetjp_438_;
}
else
{
lean_inc(v_a_437_);
lean_dec(v_e_436_);
v___x_439_ = lean_box(0);
v_isShared_440_ = v_isSharedCheck_444_;
goto v_resetjp_438_;
}
v_resetjp_438_:
{
lean_object* v___x_442_; 
if (v_isShared_440_ == 0)
{
v___x_442_ = v___x_439_;
goto v_reusejp_441_;
}
else
{
lean_object* v_reuseFailAlloc_443_; 
v_reuseFailAlloc_443_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_443_, 0, v_a_437_);
v___x_442_ = v_reuseFailAlloc_443_;
goto v_reusejp_441_;
}
v_reusejp_441_:
{
return v___x_442_;
}
}
}
case 1:
{
uint8_t v_a_445_; lean_object* v___x_447_; uint8_t v_isShared_448_; uint8_t v_isSharedCheck_452_; 
v_a_445_ = lean_ctor_get_uint8(v_e_436_, 0);
v_isSharedCheck_452_ = !lean_is_exclusive(v_e_436_);
if (v_isSharedCheck_452_ == 0)
{
v___x_447_ = v_e_436_;
v_isShared_448_ = v_isSharedCheck_452_;
goto v_resetjp_446_;
}
else
{
lean_dec(v_e_436_);
v___x_447_ = lean_box(0);
v_isShared_448_ = v_isSharedCheck_452_;
goto v_resetjp_446_;
}
v_resetjp_446_:
{
lean_object* v___x_450_; 
if (v_isShared_448_ == 0)
{
v___x_450_ = v___x_447_;
goto v_reusejp_449_;
}
else
{
lean_object* v_reuseFailAlloc_451_; 
v_reuseFailAlloc_451_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v_reuseFailAlloc_451_, 0, v_a_445_);
v___x_450_ = v_reuseFailAlloc_451_;
goto v_reusejp_449_;
}
v_reusejp_449_:
{
return v___x_450_;
}
}
}
case 2:
{
lean_object* v_a_453_; lean_object* v___x_455_; uint8_t v_isShared_456_; uint8_t v_isSharedCheck_460_; 
v_a_453_ = lean_ctor_get(v_e_436_, 0);
v_isSharedCheck_460_ = !lean_is_exclusive(v_e_436_);
if (v_isSharedCheck_460_ == 0)
{
v___x_455_ = v_e_436_;
v_isShared_456_ = v_isSharedCheck_460_;
goto v_resetjp_454_;
}
else
{
lean_inc(v_a_453_);
lean_dec(v_e_436_);
v___x_455_ = lean_box(0);
v_isShared_456_ = v_isSharedCheck_460_;
goto v_resetjp_454_;
}
v_resetjp_454_:
{
lean_object* v___x_458_; 
if (v_isShared_456_ == 0)
{
v___x_458_ = v___x_455_;
goto v_reusejp_457_;
}
else
{
lean_object* v_reuseFailAlloc_459_; 
v_reuseFailAlloc_459_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_459_, 0, v_a_453_);
v___x_458_ = v_reuseFailAlloc_459_;
goto v_reusejp_457_;
}
v_reusejp_457_:
{
return v___x_458_;
}
}
}
case 3:
{
lean_object* v_a_461_; lean_object* v___x_463_; uint8_t v_isShared_464_; uint8_t v_isSharedCheck_468_; 
v_a_461_ = lean_ctor_get(v_e_436_, 0);
v_isSharedCheck_468_ = !lean_is_exclusive(v_e_436_);
if (v_isSharedCheck_468_ == 0)
{
v___x_463_ = v_e_436_;
v_isShared_464_ = v_isSharedCheck_468_;
goto v_resetjp_462_;
}
else
{
lean_inc(v_a_461_);
lean_dec(v_e_436_);
v___x_463_ = lean_box(0);
v_isShared_464_ = v_isSharedCheck_468_;
goto v_resetjp_462_;
}
v_resetjp_462_:
{
lean_object* v___x_466_; 
if (v_isShared_464_ == 0)
{
v___x_466_ = v___x_463_;
goto v_reusejp_465_;
}
else
{
lean_object* v_reuseFailAlloc_467_; 
v_reuseFailAlloc_467_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_467_, 0, v_a_461_);
v___x_466_ = v_reuseFailAlloc_467_;
goto v_reusejp_465_;
}
v_reusejp_465_:
{
return v___x_466_;
}
}
}
case 4:
{
lean_object* v_a_469_; lean_object* v___x_471_; uint8_t v_isShared_472_; uint8_t v_isSharedCheck_476_; 
v_a_469_ = lean_ctor_get(v_e_436_, 0);
v_isSharedCheck_476_ = !lean_is_exclusive(v_e_436_);
if (v_isSharedCheck_476_ == 0)
{
v___x_471_ = v_e_436_;
v_isShared_472_ = v_isSharedCheck_476_;
goto v_resetjp_470_;
}
else
{
lean_inc(v_a_469_);
lean_dec(v_e_436_);
v___x_471_ = lean_box(0);
v_isShared_472_ = v_isSharedCheck_476_;
goto v_resetjp_470_;
}
v_resetjp_470_:
{
lean_object* v___x_474_; 
if (v_isShared_472_ == 0)
{
v___x_474_ = v___x_471_;
goto v_reusejp_473_;
}
else
{
lean_object* v_reuseFailAlloc_475_; 
v_reuseFailAlloc_475_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v_reuseFailAlloc_475_, 0, v_a_469_);
v___x_474_ = v_reuseFailAlloc_475_;
goto v_reusejp_473_;
}
v_reusejp_473_:
{
return v___x_474_;
}
}
}
case 5:
{
lean_object* v_a_477_; lean_object* v_a_478_; lean_object* v___x_480_; uint8_t v_isShared_481_; uint8_t v_isSharedCheck_489_; 
v_a_477_ = lean_ctor_get(v_e_436_, 0);
v_a_478_ = lean_ctor_get(v_e_436_, 1);
v_isSharedCheck_489_ = !lean_is_exclusive(v_e_436_);
if (v_isSharedCheck_489_ == 0)
{
v___x_480_ = v_e_436_;
v_isShared_481_ = v_isSharedCheck_489_;
goto v_resetjp_479_;
}
else
{
lean_inc(v_a_478_);
lean_inc(v_a_477_);
lean_dec(v_e_436_);
v___x_480_ = lean_box(0);
v_isShared_481_ = v_isSharedCheck_489_;
goto v_resetjp_479_;
}
v_resetjp_479_:
{
uint8_t v___x_482_; lean_object* v___x_483_; uint8_t v___x_484_; lean_object* v___x_485_; lean_object* v___x_487_; 
v___x_482_ = 2;
v___x_483_ = l_FormalSpecAgent_CSubset_lower(v___x_482_, v_a_477_);
v___x_484_ = 0;
v___x_485_ = l_FormalSpecAgent_CSubset_lower(v___x_484_, v_a_478_);
if (v_isShared_481_ == 0)
{
lean_ctor_set(v___x_480_, 1, v___x_485_);
lean_ctor_set(v___x_480_, 0, v___x_483_);
v___x_487_ = v___x_480_;
goto v_reusejp_486_;
}
else
{
lean_object* v_reuseFailAlloc_488_; 
v_reuseFailAlloc_488_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_488_, 0, v___x_483_);
lean_ctor_set(v_reuseFailAlloc_488_, 1, v___x_485_);
v___x_487_ = v_reuseFailAlloc_488_;
goto v_reusejp_486_;
}
v_reusejp_486_:
{
return v___x_487_;
}
}
}
default: 
{
lean_object* v_a_490_; lean_object* v_a_491_; lean_object* v_a_492_; lean_object* v___x_494_; uint8_t v_isShared_495_; uint8_t v_isSharedCheck_503_; 
v_a_490_ = lean_ctor_get(v_e_436_, 0);
v_a_491_ = lean_ctor_get(v_e_436_, 1);
v_a_492_ = lean_ctor_get(v_e_436_, 2);
v_isSharedCheck_503_ = !lean_is_exclusive(v_e_436_);
if (v_isSharedCheck_503_ == 0)
{
v___x_494_ = v_e_436_;
v_isShared_495_ = v_isSharedCheck_503_;
goto v_resetjp_493_;
}
else
{
lean_inc(v_a_492_);
lean_inc(v_a_491_);
lean_inc(v_a_490_);
lean_dec(v_e_436_);
v___x_494_ = lean_box(0);
v_isShared_495_ = v_isSharedCheck_503_;
goto v_resetjp_493_;
}
v_resetjp_493_:
{
uint8_t v___x_496_; lean_object* v___x_497_; lean_object* v___x_498_; lean_object* v___x_499_; lean_object* v___x_501_; 
v___x_496_ = 1;
v___x_497_ = l_FormalSpecAgent_CSubset_lower(v___x_496_, v_a_490_);
v___x_498_ = l_FormalSpecAgent_CSubset_lower(v_k_435_, v_a_491_);
v___x_499_ = l_FormalSpecAgent_CSubset_lower(v_k_435_, v_a_492_);
if (v_isShared_495_ == 0)
{
lean_ctor_set(v___x_494_, 2, v___x_499_);
lean_ctor_set(v___x_494_, 1, v___x_498_);
lean_ctor_set(v___x_494_, 0, v___x_497_);
v___x_501_ = v___x_494_;
goto v_reusejp_500_;
}
else
{
lean_object* v_reuseFailAlloc_502_; 
v_reuseFailAlloc_502_ = lean_alloc_ctor(6, 3, 1);
lean_ctor_set(v_reuseFailAlloc_502_, 0, v___x_497_);
lean_ctor_set(v_reuseFailAlloc_502_, 1, v___x_498_);
lean_ctor_set(v_reuseFailAlloc_502_, 2, v___x_499_);
v___x_501_ = v_reuseFailAlloc_502_;
goto v_reusejp_500_;
}
v_reusejp_500_:
{
lean_ctor_set_uint8(v___x_501_, sizeof(void*)*3, v_k_435_);
return v___x_501_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_lower___boxed(lean_object* v_k_504_, lean_object* v_e_505_){
_start:
{
uint8_t v_k_boxed_506_; lean_object* v_res_507_; 
v_k_boxed_506_ = lean_unbox(v_k_504_);
v_res_507_ = l_FormalSpecAgent_CSubset_lower(v_k_boxed_506_, v_e_505_);
return v_res_507_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalC___redArg(lean_object* v_e_508_, lean_object* v_ctx_509_){
_start:
{
switch(lean_obj_tag(v_e_508_))
{
case 0:
{
lean_object* v_a_510_; 
lean_dec_ref(v_ctx_509_);
v_a_510_ = lean_ctor_get(v_e_508_, 0);
lean_inc(v_a_510_);
lean_dec_ref_known(v_e_508_, 1);
return v_a_510_;
}
case 1:
{
uint8_t v_a_511_; lean_object* v___x_512_; 
lean_dec_ref(v_ctx_509_);
v_a_511_ = lean_ctor_get_uint8(v_e_508_, 0);
lean_dec_ref_known(v_e_508_, 0);
v___x_512_ = lean_box(v_a_511_);
return v___x_512_;
}
case 2:
{
lean_object* v_a_513_; lean_object* v_integers_514_; lean_object* v___x_515_; 
v_a_513_ = lean_ctor_get(v_e_508_, 0);
lean_inc(v_a_513_);
lean_dec_ref_known(v_e_508_, 1);
v_integers_514_ = lean_ctor_get(v_ctx_509_, 0);
lean_inc_ref(v_integers_514_);
lean_dec_ref(v_ctx_509_);
v___x_515_ = lean_apply_1(v_integers_514_, v_a_513_);
return v___x_515_;
}
case 3:
{
lean_object* v_a_516_; lean_object* v_booleans_517_; lean_object* v___x_518_; 
v_a_516_ = lean_ctor_get(v_e_508_, 0);
lean_inc(v_a_516_);
lean_dec_ref_known(v_e_508_, 1);
v_booleans_517_ = lean_ctor_get(v_ctx_509_, 1);
lean_inc_ref(v_booleans_517_);
lean_dec_ref(v_ctx_509_);
v___x_518_ = lean_apply_1(v_booleans_517_, v_a_516_);
return v___x_518_;
}
case 4:
{
lean_object* v_a_519_; lean_object* v_buffers_520_; lean_object* v___x_521_; 
v_a_519_ = lean_ctor_get(v_e_508_, 0);
lean_inc(v_a_519_);
lean_dec_ref_known(v_e_508_, 1);
v_buffers_520_ = lean_ctor_get(v_ctx_509_, 2);
lean_inc_ref(v_buffers_520_);
lean_dec_ref(v_ctx_509_);
v___x_521_ = lean_apply_1(v_buffers_520_, v_a_519_);
return v___x_521_;
}
case 5:
{
lean_object* v_a_522_; lean_object* v_a_523_; lean_object* v___x_524_; lean_object* v___x_525_; lean_object* v___x_526_; 
v_a_522_ = lean_ctor_get(v_e_508_, 0);
lean_inc_ref(v_a_522_);
v_a_523_ = lean_ctor_get(v_e_508_, 1);
lean_inc_ref(v_a_523_);
lean_dec_ref_known(v_e_508_, 2);
lean_inc_ref(v_ctx_509_);
v___x_524_ = l_FormalSpecAgent_CSubset_evalC___redArg(v_a_522_, v_ctx_509_);
v___x_525_ = l_FormalSpecAgent_CSubset_evalC___redArg(v_a_523_, v_ctx_509_);
v___x_526_ = l_FormalSpecAgent_CSubset_cRead(v___x_524_, v___x_525_);
lean_dec(v___x_525_);
lean_dec(v___x_524_);
return v___x_526_;
}
default: 
{
lean_object* v_a_527_; lean_object* v_a_528_; lean_object* v_a_529_; lean_object* v___x_530_; uint8_t v___x_531_; 
v_a_527_ = lean_ctor_get(v_e_508_, 0);
lean_inc_ref(v_a_527_);
v_a_528_ = lean_ctor_get(v_e_508_, 1);
lean_inc_ref(v_a_528_);
v_a_529_ = lean_ctor_get(v_e_508_, 2);
lean_inc_ref(v_a_529_);
lean_dec_ref_known(v_e_508_, 3);
lean_inc_ref(v_ctx_509_);
v___x_530_ = l_FormalSpecAgent_CSubset_evalC___redArg(v_a_527_, v_ctx_509_);
v___x_531_ = lean_unbox(v___x_530_);
lean_dec(v___x_530_);
if (v___x_531_ == 0)
{
lean_dec_ref(v_a_528_);
v_e_508_ = v_a_529_;
goto _start;
}
else
{
lean_dec_ref(v_a_529_);
v_e_508_ = v_a_528_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalC(uint8_t v_k_534_, lean_object* v_e_535_, lean_object* v_ctx_536_){
_start:
{
lean_object* v___x_537_; 
v___x_537_ = l_FormalSpecAgent_CSubset_evalC___redArg(v_e_535_, v_ctx_536_);
return v___x_537_;
}
}
LEAN_EXPORT lean_object* l_FormalSpecAgent_CSubset_evalC___boxed(lean_object* v_k_538_, lean_object* v_e_539_, lean_object* v_ctx_540_){
_start:
{
uint8_t v_k_boxed_541_; lean_object* v_res_542_; 
v_k_boxed_541_ = lean_unbox(v_k_538_);
v_res_542_ = l_FormalSpecAgent_CSubset_evalC(v_k_boxed_541_, v_e_539_, v_ctx_540_);
return v_res_542_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Foundation(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_CSubset(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Foundation(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
