import Approved

def main : IO Unit := do
  IO.println (FormalSpecAgent.CSubset.evalIR Approved.originalIR (Approved.environment ([⟨65, by decide⟩, ⟨128, by decide⟩]) ((0)) (true)))
  IO.println (FormalSpecAgent.CSubset.evalIR Approved.originalIR (Approved.environment ([⟨65, by decide⟩]) ((-1)) (true)))
  IO.println (FormalSpecAgent.CSubset.evalIR Approved.originalIR (Approved.environment ([⟨65, by decide⟩]) ((3)) (true)))
  IO.println (FormalSpecAgent.CSubset.evalIR Approved.originalIR (Approved.environment ([⟨65, by decide⟩]) ((0)) (false)))
  IO.println (FormalSpecAgent.CSubset.evalIR Approved.originalIR (Approved.environment ([⟨255, by decide⟩]) ((0)) (true)))
