import Approved

namespace Proofs

theorem read_model_equivalent : Approved.read_model_equivalent := by
  unfold Approved.read_model_equivalent
  intro xs i
  unfold FormalSpecAgent.CSubset.cRead FormalSpecAgent.byteAt
  split
  ·
    simp
  ·
    split
    ·
      have hget := List.getD_eq_getElem?_getD xs i.toNat 0
      have hnone := List.getElem?_eq_none xs i.toNat
      simp_all
    ·
      have hget := List.getD_eq_getElem?_getD xs i.toNat 0
      simp_all

theorem valid_index_bound : Approved.valid_index_bound := by
  unfold Approved.valid_index_bound
  intro len i hn hlt
  exact (Int.toNat_lt hn).mpr hlt

theorem lowering_correct : Approved.lowering_correct := by
  unfold Approved.lowering_correct
  intro k e ctx
  induction e
  all_goals
    simp_all [FormalSpecAgent.CSubset.lower, FormalSpecAgent.CSubset.evalC, FormalSpecAgent.CSubset.evalIR, Proofs.read_model_equivalent]

theorem actual_lowering : Approved.actual_lowering := by
  unfold Approved.actual_lowering
  rfl

theorem actual_refines : Approved.actual_refines := by
  unfold Approved.actual_refines
  intro ctx hctx
  have hlower := Proofs.lowering_correct FormalSpecAgent.CSubset.Kind.integer Approved.originalIR ctx
  simp [Proofs.actual_lowering, Proofs.lowering_correct]

theorem witness_valid : Approved.witness_valid := by
  unfold Approved.witness_valid
  decide

theorem witness_negative : Approved.witness_negative := by
  unfold Approved.witness_negative
  decide

theorem witness_outside : Approved.witness_outside := by
  unfold Approved.witness_outside
  decide

theorem witness_disabled : Approved.witness_disabled := by
  unfold Approved.witness_disabled
  decide

theorem witness_maximum : Approved.witness_maximum := by
  unfold Approved.witness_maximum
  decide

end Proofs
